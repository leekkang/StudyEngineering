
#include "Puzzle.h"

#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"

#include "../Collision/ColliderBox.h"
#include "Player.h"
#include "Character.h"
#include "AlphaObject.h"

#include "../Widget/AlphaImage.h"

CPuzzle::CPuzzle() {
	SetTypeID<CPuzzle>();
}
CPuzzle::~CPuzzle() {
}

void CPuzzle::SetPos(float x, float y) {
	CGameObject::SetPos(x, y);
	mPiece->SetPos(x, y);
}

void CPuzzle::SetObtained(bool obtained) {
	mObtained = obtained;
	mListCollider.front()->SetEnable(!obtained);
}

void CPuzzle::SetPieceOrder(int order) {
	mIndex = order;
	mWidgetEdge->SetPos(60.f + 90.f * order, 40.f);
	mWidgetPiece->SetPos(mWidgetEdge->GetPos());
}

void CPuzzle::SetObjectTexture(const TCHAR* filePrefix, bool immutable, bool whiteness) {
	TCHAR piece[128]{};
	TCHAR edge[128]{};

	lstrcpy(piece, filePrefix);
	lstrcat(piece, TEXT(".bmp"));

	lstrcpy(edge, filePrefix);
	if (whiteness)
		lstrcat(edge, TEXT("EdgeWhite.bmp"));
	else
		lstrcat(edge, TEXT("Edge.bmp"));


	TCHAR	name[128] = {};
	_wsplitpath_s(piece, nullptr, 0, nullptr, 0, name, 128, nullptr, 0);

	char textureName[128] = {};
#ifdef UNICODE
	int	length = WideCharToMultiByte(CP_ACP, 0, name, -1, 0, 0, 0, 0);
	WideCharToMultiByte(CP_ACP, 0, name, -1, textureName, length, 0, 0);
#else
	strcpy_s(textureName, fileName);
#endif // UNICODE

	mPiece->SetTextureWithDIB(textureName, piece);
	mPiece->GetTexture()->InitAlphaBlend();
	mPiece->GetTexture()->SetColorKey(255, 0, 255);
	mPiece->SetSize(mPiece->GetTexture()->GetSize());
	mPiece->SetAlphaValue(255);

	mWidgetPiece->SetTexture(mPiece->GetTexture()); 
	mWidgetPiece->GetTexture()->InitAlphaBlend();
	mWidgetPiece->SetSize(mWidgetPiece->GetTexture()->GetSize());
	mWidgetPiece->SetAlphaValue(155);

	strcat_s(textureName, "Edge");
	// ��������� ��¦�Ÿ��� �ϱ� ���� ������ DIB�� �����Ѵ�.
	SetTextureWithDIB(textureName, edge);
	mImmutable = immutable;
	mTexture->InitModulatedBits();
	SetColorKey(255, 0, 255);

	strcat_s(textureName, "Gray");
	lstrcpy(edge, filePrefix);
	lstrcat(edge, TEXT("EdgeGray.bmp"));

	mWidgetEdge->SetTexture(textureName, edge);
	mWidgetEdge->SetColorKey(255, 0, 255);
	mWidgetEdge->GetTexture()->InitAlphaBlend();
	mWidgetEdge->SetAlphaValue(155);

	// �׵θ� �ؽ��� ����� �°� �ݶ��̴� ����
	mSize = mTexture->GetSize();
	CColliderBox* box = (CColliderBox*)*mListCollider.front();
	box->SetOffset(mSize * 0.5f);
	box->SetExtent(mSize - 4.f);
}


bool CPuzzle::Init() {
	CGameObject::Init();
	//SetSize(54.f, 45.f);
	SetPivot(0.f, 0.f);

	mZOrder = (int)ERender_ZOrder::Player - 1;

	CGameObject::CreateSound({
		{ESound_Group::Effect, "GetPuzzle0", "got_piece_trivial", 1},
		{ESound_Group::Effect, "GetPuzzle1", "got_piece_easiest", 1},
		{ESound_Group::Effect, "GetPuzzle2", "got_piece_easy", 1},
		{ESound_Group::Effect, "GetPuzzle3", "got_piece_medium", 1},
							 });

	mPiece = mScene->CreateObject<CAlphaObject>("PuzzlePiece");
	mPiece->SetZOrder((int)ERender_ZOrder::UI);
	mWidgetEdge = mScene->GetWidgetWindow(0)->CreateWidget<CAlphaImage>("PuzzleWidgetEdge");
	mWidgetPiece = mScene->GetWidgetWindow(0)->CreateWidget<CAlphaImage>("PuzzleWidgetPiece");
	mWidgetPiece->SetEnable(false);
	mWidgetPiece->SetZOrder(1);

	// �浹ü �߰�
	CColliderBox* box = AddCollider<CColliderBox>("Puzzle");
	box->SetCollisionProfile(ECollision_Profile::StaticObj);
	box->SetCollisionBeginFunction<CPuzzle>(this, &CPuzzle::CollisionBegin);
	box->SetCollisionEndFunction<CPuzzle>(this, &CPuzzle::CollisionEnd);

	return true;
}

void CPuzzle::Update(float deltaTime) {
	if (mObtained) {
		if (mAnimationTime <= 0.f) {
			mWidgetPiece->SetEnable(true);
			mPiece->SetEnable(false);
		} else {
			mWidgetPiece->SetEnable(false);
			mAnimationTime -= deltaTime * mTimeScale;
			if (mAnimationTime <= 0.f)
				mAnimationTime = 0.f;

			// ���� ���� ��ǥ ����
			Vector2 diff = mWidgetEdge->GetPos() - mPiecePos;
			float elapsedTime = 1.f - (mAnimationTime * .5f);
			// x��ǥ�� easing�� �־��ش�.
			const Vector2& camPos = GetCameraPos();
			mPiece->SetPos(max(mWidgetEdge->GetPos().x, mPiecePos.x + diff.x * GetEaseInOutQuad(elapsedTime)) + camPos.x,
						   max(mWidgetEdge->GetPos().y, mPiecePos.y + diff.y * elapsedTime) + camPos.y);
			mPiece->SetAlphaValue(255 - (UINT8)(elapsedTime * 100.f));
		}
	} else {
		mWidgetPiece->SetEnable(false);
	}
}


void CPuzzle::Render(HDC hdc, float deltaTime) {
	Vector2 pos = GetWorldToCameraPos(mPos);

	// �׵θ�
	if (mObtained) {
		RenderTexture(hdc);
	} else {
		UINT8 mixValue = 0;
		mMixTime += deltaTime;
		if (mMixTime > 1.f) {
			mixValue = 0;
			mMixTime -= 1.f;
		}
		if (mMixTime <= .5f)
			mixValue = (UINT8)(mMixTime * 255);
		else
			mixValue = (UINT8)((1.f - mMixTime) * 255);

		RenderTextureMixColor(hdc, mTexture, pos, mSize, mixValue, 255, 255, 0);
	}

	RenderCollider(hdc, deltaTime);
}


#pragma warning( push )
#pragma warning( disable : 4805 )
bool CPuzzle::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(float) * 3 + sizeof(Vector2) * 1;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mListCollider.front()->GetEnable();
	bValue = bValue << 1 | mObtained;
	data[offset] = bValue;
	++offset;

	memcpy(data + offset, &mTimeScale, sizeof(float));		offset += sizeof(float);

	// CPuzzle
	memcpy(data + offset, &mAnimationTime, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mMixTime, sizeof(float));		offset += sizeof(float);
	memcpy(data + offset, &mPiecePos, sizeof(Vector2));		offset += sizeof(Vector2);

	return true;
}
bool CPuzzle::Deserialize(const UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mObtained = bValue & 0x01;
	bValue >>= 1;
	bool enable = bValue & 0x01;
	CCollider* col = mListCollider.front();
	col->SetEnable(enable);
	if (!enable)
		col->ClearCollisionList();

	//auto iter = mListCollider.begin();
	//auto iterEnd = mListCollider.end();
	//for (; iter != iterEnd; ++iter) {
	//	(*iter)->SetEnable(enable);
	//	if (!enable)
	//		(*iter)->ClearCollisionList();
	//}
	++offset;

	memcpy(&mTimeScale, data + offset, sizeof(float));		offset += sizeof(float);

	// CPuzzle
	memcpy(&mAnimationTime, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mMixTime, data + offset, sizeof(float));		offset += sizeof(float);
	memcpy(&mPiecePos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	return true;
}
#pragma warning( pop )



void CPuzzle::PlaySoundByLevel() {
	if (mObtainLevel == 0) {
		SoundPlay("GetPuzzle0");
	} else if(mObtainLevel == 1) {
		SoundPlay("GetPuzzle1");
	} else if (mObtainLevel == 2) {
		SoundPlay("GetPuzzle2");
	} else {
		SoundPlay("GetPuzzle3");
	}
}

void CPuzzle::Obtain() {
	mObtained = true;
	mAnimationTime = 2.f;
	mScene->ObtainPuzzle(mIndex);
	mPiecePos = GetWorldToCameraPos(mPos);
	if (mImmutable)
		mPiece->SetDisableMixTexture(true);

	CCollider* box = mListCollider.front();
	box->SetEnable(false);
	box->ClearCollisionList();

	PlaySoundByLevel();
}


void CPuzzle::CollisionBegin(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type == ECollision_Profile::Player) {
		Obtain();
	}
}

void CPuzzle::CollisionEnd(CCollider* src, CCollider* dest) {
}
