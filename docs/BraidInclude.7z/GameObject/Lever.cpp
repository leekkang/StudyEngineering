
#include "Lever.h"

#include "../Input.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"
#include "../Scene/SceneManager.h"

#include "Player.h"
#include "Platform.h"

#include "../GameManager.h"

CLever::CLever() {
	SetTypeID<CLever>();
}
CLever::~CLever() {
}

void CLever::SetInput() {
	CInput::GetInst()->AddBindFunction<CLever>("Up", Input_Type::Down, mScene, this, &CLever::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CLever>("ArrowUp", Input_Type::Down, mScene, this, &CLever::AttachUpKey);
}

void CLever::SetObjectTexture(bool immutable) {
#ifdef UNICODE
	std::vector<std::wstring> path{L"Object/leverLeft.bmp", L"Object/leverRight.bmp"};
	std::vector<std::wstring> widgetPath{L"Widget/leverLeft.bmp", L"Widget/leverRight.bmp"};
#else
	std::vector<std::string> path{"Object/leverLeft.bmp", "Object/leverRight.bmp"};
	std::vector<std::string> widgetPath{"Widget/leverLeft.bmp", "Widget/leverRight.bmp"};
#endif

	if (immutable) {
		SetTextureWithDIB("LeverDIB", path);
		SetImmutableObject();
	} else {
		SetTexture("Lever", path);
	}
	SetColorKeyAll(255, 0, 255);

	mScene->GetResource()->LoadTexture("LeverWidget", widgetPath);
	mWidgetTexture = mScene->GetResource()->FindTexture("LeverWidget");
	mWidgetTexture->SetColorKeyAll(255, 0, 255);
	mWidgetTexture->InitAlphaBlend();
}

bool CLever::Init() {
	CGameObject::Init();
	SetSize(122.f, 76.f);
	SetPivot(0.5f, 1.f);

	CGameObject::CreateSound({
		{ESound_Group::Effect, "LeverOn", "lever_twoway_on", 1},
		{ESound_Group::Effect, "LeverOff", "lever_twoway_off", 1},
		{ESound_Group::Effect, "PlatformLoop1", "platform_loop_a", 1},
		{ESound_Group::Effect, "PlatformLoop2", "platform_loop_b", 1},
		{ESound_Group::Effect, "PlatformStop1", "platform_stop_alpha", 3},
		{ESound_Group::Effect, "PlatformStop2", "platform_stop_beta", 2},
							 });

	mPlayer = mScene->GetPlayer();
	
	SetInput();

	return true;
}

void CLever::Update(float deltaTime) {
	mPlayerTouch = (fabs(mPlayer->GetPos().x - mPos.x) < 35.f &&
					fabs(mPlayer->GetPos().y - mPos.y) < 2.f);
	if (mPlayerTouch) {
		// ���İ� ���
		mAlphaTime += deltaTime;
		mAlphaValue = CalcAlphaTime(mAlphaTime);
		if (mAlphaValue == 255)
			mAlphaTime = 0.f;
	}
}

void CLever::Render(HDC hdc, float deltaTime) {
	Vector2 camPos = mScene->GetCamera()->GetPos();
	Vector2	renderLT = mPos - camPos - mPivot * mSize;

	RenderTexture(hdc, mTexture, renderLT, mSize, 0, 0, mLeverOn ? 1 : 0);
	if (mPlayerTouch && !mScene->CheckRewinding()) {
		renderLT.x = mPlayer->GetPos().x - camPos.x - 54.f;
		renderLT.y = mPlayer->GetPos().y - camPos.y - 84.f - 55.f;

		RenderAlphaTexture(hdc, mWidgetTexture, mAlphaValue, renderLT, {108.f, 55.f}, 0, 0, mLeverOn ? 1 : 0);
	}

	//RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CLever::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(int) * 1 + sizeof(float) * 1;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mLeverOn;
	bValue = bValue << 1 | mPlayerTouch;
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);

	return true;
}
bool CLever::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mPlayerTouch = bValue & 0x01;
	bValue >>= 1;
	mLeverOn = bValue & 0x01;
	bValue >>= 1;
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);

	return true;
}
#pragma warning( pop )



void CLever::ToggleLever() {
	if (mLeverOn) {
		mLeverOn = false;
		mScene->GetResource()->SoundPlay("LeverOn");
	} else {
		mLeverOn = true;
		mScene->GetResource()->SoundPlay("LeverOff");
	}

	if (mPlatform) {
		mPlatform->StartMove();
	}
}


void CLever::AttachUpKey() {
	if (!mPlayerTouch)
		return;
	ToggleLever();
}