
#include "Lever.h"

#include "../Input.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"
#include "../Scene/SceneManager.h"

#include "Player.h"
#include "Platform.h"

#include "../GameManager.h"

CLever::CLever() {
	SetTypeID<CLever>();
}
CLever::~CLever() {
	SAFE_DELETE(mTest)
}

void CLever::SetInput() {
	CInput::GetInst()->AddBindFunction<CLever>("Up", Input_Type::Down, this, &CLever::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CLever>("ArrowUp", Input_Type::Down, this, &CLever::AttachUpKey);
}

bool CLever::Init() {
	CGameObject::Init();
	SetSize(122.f, 76.f);
	SetPivot(0.5f, 1.f);
	mImmutable = true;

#ifdef UNICODE
	std::vector<std::wstring> path{L"Object/leverLeft.bmp", L"Object/leverRight.bmp"};
	std::vector<std::wstring> widgetPath{L"Widget/widgetLeverLeft.bmp", L"Widget/widgetLeverRight.bmp"};
#else
	std::vector<std::string> path{"Object/leverLeft.bmp", "Object/leverRight.bmp"};
	std::vector<std::string> widgetPath{"Widget/widgetLeverLeft.bmp", "Widget/widgetLeverRight.bmp"};
#endif

	SetTexture("Lever", path);
	SetColorKeyAll(255, 0, 255);
	ImageInfo* info = mTexture->GetImageInfo();
	PBITMAP bm = &info->BmpInfo;
	bm->bmBits; 
	mTest = new char[bm->bmWidth * bm->bmHeight *(bm->bmBitsPixel * 0.125f)];
	memcpy(mTest, bm->bmBits, bm->bmWidth * bm->bmHeight * (bm->bmBitsPixel * 0.125f));

	mScene->GetResource()->LoadTexture("LeverWidget", widgetPath);
	mWidgetTexture = mScene->GetResource()->FindTexture("LeverWidget");
	mWidgetTexture->SetColorKeyAll(255, 0, 255);

	CGameObject::CreateSound({
		{ESound_Group::Effect, "LeverOn", "lever_twoway_on", 1},
		{ESound_Group::Effect, "LeverOff", "lever_twoway_off", 1},
		{ESound_Group::Effect, "PlatformLoop1", "platform_loop_a", 1},
		{ESound_Group::Effect, "PlatformLoop2", "platform_loop_b", 1},
		{ESound_Group::Effect, "PlatformStop1", "platform_stop_alpha", 3},
		{ESound_Group::Effect, "PlatformStop2", "platform_stop_beta", 2},
							 });

	mPlayer = mScene->GetPlayer();

	return true;
}

void CLever::Update(float deltaTime) {
	mPlayerTouch = (fabs(mPlayer->GetPos().x - mPos.x) < 35.f &&
					fabs(mPlayer->GetPos().y - mPos.y) < 2.f);
}

void CLever::Render(HDC hdc, float deltaTime) {
	Vector2 camPos = mScene->GetCamera()->GetPos();
	Vector2	renderLT = mPos - camPos - mPivot * mSize;

	//HDC	tempHdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
	//HBITMAP hbmAlpha = CreateCompatibleBitmap(hdc, (int)mSize.x, (int)mSize.y);
	//HBITMAP hbmAlphaOld = (HBITMAP)SelectObject(tempHdc, hbmAlpha);

	//BitBlt(tempHdc, 0, 0, (int)mSize.x, (int)mSize.y, hdc, (int)renderLT.x, (int)renderLT.y, SRCCOPY);
	//TransparentBlt(tempHdc,
	//			   0, 0, (int)mSize.x, (int)mSize.y, mTexture->GetDC(),
	//			   0, 0, (int)mSize.x, (int)mSize.y, mTexture->GetColorKey());
	//BLENDFUNCTION bf;
	//memset(&bf, 0, sizeof BLENDFUNCTION);
	//bf.SourceConstantAlpha = 150;
	//AlphaBlend(hdc, (int)renderLT.x, (int)renderLT.y, (int)mSize.x, (int)mSize.y,
	//		   tempHdc, 0, 0, (int)mSize.x, (int)mSize.y, bf);

	//SelectObject(tempHdc, hbmAlphaOld);
	//DeleteObject(hbmAlpha);
	//DeleteDC(tempHdc);
	ImageInfo* info = mTexture->GetImageInfo();
	PBITMAP bm = &info->BmpInfo;
	int size = bm->bmWidth * bm->bmHeight * (bm->bmBitsPixel * 0.125f);
	unsigned char* t = (unsigned char*)bm->bmBits;
	unsigned char r, g, b;
	for (int i = 0; i < size; ++i) {
		b = t[i];
		g = t[++i];
		r = t[++i];
	}
	TransparentBlt(hdc,
				   (int)renderLT.x, (int)renderLT.y, (int)mSize.x, (int)mSize.y, mTexture->GetDC(0),
				   0, 0, (int)mSize.x, (int)mSize.y, mTexture->GetColorKey(0));
	//RenderTexture(hdc, mTexture, renderLT, mSize, 0, 0, mLeverOn ? 1 : 0);
	//if (mPlayerTouch && !mScene->CheckRewinding()) {
	//	renderLT.x = mPlayer->GetPos().x - 64.f;
	//	renderLT.y = mPlayer->GetPos().y - 84.f - 64.f;
	//	RenderTexture(hdc, mWidgetTexture, renderLT, {128.f, 64.f}, 0, 0, mLeverOn ? 1 : 0);
	//}

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CLever::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(int) * 1 + sizeof(float) * 1;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bvalue = mLeverOn;
	bvalue = bvalue << 1 | mPlayerTouch;
	data[offset] = bvalue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);

	return true;
}
bool CLever::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bvalue = data[offset];
	mPlayerTouch = bvalue & 0x01;
	bvalue >>= 1;
	mLeverOn = bvalue & 0x01;
	bvalue >>= 1;
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);

	return true;
}
#pragma warning( pop )



void CLever::ToggleLever() {
	if (mLeverOn) {
		mLeverOn = false;
		mScene->GetResource()->SoundPlay("LeverOn");
	} else {
		mLeverOn = true;
		mScene->GetResource()->SoundPlay("LeverOff");
	}

	if (mPlatform) {
		mPlatform->StartMove();
	}
}


void CLever::AttachUpKey() {
	if (!mPlayerTouch)
		return;
	ToggleLever();
}


#define COLORREF2RGB(Color) (Color & 0xff00) | ((Color >> 16) & 0xff) \
                                 | ((Color << 16) & 0xff0000)

//-------------------------------------------------------------------------------
// ReplaceColor
//
// Author    : Dimitri Rochette drochette@coldcat.fr
// Specials Thanks to Joe Woodbury for his comments and code corrections
//
// Includes  : Only <windows.h>

//
// hBmp         : Source Bitmap
// cOldColor : Color to replace in hBmp
// cNewColor : Color used for replacement
// hBmpDC    : DC of hBmp ( default NULL ) could be NULL if hBmp is not selected
//
// Retcode   : HBITMAP of the modified bitmap or NULL for errors
//
//-------------------------------------------------------------------------------
HBITMAP CLever::ReplaceColor(HBITMAP hBmp, COLORREF cOldColor, COLORREF cNewColor, HDC hBmpDC) {
	HBITMAP RetBmp = NULL;
	if (hBmp) {
		HDC BufferDC = CreateCompatibleDC(NULL);    // DC for Source Bitmap
		if (BufferDC) {
			HBITMAP hTmpBitmap = (HBITMAP)NULL;
			if (hBmpDC)
				if (hBmp == (HBITMAP)GetCurrentObject(hBmpDC, OBJ_BITMAP)) {
					hTmpBitmap = CreateBitmap(1, 1, 1, 1, NULL);
					SelectObject(hBmpDC, hTmpBitmap);
				}

			HGDIOBJ PreviousBufferObject = SelectObject(BufferDC, hBmp);
			// here BufferDC contains the bitmap

			HDC DirectDC = CreateCompatibleDC(NULL); // DC for working
			if (DirectDC) {
				// Get bitmap size
				BITMAP bm;
				GetObject(hBmp, sizeof(bm), &bm);

				// create a BITMAPINFO with minimal initilisation 
				// for the CreateDIBSection
				BITMAPINFO RGB32BitsBITMAPINFO;
				ZeroMemory(&RGB32BitsBITMAPINFO, sizeof(BITMAPINFO));
				RGB32BitsBITMAPINFO.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
				RGB32BitsBITMAPINFO.bmiHeader.biWidth = bm.bmWidth;
				RGB32BitsBITMAPINFO.bmiHeader.biHeight = bm.bmHeight;
				RGB32BitsBITMAPINFO.bmiHeader.biPlanes = 1;
				RGB32BitsBITMAPINFO.bmiHeader.biBitCount = 32;

				// pointer used for direct Bitmap pixels access
				UINT* ptPixels;

				HBITMAP DirectBitmap = CreateDIBSection(DirectDC,
														(BITMAPINFO*)&RGB32BitsBITMAPINFO,
														DIB_RGB_COLORS,
														(void**)&ptPixels,
														NULL, 0);
				if (DirectBitmap) {
					// here DirectBitmap!=NULL so ptPixels!=NULL no need to test
					HGDIOBJ PreviousObject = SelectObject(DirectDC, DirectBitmap);
					BitBlt(DirectDC, 0, 0,
						   bm.bmWidth, bm.bmHeight,
						   BufferDC, 0, 0, SRCCOPY);

					// here the DirectDC contains the bitmap

				 // Convert COLORREF to RGB (Invert RED and BLUE)
					cOldColor = COLORREF2RGB(cOldColor);
					cNewColor = COLORREF2RGB(cNewColor);

					// After all the inits we can do the job : Replace Color
					for (int i = ((bm.bmWidth * bm.bmHeight) - 1); i >= 0; i--) {
						if (ptPixels[i] == cOldColor) ptPixels[i] = cNewColor;
					}
					// little clean up
					// Don't delete the result of SelectObject because it's 
					// our modified bitmap (DirectBitmap)
					SelectObject(DirectDC, PreviousObject);

					// finish
					RetBmp = DirectBitmap;
				}
				// clean up
				DeleteDC(DirectDC);
			}
			if (hTmpBitmap) {
				SelectObject(hBmpDC, hBmp);
				DeleteObject(hTmpBitmap);
			}
			SelectObject(BufferDC, PreviousBufferObject);
			// BufferDC is now useless
			DeleteDC(BufferDC);
		}
	}
	return RetBmp;
}
