#pragma once

#include "MovableObject.h"

class CPlatform : public CMovableObject {
	friend class CScene;

private:
	CPlatform();
	~CPlatform();
	DISALLOW_COPY_AND_ASSIGN(CPlatform)


private:
	bool mForward = false; // ������ ��� ��->���̸� true, ������ ��� ��->�Ʒ��̸� true

	bool mVertical = false;
	float mMinPos = 0.f;
	float mMaxPos = 0.f;
	float mSpeed = 0.f;

public:
	void SetDirection(bool vertical) {
		mVertical = vertical;
	}
	void SetMinPos(float pos) {
		mMinPos = pos;
	}
	void SetMaxPos(float pos) {
		mMaxPos = pos;
	}
	void SetSpeed(float speed) {
		mSpeed = speed;
	}

	void SetColliderSize(const Vector2& size) {
		SetColliderSize(size.x, size.y);
	}
	void SetColliderSize(float w, float h);

	void SetObjectTexture(const TCHAR* fileName, bool immutable);

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(const UINT8* data);

	void StartMove(bool forward);

private:
	bool CheckMove() {
		return !(mVelocity.x == 0.f && mVelocity.y == 0.f);
	}

public:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);
};

