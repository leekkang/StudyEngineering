#pragma once

#include "MovableObject.h"

class CPlatform : public CMovableObject {
	friend class CScene;

private:
	CPlatform();
	~CPlatform();
	DISALLOW_COPY_AND_ASSIGN(CPlatform)


private:
	bool mForward = false; // ������ ��� ��->���̸� true, ������ ��� ��->�Ʒ��̸� true

	bool mVertical = false;
	float mMinPos = 0.f;
	float mMaxPos = 0.f;
	float mSpeed = 0.f;

public:
	void SetDirection(bool vertical) {
		mVertical = vertical;
	}
	void SetPlatformSize(const Vector2& pos);

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(UINT8* data);


private:
	bool CheckMove() {
		return !(mVelocity.x == 0.f && mVelocity.y == 0.f);
	}

public:
	void StartMove();

public:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);
};

