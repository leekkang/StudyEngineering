
#include "Monster.h"
#include "../Scene/Scene.h"
#include "Bullet.h"
#include "../Scene/Camera.h"
#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderCircle.h"
#include "../Collision/ColliderLine.h"

CMonster::CMonster() {
	SetTypeID<CMonster>();
}

CMonster::CMonster(const CMonster& obj) : 
	CCharacter(obj),
	mDirection{obj.mDirection},
	mFireTime(obj.mFireTime) {
}

CMonster::~CMonster() {
}

bool CMonster::Init() {
	SetPos(0.f, 0.f);
	SetSize(100.f, 100.f);
	SetPivot(0.5f, 0.5f);

	mLookDir = -1;
	mDirection = {-1.f, 0.f}; // ������ �ٶ󺻴�.
	mFireTime = 0.f;

	mDead = false;

	SetTexture("Monster", TEXT("teemo.bmp"));
	//CreateAnimation();
	//AddAnimation("FrameTest");
	
	//CColliderLine* line = AddCollider<CColliderLine>("Center");
	//line->SetLinePoint(30.f, -40.f);
	//line->SetOffset(0.f, -50.f);
	//line->SetCollisionProfile(ECollision_Profile::Default);

	//CColliderCircle* col = AddCollider<CColliderCircle>("MonsterBody");

	//col->SetRadius(50.f);
	//col->SetCollisionProfile(ECollision_Profile::Monster);

	//col->SetCollisionBeginFunction<CMonster>(this, &CMonster::CollisionBegin);
	//col->SetCollisionEndFunction<CMonster>(this, &CMonster::CollisionEnd);

	return true;
}

void CMonster::Update(float deltaTime) {
	if (mDead) {
		SetActive(false);
	}

	CCharacter::Update(deltaTime);
	deltaTime *= mTimeScale;

	//MoveDir(mDirection);
	Vector2 worldRS = mScene->GetCamera()->GetWorldResolution();
	// ����, ������
	Vector2 vertexLT = mPos - mSize * mPivot;
	if (vertexLT.x < 0 || vertexLT.x + mSize.x > worldRS.x) {
		mDirection.x = -mDirection.x;
	}
	// ����, �Ʒ���
	if (vertexLT.y < 0 || vertexLT.y + mSize.y > worldRS.y) {
		mDirection.y = -mDirection.y;
	}
}


void CMonster::PostUpdate(float deltaTime) {
	CCharacter::PostUpdate(deltaTime);

	if (mLookDir == 1) {
		if (mMove.x < 0.f)
			mLookDir = -1;
	} else {
		if (mMove.x > 0.f)
			mLookDir = 1;
	}
}

void CMonster::Render(HDC hdc, float deltaTime) {
	CCharacter::Render(hdc, deltaTime);
}

void CMonster::CollisionBegin(CCollider* src, CCollider* dest) {
	//MessageBox(nullptr, TEXT("�׾��!!"), TEXT("^��^"), MB_OK);
}

void CMonster::CollisionEnd(CCollider* src, CCollider* dest) {
	//MessageBox(nullptr, TEXT("����."), TEXT("^��^"), MB_OK);
}
