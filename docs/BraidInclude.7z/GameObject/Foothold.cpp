
#include "Foothold.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"

#include "../Resource/Texture/Texture.h"

CFoothold::CFoothold() {
	SetTypeID<CFoothold>();
}

CFoothold::~CFoothold() {
}

bool CFoothold::Init() {
	SetPivot(0.f, 0.f);
	mZOrder = (int)ERender_ZOrder::Foothold;

	SetTexture("FootholdBody", TEXT("Foothold/body.bmp"));
	SetColorKeyAll(255, 0, 255);

	std::vector<const TCHAR*> endPath{TEXT("Foothold/endLeft.bmp"), TEXT("Foothold/endRight.bmp")};
	std::vector<const TCHAR*> holderPath{TEXT("Foothold/holderLeft.bmp"), TEXT("Foothold/holderRight.bmp")};

	mScene->GetResource()->LoadTexture("FootholdEnd", endPath);
	mEnd = mScene->GetResource()->FindTexture("FootholdEnd");
	mEnd->SetColorKeyAll(255, 0, 255);
	mEndSize[0].x = 28.f;
	mEndSize[0].y = 31.f;
	mEndSize[1].x = 33.f;
	mEndSize[1].y = 31.f;

	mScene->GetResource()->LoadTexture("FootholdHolder", holderPath);
	mHolder = mScene->GetResource()->FindTexture("FootholdHolder");
	mHolder->SetColorKeyAll(255, 0, 255);
	mHolderSize[0].x = 42.f;
	mHolderSize[0].y = 42.f;
	mHolderSize[1].x = 50.f;
	mHolderSize[1].y = 42.f;

	return true;
}

void CFoothold::Render(HDC hdc, float deltaTime) {
	Vector2	renderLT = GetWorldToCameraPos(mPos);
	if (mLeftEnd) {
		RenderTexture(hdc, mEnd, renderLT, mEndSize[0]);
		renderLT.x += mEndSize[0].x;
	} else {
		RenderTexture(hdc, mHolder, renderLT, mHolderSize[0]);
		renderLT.x += mHolderSize[0].x;
	}
	int num = mLength / 10;
	int remainder = mLength % 10;
	for (int i = 0; i < num; ++i) {
		RenderTexture(hdc, mTexture, renderLT, {175.f, 27.f});
		renderLT.x += 175.f;
	}
	if (remainder > 0)
		RenderTexture(hdc, mTexture, renderLT, {(float)mSizeX[remainder], 27.f});

	renderLT.x += (float)(mSizeX[remainder] - mRightOffset[remainder]);
	if (mRightEnd)
		RenderTexture(hdc, mEnd, renderLT, mEndSize[1], 0, 0, 1);
	else
		RenderTexture(hdc, mHolder, renderLT, mHolderSize[1], 0, 0, 1);
}