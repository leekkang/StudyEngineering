
#include "MovableObject.h"

#include "../Collision/ColliderLine.h"

CMovableObject::CMovableObject() {
	SetTypeID<CMovableObject>();
}

CMovableObject::CMovableObject(const CMovableObject& obj) :
	CGameObject(obj),
	mMove(obj.mMove),
	mPrevPos(obj.mPrevPos),
	mVelocity(obj.mVelocity)
{
}

CMovableObject::~CMovableObject() {
}

bool CMovableObject::Init() {
	return true;
}

void CMovableObject::Reset() {
	mImmutable = false;

	mPhysicsSimulate = false;
	mFloating = true;
	mFallTime = 0.f;
	mFallStartY = 0.f;

	mMove = 0.f;
	mPrevPos = 0.f;
	mVelocity = 0.f;
}

void CMovableObject::Update(float deltaTime) {
	float scaledDeltaTime = deltaTime * mTimeScale;
	if (mPhysicsSimulate) {
		// ���� ����� �����Ѵ�. �߷�(y��)ó��, �ٴ� ����(x��)ó���� ���⼭ �Ѵ�.
		// t�� �� y��
		// y = V * t - 0.5f * G * t * t
		// 0 = -0.5f*G*t^2 + V*t - y
		if (mFloating) {
			mFallTime += scaledDeltaTime;

			// �߷� ó��
			mVelocity.y += mGravity * scaledDeltaTime;
			if (mVelocity.y > MAX_GRAVITY_SPEED)
				mVelocity.y = MAX_GRAVITY_SPEED;
			// �������� ó��
			//if (mVelocity.x != 0.f) {
			//	if (mVelocity.x > 0.f) {
			//		mVelocity.x -= AIR_RESIST * scaledDeltaTime;
			//		if (mVelocity.x < 0.f)
			//			mVelocity.x = 0.f;
			//	} else {
			//		mVelocity.x += AIR_RESIST * scaledDeltaTime;
			//		if (mVelocity.x > 0.f)
			//			mVelocity.x = 0.f;
			//	}
			//}
		} else if (mApplyFriction) {
			// ���� ó��
			if (mVelocity.x != 0.f) {
				if (mVelocity.x > 0.f) {
					mVelocity.x -= FRICTION * scaledDeltaTime;
					if (mVelocity.x < 0.f)
						mVelocity.x = 0.f;
				} else {
					mVelocity.x += FRICTION * scaledDeltaTime;
					if (mVelocity.x > 0.f)
						mVelocity.x = 0.f;
				}
			}
		} else {

		}
	}

	mPos += mVelocity * scaledDeltaTime;
	CGameObject::Update(deltaTime);
}

void CMovableObject::PostUpdate(float deltaTime) {
	CGameObject::PostUpdate(deltaTime);

	mMove = mPos - mPrevPos;
	mPrevPos = mPos;
}

void CMovableObject::Render(HDC hdc, float deltaTime) {
	CGameObject::Render(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CMovableObject::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) * 1 + sizeof(int) * 1 + sizeof(float) * 4 + sizeof(Vector2) * 5;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mListCollider.begin()->Get()->GetEnable();
	bValue = bValue << 1 | mPhysicsSimulate;
	bValue = bValue << 1 | mFloating;
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mSize, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(data + offset, &mGravity, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mFallTime, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mFallStartY, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mMove, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mPrevPos, sizeof(Vector2));	offset += sizeof(Vector2);
	memcpy(data + offset, &mVelocity, sizeof(Vector2));	offset += sizeof(Vector2);

	return true;
}
bool CMovableObject::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mFloating = bValue & 0x01;
	bValue >>= 1;
	mPhysicsSimulate = bValue & 0x01;
	bValue >>= 1;
	bool enable = bValue & 0x01;
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(enable);
		if (!enable)
			(*iter)->ClearCollisionList();
	}
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mSize, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(&mGravity, data + offset, sizeof(float));	offset += sizeof(float);
	memcpy(&mFallTime, data + offset, sizeof(float));	offset += sizeof(float);
	memcpy(&mFallStartY, data + offset, sizeof(float)); offset += sizeof(float);
	memcpy(&mMove, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mPrevPos, data + offset, sizeof(Vector2));	offset += sizeof(Vector2);
	memcpy(&mVelocity, data + offset, sizeof(Vector2)); offset += sizeof(Vector2);

	return true;
}
#pragma warning( pop )



void CMovableObject::Landing(CColliderLine* line) {
	mFloating = false;
	if (line) {
		// ��翡 ���� ���ӵ��� �߰��Ѵ�.
		float sin = line->GetSlopeSin();
		if (sin != 0.f) {
			float v = std::abs(mVelocity.y * sin) * .8f;
			mVelocity.x += (line->IsAscend() ? -v : v);
		}
	}

	// y�� �̵��ӵ��� ���ش�.
	mVelocity.y = 0.f;
}