
#include "MovableObject.h"

#include "../Collision/ColliderLine.h"

CMovableObject::CMovableObject() {
	SetTypeID<CMovableObject>();
}

CMovableObject::CMovableObject(const CMovableObject& obj) :
	CGameObject(obj),
	mMove(obj.mMove),
	mPrevPos(obj.mPrevPos),
	mVelocity(obj.mVelocity)
{
}

CMovableObject::~CMovableObject() {
}

bool CMovableObject::Init() {
	return true;
}

void CMovableObject::Reset() {
	mImmutable = false;

	mPhysicsSimulate = false;
	mFloating = true;
	mFallTime = 0.f;
	mFallStartY = 0.f;

	mMove = 0.f;
	mPrevPos = 0.f;
	mVelocity = 0.f;
}

void CMovableObject::Update(float deltaTime) {
	float dt = deltaTime * mTimeScale;
	if (mPhysicsSimulate) {
		// ���� ����� �����Ѵ�. �߷�(y��)ó��, �ٴ� ����(x��)ó���� ���⼭ �Ѵ�.
		// t�� �� y��
		// y = V * t - 0.5f * G * t * t
		// 0 = -0.5f*G*t^2 + V*t - y
		if (mFloating) {
			mFallTime += dt;

			// �߷� ó��
			mVelocity.y += GRAVITY_ACCEL * dt;
			if (mVelocity.y > MAX_GRAVITY_SPEED)
				mVelocity.y = MAX_GRAVITY_SPEED;
			// �������� ó��
			//if (mVelocity.x != 0.f) {
			//	if (mVelocity.x > 0.f) {
			//		mVelocity.x -= AIR_RESIST * dt;
			//		if (mVelocity.x < 0.f)
			//			mVelocity.x = 0.f;
			//	} else {
			//		mVelocity.x += AIR_RESIST * dt;
			//		if (mVelocity.x > 0.f)
			//			mVelocity.x = 0.f;
			//	}
			//}
		} else {
			// ���� ó��
			if (mVelocity.x != 0.f) {
				if (mVelocity.x > 0.f) {
					mVelocity.x -= FRICTION * dt;
					if (mVelocity.x < 0.f)
						mVelocity.x = 0.f;
				} else {
					mVelocity.x += FRICTION * dt;
					if (mVelocity.x > 0.f)
						mVelocity.x = 0.f;
				}
			}
		}
	}

	mPos += mVelocity * dt;
	mMove = mPos - mPrevPos;

	CGameObject::Update(deltaTime);
}

void CMovableObject::PostUpdate(float deltaTime) {
	CGameObject::PostUpdate(deltaTime);

	mPrevPos = mPos;
}

void CMovableObject::Render(HDC hdc, float deltaTime) {
	CGameObject::Render(hdc, deltaTime);
}

void CMovableObject::Landing(CColliderLine* line) {
	mFloating = false;
	if (line) {
		// ��翡 ���� ���ӵ��� �߰��Ѵ�.
		float sin = line->GetSlopeSin();
		if (sin != 0.f) {
			float v = std::abs(mVelocity.y * sin) * .8f;
			mVelocity.x += (line->IsAscend() ? -v : v);
		}
	}

	// y�� �̵��ӵ��� ���ش�.
	mVelocity.y = 0.f;
}