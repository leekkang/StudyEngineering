
#include "AlphaObject.h"

CAlphaObject::CAlphaObject() {
	SetTypeID<CAlphaObject>();
}

CAlphaObject::CAlphaObject(const CAlphaObject& obj):
	CGameObject(obj),
	mAlphaValue{obj.mAlphaValue}
{
}

CAlphaObject::~CAlphaObject() {
}

void CAlphaObject::SetTexture(int alphaValue, const std::string& name, const TCHAR* fileName) {
	CGameObject::SetTexture(name, fileName);
	mTexture->InitAlphaBlend();
	mAlphaValue = alphaValue;

	mSize = mTexture->GetSize();
}

bool CAlphaObject::Init() {
	return true;
}

void CAlphaObject::Render(HDC hdc, float deltaTime) {
	Vector2	renderLT = GetWorldToCameraPos(mPos) - mPivot * mSize;
	RenderAlphaTexture(hdc, mTexture, mAlphaValue, renderLT, mSize);
	RenderCollider(hdc, deltaTime);
}
