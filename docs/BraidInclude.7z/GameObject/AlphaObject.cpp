
#include "AlphaObject.h"

CAlphaObject::CAlphaObject() {
	SetTypeID<CAlphaObject>();
}

CAlphaObject::CAlphaObject(const CAlphaObject& obj):
	CGameObject(obj),
	mAlphaValue{obj.mAlphaValue}
{
}

CAlphaObject::~CAlphaObject() {
}

void CAlphaObject::SetTexture(int alphaValue, const std::string& name, const TCHAR* fileName) {
	CGameObject::SetTexture(name, fileName);
	mTexture->InitAlphaBlend();
	mAlphaValue = alphaValue;

	mSize = mTexture->GetSize();
}

bool CAlphaObject::Init() {
	return true;
}

void CAlphaObject::Render(HDC hdc, float deltaTime) {
	Vector2	renderLT = GetWorldToCameraPos(mPos) - mPivot * mSize;
	if (mTwinkle) {
		mAlphaTime += deltaTime;
		float halfTime = mCycleTime * .5f;
		if (mAlphaTime > mCycleTime) {
			mAlphaValue = 255;
			mAlphaTime -= mCycleTime;
		}
		if (mAlphaTime <= halfTime)
			mAlphaValue = 255 - (UINT8)(mAlphaTime / mCycleTime * mRange);
		else
			mAlphaValue = 255 - (UINT8)((mCycleTime - mAlphaTime) / mCycleTime * mRange);
	}

	if (mTexture) {
		if (!mTexture->GetEnableAlpha())
			mTexture->InitAlphaBlend();
		RenderAlphaTexture(hdc, mTexture, mAlphaValue, renderLT, mSize);
	} else {
		Rectangle(hdc, (int)renderLT.x, (int)renderLT.y,
				  (int)(renderLT.x + mSize.x), (int)(renderLT.y + mSize.y));
	}

	RenderCollider(hdc, deltaTime);
}


#pragma warning( push )
#pragma warning( disable : 4805 )
bool CAlphaObject::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) * 2 + sizeof(int) * 1 + sizeof(float) * 2 + sizeof(Vector2) * 2;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mEnable;
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mSize, sizeof(Vector2));		offset += sizeof(Vector2);

	// CAlphaObject
	memcpy(data + offset, &mAlphaValue, sizeof(UINT8));		offset += sizeof(UINT8);
	memcpy(data + offset, &mAlphaTime, sizeof(float));		offset += sizeof(float);

	return true;
}
bool CAlphaObject::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mEnable = bValue & 0x01;
	//auto iter = mListCollider.begin();
	//auto iterEnd = mListCollider.end();
	//for (; iter != iterEnd; ++iter) {
	//	(*iter)->SetEnable(bValue & 0x01);
	//}
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mSize, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	// CAlphaObject
	memcpy(&mAlphaValue, data + offset, sizeof(UINT8));	offset += sizeof(UINT8);
	memcpy(&mAlphaTime, data + offset, sizeof(float));	offset += sizeof(float);

	return true;
}
#pragma warning( pop )