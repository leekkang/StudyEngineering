
#include "Character.h"

#include "../Collision/Collider.h"

CCharacter::CCharacter() {
	SetTypeID<CCharacter>();
}

CCharacter::CCharacter(const CCharacter& obj) :
	CMovableObject(obj),
	mDead{obj.mDead},
	mJump{obj.mJump},
	mLookDir{obj.mLookDir}
{
}

CCharacter::~CCharacter() {
}

bool CCharacter::Init() {
	SetPhysicsSimulate(true);
	return true;
}

void CCharacter::Update(float deltaTime) {
	CMovableObject::Update(deltaTime);
}

void CCharacter::PostUpdate(float deltaTime) {
	CMovableObject::PostUpdate(deltaTime);
}

void CCharacter::Render(HDC hdc, float deltaTime) {
	CMovableObject::Render(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CCharacter::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) * 1 + sizeof(int) * 1 + sizeof(float) * 3 + sizeof(Vector2) * 5;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bvalue = mListCollider.begin()->Get()->GetEnable();
	bvalue = bvalue << 1 | mPhysicsSimulate;
	bvalue = bvalue << 1 | mFloating;
	bvalue = bvalue << 1 | mDead;
	bvalue = bvalue << 1 | mJump;
	bvalue = bvalue << 1 | (mLookDir == -1);
	bvalue = bvalue << 1 | (mLookDir == 1);
	data[offset] = bvalue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mSize, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(data + offset, &mFallTime, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mFallStartY, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mMove, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mPrevPos, sizeof(Vector2));	offset += sizeof(Vector2);
	memcpy(data + offset, &mVelocity, sizeof(Vector2));	offset += sizeof(Vector2);

	return true;
}
bool CCharacter::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bvalue = data[offset];
	mLookDir = bvalue & 0x01 ? 1 : 0;
	bvalue >>= 1;
	mLookDir = bvalue & 0x01 ? -1 : mLookDir;
	bvalue >>= 1;
	mJump = bvalue & 0x01;
	bvalue >>= 1;
	mDead = bvalue & 0x01;
	bvalue >>= 1;
	mFloating = bvalue & 0x01;
	bvalue >>= 1;
	mPhysicsSimulate = bvalue & 0x01;
	bvalue >>= 1;
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(bvalue & 0x01);
	}
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mSize, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(&mFallTime, data + offset, sizeof(float));	offset += sizeof(float);
	memcpy(&mFallStartY, data + offset, sizeof(float)); offset += sizeof(float);
	memcpy(&mMove, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mPrevPos, data + offset, sizeof(Vector2));	offset += sizeof(Vector2);
	memcpy(&mVelocity, data + offset, sizeof(Vector2)); offset += sizeof(Vector2);

	return true;
}
#pragma warning( pop )
