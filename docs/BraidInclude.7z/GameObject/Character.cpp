
#include "Character.h"

CCharacter::CCharacter() {
	SetTypeID<CCharacter>();
}

CCharacter::CCharacter(const CCharacter& obj) :
	CMovableObject(obj),
	mDead{obj.mDead},
	mJump{obj.mJump},
	mLookDir{obj.mLookDir}
{
}

CCharacter::~CCharacter() {
}

bool CCharacter::Init() {
	SetPhysicsSimulate(true);
	return true;
}

void CCharacter::Update(float deltaTime) {
	CMovableObject::Update(deltaTime);
}

void CCharacter::PostUpdate(float deltaTime) {
	CMovableObject::PostUpdate(deltaTime);
}

void CCharacter::Render(HDC hdc, float deltaTime) {
	CMovableObject::Render(hdc, deltaTime);
}
