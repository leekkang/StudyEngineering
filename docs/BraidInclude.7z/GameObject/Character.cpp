
#include "Character.h"

#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderLine.h"

CCharacter::CCharacter() {
	SetTypeID<CCharacter>();
}

CCharacter::CCharacter(const CCharacter& obj) :
	CMovableObject(obj),
	mDead{obj.mDead},
	mJump{obj.mJump},
	mLookDir{obj.mLookDir}
{
}

CCharacter::~CCharacter() {
}

bool CCharacter::Init() {
	SetPhysicsSimulate(true);
	mLookDir = 1; // ������ ���� ����.

	return true;
}

void CCharacter::Update(float deltaTime) {
	CMovableObject::Update(deltaTime);

	if (!mFloating && mFloorCollider) {
		// ������ �����̴� ��� �ӵ� ó���� ���ش�.
		CGameObject* floor = mFloorCollider->GetOwner();
		if (dynamic_cast<CMovableObject*>(floor)) {
			float floorSpeed = ((CMovableObject*)floor)->GetVelocity().x;
			mPos.x += floorSpeed * deltaTime;
		}
	}
}

void CCharacter::PostUpdate(float deltaTime) {
	// ĳ���Ͱ� ���� �������� �̵��ߴ�. (���� üũ�� �ݶ��̴�����)
	if (!CheckFootsteping(mFloorCollider)) {
		if (mFloorNextCollider) {
			CCollider* col = mFloorCollider;
			mFloorCollider = mFloorNextCollider;
			mFloorNextCollider = col;
		}
	}
	// ���� �꿩�� �����س��� ���� ������ �Ʒ��� ���� �÷ξ� �ݶ��̴��� �����Ѵ�.
	else if (!mJump && CheckFootsteping(mFloorNextCollider)) {
		Landing(mFloorNextCollider);
		CCollider* col = mFloorNextCollider;
		mFloorNextCollider = mFloorCollider;
		mFloorCollider = col;
	}

	if (!mFloating && mFloorCollider)
		mPos.y = mFloorCollider->GetTopY(mPos.x);

	CMovableObject::PostUpdate(deltaTime);
}

void CCharacter::Render(HDC hdc, float deltaTime) {
	CMovableObject::Render(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CCharacter::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) * 2 + sizeof(int) * 1 + sizeof(float) * 4 + sizeof(Vector2) * 5;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mListCollider.begin()->Get()->GetEnable();
	bValue = bValue << 1 | mPhysicsSimulate;
	bValue = bValue << 1 | mFloating;
	bValue = bValue << 1 | mDead;
	bValue = bValue << 1 | mJump;
	bValue = bValue << 1 | (mLookDir == -1);
	bValue = bValue << 1 | (mLookDir == 1);
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mSize, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(data + offset, &mGravity, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mFallTime, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mFallStartY, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mMove, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mPrevPos, sizeof(Vector2));	offset += sizeof(Vector2);
	memcpy(data + offset, &mVelocity, sizeof(Vector2));	offset += sizeof(Vector2);

	// CCharacter
	memcpy(data + offset, &mCurrentAnimType, sizeof(UINT8));	offset += sizeof(UINT8);
	//memcpy(data + offset, &mFloorCollider, sizeof(char*));	 offset += sizeof(char*);
	//memcpy(data + offset, &mFloorNextCollider, sizeof(char*)); offset += sizeof(char*);

	return true;
}
bool CCharacter::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mLookDir = bValue & 0x01 ? 1 : 0;
	bValue >>= 1;
	mLookDir = bValue & 0x01 ? -1 : mLookDir;
	bValue >>= 1;
	mJump = bValue & 0x01;
	bValue >>= 1;
	mDead = bValue & 0x01;
	bValue >>= 1;
	mFloating = bValue & 0x01;
	bValue >>= 1;
	mPhysicsSimulate = bValue & 0x01;
	bValue >>= 1;
	bool enable = bValue & 0x01;
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(enable);
		if (!enable)
			(*iter)->ClearCollisionList();
	}
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mSize, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(&mGravity, data + offset, sizeof(float));	offset += sizeof(float);
	memcpy(&mFallTime, data + offset, sizeof(float));	offset += sizeof(float);
	memcpy(&mFallStartY, data + offset, sizeof(float)); offset += sizeof(float);
	memcpy(&mMove, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mPrevPos, data + offset, sizeof(Vector2));	offset += sizeof(Vector2);
	memcpy(&mVelocity, data + offset, sizeof(Vector2)); offset += sizeof(Vector2);

	// CCharacter
	memcpy(&mCurrentAnimType, data + offset, sizeof(UINT8));	offset += sizeof(UINT8);
	//memcpy(&mFloorCollider, data + offset, sizeof(char*));	 offset += sizeof(char*);
	//memcpy(&mFloorNextCollider, data + offset, sizeof(char*)); offset += sizeof(char*);

	return true;
}
#pragma warning( pop )



void CCharacter::Dead(bool randomX, bool ignorePlayerVelocity) {
	DeadProcess();
	float velocityX = randomX ? rand() % 100 - 50 : 0.f;
	if (ignorePlayerVelocity) {
		mVelocity.x = velocityX;
		mVelocity.y = 0.f;
	} else {
		mVelocity.x = velocityX + mVelocity.x * 0.5f;
		mVelocity.y = mJump ? mVelocity.y : 0.f;
	}
}

void CCharacter::DeadByCannon(float xV, float yV) {
	DeadProcess();
	mVelocity.x = (mVelocity.x + xV) * 0.5f;
	mVelocity.y = mVelocity.y + yV;
}

void CCharacter::Landing(CCollider* col, bool addSlopeAccel) {
	if (!mFloorCollider)
		mFloorCollider = col;
	else if (CheckFootsteping(col))
		mFloorCollider = col;
	else // ���� �÷ξ� �ݶ��̴��� �ְ�, �߽��� �ݶ��̴� �ۿ� �ִ� ���� ������ �ִ� �����̴�.
		mFloorNextCollider = col;

	// �������� �־��ٸ� ��翡 ���� ���ӵ��� �߰��Ѵ�.
	CColliderLine* floor = nullptr;
	if (addSlopeAccel && mFloorCollider->GetColliderType() == ECollider_Type::Line)
		floor = (CColliderLine*)mFloorCollider;

	mJump = false;
	CMovableObject::Landing(floor);
}

void CCharacter::DeadProcess() {
	mDead = true;
	// �ݶ��̴��� ���ش�
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(false);
		(*iter)->ClearCollisionList();
	}

	// �ӽ÷� ���� ��. ���߿� ������
	mFloorCollider = nullptr;
	mFloorNextCollider = nullptr;
	mFloating = true;
	mJump = false;

	mZOrder = (int)ERender_ZOrder::Dead;
	ChangeAnimation(ECharacter_AnimType::Dead);
}

bool CCharacter::CheckFootsteping(CCollider* col) {
	if (!col)
		return false;

	float leftX, rightX;
	if (col->GetColliderType() == ECollider_Type::Box) {
		leftX = ((CColliderBox*)col)->GetInfo().LT.x;
		rightX = ((CColliderBox*)col)->GetInfo().RB.x;
	} else {
		leftX = ((CColliderLine*)col)->GetInfo().p1.x;
		rightX = ((CColliderLine*)col)->GetInfo().p2.x;
	}

	return leftX < mPos.x && mPos.x <= rightX;
}

bool CCharacter::CheckLandingFoothold() {
	return mFloorCollider &&
		mFloorCollider->GetColliderType() == ECollider_Type::Line &&
		((CColliderLine*)mFloorCollider)->GetSlopeSin() == 0.f;
	//return mFloorCollider && mFloorCollider->GetName() == "Foothold";
}