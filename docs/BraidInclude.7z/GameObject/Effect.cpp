#include "Effect.h"

CEffect::CEffect() {
	SetTypeID<CEffect>();
}

CEffect::CEffect(const CEffect& obj) :
	CGameObject(obj) {
}

CEffect::~CEffect() {
}

bool CEffect::Init() {
	// ������ �ִϸ��̼� ����
	CreateAnimation();

	//SetCurrentAnimationEndFunction(this, &CEffect::AnimationEnd);

	return true;
}

void CEffect::Update(float deltaTime) {
	CGameObject::Update(deltaTime);

	if (mEffectType == EEffect_Type::Duration) {
		mTime += deltaTime;

		if (mTime > mDuration) {
			SetActive(false);
		}
	}
}

void CEffect::PostUpdate(float deltaTime) {
	CGameObject::PostUpdate(deltaTime);
}

void CEffect::Render(HDC hdc, float deltaTime) {
	CGameObject::Render(hdc, deltaTime);
	//Vector2 pos = mPos - mScene->GetCamera()->GetPos();
	//char tmp[30]{};
	//sprintf_s(tmp, "%d", (int)damage);

	//TextOutA(hdc, pos.x, pos.y - 30.f, tmp, strlen(tmp));
}

void CEffect::AnimationEnd() {
	if (mEffectType == EEffect_Type::Once)
		SetActive(false);
}
