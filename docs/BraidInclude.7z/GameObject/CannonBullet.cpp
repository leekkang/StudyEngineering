#include "CannonBullet.h"
#include "../Collision/ColliderBox.h"
#include "../Scene/Scene.h"

CCannonBullet::CCannonBullet() {
	SetTypeID<CCannonBullet>();
}

CCannonBullet::CCannonBullet(const CCannonBullet& obj) :
	CBullet(obj) {
}

CCannonBullet::~CCannonBullet() {
}

bool CCannonBullet::Init() {
	SetPos(0.f, 0.f);
	SetPivot(0.5f, 0.5f);
	mMoveSpeed = 700.f;
	mDistance = 1500.f;
	mDamage = 20.f;

	SetTexture("CannonBullet", TEXT("teemo.bmp"));
	SetSize(40.f, 40.f);

	CColliderBox* box = AddCollider<CColliderBox>("CannonBody");
	box->SetExtent(50.f, 50.f);
	box->SetCollisionProfile(ECollision_Profile::Attack);

	box->SetCollisionBeginFunction<CBullet>(this, &CBullet::CollisionBegin);
	box->SetCollisionEndFunction<CBullet>(this, &CBullet::CollisionEnd);


	return true;
}


//void CCannonBullet::CollisionBegin(CCollider* src, CCollider* dest) {
//	CBullet::CollisionBegin(src, dest);
//}