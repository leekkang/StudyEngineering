#pragma once

#include "GameObject.h"

class CKey : public CGameObject {
	friend class CScene;

private:
	CKey();
	~CKey();
	DISALLOW_COPY_AND_ASSIGN(CKey)

private:
	bool mUsed = false;
	bool mPlayerHave = false;
	bool mLookLeft = false;
	class CCharacter* mOwner = nullptr;

public:
	void SetObjectTexture(bool immutable);
	void SetLookLeft(bool flag) {
		mLookLeft = flag;
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(UINT8* data);

public:
	void UnlockGate(class CColliderBox* box);

public:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);



private:
	const Vector2 RunMotionPos[27]{ // x - 36.f, -(81.f - y)
		{29.f, -36.f}, {28.f, -34.f}, {28.f, -33.f}, {27.f, -31.f}, {25.f, -27.f}, {22.f, -27.f}, {22.f, -26.f}, {18.f, -25.f}, {14.f, -26.f},
		{12.f, -26.f}, {7.f, -27.f}, {-3.f, -29.f}, {-14.f, -38.f}, {-18.f, -41.f}, {-19.f, -42.f}, {-18.f, -40.f}, {-14.f, -40.f}, {-5.f, -33.f},
		{-1.f, -32.f}, {4.f, -29.f}, {12.f, -24.f}, {13.f, -25.f}, {17.f, -26.f}, {21.f, -29.f}, {21.f, -31.f}, {24.f, -32.f}, {27.f, -35.f}
	};
	const Vector2 JumpMotionPos[9]{ // x - 31.f, -(84.f - y)
		{20.f, -37.f}, {20.f, -34.f}, {21.f, -33.f}, {21.f, -29.f},
		{23.f, -23.f}, {21.f, -23.f}, {20.f, -25.f}, {21.f, -27.f}, {20.f, -29.f}
	};
	const Vector2 JumpForwardMotionPos[12]{ // x - 37.f, -(82.f - y)
		{0.f, -28.f}, {-7.f, -35.f}, {-10.f, -36.f}, {-4.f, -33.f}, {-2.f, -32.f}, {0.f, -29.f}, 
		{1.f, -28.f}, {1.f, -28.f}, {1.f, -28.f}, {2.f, -28.f}, {7.f, -28.f}, {14.f, -31.f}
	};
	const Vector2 BoundMotionPos[8]{ // x - 35.f, -(84.f - y)
		{20.f, -33.f}, {20.f, -28.f}, {26.f, -31.f}, {27.f, -35.f},
		{28.f, -37.f}, {27.f, -35.f}, {25.f, -33.f}, {17.f, -32.f}
	};
	const Vector2 BoundForwardMotionPos[9]{ // x - 36.f, -(81.f - y)
		{15.f, -29.f}, {21.f, -32.f}, {27.f, -42.f}, {30.f, -51.f}, 
		{27.f, -45.f}, {28.f, -46.f}, {27.f, -45.f}, {23.f, -34.f}, {17.f, -32.f}
	};
	const Vector2 FallMotionPos[8]{ // x - 39.f, -(84.f - y)
		{17.f, -32.f}, {21.f, -35.f}, {23.f, -37.f}, {24.f, -37.f},
		{25.f, -38.f}, {25.f, -38.f}, {25.f, -38.f}, {25.f, -38.f}
	};
	const Vector2 LadderMotionPos[8]{ // x - 34.f, -(85.f - y)
		{23.f, -62.f}, {25.f, -61.f}, {25.f, -64.f}, {26.f, -70.f},
		{22.f, -75.f}, {20.f, -76.f}, {21.f, -72.f}, {22.f, -67.f}
	};
	const Vector2 LadderAsideMotionPos[8]{ // x - 45.f, -(81.f - y)
		{31.f, -61.f}, {35.f, -59.f}, {34.f, -63.f}, {24.f, -65.f},
		{23.f, -63.f}, {24.f, -62.f}, {24.f, -62.f}, {23.f, -64.f}
	};
};

