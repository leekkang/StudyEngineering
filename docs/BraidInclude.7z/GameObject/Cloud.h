#pragma once

#include "MovableObject.h"

class CCloud : public CMovableObject {
	friend class CScene;

private:
	CCloud();
	~CCloud();
	DISALLOW_COPY_AND_ASSIGN(CCloud)

private:
	bool mLookLeft = false;
	float mRenderLimitPoint = 0.f;	// ������ �Ա� x��ǥ. ������ �κ��� �������� ���ϵ��� �����Ѵ�.

	bool mFade = false;
	float mFadeTime = 0.f;

	class CCharacter* mStandOn = nullptr;

public:
	void SetRenderLimitPoint(float x) {
		mRenderLimitPoint = x;
	}

	void SetDirection(bool left);
	void SetObjectTexture(bool immutable);

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(const UINT8* data);

public:
	void ResetForBullet(const Vector2& velocity);

private:
	void Fadeout();

	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);
};