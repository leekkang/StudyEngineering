#pragma once

#include "GameObject.h"

class CFoothold : public CGameObject {
	friend class CScene;

protected:
	CFoothold();
	virtual ~CFoothold();

private:
	bool mLeftEnd  = true;
	bool mRightEnd = true;
	int mLength		= 0;

	Vector2 mEndSize[2];
	Vector2 mHolderSize[2];
	class CTexture* mEnd  = nullptr;
	class CTexture* mHolder = nullptr;

	const UINT8 mSizeX[10]{175, 17, 36, 52, 70, 88, 105, 124, 140, 158};
	const UINT8 mRightOffset[10]{4, 2, 4, 3, 3, 3, 2, 4, 3, 2};

public:
	void SetLeftEnd(bool left) {
		mLeftEnd = left;
		SetSize();
	}
	void SetRightEnd(bool right) {
		mRightEnd = right;
		SetSize();
	}
	void SetLength(int len) {
		mLength = len;
		SetSize();
	}

public:
	virtual bool Init();
	virtual void Render(HDC hdc, float deltaTime);

private: 
	void SetSize() {
		float x = 0.f;
		int num = mLength / 10;
		int remainder = mLength % 10;
		for (int i = 0; i < num; ++i)
			x += 175.f;
		if (remainder > 0)
			x += (float)mSizeX[remainder];

		if (mLeftEnd) {
			x += mEndSize[0].x;
			mSize.y = 31.f;
		} else {
			x += mHolderSize[0].x;
			mSize.y = 42.f;
		}

		if (mRightEnd) {
			x += mEndSize[1].x - mRightOffset[remainder];
			mSize.y = 31.f;
		} else {
			x += mHolderSize[1].x - mRightOffset[remainder];
			mSize.y = 42.f;
		}

		mSize.x = x;
	}
};