
#include "Cannon.h"

#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"

#include "../Widget/Text.h"
#include "Monstar.h"
#include "Bullet.h"

CCannon::CCannon() {
	SetTypeID<CCannon>();
}
CCannon::~CCannon() {
}

void CCannon::SetObjectTexture(const TCHAR* fileName, const char* textureName, bool immutable) {
	CGameObject::SetObjectTexture(fileName, textureName, immutable);

	mTimer->SetPos(90.f, -mSize.y * .5f );
}

void CCannon::InitBullet() {
	for (int i = 0; i < mBulletCount; ++i) {
		if (mCannonType == ECannon_Type::Monstar) {
			CMonstar* monstar = mScene->CreateObject<CMonstar>("Monstar");
			monstar->SetPatrolArea(0.f, (float)mScene->GetWorldResolution().width);
			monstar->SetEnable(false);
			if (mImmutable)
				monstar->SetImmutableObject();
			mVecBullet.push_back(monstar);
		} else if (mCannonType == ECannon_Type::Bullet) {
			CBullet* bullet = mScene->CreateObject<CBullet>("Bullet");
			bullet->SetVelocity(mBulletVelocity);
			bullet->SetZOrder((int)ERender_ZOrder::Bullet);
			bullet->SetEnable(false);
			if (mImmutable)
				bullet->SetImmutableObject();
			mVecBullet.push_back(bullet);
		} else {

		}
	}
}

bool CCannon::Init() {
	CGameObject::Init();
	SetPivot(0.5f, 0.5f);
	SetZOrder((int)ERender_ZOrder::Foothold);

	CGameObject::CreateSound({
		{ESound_Group::Effect, "FireBullet", "cannon_fire_bullet", 2},
		{ESound_Group::Effect, "FireMonstar", "cannon_fire_monstar", 4},
		{ESound_Group::Effect, "FireCloud", "cannon_fire_cloud", 2},
							 });

	mTimer = CreateWidgetComponent<CText>("Timer");
	mTimer->GetWidget<CText>()->SetText(TEXT("3"));
	mTimer->GetWidget<CText>()->EnableShadow(true);
	mTimer->GetWidget<CText>()->SetTextColor(255, 255, 255);
	mTimer->GetWidget<CText>()->SetShadowOffset(1.f, 1.f);

	return true;
}

void CCannon::Update(float deltaTime) {
	float scaledDeltaTime = deltaTime * mTimeScale;
	auto CountDeltaTime = [&]() {
		mSpawnDeltaTime -= scaledDeltaTime;
		mEnableCount = (mSpawnTime - mSpawnDeltaTime) > .5f;
		if (mSpawnDeltaTime <= 0.f) {
			mSpawning = false;
			mEnableCount = false;
			SpawnBullet();
			mSpawnDeltaTime += mSpawnTime;
			mTimer->SetEnable(false);
		}
	};
	if (mCannonType == ECannon_Type::Monstar) {
		auto CheckSpawning = [&]() -> bool {
			for (int i = 0; i < mBulletCount; ++i) {
				if (!mVecBullet[i]->GetEnable() ||
					((CCharacter*)mVecBullet[i])->CheckDead())
					return true;
			}
			return false;
		};
		if (!mSpawning) {
			mSpawning = CheckSpawning();
		} else {
			CountDeltaTime();
		}
	} else {
		CountDeltaTime();
	}
}

void CCannon::Render(HDC hdc, float deltaTime) {
	if (mEnableCount) {
		int count = (int)mSpawnDeltaTime + 1;
		mTimer->SetEnable(true);
		mTimer->GetWidget<CText>()->SetText(std::to_wstring(count).c_str());
	}

	RenderTexture(hdc);
	//RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CCannon::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(int) * 2 + sizeof(float) * 2;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mSpawning;
	bValue = bValue << 1 | mEnableCount;
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);

	memcpy(data + offset, &mSpawnIndex, sizeof(int));	offset += sizeof(int);
	memcpy(data + offset, &mSpawnDeltaTime, sizeof(float));	offset += sizeof(float);

	return true;
}
bool CCannon::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mEnableCount = bValue & 0x01;
	bValue >>= 1;
	mSpawning = bValue & 0x01;
	bValue >>= 1;
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);

	memcpy(&mSpawnIndex, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mSpawnDeltaTime, data + offset, sizeof(float));  offset += sizeof(float);

	return true;
}
#pragma warning( pop )


void CCannon::SpawnBullet() {
	if (mCannonType == ECannon_Type::Monstar) {
		auto GetSpawnIndex = [&]() -> int {
			for (int i = 0; i < mBulletCount; ++i) {
				if (!mVecBullet[i]->GetEnable()) {
					return i;
				}
			}
			return mSpawnIndex;
		};
		mSpawnIndex = GetSpawnIndex();
		CMonstar* monstar = (CMonstar*)mVecBullet[mSpawnIndex];
		monstar->ResetForBullet(mBulletVelocity);
		monstar->SetPos(mSpawnPoint);
		monstar->SetEnable(true);
		monstar->SetZOrder((int)ERender_ZOrder::Monstar + mSpawnIndex);
		mScene->GetResource()->SoundPlay("FireMonstar" + std::to_string(rand() % 4));
	} else {
		mVecBullet[mSpawnIndex]->SetPos(mSpawnPoint);
		mVecBullet[mSpawnIndex]->SetEnable(true);
		mSpawnIndex = (mSpawnIndex + 1) % mBulletCount;
		if (mCannonType == ECannon_Type::Bullet)
			mScene->GetResource()->SoundPlay("FireBullet" + std::to_string(rand() % 2));
		else
			mScene->GetResource()->SoundPlay("FireCloud" + std::to_string(rand() % 2));
	}
}