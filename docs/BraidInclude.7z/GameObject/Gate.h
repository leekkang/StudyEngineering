#pragma once

#include "GameObject.h"

class CGate : public CGameObject {
	friend class CScene;

private:
	CGate();
	~CGate();
	DISALLOW_COPY_AND_ASSIGN(CGate)


private:
	bool  mOpen		  = false;
	float mDoorOffset = 0.f;

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(UINT8* data);

public:
	void UnlockGate();

public:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);
};