
#include "Gate.h"

#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"

#include "../Collision/ColliderBox.h"
#include "Key.h"

CGate::CGate() {
	SetTypeID<CGate>();
}
CGate::~CGate() {
}

void CGate::SetObjectTexture(bool immutable) {
	std::vector<const TCHAR*> path{TEXT("Object/gate1.bmp"), TEXT("Object/gate2.bmp")};

	if (immutable) {
		SetTextureWithDIB("GateDIB", path);
		SetImmutableObject();
	} else {
		SetTexture("Gate", path);
	}
	SetColorKeyAll(255, 0, 255);

	mSize = mTexture->GetSize();
}

bool CGate::Init() {
	CGameObject::Init();
	//SetSize(120.f, 152.f);
	SetPivot(0.5f, 1.0f);

	mZOrder = (int)ERender_ZOrder::Gate;

	CGameObject::CreateSound({
		{ESound_Group::Effect, "GateUnlock", "gate_unlock", 2}
							 });

	// �浹ü �߰�
	CColliderBox* box = AddCollider<CColliderBox>("Gate");
	box->SetExtent(110.f, 152.f);
	box->SetOffset(0.f, -76.f);
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetCollisionBeginFunction<CGate>(this, &CGate::CollisionBegin);
	box->SetCollisionEndFunction<CGate>(this, &CGate::CollisionEnd);

	return true;
}

void CGate::Update(float deltaTime) {
	if (mOpen && mDoorOffset < 150.f) {
		mDoorOffset += 300.f * deltaTime * mTimeScale;
	}
}

void CGate::Render(HDC hdc, float deltaTime) {
	Vector2	renderLT = GetWorldToCameraPos(mPos) - mPivot * mSize;

	RenderTexture(hdc, mTexture, {renderLT.x ,renderLT.y + mDoorOffset}, {mSize.x ,mSize.y - mDoorOffset});
	RenderTexture(hdc, mTexture, renderLT, mSize, 0, 0, 1);

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CGate::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(float) * 2;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mListCollider.begin()->Get()->GetEnable();
	bValue = bValue << 1 | mOpen;
	data[offset] = bValue;
	++offset;

	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mDoorOffset, sizeof(float));	offset += sizeof(float);

	return true;
}
bool CGate::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mOpen = bValue & 0x01;
	bValue >>= 1;
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(bValue & 0x01);
	}
	++offset;

	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mDoorOffset, data + offset, sizeof(float));	offset += sizeof(float);

	return true;
}
#pragma warning( pop )



void CGate::UnlockGate() {
	mOpen = true;
	mDoorOffset = 0.f;
	mListCollider.begin()->Get()->SetEnable(false);

	mScene->GetResource()->SoundPlay("GateUnlock" + std::to_string(rand() % 2));
}

void CGate::CollisionBegin(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type == ECollision_Profile::MoveObj &&
		dest->GetName() == "Key") {
		UnlockGate();
		((CKey*)dest->GetOwner())->UnlockGate((CColliderBox*)src);
	}
}

void CGate::CollisionEnd(CCollider* src, CCollider* dest) {
}
