
#include "Gate.h"

#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"
#include "../Scene/SceneManager.h"

#include "../Collision/ColliderBox.h"
#include "Key.h"

CGate::CGate() {
	SetTypeID<CGate>();
}

CGate::CGate(const CGate& obj) {
}

CGate::~CGate() {
}

bool CGate::Init() {
	CGameObject::Init();
	SetSize(125.f, 150.f);
	SetPivot(0.5f, 0.95f);

#ifdef UNICODE
	std::vector<std::wstring> path{L"Object/gate1.bmp", L"Object/gate2.bmp"};
#else
	std::vector<std::string> path{"Object/gate1.bmp", "Object/gate2.bmp"};
#endif
	SetTexture("Gate", path);
	SetColorKeyAll(255, 0, 255);


	CGameObject::CreateSound({
		{ESound_Group::Effect, "GateUnlock", "gate_unlock", 2}
							 });


	// �浹ü �߰�
	CColliderBox* box = AddCollider<CColliderBox>("Gate");
	box->SetExtent(110.f, 150.f);
	box->SetOffset(0.f, -75.f);
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetCollisionBeginFunction<CGate>(this, &CGate::CollisionBegin);
	box->SetCollisionEndFunction<CGate>(this, &CGate::CollisionEnd);

	return true;
}

void CGate::Update(float deltaTime) {
	if (mOpen && mDoorOffset < 150.f) {
		mDoorOffset += 300.f * deltaTime;
	}
}

void CGate::PostUpdate(float deltaTime) {
}

void CGate::Render(HDC hdc, float deltaTime) {
	Vector2	renderLT = GetWorldToCameraPos() - mPivot * mSize;

	RenderTexture(hdc, mTexture, {renderLT.x ,renderLT.y + mDoorOffset}, {mSize.x ,mSize.y - mDoorOffset}, 0, 0, 0);
	RenderTexture(hdc, mTexture, renderLT, mSize, 0, 0, 1);

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CGate::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(int) * 1 + sizeof(float) * 2 + sizeof(Vector2) * 2;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bvalue = mListCollider.begin()->Get()->GetEnable();
	bvalue = bvalue << 1 | mOpen;
	data[offset] = bvalue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mSize, sizeof(Vector2));		offset += sizeof(Vector2);

	memcpy(data + offset, &mDoorOffset, sizeof(float));	offset += sizeof(float);

	return true;
}
bool CGate::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bvalue = data[offset];
	mOpen = bvalue & 0x01;
	bvalue >>= 1;
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(bvalue & 0x01);
	}
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mSize, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	memcpy(&mDoorOffset, data + offset, sizeof(float));	offset += sizeof(float);

	return true;
}
#pragma warning( pop )



void CGate::UnlockGate() {
	mOpen = true;
	mDoorOffset = 0.f;
	mListCollider.begin()->Get()->SetEnable(false);

	mScene->GetResource()->SoundPlay("GateUnlock" + std::to_string(rand() % 2));
}

void CGate::CollisionBegin(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type == ECollision_Profile::Object &&
		dest->GetName() == "Key") {
		UnlockGate();
		((CKey*)dest->GetOwner())->UnlockGate((CColliderBox*)src);
	}
}

void CGate::CollisionEnd(CCollider* src, CCollider* dest) {
}
