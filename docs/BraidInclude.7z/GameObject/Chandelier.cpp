
#include "Chandelier.h"

#include "../GameManager.h"
#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"
#include "../Scene/SceneCollision.h"
#include "../Scene/StageBoss.h"

#include "../Collision/ColliderBox.h"

#include "Player.h"
#include "Boss.h"


CChandelier::CChandelier() : 
	mVecDebris(mDebrisCount){
	SetTypeID<CChandelier>();
}

CChandelier::~CChandelier() {
}

void CChandelier::SetObjectTexture(bool left) {
	std::vector<const TCHAR*> path;
	if (left)
		path = {TEXT("Object/Chandelier/chandelier.bmp"), TEXT("Object/Chandelier/chainLeft.bmp"),
				TEXT("Object/Chandelier/hangerLeft.bmp"), TEXT("Object/Chandelier/hangerLeftOpen.bmp")};
	else
		path = {TEXT("Object/Chandelier/chandelier.bmp"), TEXT("Object/Chandelier/chainRight.bmp"),
				TEXT("Object/Chandelier/hangerRight.bmp"),TEXT("Object/Chandelier/hangerRightOpen.bmp")};

	SetTexture(left ? "ChandelierLeft" : "ChandelierRight", path);
	SetColorKeyAll(255, 0, 255);

	mSize = mTexture->GetSize();
}

void CChandelier::InitDebris() {
	std::string namePrefix{"debris"};
	const TCHAR* pathPrefix{TEXT("Object/Chandelier/debris")};

	for (int i = 0; i < mDebrisCount; ++i) {
		TCHAR	fileName[MAX_PATH] = {};
		wsprintf(fileName, TEXT("%s%d.bmp"), pathPrefix, i + 1);
		std::string name = namePrefix + std::to_string(i + 1);

		mScene->GetResource()->LoadTexture(name, fileName);
		CTexture* texture = mScene->GetResource()->FindTexture(name);
		texture->SetColorKey(255, 0, 255);
		mVecDebris[i].texture = texture;

		CColliderBox* box = CreateCollider<CColliderBox>(name);
		box->SetExtent(texture->GetSize());
		box->SetCollisionProfile(ECollision_Profile::MoveObj);
		box->SetCollisionBeginFunction<CChandelier>(this, &CChandelier::DebrisCollisionBegin);
		box->SetCollisionEndFunction<CChandelier>(this, &CChandelier::DebrisCollisionEnd);
		box->SetEnable(false);
		mVecDebris[i].collider = box;

		// ���鸮���� ����� ��ġ�̴�. �ǹ��� 0, 0 �̴�.
		mVecDebris[i].pos.x = (i < 2 ? 0.f : i == 2 ? 81.f : i < 9 ? 32.f * (i - 3) : 16.f * (i - 9)) - 100.f;
		mVecDebris[i].pos.y = i == 0 ? 65.f :
							  i == 1 ? 0.f :
							  i == 2 ? 17.f : 80.f;
	}
}

bool CChandelier::Init() {
	CMovableObject::Init();
	SetPivot(0.5f, 0.f);

	mGravity *= .5f;
	mZOrder = (int)ERender_ZOrder::Topography + 1;

	CGameObject::CreateSound({
		{ESound_Group::Effect, "ChandelierSnap", "chandelier_snap", 1},
		{ESound_Group::Effect, "ChandelierBreak", "chandelier_break", 2},
		{ESound_Group::Effect, "ChandelierBreakMiss", "chandelier_break_miss", 2},
		{ESound_Group::Effect, "ChandelierPieceHit", "chandelier_piece_hit", 9},
		{ESound_Group::Effect, "ChandelierPieceHitOther", "chandelier_other_piece_hit", 7},
							 });

	// �浹ü �߰�
	CColliderBox* box = AddCollider<CColliderBox>("ChandelierBody");
	box->SetExtent(100.f, 90.f);
	box->SetOffset(0.f, 55.f);
	box->SetCollisionProfile(ECollision_Profile::MoveObj);
	box->SetCollisionBeginFunction<CChandelier>(this, &CChandelier::BodyCollisionBegin);
	box->SetCollisionEndFunction<CChandelier>(this, &CChandelier::BodyCollisionEnd);

	box = AddCollider<CColliderBox>("ChandelierChain");
	box->SetExtent(10.f, 20.f);
	box->SetOffset(2.f, -45.f);
	box->SetCollisionProfile(ECollision_Profile::MoveObj);
	box->SetCollisionBeginFunction<CChandelier>(this, &CChandelier::ChainCollisionBegin);
	box->SetCollisionEndFunction<CChandelier>(this, &CChandelier::ChainCollisionEnd);

	InitDebris();

	return true;
}

void CChandelier::Update(float deltaTime) {
	if (!mCrashed) {
		CMovableObject::Update(deltaTime);
		return;
	}

	float scaledDeltaTime = deltaTime * mTimeScale;

	for (int i = 0; i < mDebrisCount; ++i) {
		Debris& debris = mVecDebris[i];
		if (!debris.collider->GetEnable())
			continue;

		// ���� ��ġ ���� (�߷� ó��)
		debris.velocity.y += mGravity * scaledDeltaTime;
		if (debris.velocity.y > MAX_GRAVITY_SPEED)
			debris.velocity.y = MAX_GRAVITY_SPEED;

		debris.pos += debris.velocity * scaledDeltaTime;

		// �ݶ��̴� ������Ʈ
		debris.collider->SetOffset(debris.pos - mPos + debris.texture->GetSize() * .5f);
		debris.collider->Update(deltaTime);
		mScene->GetCollision()->AddCollider(debris.collider);
	}
}

void CChandelier::PostUpdate(float deltaTime) {
	CMovableObject::PostUpdate(deltaTime);
}

void CChandelier::Render(HDC hdc, float deltaTime) {
	// ü�� ������
	Vector2 camPos = GetCameraPos();
	Vector2	renderLT = mOriginPos - camPos;
	RenderTexture(hdc, mTexture, renderLT, mTexture->GetSize(1), 0, 0, 1);

	// ü�� Ȧ�� ������
	renderLT.x += mHangerXOffset;
	renderLT.y += mTexture->GetHeight(1);
	int hangerIndex = mPhysicsSimulate || mCrashed ? 3 : 2;
	RenderTexture(hdc, mTexture, renderLT, mTexture->GetSize(hangerIndex), 0, 0, hangerIndex);
	
	// ��ü ������
	if (!mCrashed)
		RenderTexture(hdc);
	else {
		// ���� ������
		for (int i = 0; i < mDebrisCount; ++i) {
			const Debris& debris = mVecDebris[mDebrisRenderOrder[i]];
			renderLT = debris.pos - camPos;
			RenderTexture(hdc, debris.texture, renderLT, debris.texture->GetSize());
#ifdef _DEBUG
			if (debris.collider->GetEnable())
				debris.collider->Render(hdc, deltaTime);
#endif
		}
	}

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CChandelier::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) * 1 + sizeof(int) * 1 + sizeof(float) * 1 +
			sizeof(Vector2) * 2 + mDebrisCount * (sizeof(Vector2) * 2 + 1);
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mListCollider.begin()->Get()->GetEnable();
	bValue = bValue << 1 | mPhysicsSimulate;
	bValue = bValue << 1 | mCrashed;
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));			offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));		offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));			offset += sizeof(Vector2);

	// CMovableObject
	memcpy(data + offset, &mVelocity, sizeof(Vector2));		offset += sizeof(Vector2);

	// CChandelier
	for (int i = 0; i < mDebrisCount; ++i) {
		const Debris& debris = mVecDebris[i];
		memcpy(data + offset, &debris.pos, sizeof(Vector2));	  offset += sizeof(Vector2);
		memcpy(data + offset, &debris.velocity, sizeof(Vector2)); offset += sizeof(Vector2);

		bValue = debris.collider->GetEnable();
		data[offset] = bValue;
		++offset;
	}

	return true;
}
bool CChandelier::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mCrashed = bValue & 0x01;
	bValue >>= 1;
	mPhysicsSimulate = bValue & 0x01;
	bValue >>= 1;
	bool enable = bValue & 0x01;
	(*mListCollider.begin())->SetEnable(enable);
	if (!enable)
		(*mListCollider.begin())->ClearCollisionList();
	++offset;


	/*auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(enable);
		if (!enable)
			(*iter)->ClearCollisionList();
	}*/


	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));			offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));		offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));			offset += sizeof(Vector2);

	// CMovableObject
	memcpy(&mVelocity, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	// CChandelier
	for (int i = 0; i < mDebrisCount; ++i) {
		Debris& debris = mVecDebris[i];
		memcpy(&debris.pos, data + offset, sizeof(Vector2));	  offset += sizeof(Vector2);
		memcpy(&debris.velocity, data + offset, sizeof(Vector2)); offset += sizeof(Vector2);

		enable = data[offset];
		debris.collider->SetEnable(enable);
		if (!enable)
			debris.collider->ClearCollisionList();
		++offset;
	}

	return true;
}
#pragma warning( pop )



void CChandelier::Collapse(bool hit, float hitPosX) {
	mCrashed = true;
	mPhysicsSimulate = false;
	mVelocity = 0.f;

	if (hit)
		mScene->GetResource()->SoundPlay("ChandelierBreak" + std::to_string(rand() % 2));
	else
		mScene->GetResource()->SoundPlay("ChandelierBreakMiss" + std::to_string(rand() % 2));

	// �������� ��ġ�� �ӵ��� �����Ѵ�. ������Ʈ �Լ����� ��� ���ŵ�
	for (int i = 0; i < mDebrisCount; ++i) {
		Debris& debris = mVecDebris[i];
		debris.collider->SetEnable(true);

		// �����¿��� ���� ��ǥ�� ����
		debris.pos += mPos;

		float diff = debris.pos.x + debris.texture->GetWidth() * .5f - hitPosX;
		if (i == 0) {
			debris.velocity.x = rand() % 50 - 25.f;
			debris.velocity.y = -(float)(rand() % 200) - 300.f;
		} else if (i < 3) {
			debris.velocity.x = i == 1 ? -(float)(rand() % 100) : (float)(rand() % 100);
			debris.velocity.y = -(float)(rand() % 100) - 200.f;
		} else {
			// �浹 ��ġ�� ���� ƨ��� ��ġ�� ���� �ٲ۴�.
			debris.velocity.x = rand() % 400 - 200.f + diff * 2.f;
			debris.velocity.y = -(float)(rand() % 300) - 400.f;
		}
	}
}

void CChandelier::DebrisBound(int index, CCollider* terrain) {
	Vector2& pos = mVecDebris[index].pos;
	Vector2& velocity = mVecDebris[index].velocity;
	CColliderBox* col = mVecDebris[index].collider;
	velocity.y *= (index < 3 ? 0.2f : 0.4f);
	if (velocity.y < mMaxIgnoreVelocity) {
		col->SetEnable(false);
		col->ClearCollisionList();
		return;
	}

	pos.y = terrain->GetTopY(pos.x) - mVecDebris[index].texture->GetHeight();
	velocity.x *= .6f;
	velocity.y = -velocity.y;

	int soundIndex = rand() % 16;
	if (soundIndex < 9)
		mScene->GetResource()->SoundPlay("ChandelierPieceHit" + std::to_string(soundIndex));
	else {
		soundIndex -= 9;
		mScene->GetResource()->SoundPlay("ChandelierPieceHitOther" + std::to_string(soundIndex));
	}
}


void CChandelier::ChainCollisionBegin(CCollider* src, CCollider* dest) {
	if (mPhysicsSimulate || mCrashed)
		return;

	if (dest->GetProfile()->type != ECollision_Profile::Player)
		return;

	mPhysicsSimulate = true;
	mScene->GetResource()->SoundPlay("ChandelierSnap");
}
void CChandelier::ChainCollisionEnd(CCollider* src, CCollider* dest) {
}

void CChandelier::BodyCollisionBegin(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type == ECollision_Profile::Monster && dest->GetName() == "Boss") {
		mPos.y = dest->GetTopY(mPos.x) - mSize.y;
		Collapse(true, src->GetHitPoint().x);
	} else if (dest->GetProfile()->type == ECollision_Profile::Terrain) {
		mPos.y = dest->GetTopY(mPos.x) - mSize.y;
		Collapse(false, mPos.x);
		((CBoss*)(((CStageBoss*)mScene)->GetBoss()))->Alert();
	}
}
void CChandelier::BodyCollisionEnd(CCollider* src, CCollider* dest) {
}



void CChandelier::DebrisCollisionBegin(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type != ECollision_Profile::Terrain)
		return;

	int index = 0;
	for (int i = 0; i < mDebrisCount; ++i) {
		if (mVecDebris[i].collider == src) {
			index = i;
			break;
		}
	}

	// ���� �ݶ��̴��� ������ �ٴ� �浹�̴�
	if (dest->GetColliderType() == ECollider_Type::Line) {
		DebrisBound(index, dest);
		return;
	}

	float leftOffset = src->GetHitPoint().x - ((CColliderBox*)src)->GetInfo().LT.x;
	float rightOffset = ((CColliderBox*)src)->GetInfo().RB.x - src->GetHitPoint().x;
	float topOffset = src->GetHitPoint().y - ((CColliderBox*)src)->GetInfo().LT.y;
	float bottomOffset = ((CColliderBox*)src)->GetInfo().RB.y - src->GetHitPoint().y;

	bool leftCollision = leftOffset > rightOffset; // ������Ʈ�� ����, ���� ������


	const Vector2& terrainLT = ((CColliderBox*)dest)->GetInfo().LT;
	const Vector2& terrainRB = ((CColliderBox*)dest)->GetInfo().RB;

	Debris& debris = mVecDebris[index];
	if (topOffset < bottomOffset) { // õ�� �浹
		// ��ġ�� ������ ���� ���̰� ���� ���̺��� ���.
		if ((leftCollision && rightOffset > topOffset) ||
			(!leftCollision && leftOffset > topOffset)) {
			debris.pos.y = dest->GetBottom();
			src->ClearCollisionList();
			if (debris.velocity.y < 0.f)
				debris.velocity.y = -(debris.velocity.y);
			return;
		}
	} else { // �ٴ� �浹
		if (leftOffset == rightOffset ||
			(leftCollision && rightOffset > bottomOffset) ||
			(!leftCollision && leftOffset > bottomOffset)) {
			DebrisBound(index, dest);
			return;
		}
	}

	// ���� �浹
	if (leftCollision) {
		debris.pos.x = ((CColliderBox*)dest)->GetInfo().LT.x + debris.texture->GetWidth();
		if (debris.velocity.x > 0.f)
			debris.velocity.x = -debris.velocity.x;
	} else {
		debris.pos.x = ((CColliderBox*)dest)->GetInfo().RB.x;
		if (debris.velocity.x < 0.f)
			debris.velocity.x = -debris.velocity.x;
	}
}
void CChandelier::DebrisCollisionEnd(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type != ECollision_Profile::Terrain)
		return;

	// ������ ������� �������� �Ʒ��� �������� �ʰ� �ϱ� ���� ���� ó���� �Ѵ�.
	if (dest->GetColliderType() != ECollider_Type::Line)
		return;

	int index = 0;
	for (int i = 0; i < mDebrisCount; ++i) {
		if (mVecDebris[i].collider == src) {
			index = i;
			break;
		}
	}

	if (mVecDebris[index].velocity.y > 0.f) {
		src->SetEnable(false);
		src->ClearCollisionList();
	}
}