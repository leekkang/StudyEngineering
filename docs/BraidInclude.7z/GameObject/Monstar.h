#pragma once

#include "Character.h"

class CMonstar : public CCharacter {
	friend class CScene;

private:
	const float mMaxXSpeed = 162.f;
	const float mBoundSpeed = 600.f;		// �÷��̾ ����� �� y�� �̵� �ӷ�
	const float mMaxIgnoreVelocity = 50.f;	// �浹 �� �����ع��� �ݹ߼ӷ�

protected:
	CMonstar();
	virtual ~CMonstar();
	DISALLOW_COPY_AND_ASSIGN(CMonstar)

private:
	bool mBounding = false;
	float mPatrolMin = 0.f;
	float mPatrolMax = 0.f;

	class CColliderBox* mBodyCollider = nullptr;

private:
	void CreateAnimation();

public:
	void SetPatrolArea(float min, float max) {
		mPatrolMin = min;
		mPatrolMax = max;
	}
	void SetDirection(int dir) {
		mLookDir = dir;
		mVelocity.x = dir * mMaxXSpeed;
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(UINT8* data);

public:
	void ResetForBullet(const Vector2& velocity);
	virtual void Dead(bool randomX, bool ignoreVelocity);
	virtual void DeadByCannon(float xV, float yV);

private:
	// �÷��̾ �׿��� �� ȣ���
	void Bound();
	void Landing(CCollider* col);

private:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);

private:
	void ChangeVelocity(float deltaTime);
	void ChangeMonstarAnimation();
};