#pragma once

#include "GameObject.h"

class CBackObj : public CGameObject {
	friend class CScene;

protected:
	CBackObj();
	CBackObj(const CBackObj& obj);
	virtual ~CBackObj();

public:
	void SetTexture(const TCHAR* path);

public:
	virtual bool Init();
	// ���߿� ��������
	virtual void Render(HDC hdc, float deltaTime);

};


