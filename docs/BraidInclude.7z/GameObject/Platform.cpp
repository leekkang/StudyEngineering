
#include "Platform.h"

#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"
#include "../Scene/SceneManager.h"

#include "../Collision/ColliderBox.h"
#include "Key.h"

CPlatform::CPlatform() {
	SetTypeID<CPlatform>();
}
CPlatform::~CPlatform() {
}

void CPlatform::SetPlatformSize(const Vector2& pos) {
	SetSize(pos);
	
	// �浹ü �߰�
	CColliderBox* box = AddCollider<CColliderBox>("Platfrom");
	box->SetExtent(pos.x, pos.y);
	box->SetOffset(pos.x * 0.5f, pos.y * 0.5f);
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetCollisionBeginFunction<CPlatform>(this, &CPlatform::CollisionBegin);
	box->SetCollisionEndFunction<CPlatform>(this, &CPlatform::CollisionEnd);
}

bool CPlatform::Init() {
	CGameObject::Init();
	SetPivot(0.f, 0.f);

	//SetTexture("Platform", TEXT("Object/gate1.bmp"));
	//SetColorKey(255, 0, 255);

	CGameObject::CreateSound({
		{ESound_Group::Effect, "PlatformStop1", "platform_stop_alpha", 3},
		{ESound_Group::Effect, "PlatformStop2", "platform_stop_beta", 2},
							 });



	return true;
}

void CPlatform::Update(float deltaTime) {
	if (!CheckMove())
		return;

	if (mForward) {
		if (mVertical) {
			if (mPos.y + mSize.y > mMaxPos) {
				mPos.y = mMaxPos - mSize.y;
				mVelocity.y = 0.f;
				// TODO �ε�ġ�� �Ҹ� �߰�
			}
		} else {
			if (mPos.x + mSize.x > mMaxPos) {
				mPos.x = mMaxPos - mSize.x;
				mVelocity.x = 0.f;
				// TODO �ε�ġ�� �Ҹ� �߰�
			}
		}
	} else {
		if (mVertical) {
			if (mPos.y < mMinPos) {
				mPos.y = mMinPos;
				mVelocity.y = 0.f;
				// TODO �ε�ġ�� �Ҹ� �߰�
			}
		} else {
			if (mPos.x < mMinPos) {
				mPos.x = mMinPos;
				mVelocity.x = 0.f;
				// TODO �ε�ġ�� �Ҹ� �߰�
			}
		}
	}
}

void CPlatform::Render(HDC hdc, float deltaTime) {
	Vector2	renderLT = GetWorldToCameraPos() - mPivot * mSize;

	RenderTexture(hdc, mTexture, renderLT, mSize);

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CPlatform::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(float) * 2 + sizeof(Vector2) * 2;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bvalue = mForward;
	data[offset] = bvalue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(data + offset, &mVelocity, sizeof(Vector2));	offset += sizeof(Vector2);

	return true;
}
bool CPlatform::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bvalue = data[offset];
	mForward = bvalue & 0x01;
	++offset;

	// CGameObject
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(&mVelocity, data + offset, sizeof(Vector2)); offset += sizeof(Vector2);

	return true;
}
#pragma warning( pop )



void CPlatform::StartMove() {
	if (mForward) {
		mForward = false;
		if (mVertical)
			mVelocity.y = -mSpeed;
		else
			mVelocity.x = -mSpeed;
	} else {
		mForward = true;
		if (mVertical)
			mVelocity.y = mSpeed;
		else
			mVelocity.x = mSpeed;
	}
}

void CPlatform::CollisionBegin(CCollider* src, CCollider* dest) {
}

void CPlatform::CollisionEnd(CCollider* src, CCollider* dest) {
}
