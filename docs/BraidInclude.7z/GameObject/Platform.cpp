
#include "Platform.h"

#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"

#include "../Collision/ColliderBox.h"
#include "Key.h"

CPlatform::CPlatform() {
	SetTypeID<CPlatform>();
}
CPlatform::~CPlatform() {
}

void CPlatform::SetColliderSize(float w, float h) {
	CColliderBox* box = (CColliderBox*)*mListCollider.front();
	box->SetExtent(w, h);
}

void CPlatform::SetObjectTexture(const TCHAR* fileName, bool immutable) {
	CGameObject::SetObjectTexture(fileName, immutable);

	// �׵θ� �ؽ��� ����� �°� �ݶ��̴� ����
	mSize = mTexture->GetSize();
	CColliderBox* box = (CColliderBox*)*mListCollider.front();
	box->SetOffset(mSize * 0.5f);
	box->SetExtent(mSize);
}

bool CPlatform::Init() {
	CGameObject::Init();
	SetPivot(0.f, 0.f);

	CGameObject::CreateSound({
		{ESound_Group::Effect, "PlatformLoopLeft", "platform_loop_a", 1, true},
		{ESound_Group::Effect, "PlatformLoopRight", "platform_loop_b", 1, true},
		{ESound_Group::Effect, "PlatformLoopDown", "stone_loop_a", 1, true},
		{ESound_Group::Effect, "PlatformLoopUp", "stone_loop_b", 1, true},
		{ESound_Group::Effect, "HorizontalStop", "platform_stop_alpha", 3, false},
		{ESound_Group::Effect, "VerticalStop", "stone_stop", 1, false},
							 });

	// �浹ü �߰�
	CColliderBox* box = AddCollider<CColliderBox>("Platfrom");
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetCollisionBeginFunction<CPlatform>(this, &CPlatform::CollisionBegin);
	box->SetCollisionEndFunction<CPlatform>(this, &CPlatform::CollisionEnd);

	return true;
}

void CPlatform::Update(float deltaTime) {
	if (!CheckMove())
		return;

	CMovableObject::Update(deltaTime);

	if (mForward) {
		if (mVertical) {
			if (mPos.y + mSize.y > mMaxPos) {
				mPos.y = mMaxPos - mSize.y;
				mVelocity.y = 0.f;
				SoundPlay("VerticalStop");
				mScene->GetResource()->SoundStop("PlatformLoopDown");
			}
		} else {
			if (mPos.x + mSize.x > mMaxPos) {
				mPos.x = mMaxPos - mSize.x;
				mVelocity.x = 0.f;
				SoundPlay("HorizontalStop" + std::to_string(rand() % 3), 50);
				mScene->GetResource()->SoundStop("PlatformLoopRight");
			}
		}
	} else {
		if (mVertical) {
			if (mPos.y < mMinPos) {
				mPos.y = mMinPos;
				mVelocity.y = 0.f;
				SoundPlay("VerticalStop");
				mScene->GetResource()->SoundStop("PlatformLoopUp");
			}
		} else {
			if (mPos.x < mMinPos) {
				mPos.x = mMinPos;
				mVelocity.x = 0.f;
				SoundPlay("HorizontalStop" + std::to_string(rand() % 3), 50);
				mScene->GetResource()->SoundStop("PlatformLoopLeft");
			}
		}
	}
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CPlatform::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(float) * 2 + sizeof(Vector2) * 2;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mForward;
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(data + offset, &mVelocity, sizeof(Vector2));	offset += sizeof(Vector2);

	return true;
}
bool CPlatform::Deserialize(const UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mForward = bValue & 0x01;
	++offset;

	// CGameObject
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	// CMovableObject
	memcpy(&mVelocity, data + offset, sizeof(Vector2)); offset += sizeof(Vector2);

	return true;
}
#pragma warning( pop )



void CPlatform::StartMove(bool forward) {
	mForward = forward;
	if (mForward) {
		if (mVertical) {
			mVelocity.y = mSpeed;
			SoundPlay("PlatformLoopDown");
		}
		else {
			mVelocity.x = mSpeed;
			SoundPlay("PlatformLoopRight", 50);
		}
	} else {
		if (mVertical) {
			mVelocity.y = -mSpeed;
			SoundPlay("PlatformLoopUp");
		}
		else {
			mVelocity.x = -mSpeed;
			SoundPlay("PlatformLoopLeft", 50);
		}
	}
}

void CPlatform::CollisionBegin(CCollider* src, CCollider* dest) {
}

void CPlatform::CollisionEnd(CCollider* src, CCollider* dest) {
}
