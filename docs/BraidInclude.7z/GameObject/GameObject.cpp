
#include "GameObject.h"
#include "../GameManager.h"

#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"
#include "../Scene/SceneManager.h"

#include "../Resource/Animation/AnimationSequence.h"

#include "../Scene/SceneCollision.h"
#include "../Collision/Collider.h"
#include "../Collision/ColliderLine.h"

CGameObject::CGameObject() {
	SetTypeID<CGameObject>();
}

CGameObject::CGameObject(const CGameObject& obj) :
	CRef(obj),
	mScene{obj.mScene},
	mTimeScale(obj.mTimeScale),
	mPos(obj.mPos),
	mPrevPos(obj.mPrevPos),
	mSize(obj.mSize),
	mPivot(obj.mPivot),
	mMove(obj.mMove),
	mRenderLayer(obj.mRenderLayer),
	mTexture(obj.mTexture)
{
	if (!obj.mAnimation) {
		// �ִϸ��̼� ���� ����
	}
}

CGameObject::~CGameObject() {
	{
		auto iter = mListCollider.begin();
		auto iterEnd = mListCollider.end();
		for (; iter != iterEnd; ++iter) {
			(*iter)->ClearCollisionList();
		}
	}
	{
		auto iter = mListWidgetComponent.begin();
		auto iterEnd = mListWidgetComponent.end();
		for (; iter != iterEnd; ++iter) {
			(*iter)->SetActive(false);
		}
	}

	SAFE_DELETE(mAnimation);
}

bool CGameObject::Init() {
	return true;
}

void CGameObject::Reset() {
}

void CGameObject::Update(float deltaTime) {
	float dt = deltaTime * mTimeScale;

	if (mAnimation) {
		mAnimation->Update(dt);
		// �ִϸ��̼��� �̹��� ũ��� ����� �ٽ� �����ش�.
		const AnimationFrameData& frameData = mAnimation->GetCurrentFrameData();
		mSize = frameData.end - frameData.start;
	}

	if (mPhysicsSimulate) {
		// ���� ����� �����Ѵ�. �߷�(y��)ó��, �ٴ� ����(x��)ó���� ���⼭ �Ѵ�.
		// t�� �� y��
		// y = V * t - 0.5f * G * t * t
		// 0 = -0.5f*G*t^2 + V*t - y
		if (mFloating) {
			mFallTime += dt;

			// �߷� ó��
			mVelocity.y += mGravity * dt;
			if (mVelocity.y > mMaxYSpeed)
				mVelocity.y = mMaxYSpeed;
			// �������� ó��
			//if (mVelocity.x != 0.f) {
			//	if (mVelocity.x > 0.f) {
			//		mVelocity.x -= mAirResist * dt;
			//		if (mVelocity.x < 0.f)
			//			mVelocity.x = 0.f;
			//	} else {
			//		mVelocity.x += mAirResist * dt;
			//		if (mVelocity.x > 0.f)
			//			mVelocity.x = 0.f;
			//	}
			//}
		} else {
			// ���� ó��
			if (mVelocity.x != 0.f) {
				if (mVelocity.x > 0.f) {
					mVelocity.x -= mFriction * dt;
					if (mVelocity.x < 0.f)
						mVelocity.x = 0.f;
				} else {
					mVelocity.x += mFriction * dt;
					if (mVelocity.x > 0.f)
						mVelocity.x = 0.f;
				}
			}
		}
	}

	mPos += mVelocity * dt;
	mMove = mPos - mPrevPos;

	// �ݶ��̴� ������Ʈ�� �����Ѵ�.
	UpdateCollider(deltaTime); 
	UpdateWidgetComponent(deltaTime);
}

void CGameObject::PostUpdate(float deltaTime) {
	mPrevPos = mPos;

	// ������ ���ӻ��� ����
	//PostUpdateCollider(deltaTime);
	PostUpdateWidgetComponent(deltaTime);
}

void CGameObject::Render(HDC hdc, float deltaTime) {
	Vector2	pos;
	if (mScene) {
		pos = mPos - mScene->GetCamera()->GetPos();
	} else {
		CScene* scene = CSceneManager::GetInst()->GetScene();
		pos = mPos - scene->GetCamera()->GetPos();
	}

	Vector2	renderLT = pos - mPivot * mSize;
	if (mAnimation) {
		const CTexture* texture = mAnimation->GetCurrentSequence()->GetTexture();

		int frameIndex = 0;
		if (texture->GetTextureType() == ETexture_Type::Frame) {
			frameIndex = mAnimation->GetCurrentFrameNumber();
		}

		const AnimationFrameData& frameData = mAnimation->GetCurrentFrameData();
		RenderTexture(hdc, texture, renderLT, mSize, (int)frameData.start.x, (int)frameData.start.y, frameIndex);
	} else if (mTexture) {
		RenderTexture(hdc, mTexture, renderLT, mSize);
	}

	RenderCollider(hdc, deltaTime);
}

bool CGameObject::OutOfCamera(CCamera* cam) {
	Vector2 vertexLT = mPos - cam->GetPos() - mSize * mPivot;

	return vertexLT.x + mSize.x < 0 || vertexLT.x > cam->GetResolution().x ||
		   vertexLT.y + mSize.y < 0 || vertexLT.y > cam->GetResolution().y;
}

void CGameObject::Landing(CColliderLine* line) {
	mFloating = false;
	if (line) {
		// ��翡 ���� ���ӵ��� �߰��Ѵ�.
		float sin = line->GetSlopeSin();
		if (sin != 0.f) {
			float v = std::abs(mVelocity.y * sin) * .8f;
			mVelocity.x += (line->IsAscend() ? -v : v);
		}
	}

	// y�� �̵��ӵ��� ���ش�.
	mVelocity.y = 0.f;
}

CCollider* CGameObject::FindCollider(const std::string& name) {
	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();

	for (; iter != iterEnd; ++iter) {
		if ((*iter)->GetName() == name)
			return *iter;
	}

	return nullptr;
}

void CGameObject::UpdateCollider(float deltaTime) {
	if (!GetActive() || !GetEnable())
		return;

	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();
	for (; iter != iterEnd;) {
		// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
		if (!(*iter)->GetActive()) {
			iter = mListCollider.erase(iter);
			iterEnd = mListCollider.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->Update(deltaTime);

		// �ݶ��̴��� ���� �ݶ��̴� ����Ʈ�� �߰��Ѵ�.
		mScene->GetCollision()->AddCollider(*iter);
		++iter;
	}
}
void CGameObject::PostUpdateCollider(float deltaTime) {
	if (!GetActive() || !GetEnable())
		return;

	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mListCollider.erase(iter);
			iterEnd = mListCollider.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}
		(*iter)->PostUpdate(deltaTime);
		++iter;
	}
}
void CGameObject::RenderCollider(HDC hdc, float deltaTime) {
	if (!GetActive() || !GetEnable())
		return;

	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mListCollider.erase(iter);
			iterEnd = mListCollider.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}
		(*iter)->Render(hdc, deltaTime);
		++iter;
	}
}

void CGameObject::UpdateWidgetComponent(float deltaTime) {
	auto iter = mListWidgetComponent.begin();
	auto iterEnd = mListWidgetComponent.end();
	for (; iter != iterEnd;) {
		// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
		if (!(*iter)->GetActive()) {
			iter = mListWidgetComponent.erase(iter);
			iterEnd = mListWidgetComponent.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->Update(deltaTime);
		++iter;
	}
}

void CGameObject::PostUpdateWidgetComponent(float deltaTime) {
	auto iter = mListWidgetComponent.begin();
	auto iterEnd = mListWidgetComponent.end();
	for (; iter != iterEnd;) {
		// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
		if (!(*iter)->GetActive()) {
			iter = mListWidgetComponent.erase(iter);
			iterEnd = mListWidgetComponent.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->PostUpdate(deltaTime);
		++iter;
	}
}


void CGameObject::SetTexture(CTexture* texture) {
	mTexture = texture;
}
void CGameObject::SetTexture(const std::string& name) {
	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTexture(const std::string& name, const TCHAR* filename,
							 const std::string& pathname) {
	mScene->GetResource()->LoadTexture(name, filename, pathname);

	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureFullPath(const std::string& name,
									 const TCHAR* fullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, fullPath);

	mTexture = mScene->GetResource()->FindTexture(name);
}

#ifdef UNICODE

void CGameObject::SetTexture(const std::string& name,
							 const std::vector<std::wstring>& vecFilename, const std::string& pathname) {
	mScene->GetResource()->LoadTexture(name, vecFilename, pathname);

	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureFullPath(const std::string& name,
									 const std::vector<std::wstring>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);

	mTexture = mScene->GetResource()->FindTexture(name);
}

#else

void CGameObject::SetTexture(const std::string& name,
							 const std::vector<std::string>& vecFilename, const std::string& pathname) {
	mScene->GetResource()->LoadTexture(name, vecFilename, pathname);

	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureFullPath(const std::string& name,
									 const std::vector<std::string>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);

	mTexture = mScene->GetResource()->FindTexture(name);
}

#endif


void CGameObject::SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index) {
	if (mTexture)
		mTexture->SetColorKey(r, g, b, index);
}
void CGameObject::SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b) {
	if (mTexture)
		mTexture->SetColorKeyAll(r, g, b);
}