
#include "GameObject.h"

#include "../GameManager.h"
#include "../PathManager.h"

#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"
#include "../Scene/SceneCollision.h"

#include "../Resource/Animation/AnimationSequence.h"

#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderLine.h"

CGameObject::CGameObject() {
	SetTypeID<CGameObject>();
}

CGameObject::CGameObject(const CGameObject& obj) :
	CRef(obj),
	mScene{nullptr},
	mRenderLayer(obj.mRenderLayer),
	mZOrder{obj.mZOrder},
	mTimeScale(obj.mTimeScale),
	mPos(obj.mPos),
	mSize(obj.mSize),
	mPivot(obj.mPivot),
	mTexture(obj.mTexture)
{
	if (!obj.mAnimation) {
		// �ִϸ��̼� ���� ����
	}
}

CGameObject::~CGameObject() {
	{
		auto iter = mListCollider.begin();
		auto iterEnd = mListCollider.end();
		for (; iter != iterEnd; ++iter) {
			(*iter)->ClearCollisionList();
		}
	}
	{
		auto iter = mListWidgetComponent.begin();
		auto iterEnd = mListWidgetComponent.end();
		for (; iter != iterEnd; ++iter) {
			(*iter)->SetActive(false);
		}
	}

	SAFE_DELETE(mAnimation);
}

void CGameObject::SetImmutableObject() {
	mImmutable = true;
	if (mAnimation) {
		auto iter = mAnimation->mMapAnimation.begin();
		auto iterEnd = mAnimation->mMapAnimation.end();
		for (; iter != iterEnd; ++iter) {
			CTexture* texture = iter->second->GetTexture();
			texture->InitModulatedBits();
		}
	}
	if (mTexture) {
		mTexture->InitModulatedBits();
	}
}

void CGameObject::SetObjectTexture(const TCHAR* fileName, bool immutable) {
	TCHAR	name[128] = {};
	_wsplitpath_s(fileName, nullptr, 0, nullptr, 0, name, 128, nullptr, 0);

	char textureName[128] = {};
#ifdef UNICODE
	int	length = WideCharToMultiByte(CP_ACP, 0, name, -1, 0, 0, 0, 0);
	WideCharToMultiByte(CP_ACP, 0, name, -1, textureName, length, 0, 0);
#else
	strcpy_s(textureName, fileName);
#endif // UNICODE

	if (immutable) {
		SetTextureWithDIB(textureName, fileName);
		SetImmutableObject();
	} else {
		SetTexture(textureName, fileName);
	}
	SetColorKey(255, 0, 255);

	mSize = mTexture->GetSize();
}
void CGameObject::SetObjectTexture(std::vector<const TCHAR*> vecFileName, bool immutable) {
	TCHAR	name[128] = {};
	_wsplitpath_s(vecFileName[0], nullptr, 0, nullptr, 0, name, 128, nullptr, 0);

	char textureName[128] = {};
#ifdef UNICODE
	int	length = WideCharToMultiByte(CP_ACP, 0, name, -1, 0, 0, 0, 0);
	WideCharToMultiByte(CP_ACP, 0, name, -1, textureName, length, 0, 0);
#else
	strcpy_s(textureName, fileName);
#endif // UNICODE

	if (immutable) {
		SetTextureWithDIB(textureName, vecFileName);
		SetImmutableObject();
	} else {
		SetTexture(textureName, vecFileName);
	}
	SetColorKeyAll(255, 0, 255);

	mSize = mTexture->GetSize();
}

bool CGameObject::Init() {
	return true;
}

void CGameObject::Update(float deltaTime) {
	if (mAnimation) {
		mAnimation->Update(deltaTime * mTimeScale);
		// �ִϸ��̼��� �̹��� ũ��� ����� �ٽ� �����ش�.
		const AnimationFrameData& frameData = mAnimation->GetCurrentFrameData();
		mSize = frameData.end - frameData.start;
	}
}

void CGameObject::PostUpdate(float deltaTime) {
}

void CGameObject::Render(HDC hdc, float deltaTime) {
	if (mAnimation) {
		const CTexture* texture = mAnimation->GetCurrentSequence()->GetTexture();

		int frameIndex = 0;
		if (texture->GetTextureType() == ETexture_Type::Frame) {
			frameIndex = mAnimation->GetCurrentFrameNumber();
		}

		const AnimationFrameData& frameData = mAnimation->GetCurrentFrameData();
		RenderTexture(hdc, texture, GetWorldToCameraPos(mPos) - mPivot * mSize, mSize, 
					  (int)frameData.start.x, (int)frameData.start.y, frameIndex);
	} else if (mTexture) {
		RenderTexture(hdc);
	}

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CGameObject::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(int) * 1 + sizeof(float) * 1 + sizeof(Vector2) * 2;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mEnable;
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mSize, sizeof(Vector2));		offset += sizeof(Vector2);

	return true;
}
bool CGameObject::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mEnable = bValue & 0x01;
	bValue >>= 1;
	//auto iter = mListCollider.begin();
	//auto iterEnd = mListCollider.end();
	//for (; iter != iterEnd; ++iter) {
	//	(*iter)->SetEnable(bValue & 0x01);
	//}
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mSize, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	return true;
}
#pragma warning( pop )



bool CGameObject::OutOfCamera(CCamera* cam) {
	Vector2 renderLT = mPos - cam->GetPos() - mSize * mPivot;
	return OutOfCamera(cam, renderLT, mSize);
}

bool CGameObject::OutOfCamera(CCamera* cam, const Vector2& renderLT, const Vector2& size) {
	return renderLT.x + size.x < 0 || renderLT.x > cam->GetResolution().width ||
		renderLT.y + size.y < 0 || renderLT.y > cam->GetResolution().height;
}

Vector2 CGameObject::GetWorldToCameraPos(const Vector2& pos) {
	if (mScene)
		return pos - mScene->GetCamera()->GetPos();
	else
		return pos - CSceneManager::GetInst()->GetScene()->GetCamera()->GetPos();
}


UINT8 CGameObject::CalcAlphaTime(float alphaTime, float maxTime, UINT8 range) {
	float halfTime = maxTime * .5f;
	if (alphaTime < halfTime)
		return 255 - (UINT8)(alphaTime / maxTime * range);
	else if (alphaTime < maxTime)
		return 255 - (UINT8)((maxTime - alphaTime) / maxTime * range);
	else
		return 255;
}

void CGameObject::RenderTexture(HDC hdc, const CTexture* texture, const Vector2& pos, const Vector2& size, 
								int imageX, int imageY, int imageIndex) {
	UINT8 mixValue = 0;
	if (!mDisableMix && mImmutable)
		mixValue = mScene->GetImmutableValue();

	RenderTextureAllCheck(hdc, texture, pos, size, imageX, imageY, imageIndex, 255, mixValue);
}

void CGameObject::RenderTextureAllCheck(HDC hdc, const CTexture* texture, const Vector2& pos, const Vector2& size,
										int imageX, int imageY, int imageIndex, UINT8 alphaValue,
										UINT8 mixValue, UINT8 r, UINT8 g, UINT8 b) {
	// ������ ������ �ø��Ѵ�.
	CCamera* cam = mScene->GetCamera();
	if (OutOfCamera(cam, pos, size))
		return;

	// ȭ�鿡 ��µǴ� ������ �����Ѵ�.
	int posX = (int)pos.x;
	int posY = (int)pos.y;
	int sizeX = (int)size.x;
	int sizeY = (int)size.y;

	if (posX < 0) {
		imageX -= posX;
		sizeX += posX;
		posX = 0;
	}
	if ((int)pos.x + (int)size.x > cam->GetResolution().width) {
		sizeX -= ((int)pos.x + (int)size.x - cam->GetResolution().width);
	}
	if (posY < 0) {
		imageY -= posY;
		sizeY += posY;
		posY = 0;
	}
	if ((int)pos.y + (int)size.y > cam->GetResolution().height) {
		sizeY -= ((int)pos.y + (int)size.y - cam->GetResolution().height);
	}

	texture->Render(hdc, posX, posY, sizeX, sizeY, imageX, imageY, imageIndex, alphaValue, mixValue, r, g, b);
}

CCollider* CGameObject::FindCollider(const std::string& name) {
	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();

	for (; iter != iterEnd; ++iter) {
		if ((*iter)->GetName() == name)
			return *iter;
	}

	return nullptr;
}

void CGameObject::UpdateCollider(float deltaTime) {
	if (!GetActive() || !GetEnable())
		return;

	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();
	for (; iter != iterEnd;) {
		// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
		if (!(*iter)->GetActive()) {
			iter = mListCollider.erase(iter);
			iterEnd = mListCollider.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->Update(deltaTime);

		// �ݶ��̴��� ���� �ݶ��̴� ����Ʈ�� �߰��Ѵ�.
		mScene->GetCollision()->AddCollider(*iter);
		++iter;
	}
}
void CGameObject::PostUpdateCollider(float deltaTime) {
	if (!GetActive() || !GetEnable())
		return;

	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mListCollider.erase(iter);
			iterEnd = mListCollider.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}
		(*iter)->PostUpdate(deltaTime);
		++iter;
	}
}
void CGameObject::RenderCollider(HDC hdc, float deltaTime) {
#ifdef _DEBUG
	if (!GetActive() || !GetEnable())
		return;

	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mListCollider.erase(iter);
			iterEnd = mListCollider.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}
		(*iter)->Render(hdc, deltaTime);
		++iter;
	}
#endif // _DEBUG
}

void CGameObject::UpdateWidgetComponent(float deltaTime) {
	auto iter = mListWidgetComponent.begin();
	auto iterEnd = mListWidgetComponent.end();
	for (; iter != iterEnd;) {
		// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
		if (!(*iter)->GetActive()) {
			iter = mListWidgetComponent.erase(iter);
			iterEnd = mListWidgetComponent.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->Update(deltaTime);
		++iter;
	}
}

void CGameObject::PostUpdateWidgetComponent(float deltaTime) {
	auto iter = mListWidgetComponent.begin();
	auto iterEnd = mListWidgetComponent.end();
	for (; iter != iterEnd;) {
		// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
		if (!(*iter)->GetActive()) {
			iter = mListWidgetComponent.erase(iter);
			iterEnd = mListWidgetComponent.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->PostUpdate(deltaTime);
		++iter;
	}
}

void CGameObject::Save(FILE* file) {
	CRef::Save(file);

	//UINT8 tmp = (UINT8)mRenderLayer;
	//fwrite(&tmp, 1, 1, file);
	fwrite(&mRenderLayer, sizeof(ERender_Layer), 1, file);
	fwrite(&mZOrder, sizeof(int), 1, file);
	fwrite(&mTimeScale, sizeof(float), 1, file);
	fwrite(&mPos, sizeof(Vector2), 1, file);
	fwrite(&mSize, sizeof(Vector2), 1, file);
	fwrite(&mPivot, sizeof(Vector2), 1, file);

	fwrite(&mImmutable, sizeof(bool), 1, file);

	bool texture = false;
	if (mTexture)
		texture = true;

	fwrite(&texture, sizeof(bool), 1, file);

	if (mTexture) {
		// Texture ����
		mTexture->Save(file);
	}

	bool animation = false;
	if (mAnimation)
		animation = true;

	fwrite(&animation, sizeof(bool), 1, file);

	if (mAnimation) {
		// Animation ����
	}

	int size = (int)mListCollider.size();
	fwrite(&size, sizeof(int), 1, file);
	if (size > 0) {
		auto iter = mListCollider.begin();
		auto iterEnd = mListCollider.end();
		ECollider_Type type;
		for (; iter != iterEnd; ++iter) {
			type = (*iter)->GetColliderType();
			//UINT8 tmp = tmp = (UINT8)type;
			//fwrite(&tmp, 1, 1, file);
			fwrite(&type, sizeof(ECollider_Type), 1, file);
			(*iter)->Save(file);
		}
	}

}

void CGameObject::Load(FILE* file) {
	CRef::Load(file);

	//UINT8 tmp;
	//fread(&tmp, 1, 1, file);
	//mRenderLayer = (ERender_Layer)tmp;
	fread(&mRenderLayer, sizeof(ERender_Layer), 1, file);
	fread(&mZOrder, sizeof(int), 1, file);
	fread(&mTimeScale, sizeof(float), 1, file);
	fread(&mPos, sizeof(Vector2), 1, file);
	fread(&mSize, sizeof(Vector2), 1, file);
	fread(&mPivot, sizeof(Vector2), 1, file);

	fread(&mImmutable, sizeof(bool), 1, file);

	bool texture = false;
	fread(&texture, sizeof(bool), 1, file);
	if (texture) {
		// texture �ҷ�����
		mTexture = mScene->GetResource()->LoadTexture(file);
	}

	bool animation = false;
	fread(&animation, sizeof(bool), 1, file);
	if (animation) {
		// Animation �ҷ�����
	}

	int size = (int)mListCollider.size();
	fread(&size, sizeof(int), 1, file);
	if (size > 0) {
		ECollider_Type type;
		for (int i = 0; i < size; ++i) {
			//UINT8 tmp;
			//fread(&tmp, 1, 1, file);
			//type = (ECollider_Type)tmp;
			fread(&type, sizeof(ECollider_Type), 1, file);
			if (type == ECollider_Type::Box) {
				CColliderBox* box = new CColliderBox;
				box->Load(file);
				box->mOwner = this;
				box->mScene = mScene;
				mListCollider.push_back(box);
			} else {
				CColliderLine* line = new CColliderLine;
				line->Load(file);
				line->mOwner = this;
				line->mScene = mScene;
				mListCollider.push_back(line);
			}
		}
	}
}

void CGameObject::SaveFullPath(const char* fullPath) {
	FILE* file = nullptr;
	fopen_s(&file, fullPath, "wb");
	if (!file)
		return;

	Save(file);
	fclose(file);
}

void CGameObject::LoadFullPath(const char* fullPath) {
	FILE* file = nullptr;
	fopen_s(&file, fullPath, "rb");
	if (!file)
		return;

	Load(file);
	fclose(file);
}

void CGameObject::SaveFileName(const char* fileName, const std::string& pathName) {
	const PathInfo* info = CPathManager::GetInst()->FindPath(pathName);
	char fullPath[MAX_PATH] = {};

	if (info)
		strcpy_s(fullPath, info->pathMultibyte);
	strcat_s(fullPath, fileName);

	SaveFullPath(fullPath);
}

void CGameObject::LoadFileName(const char* fileName, const std::string& pathName) {
	const PathInfo* info = CPathManager::GetInst()->FindPath(pathName);
	char fullPath[MAX_PATH] = {};

	if (info)
		strcpy_s(fullPath, info->pathMultibyte);
	strcat_s(fullPath, fileName);

	LoadFullPath(fullPath);
}

void CGameObject::SetTextureWithDIB(const std::string& name, const TCHAR* fileName) {
	mScene->GetResource()->LoadTextureWithDIB(name, fileName);

	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureWithDIB(const std::string& name, const std::vector<const TCHAR*>& vecFileName) {
	mScene->GetResource()->LoadTextureWithDIB(name, vecFileName);

	mTexture = mScene->GetResource()->FindTexture(name);
}


void CGameObject::SetTexture(CTexture* texture) {
	mTexture = texture;
}
void CGameObject::SetTexture(const std::string& name) {
	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTexture(const std::string& name, const TCHAR* fileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, fileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, fullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTexture(const std::string& name, const std::vector<const TCHAR*>& vecFileName,
							 const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureFullPath(const std::string& name, const std::vector<const TCHAR*>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

//#ifdef UNICODE
//
//void CGameObject::SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName, 
//							 const std::string& pathName) {
//	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
//	mTexture = mScene->GetResource()->FindTexture(name);
//}
//
//void CGameObject::SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath) {
//	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
//	mTexture = mScene->GetResource()->FindTexture(name);
//}
//
//#else
//
//void CGameObject::SetTexture(const std::string& name, const std::vector<std::string>& vecFileName, 
//							 const std::string& pathName) {
//	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
//	mTexture = mScene->GetResource()->FindTexture(name);
//}
//
//void CGameObject::SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath) {
//	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
//	mTexture = mScene->GetResource()->FindTexture(name);
//}
//
//#endif


void CGameObject::SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index) {
	if (mTexture)
		mTexture->SetColorKey(r, g, b, index);
}
void CGameObject::SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b) {
	if (mTexture)
		mTexture->SetColorKeyAll(r, g, b);
}

void CGameObject::CreateSound(const std::vector<std::tuple<ESound_Group, const char*, const char*, int>>& soundInfo) {
	size_t size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			mScene->GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
											 (std::string(std::get<2>(info)) + ".wav").c_str());
		}

		for (int j = 1; j <= count; ++j) {
			mScene->GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j - 1), false,
											 (std::get<2>(info) + std::to_string(j) + ".wav").c_str());
		}
	}
}

// ������ �̸�, �ؽ��� �̸�, ��� + ���� �̸�, ũ��, ����
void CGameObject::CreateAnimationSequence(
	const std::vector<std::tuple<const std::string, const std::string, const TCHAR*, Vector2, int>>& animInfo,
	const std::vector<const TCHAR*>& vecPath, bool frameType, bool createDIB) {
	// ���� �迭�� �̸� + postfix�� ���� �ִϸ��̼ǰ� �ؽ����� �̸��� �ȴ�.
	const char* postfix[] = {"Left", "Right"};
	if (vecPath.size() == 1)
		postfix[0] = "";

	bool createOK = false;
	size_t infoSize = animInfo.size();
	for (int i = 0; i < vecPath.size(); ++i) {
#ifdef UNICODE
		std::wstring path = vecPath[i];
#else
		std::string path = vecPath[i];
#endif

		// ETexture_Type::Frame
		if (frameType) {
			for (size_t j = 0; j < infoSize; ++j) {
				const auto& info = animInfo[j];
				int size = std::get<4>(info);
#ifdef UNICODE
				std::vector<std::wstring> vec(size, path + std::get<2>(info));
				for (int k = 0; k < size; ++k) {
					vec[k] += std::to_wstring(k);
#else
				std::vector<std::string> vec(size, path + std::get<2>(info));
				for (int k = 0; k < size; ++k) {
					vec[k] += std::to_string(k);
#endif
					vec[k] += TEXT(".bmp");
				}
				std::vector<const TCHAR*> vecName;
				for (int k = 0; k < size; ++k)
					vecName.push_back(vec[k].data());

				//std::vector<const TCHAR*> vecName;
				//for (int k = 0; k < size; ++k) {
				//	TCHAR	fileName[MAX_PATH] = {};
				//	wsprintf(fileName, TEXT("%s%s/%d.bmp"), vecPath[i], std::get<2>(info), k);
				//	vecName.push_back(vec[k].data());
				//}

				if (createDIB)
					createOK = mScene->GetResource()->CreateAnimSeqWithDIB(
						std::get<0>(info) + postfix[i], std::get<1>(info) + postfix[i], vecName);
				else
					createOK = mScene->GetResource()->CreateAnimationSequence(
						std::get<0>(info) + postfix[i], std::get<1>(info) + postfix[i], vecName);

				if (createOK) {
					for (int k = 0; k < size; ++k) {
						mScene->GetResource()->AddAnimationFrame(
							std::get<0>(info) + postfix[i], {0.f, 0.f}, std::get<3>(info));
					}
					mScene->GetResource()->SetColorKeyAll(std::get<1>(info) + postfix[i], 255, 0, 255);
				}
			}
		} else {
			// ETexture_Type::Sprite
			for (size_t j = 0; j < infoSize; ++j) {
				auto& info = animInfo[j];
				if (createDIB)
					createOK = mScene->GetResource()->CreateAnimSeqWithDIB(
						std::get<0>(info) + postfix[i],
						std::get<1>(info) + postfix[i], (path + std::get<2>(info)).c_str());
				else
					createOK = mScene->GetResource()->CreateAnimationSequence(
						std::get<0>(info) + postfix[i],
						std::get<1>(info) + postfix[i], (path + std::get<2>(info)).c_str());

				if (createOK) {
					mScene->GetResource()->AddAnimationFullFrame(
						std::get<0>(info) + postfix[i], std::get<3>(info), std::get<4>(info), 1);
					mScene->GetResource()->SetColorKey(std::get<1>(info) + postfix[i], 255, 0, 255);
				}
			}
		}
	}
}