
#include "GameObject.h"
#include "../GameManager.h"

#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneManager.h"
#include "../Scene/SceneResource.h"

#include "../Resource/Animation/AnimationSequence.h"

#include "../Scene/SceneCollision.h"
#include "../Collision/Collider.h"
#include "../Collision/ColliderLine.h"

CGameObject::CGameObject() {
	SetTypeID<CGameObject>();
}

CGameObject::CGameObject(const CGameObject& obj) :
	CRef(obj),
	mScene{nullptr},
	mRenderLayer(obj.mRenderLayer),
	mZOrder{obj.mZOrder},
	mTimeScale(obj.mTimeScale),
	mPos(obj.mPos),
	mSize(obj.mSize),
	mPivot(obj.mPivot),
	mTexture(obj.mTexture)
{
	if (!obj.mAnimation) {
		// �ִϸ��̼� ���� ����
	}
}

CGameObject::~CGameObject() {
	{
		auto iter = mListCollider.begin();
		auto iterEnd = mListCollider.end();
		for (; iter != iterEnd; ++iter) {
			(*iter)->ClearCollisionList();
		}
	}
	{
		auto iter = mListWidgetComponent.begin();
		auto iterEnd = mListWidgetComponent.end();
		for (; iter != iterEnd; ++iter) {
			(*iter)->SetActive(false);
		}
	}

	SAFE_DELETE(mAnimation);
}

void CGameObject::SetImmutableObject() {
	mImmutable = true;
	if (mAnimation) {
		auto iter = mAnimation->mMapAnimation.begin();
		auto iterEnd = mAnimation->mMapAnimation.end();
		for (; iter != iterEnd; ++iter) {
			CTexture* texture = iter->second->GetTexture();
			texture->InitModulatedBits();
		}
	}
	if (mTexture) {
		mTexture->InitModulatedBits();
	}
}

bool CGameObject::Init() {
	return true;
}

void CGameObject::Update(float deltaTime) {
	if (mAnimation) {
		mAnimation->Update(deltaTime * mTimeScale);
		// �ִϸ��̼��� �̹��� ũ��� ����� �ٽ� �����ش�.
		const AnimationFrameData& frameData = mAnimation->GetCurrentFrameData();
		mSize = frameData.end - frameData.start;
	}
}

void CGameObject::PostUpdate(float deltaTime) {
}

void CGameObject::Render(HDC hdc, float deltaTime) {
	Vector2	renderLT = GetWorldToCameraPos() - mPivot * mSize;
	if (mAnimation) {
		const CTexture* texture = mAnimation->GetCurrentSequence()->GetTexture();

		int frameIndex = 0;
		if (texture->GetTextureType() == ETexture_Type::Frame) {
			frameIndex = mAnimation->GetCurrentFrameNumber();
		}

		const AnimationFrameData& frameData = mAnimation->GetCurrentFrameData();
		RenderTexture(hdc, texture, renderLT, mSize, (int)frameData.start.x, (int)frameData.start.y, frameIndex);
	} else if (mTexture) {
		RenderTexture(hdc, mTexture, renderLT, mSize);
	}

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CGameObject::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(int) * 1 + sizeof(float) * 1 + sizeof(Vector2) * 2;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mListCollider.begin()->Get()->GetEnable();
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mSize, sizeof(Vector2));		offset += sizeof(Vector2);

	return true;
}
bool CGameObject::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(bValue & 0x01);
	}
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mSize, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	return true;
}
#pragma warning( pop )



bool CGameObject::OutOfCamera(CCamera* cam) {
	Vector2 vertexLT = mPos - cam->GetPos() - mSize * mPivot;

	return vertexLT.x + mSize.x < 0 || vertexLT.x > cam->GetResolution().x ||
		   vertexLT.y + mSize.y < 0 || vertexLT.y > cam->GetResolution().y;
}

Vector2 CGameObject::GetWorldToCameraPos() {
	if (mScene) {
		return mPos - mScene->GetCamera()->GetPos();
	} else {
		return mPos - CSceneManager::GetInst()->GetScene()->GetCamera()->GetPos();
	}
}

void CGameObject::RenderTexture(HDC hdc, const CTexture* texture, const Vector2& pos, const Vector2& size, 
								int imageX, int imageY, int imageIndex, bool allowMix) {
	texture->ResetModulatedBmpBits(imageIndex);
	if (mImmutable && allowMix) {
		texture->MixColor(mScene->GetImmutableValue(), 0, 255, 0, (int)size.x, (int)size.y, imageX, imageY, imageIndex);
	}

	if (texture->GetEnableColorKey(imageIndex)) {
		TransparentBlt(hdc, (int)pos.x, (int)pos.y, (int)size.x, (int)size.y, 
					   texture->GetDC(imageIndex), imageX, imageY, (int)size.x, (int)size.y, 
					   texture->GetColorKey(imageIndex));
	} else {
		BitBlt(hdc, (int)pos.x, (int)pos.y, (int)size.x, (int)size.y,
			   texture->GetDC(imageIndex), imageX, imageY, SRCCOPY);
	}
}

void CGameObject::RenderAlphaTexture(HDC hdc, const CTexture* texture, UINT8 alphaValue, 
									 const Vector2& pos, const Vector2& size, int imageX, int imageY, int imageIndex) {
	if (!texture->GetEnableAlpha(imageIndex)) {
		RenderTexture(hdc, texture, pos, size, imageX, imageY, imageIndex);
		return;
	}

	//HDC	tempHdc = CreateCompatibleDC(CGameManager::GetInst()->GetBackDC());
	//HBITMAP hbmAlpha = CreateCompatibleBitmap(CGameManager::GetInst()->GetBackDC(), 128, 64);
	//HBITMAP hbmAlphaOld = (HBITMAP)SelectObject(tempHdc, hbmAlpha);

	//BitBlt(tempHdc, 0, 0, 128, 64, hdc, (int)pos.x, (int)pos.y, SRCCOPY);
	//TransparentBlt(tempHdc,
	//			   0, 0, 128, 64, texture->GetDC(imageIndex),
	//			   0, 0, 128, 64, texture->GetColorKey(imageIndex));
	//BLENDFUNCTION tmpbf;
	//memset(&tmpbf, 0, sizeof BLENDFUNCTION);
	//tmpbf.SourceConstantAlpha = 150;
	//AlphaBlend(hdc, (int)pos.x, (int)pos.y, 128, 64,
	//		   tempHdc, 0, 0, 128, 64, tmpbf);

	//SelectObject(tempHdc, hbmAlphaOld);
	//DeleteObject(hbmAlpha);
	//DeleteDC(tempHdc);
	//return;

	BLENDFUNCTION bf;
	memset(&bf, 0, sizeof BLENDFUNCTION);
	bf.SourceConstantAlpha = alphaValue;

	if (texture->GetEnableColorKey(imageIndex)) {
		HDC alphaDC = texture->GetAlphaDC(imageIndex);
		BitBlt(alphaDC, 0, 0, (int)size.x, (int)size.y, hdc, (int)pos.x, (int)pos.y, SRCCOPY);
		TransparentBlt(alphaDC, 0, 0, (int)size.x, (int)size.y,
					   texture->GetDC(imageIndex), imageX, imageY, (int)size.x, (int)size.y,
					   texture->GetColorKey(imageIndex));

		AlphaBlend(hdc, (int)pos.x, (int)pos.y, (int)size.x, (int)size.y,
				   alphaDC, 0, 0, (int)size.x, (int)size.y, bf);
	} else {
		AlphaBlend(hdc, (int)pos.x, (int)pos.y, (int)size.x, (int)size.y,
				   texture->GetDC(imageIndex), imageX, imageY, (int)size.x, (int)size.y, bf);
	}
}

CCollider* CGameObject::FindCollider(const std::string& name) {
	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();

	for (; iter != iterEnd; ++iter) {
		if ((*iter)->GetName() == name)
			return *iter;
	}

	return nullptr;
}

void CGameObject::UpdateCollider(float deltaTime) {
	if (!GetActive() || !GetEnable())
		return;

	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();
	for (; iter != iterEnd;) {
		// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
		if (!(*iter)->GetActive()) {
			iter = mListCollider.erase(iter);
			iterEnd = mListCollider.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->Update(deltaTime);

		// �ݶ��̴��� ���� �ݶ��̴� ����Ʈ�� �߰��Ѵ�.
		mScene->GetCollision()->AddCollider(*iter);
		++iter;
	}
}
void CGameObject::PostUpdateCollider(float deltaTime) {
	if (!GetActive() || !GetEnable())
		return;

	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mListCollider.erase(iter);
			iterEnd = mListCollider.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}
		(*iter)->PostUpdate(deltaTime);
		++iter;
	}
}
void CGameObject::RenderCollider(HDC hdc, float deltaTime) {
	if (!GetActive() || !GetEnable())
		return;

	auto	iter = mListCollider.begin();
	auto	iterEnd = mListCollider.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mListCollider.erase(iter);
			iterEnd = mListCollider.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}
		(*iter)->Render(hdc, deltaTime);
		++iter;
	}
}

void CGameObject::UpdateWidgetComponent(float deltaTime) {
	auto iter = mListWidgetComponent.begin();
	auto iterEnd = mListWidgetComponent.end();
	for (; iter != iterEnd;) {
		// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
		if (!(*iter)->GetActive()) {
			iter = mListWidgetComponent.erase(iter);
			iterEnd = mListWidgetComponent.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->Update(deltaTime);
		++iter;
	}
}

void CGameObject::PostUpdateWidgetComponent(float deltaTime) {
	auto iter = mListWidgetComponent.begin();
	auto iterEnd = mListWidgetComponent.end();
	for (; iter != iterEnd;) {
		// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
		if (!(*iter)->GetActive()) {
			iter = mListWidgetComponent.erase(iter);
			iterEnd = mListWidgetComponent.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->PostUpdate(deltaTime);
		++iter;
	}
}

void CGameObject::SetTextureWithDIB(const std::string& name, const TCHAR* fileName) {
	mScene->GetResource()->LoadTextureWithDIB(name, fileName);

	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureWithDIB(const std::string& name, const std::vector<std::wstring>& vecFileName) {
	mScene->GetResource()->LoadTextureWithDIB(name, vecFileName);

	mTexture = mScene->GetResource()->FindTexture(name);
}


void CGameObject::SetTexture(CTexture* texture) {
	mTexture = texture;
}
void CGameObject::SetTexture(const std::string& name) {
	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTexture(const std::string& name, const TCHAR* fileName,
							 const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, fileName, pathName);

	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureFullPath(const std::string& name,
									 const TCHAR* fullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, fullPath);

	mTexture = mScene->GetResource()->FindTexture(name);
}

#ifdef UNICODE

void CGameObject::SetTexture(const std::string& name,
							 const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);

	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureFullPath(const std::string& name,
									 const std::vector<std::wstring>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);

	mTexture = mScene->GetResource()->FindTexture(name);
}

#else

void CGameObject::SetTexture(const std::string& name,
							 const std::vector<std::string>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);

	mTexture = mScene->GetResource()->FindTexture(name);
}

void CGameObject::SetTextureFullPath(const std::string& name,
									 const std::vector<std::string>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);

	mTexture = mScene->GetResource()->FindTexture(name);
}

#endif


void CGameObject::SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index) {
	if (mTexture)
		mTexture->SetColorKey(r, g, b, index);
}
void CGameObject::SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b) {
	if (mTexture)
		mTexture->SetColorKeyAll(r, g, b);
}

void CGameObject::CreateSound(const std::vector<std::tuple<ESound_Group, const char*, const char*, int>>& soundInfo) {
	size_t size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			mScene->GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
											 (std::string(std::get<2>(info)) + ".wav").c_str());
		}

		for (int j = 1; j <= count; ++j) {
			mScene->GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j - 1), false,
											 (std::get<2>(info) + std::to_string(j) + ".wav").c_str());
		}
	}
}

// ������ �̸�, �ؽ��� �̸�, ��� + ���� �̸�, ũ��, ����
void CGameObject::CreateAnimationSequence(
	const std::vector<std::tuple<const std::string, const std::string, const TCHAR*, Vector2, int>>& animInfo,
	const std::vector<const TCHAR*>& vecPath, bool frameType, bool createDIB) {
	// ���� �迭�� �̸� + postfix�� ���� �ִϸ��̼ǰ� �ؽ����� �̸��� �ȴ�.
	const char* postfix[] = {"Left", "Right"};
	if (vecPath.size() == 1)
		postfix[0] = "";

	bool createOK = false;
	size_t size = animInfo.size();
	for (int i = 0; i < vecPath.size(); ++i) {
#ifdef UNICODE
		std::wstring path = vecPath[i];
#else
		std::string path = vecPath[i];
#endif

		// ETexture_Type::Frame
		if (frameType) {
			for (size_t j = 0; j < size; ++j) {
				const auto& info = animInfo[j];
				int size = std::get<4>(info);
#ifdef UNICODE
				std::vector<std::wstring> vec(size, path + std::get<2>(info));
				for (int k = 0; k < size; ++k) {
					vec[k] += std::to_wstring(k);
#else
				std::vector<std::string> vec(size, path + std::get<2>(info));
				for (int k = 0; k < size; ++k) {
					vec[k] += std::to_string(k);
#endif
					vec[k] += TEXT(".bmp");
				}

				if (createDIB)
					createOK = mScene->GetResource()->CreateAnimSeqWithDIB(
						std::get<0>(info) + postfix[i], std::get<1>(info) + postfix[i], vec);
				else
					createOK = mScene->GetResource()->CreateAnimationSequence(
						std::get<0>(info) + postfix[i], std::get<1>(info) + postfix[i], vec);

				if (createOK) {
					for (int k = 0; k < size; ++k) {
						mScene->GetResource()->AddAnimationFrame(
							std::get<0>(info) + postfix[i], {0.f, 0.f}, std::get<3>(info));
					}
					mScene->GetResource()->SetColorKeyAll(std::get<1>(info) + postfix[i], 255, 0, 255);
				}
			}
		} else {
			// ETexture_Type::Sprite
			for (size_t j = 0; j < size; ++j) {
				auto& info = animInfo[j];
				if (createDIB)
					createOK = mScene->GetResource()->CreateAnimSeqWithDIB(
						std::get<0>(info) + postfix[i],
						std::get<1>(info) + postfix[i], (path + std::get<2>(info)).c_str());
				else
					createOK = mScene->GetResource()->CreateAnimationSequence(
						std::get<0>(info) + postfix[i],
						std::get<1>(info) + postfix[i], (path + std::get<2>(info)).c_str());

				if (createOK) {
					mScene->GetResource()->AddAnimationFullFrame(
						std::get<0>(info) + postfix[i], std::get<3>(info), std::get<4>(info), 1);
					mScene->GetResource()->SetColorKey(std::get<1>(info) + postfix[i], 255, 0, 255);
				}
			}
		}
	}
}