
#include "Boss.h"

#include "../GameManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"

#include "../Resource/Animation/AnimationSequence.h"
#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderLine.h"

#include "Player.h"

// �׽�Ʈ�� ���߿� ������
#include "../Input.h"

CBoss::CBoss() {
	SetTypeID<CBoss>();
}

CBoss::~CBoss() {
}


void CBoss::CreateTextureData() {
	std::vector<const TCHAR*> path = {TEXT("Boss/clockBack.bmp"), TEXT("Boss/clockIdle.bmp"),
		TEXT("Boss/clockMove0.bmp"), TEXT("Boss/clockMove1.bmp"), TEXT("Boss/clockMove2.bmp"),
		TEXT("Boss/clockMoveLeft0.bmp"), TEXT("Boss/clockMoveLeft1.bmp"), TEXT("Boss/clockMoveLeft2.bmp"),
		TEXT("Boss/clockMoveLeft3.bmp"), TEXT("Boss/clockMoveLeft4.bmp"), TEXT("Boss/clockMoveLeft5.bmp"),
		TEXT("Boss/clockMoveLeft6.bmp"), TEXT("Boss/clockMoveLeft7.bmp"),
		TEXT("Boss/clockMoveRight0.bmp"), TEXT("Boss/clockMoveRight1.bmp"), TEXT("Boss/clockMoveRight2.bmp"),
		TEXT("Boss/clockMoveRight3.bmp"), TEXT("Boss/clockMoveRight4.bmp"), TEXT("Boss/clockMoveRight5.bmp"),
		TEXT("Boss/clockMoveRight6.bmp"), TEXT("Boss/clockMoveRight7.bmp"),};

	mScene->GetResource()->LoadTexture("BossCloak", path);
	mCloakTexture = mScene->GetResource()->FindTexture("BossCloak");
	mCloakTexture->SetColorKeyAll(255, 0, 255);


	path = {TEXT("Boss/footLeft.bmp"), TEXT("Boss/footRight.bmp")};

	mScene->GetResource()->LoadTexture("BossFoot", path);
	mFootTexture = mScene->GetResource()->FindTexture("BossFoot");
	mFootTexture->SetColorKeyAll(255, 0, 255);


	path = {TEXT("Boss/armor0.bmp"), TEXT("Boss/armor1.bmp")};

	mScene->GetResource()->LoadTexture("BossArmor", path);
	mArmorTexture = mScene->GetResource()->FindTexture("BossArmor");
	mArmorTexture->SetColorKeyAll(255, 0, 255);


	path = {TEXT("Boss/eye.bmp"), TEXT("Boss/irisLeft.bmp"), TEXT("Boss/irisRight.bmp"),
							TEXT("Boss/irisRedLeft.bmp"), TEXT("Boss/irisRedRight.bmp")};

	mScene->GetResource()->LoadTexture("BossEye", path);
	mEyeTexture = mScene->GetResource()->FindTexture("BossEye");
	mEyeTexture->SetColorKeyAll(255, 0, 255);


	path = {TEXT("Boss/head0.bmp"), TEXT("Boss/head1.bmp"), TEXT("Boss/head2.bmp"), TEXT("Boss/head3.bmp")};

	mScene->GetResource()->LoadTexture("BossHead", path);
	mHeadTexture = mScene->GetResource()->FindTexture("BossHead");
	mHeadTexture->SetColorKeyAll(255, 0, 255);


	path = {TEXT("Boss/mask0.bmp"), TEXT("Boss/mask1.bmp"), TEXT("Boss/mask2.bmp"), TEXT("Boss/mask3.bmp")};

	mScene->GetResource()->LoadTexture("BossMask", path);
	mMaskTexture = mScene->GetResource()->FindTexture("BossMask");
	mMaskTexture->SetColorKeyAll(255, 0, 255);


	path = {TEXT("Boss/mouth0.bmp"), TEXT("Boss/mouth1.bmp"), TEXT("Boss/mouth2.bmp"), TEXT("Boss/mouth3.bmp")};

	mScene->GetResource()->LoadTexture("BossMouth", path);
	mMouthTexture = mScene->GetResource()->FindTexture("BossMouth");
	mMouthTexture->SetColorKeyAll(255, 0, 255);


	path = {TEXT("Boss/cape0.bmp"), TEXT("Boss/cape1.bmp"), TEXT("Boss/cape2.bmp"),
			TEXT("Boss/cape3.bmp"), TEXT("Boss/cape4.bmp"),TEXT("Boss/cape5.bmp"),
			TEXT("Boss/cape6.bmp"), TEXT("Boss/cape7.bmp"), TEXT("Boss/cape8.bmp")};

	mScene->GetResource()->LoadTexture("BossCape", path);
	mCapeTexture = mScene->GetResource()->FindTexture("BossCape");
	mCapeTexture->SetColorKeyAll(255, 0, 255);


	path = {TEXT("Boss/horn.bmp")};

	mScene->GetResource()->LoadTexture("BossHorn", path);
	mHornTexture = mScene->GetResource()->FindTexture("BossHorn");
	mHornTexture->SetColorKeyAll(255, 0, 255);
}



// �׽�Ʈ�� ���߿� ������
void CBoss::SetInput() {
	CInput::GetInst()->AddBindFunction("Left", Input_Type::Down, mScene, [&]() {
		mMouthIndex = (mMouthIndex + 1) % 4;
											  });
	CInput::GetInst()->AddBindFunction("Right", Input_Type::Down, mScene, [&]() {
		mHeadIndex = (mHeadIndex + 1) % 4;
		mMaskIndex = rand() % 4;
											  });
}

bool CBoss::Init() {
	//SetSize(96.f, 76.f);
	SetPivot(0.5f, 1.f);

	mZOrder = (int)ERender_ZOrder::Bullet - 1 ;
	CreateTextureData();

	CGameObject::CreateSound({
		{ESound_Group::Effect, "BossSnore", "boss_snoring", 1},
		{ESound_Group::Effect, "BossAwake", "boss_laugh", 1},
		{ESound_Group::Effect, "BossStomp", "boss_stomp_deep", 1},
		{ESound_Group::Effect, "BossHurt", "boss_hurt", 4},
		{ESound_Group::Effect, "BossDying", "boss_dying", 1},
							 });

	// �浹ü �߰�
	CColliderBox* box = AddCollider<CColliderBox>("Boss");
	box->SetExtent(100.f, 100.f);
	box->SetOffset(0.f, -50.f);
	box->SetCollisionProfile(ECollision_Profile::Monster);
	box->SetCollisionBeginFunction<CBoss>(this, &CBoss::CollisionBegin);
	box->SetCollisionEndFunction<CBoss>(this, &CBoss::CollisionEnd);


	//mBodyCollider->SetEnable(false);
	mPhysicsSimulate = false;

	// �׽�Ʈ�� �Լ�
	SetInput();

	return true;
}

void CBoss::Update(float deltaTime) {
	if (mDead) {
		CCharacter::Update(deltaTime);
		return;
	}

	float scaledDeltaTime = deltaTime * mTimeScale;

	// ���� üũ �� ����
	if (!mSnore && fabs(mScene->GetPlayer()->GetPos().x - mPos.x) < mSnoreAreaRadius) {
		mSnore = true;
		mScene->GetResource()->SoundPlay("BossSnore");
	}

	// �ִϸ��̼� ���¿� ���� �ӷ�, ���� ó��
	// �̹��� �ִϸ��̼��� �Ź� ó������ �ʴ´�.
	//if (!mAlert) {
	//	if (mScene->GetPlayer()->GetPos().x > mAlertXPos)
	//		Alert();
	//	return;
	//}

	// ������ ���������� ��
	if (mCurrentAnimType == ECharacter_AnimType::Jump) {
		mAnimation->AddAnimationInterval(scaledDeltaTime);
		mAnimation->Update(scaledDeltaTime);
		return;
	}

	//mAnimSpaceTime += scaledDeltaTime;
	//if (mCurrentAnimType == ECharacter_AnimType::StareUp && mAnimSpaceTime > mAfterAttackTime) {
	//	// ��� ���¿��� �÷��̾ ����� ���� ��
	//	Vector2 diff = GetPlayerDistance();
	//	if (diff.x > mChaseYDistance || diff.y < mChaseYDistance) {
	//		mWaitAnimType = ECharacter_AnimType::Run;
	//		mCurrentAnimType = ECharacter_AnimType::Idle;
	//	}
	//}

	//if (mCurrentAnimType == ECharacter_AnimType::Attack) {
	//	// ���� ��� ���� mMaxAnimSpaceTime ��ŭ�� �ð��� ������ �����ϵ��� ���
	//	if (mAnimSpaceTime > mMaxAnimSpaceTime) {
	//		if (mWaitAnimType == ECharacter_AnimType::Attack)
	//			Attack();
	//		mAnimation->AddAnimationInterval(scaledDeltaTime);
	//	}
	//}

	//// �е� �ִϸ��̼��� ���� �� �� ��
	//if (mCurrentAnimType == ECharacter_AnimType::Idle && mAnimSpaceTime > mMaxAnimSpaceTime) {
	//	if (mWaitAnimType == ECharacter_AnimType::Run) {
	//		Hop();
	//	} else if (mWaitAnimType == ECharacter_AnimType::StareUp) {
	//		ChangeAnimation(ECharacter_AnimType::StareUp);
	//		mVelocity.x = 0.f;
	//	}
	//}

	// �ִϸ��̼� ������ ������ ���� �ֱ� ������ �ִϸ��̼� ���� �ڵ� ���Ŀ� �����ؾ� �Ѵ�.
	CCharacter::Update(deltaTime);
}

void CBoss::PostUpdate(float deltaTime) {
	if (mDead) {
		// 69.f�� dead �ִϸ��̼��� ���� ���� ���̴�.
		if ((mPos.y - 69.f - mScene->GetCamera()->GetPos().y) > CGameManager::GetInst()->GetResolution().height)
			SetEnable(false);
		return;
	}

	CCharacter::PostUpdate(deltaTime);
}

void CBoss::Render(HDC hdc, float deltaTime) {
	// ���� ���� : ���� ����, ����(cloak), ��, ����, ������(cape), ����, ȫä, ��, ����ũ, ��, ��
	// cape4 ���ʹ� �� ó�� �������� ������ �Ѵ�.
	const Vector2& pos = GetWorldToCameraPos(mPos);

	// ���� ��ġ Ȯ��
	const Vector2 armorPos{pos.x, pos.y - 79.f - 9.f + mArmorOffset};
	Vector2 size;

	// ������ ������
	if (mCapeIndex >= 3) {
		size = mCapeTexture->GetSize(mCapeIndex);
		RenderTexture(hdc, mCapeTexture, {pos.x - size.x * 0.5f, armorPos.y + (mCapeIndex == 3 ? -17.f : 10.f)},
					  size, 0, 0, mCapeIndex);
	}

	// ���� ������
	size = mCloakTexture->GetSize(); // ����
	RenderTexture(hdc, mCloakTexture, {pos.x - size.x * 0.5f, armorPos.y + 18.f}, size);
	size = mCloakTexture->GetSize(mCloakIndex);
	RenderTexture(hdc, mCloakTexture, {pos.x - size.x * 0.5f, armorPos.y + 17.f}, size, 0, 0, mCloakIndex);

	// �� ������
	size = mFootTexture->GetSize(0);
	RenderTexture(hdc, mFootTexture, {pos.x - 78.f, pos.y - size.y - mFootOffset[0]}, size);
	size = mFootTexture->GetSize(1);
	RenderTexture(hdc, mFootTexture, {pos.x + 28.f, pos.y - size.y - mFootOffset[1]}, size, 0, 0, 1);

	// ���� ������
	int index = mDead ? 0 : 1;
	size = mArmorTexture->GetSize(index);
	RenderTexture(hdc, mArmorTexture, {pos.x - size.x * 0.5f, armorPos.y}, size, 0, 0, index);

	// ������ ������
	if (mCapeIndex < 3) {
		size = mCapeTexture->GetSize(mCapeIndex);
		RenderTexture(hdc, mCapeTexture, {pos.x - size.x * 0.5f, armorPos.y + 3.f}, size, 0, 0, mCapeIndex);
	}


	// �Ӹ� ��ġ Ȯ��
	const Vector2 headPos{pos.x, armorPos.y - 94.f + mHeadOffset};

	// ������ ������
	if (mMaskIndex > 0) {
		// ����
		size = mEyeTexture->GetSize();
		float left = pos.x - size.x * 0.5f;
		RenderTexture(hdc, mEyeTexture, {left, headPos.y + 33.f}, size);
		// ���� ȫä
		index = mHitProcess ? 3 : 1;
		RenderTexture(hdc, mEyeTexture, {left + 16.f + mIrisOffset[0].x, headPos.y + 48.f + mIrisOffset[0].y},
					  mEyeTexture->GetSize(index), 0, 0, index);
		// ������ ȫä
		index = mHitProcess ? 4 : 2;
		RenderTexture(hdc, mEyeTexture, {left + 82.f + mIrisOffset[1].x, headPos.y + 48.f + mIrisOffset[1].y},
					  mEyeTexture->GetSize(index), 0, 0, index);
	}


	// �Ӹ� ������
	size = mHeadTexture->GetSize(mHeadIndex);
	RenderTexture(hdc, mHeadTexture, {pos.x - size.x * 0.5f, headPos.y}, size, 0, 0, mHeadIndex);
	// �� ����ũ ������
	size = mMaskTexture->GetSize(mMaskIndex);
	RenderTexture(hdc, mMaskTexture, {pos.x - size.x * 0.5f, headPos.y + 23.f}, size, 0, 0, mMaskIndex);
	// �� ������
	size = mMouthTexture->GetSize(mMouthIndex);
	RenderTexture(hdc, mMouthTexture, {pos.x - size.x * 0.5f, headPos.y + 70.f}, size, 0, 0, mMouthIndex);


	// �� ������
	if (mHP > 0) {
		size = mHornTexture->GetSize();
		float left = pos.x - size.x * 0.5f;
		int imageX = mHP > 4 ? 0 : mHP > 2 ? 34 : 61;
		size.x = mHP == 4 ? size.x - 34.f :
				 mHP == 3 ? size.x - 68.f :	// -34.f -34.f
				 mHP == 2 ? size.x - 95.f : // -34.f -34.f -27.f
				 mHP == 1 ? size.x - 122.f : size.x;
		RenderTexture(hdc, mHornTexture, {left + imageX, headPos.y - 37.f}, size, imageX);
	}

	RenderCollider(hdc, deltaTime);
}



void CBoss::Alert() {
	if (mAlert)
		return;

	mAlert = true;
	mScene->GetResource()->SoundPlay("BossAwake");
}

void CBoss::Dead(bool randomX, bool ignoreVelocity) {
	if (mDead)
		return;

	mGravity *= 1.6f;	// 0.5 * 1.6 = 0.8
	CCharacter::Dead(randomX, ignoreVelocity);
	mScene->GetResource()->SoundPlay("BossDying");
}

//void CBoss::Landing(CCollider* col) {
//	CCharacter::Landing(col);
//
//	if (mCurrentAnimType == ECharacter_AnimType::Jump)
//		return;
//
//	if (mScene->GetPlayer()->CheckDead()) {
//		mWaitAnimType = ECharacter_AnimType::Idle;
//		ChangeAnimation(ECharacter_AnimType::Idle);
//		mVelocity.x = 0.f;
//		return;
//	}
//
//	// ���� ����
//	if (mCurrentAnimType == ECharacter_AnimType::Attack) {
//		mHopCount = 0;
//		mAnimSpaceTime = 0.f;
//
//		mVelocity.x = 0.f;
//		ChangeAnimation(ECharacter_AnimType::StareUp);
//	} else {
//		Vector2 diff = mPos - mScene->GetPlayer()->GetPos();
//		diff.x = fabs(diff.x);
//		diff.y = fabs(diff.y);
//		// ���� �غ�
//		if (mHopCount >= mHopCountBeforeAttack &&
//			diff.x <= mAttackDistance && diff.y <= mChaseYDistance) {
//			mAnimSpaceTime = 0.f;
//
//			mVelocity.x = 0.f;
//			mWaitAnimType = ECharacter_AnimType::Attack;
//			ChangeAnimation(ECharacter_AnimType::Attack);
//			mScene->GetResource()->SoundPlay("MimicAttack" + std::to_string(rand() % 4));
//		}
//		// �÷��̾ �Ӹ� ���� �ִ� ���
//		if (diff.x < mChaseXDistance && diff.y > mChaseYDistance) {
//			if (mCurrentAnimType != ECharacter_AnimType::StareUp) {
//				mWaitAnimType = ECharacter_AnimType::StareUp;
//				ChangeAnimation(ECharacter_AnimType::Idle);
//			}
//		} else if (mCurrentAnimType == ECharacter_AnimType::Run) {
//			ChangeAnimation(ECharacter_AnimType::Idle);
//		}
//	}
//}
//
//void CBoss::Alert() {
//	mAlert = true;
//	mPhysicsSimulate = true;
//	mBodyCollider->SetEnable(true);
//	SetDirection();
//	// TODO �ν� ���� �߰�
//}
//
//void CBoss::Hop() {
//	CCharacter::Jump(mHopYSpeed);
//
//	// x�� �ӷ� ó��
//	SetDirection();
//	if (fabs(mPos.x - mScene->GetPlayer()->GetPos().x) < mChaseRadius)
//		mVelocity.x = mLookDir * mHopXSpeed;
//	else
//		mVelocity.x = mLookDir * 50.f;
//
//	if (mCurrentAnimType == ECharacter_AnimType::Run)
//		ResetCurrentAnimation();
//	else
//		ChangeAnimation(ECharacter_AnimType::Run);
//
//	mScene->GetResource()->SoundPlay("MimicHop");
//
//	++mHopCount;
//}
//
//void CBoss::Attack() {
//	CCharacter::Jump(mAttackYSpeed);
//
//	//SetDirection();
//	mVelocity.x = mLookDir * mAttackXSpeed;
//	mWaitAnimType = ECharacter_AnimType::StareUp;
//	// TODO ���� �� ���ư��� ȿ���� �ֱ�
//	//mScene->GetResource()->SoundPlay("MimicAttack" + std::to_string(rand() % 4));
//}
//
//void CBoss::Bound() {
//	if (!mFloating)
//		return;
//
//	CCharacter::Jump(mBoundSpeed);
//	mScene->GetResource()->SoundPlay("MimicBound");
//}


void CBoss::CollisionBegin(CCollider* src, CCollider* dest) {
	// ��ٸ�, ���� ���� �͵��� �ش� Ŭ���� �ݶ��̴����� �÷��̾��� �Լ��� ȣ���ϰ� �Ѵ�.
	if (dest->GetProfile()->type == ECollision_Profile::Player) {
		// �÷��̾���� ��ġ�� ����ؼ� ���̴���, ������ ���ϴ��� Ȯ��
		CPlayer* player = (CPlayer*)dest->GetOwner();
		// ų ���� ����
		float killArea = mCurrentAnimType == ECharacter_AnimType::Attack ? 30.f : 15.f;
		if (mPos.y - player->GetPos().y > killArea) { // �ݶ��̴� ���� ũ��(40.f) - ų ���� ����
			// ���Ͱ� �������� �� ���ÿ� ���� �ʵ��� ������ Ȯ���Ѵ�.
			if (!player->CheckBounding()) {
				player->Bound();
				Dead(false, true);
			}
		} else {
			player->Dead(false, true);
			// TODO ���� ų ���� �߰� (bite)
			//mScene->GetResource()->SoundPlay("MonstarDead" + std::to_string(rand() % 2));
			if (player->GetPos().y - mPos.y > 56.f) { // �÷��̾� Ű(76.f) - 20.f
				//Bound();
			}
		}
		return;
	}

	// ������ ���� �⵵�� ���� ������ �Ǿ� �ִ�.
	if (dest->GetProfile()->type == ECollision_Profile::Terrain) {
		mFloorNextCollider = dest;
	}
}

void CBoss::CollisionEnd(CCollider* src, CCollider* dest) {
	// �׶��� �ܿ��� ���� �����Ѵ�.
	if (dest->GetProfile()->type != ECollision_Profile::Terrain)
		return;

	if (dest == mFloorCollider) {
		mFloorCollider = nullptr;
	} else if (dest == mFloorNextCollider) {
		mFloorNextCollider = nullptr;
	}
}