#pragma once

#include "Bullet.h"

class CCannonBullet : public CBullet {
	friend class CScene;

protected:
	CCannonBullet();
	CCannonBullet(const CCannonBullet& obj);
	~CCannonBullet();


public:
	virtual bool Init();

//protected:
//	void CollisionBegin(CCollider* src, CCollider* dest);
};