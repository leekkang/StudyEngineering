#pragma once

#include "GameObject.h"

class CCannon : public CGameObject {
};

