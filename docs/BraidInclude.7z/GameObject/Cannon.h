#pragma once

#include "GameObject.h"

enum class ECannon_Type : UINT8 {
	Bullet,
	Monstar,
	Cloud
};

class CCannon : public CGameObject {
	friend class CScene;

private:
	CCannon();
	~CCannon();
	DISALLOW_COPY_AND_ASSIGN(CCannon)


private:
	ECannon_Type mCannonType	= ECannon_Type::Bullet;

	int			 mBulletCount	= 0;
	Vector2		 mBulletVelocity;
	
	float		 mSpawnTime		= 0.f;
	Vector2		 mSpawnPoint;

	bool		 mSpawning		= true;
	bool		 mEnableCount	= false;
	int			 mSpawnIndex	= 0;
	float		 mSpawnDeltaTime = 0.f;

	CWidgetComponent* mTimer	= nullptr;
	std::vector<CGameObject*> mVecBullet;

public:
	void SetCannonType(ECannon_Type type) {
		mCannonType = type;
	}
	void SetBulletCount(int count) {
		mBulletCount = count;
	}
	void SetBulletVelocity(float x, float y) {
		mBulletVelocity.x = x;
		mBulletVelocity.y = y;
	}
	void SetBulletVelocity(const Vector2& vel) {
		mBulletVelocity = vel;
	}

	void SetSpawnTime(float time) {
		mSpawnTime = time;
		mSpawnDeltaTime = time;
	}
	void SetSpawnPos(float x, float y) {
		mSpawnPoint.x = x;
		mSpawnPoint.y = y;
	}
	void SetSpawnPos(const Vector2& vel) {
		mSpawnPoint = vel;
	}

	void SetObjectTexture(const TCHAR* fileName, bool immutable);
	void InitBullet();

public:
	virtual bool Init();
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(const UINT8* data);

private:
	void SpawnBullet();
};