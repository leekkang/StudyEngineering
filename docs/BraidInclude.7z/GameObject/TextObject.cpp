
#include "TextObject.h"

#include "../Resource/Font/Font.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"


CTextObject::CTextObject() {
	SetTypeID<CTextObject>();
	mText = new TCHAR[mCapacity]{};
	//memset(mText, 0, sizeof(TCHAR) * mCapacity);
}

CTextObject::CTextObject(const CTextObject& obj) :
	CGameObject(obj) 
{
}

CTextObject::~CTextObject() {
	SAFE_DELETE_ARRAY(mText);
}

void CTextObject::SetFont(const std::string& name) {
	mFont = mScene->GetResource()->FindFont(name);
}

bool CTextObject::Init() {
	return true;
}

void CTextObject::Render(HDC hdc, float deltaTime) {
	mFont->SetFont(hdc);

	SetBkMode(hdc, TRANSPARENT);

	Vector2	renderLT = GetWorldToCameraPos(mPos) - mPivot * mSize;
	if (mShadow) {
		::SetTextColor(hdc, mShadowColor);
		TextOut(hdc, (int)(renderLT.x + mShadowOffset.x), (int)(renderLT.y + mShadowOffset.y), mText, mCount);
	}
	::SetTextColor(hdc, mTextColor);
	TextOut(hdc, (int)renderLT.x, (int)renderLT.y, mText, mCount);

	mFont->ResetFont(hdc);
}
