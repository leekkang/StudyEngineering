
#include "Bullet.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"

#include "Player.h"
#include "../Collision/ColliderCircle.h"
#include "Effect.h"

CBullet::CBullet() {
	SetTypeID<CBullet>();
}

CBullet::~CBullet() {
}

void CBullet::CreateAnimation() {
	CGameObject::CreateAnimation();

	// ������ �̸�, �ؽ��� �̸�, ��� + ���� �̸�, ũ��, ���� (ETexture_Type::Frame)
	std::vector<std::tuple<const std::string, const std::string, const TCHAR*, Vector2, int>> frameAnimInfo{
		{"Bullet", "Bullet", TEXT(""), {50.f, 50.f}, 28},
	};
	CreateAnimationSequence(frameAnimInfo, {TEXT("Object/Bullet/")});

	// �ִϸ��̼� ���� ����
	AddAnimationInfo("Fire", "Bullet", 28 * 0.05f, true);
}

bool CBullet::Init() {
	SetPos(0.f, 0.f);
	SetPivot(0.5f, 0.5f);
	SetSize(50.f, 50.f);

	CreateAnimation();
	SetZOrder((int)ERender_ZOrder::Bullet);

	CGameObject::CreateSound({
		{ESound_Group::Effect, "HitBullet", "bullet_hits_bullet", 1},
		{ESound_Group::Effect, "HitPlayer", "bullet_hits_player", 1},
		{ESound_Group::Effect, "HitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "HitWall", "bullet_hits_wall", 3},
							 });

	CColliderCircle* col = AddCollider<CColliderCircle>("BulletBody");
	col->SetRadius(15.f);
	col->SetCollisionProfile(ECollision_Profile::Attack);
	col->SetCollisionBeginFunction<CBullet>(this, &CBullet::CollisionBegin);
	col->SetCollisionEndFunction<CBullet>(this, &CBullet::CollisionEnd);

	return true;
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CBullet::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) * 2 + sizeof(int) * 2 + sizeof(float) * 2 + 
					  sizeof(Vector2) * 2 + sizeof(char*) * 1;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mListCollider.begin()->Get()->GetEnable();
	bValue = bValue << 1 | mEnable;
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);

	CAnimationInfo* info = mAnimation->GetCurrentAnimationInfo();
	memcpy(data + offset, &info, sizeof(char*));		offset += sizeof(char*);
	int frameNum = mAnimation->GetCurrentFrameNumber();
	memcpy(data + offset, &frameNum, sizeof(int));		offset += sizeof(int);
	float interval = mAnimation->GetCurrentInterval();
	memcpy(data + offset, &interval, sizeof(float));	offset += sizeof(float);
	UINT8 animationEnd = mAnimation->GetCurrentAnimationEnd();
	memcpy(data + offset, &animationEnd, sizeof(UINT8)); offset += sizeof(UINT8);

	// CMovableObject
	memcpy(data + offset, &mVelocity, sizeof(Vector2));	offset += sizeof(Vector2);

	return true;
}
bool CBullet::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mEnable = bValue & 0x01;
	bValue >>= 1;
	bool enable = bValue & 0x01;
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(enable);
		if (!enable)
			(*iter)->ClearCollisionList();
	}
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	CAnimationInfo* info;
	memcpy(&info, data + offset, sizeof(char*));		offset += sizeof(char*);
	int frameNum;
	memcpy(&frameNum, data + offset, sizeof(int));		offset += sizeof(int);
	info->SetFrameNumber(frameNum);
	float interval;
	memcpy(&interval, data + offset, sizeof(float));	offset += sizeof(float);
	info->SetCurrentInterval(interval);
	memcpy(&bValue, data + offset, sizeof(UINT8));		offset += sizeof(UINT8);
	info->SetAnimationEnd(bValue & 0x01);

	mAnimation->SetCurrentAnimationInfo(info);

	// CMovableObject
	memcpy(&mVelocity, data + offset, sizeof(Vector2)); offset += sizeof(Vector2);

	return true;
}
#pragma warning( pop )


void CBullet::CollisionBegin(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type == ECollision_Profile::Terrain) {
		mScene->GetResource()->SoundPlay("HitWall" + std::to_string(rand() % 3));
		// TODO ����Ʈ �߰�
		SetEnable(false);
		src->ClearCollisionList();
	} else if (dest->GetProfile()->type == ECollision_Profile::Attack) {
		mScene->GetResource()->SoundPlay("HitBullet");
		// TODO ����Ʈ �߰�
		SetEnable(false);
		src->ClearCollisionList();
	} else {
		((CCharacter*)dest->GetOwner())->DeadByCannon(mVelocity.x, mVelocity.y);
		if (dest->GetProfile()->type == ECollision_Profile::Player) {
			mScene->GetResource()->SoundPlay("HitPlayer");
		} else {
			mScene->GetResource()->SoundPlay("HitOther");
		}
	}
}

void CBullet::CollisionEnd(CCollider* src, CCollider* dest) {
}
