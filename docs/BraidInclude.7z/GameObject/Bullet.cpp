
#include "Bullet.h"
#include "../Collision/ColliderCircle.h"
#include "../Scene/Scene.h"
#include "Character.h"
#include "Effect.h"

CBullet::CBullet() {
	SetTypeID<CBullet>();
}

CBullet::CBullet(const CBullet& obj) :
	CGameObject(obj),
	mDirection{obj.mDirection},
	mDistance(obj.mDistance),
	mDamage(obj.mDamage)  {
}

CBullet::~CBullet() {
}

bool CBullet::Init() {
	SetPos(0.f, 0.f);
	SetPivot(0.5f, 0.5f);
	mMoveSpeed = 700.f;
	mDistance = 1500.f;
	mDamage = 7.f;

	// ����� �ؽ�ó ������� ũ�� �ȳ��� ���� �ִ�.
	SetTexture("Bullet", TEXT("Mouse/6.bmp"));
	SetSize(20.f, 20.f);
	SetColorKey(255, 0, 255);


	CColliderCircle* col = AddCollider<CColliderCircle>("BulletBody");
	col->SetRadius(30.f);
	col->SetCollisionProfile(ECollision_Profile::Default);
	
	col->SetCollisionBeginFunction<CBullet>(this, &CBullet::CollisionBegin);
	col->SetCollisionEndFunction<CBullet>(this, &CBullet::CollisionEnd);

	return true;
}

void CBullet::Update(float deltaTime) {
	CGameObject::Update(deltaTime);
	deltaTime *= mTimeScale;

	//MoveDir(mDirection);
	mDistance -= mMoveSpeed * deltaTime;

	if (mDistance <= 0.f)
		SetActive(false);
}

void CBullet::PostUpdate(float deltaTime) {
	CGameObject::PostUpdate(deltaTime);
}

void CBullet::Render(HDC hdc, float deltaTime) {
	CGameObject::Render(hdc, deltaTime);
}

void CBullet::CollisionBegin(CCollider* src, CCollider* dest) {
	SetActive(false);

	CEffect* effect = mScene->CreateObject<CEffect>("Explode");
	effect->SetPos(src->GetHitPoint());
	effect->SetPivot(0.5f, 0.5f);

	effect->AddAnimationInfo("HitEffectRight", .3f, false);
	((CCharacter*)(dest->GetOwner()))->SetDead();
}

void CBullet::CollisionEnd(CCollider* src, CCollider* dest) {
}
