
#include "BackObj.h"

CBackObj::CBackObj() {
	SetTypeID<CBackObj>();
	mRenderLayer = ERender_Layer::Back;
}

CBackObj::CBackObj(const CBackObj& obj) :
	CGameObject(obj) {
}

CBackObj::~CBackObj() {
}

void CBackObj::SetTexture(const TCHAR* path) {
	CGameObject::SetTexture("BG", path);
	SetSize(1600.f, 900.f);
}

bool CBackObj::Init() {
	SetPos(0.f, 0.f);
	SetPivot(0.f, 0.f);

	return true;
}

void CBackObj::Render(HDC hdc, float deltaTime) {
	BitBlt(hdc, 0, 0, (int)mSize.x, (int)mSize.y, mTexture->GetDC(), 0, 0, SRCCOPY);
}
