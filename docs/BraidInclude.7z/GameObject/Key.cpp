
#include "Key.h"

#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"
#include "../Scene/SceneManager.h"

#include "../Collision/ColliderBox.h"
#include "Character.h"
#include "Player.h"

CKey::CKey() {
	SetTypeID<CKey>();
}

CKey::~CKey() {
}

bool CKey::Init() {
	CGameObject::Init();
	SetSize(54.f, 45.f);
	SetPivot(0.5f, 1.f);

#ifdef UNICODE
	std::vector<std::wstring> path{L"Object/key1Left.bmp", L"Object/key1Right.bmp",
								   L"Object/key2Left.bmp", L"Object/key2Right.bmp"};
#else
	std::vector<std::string> path{"Object/key1Left.bmp", "Object/key1Right.bmp",
								  "Object/key2Left.bmp", "Object/key2Right.bmp"};
#endif
	SetTexture("Key", path);
	SetColorKeyAll(255, 0, 255);


	CGameObject::CreateSound({
		{ESound_Group::Effect, "KeyBreak", "key_break", 1},
		{ESound_Group::Effect, "PlayerGetsKey", "player_gets_key", 1},
		{ESound_Group::Effect, "MonsterGetsKey", "monstar_gets_key", 1},
		{ESound_Group::Effect, "PlayerGetsExemptKey", "player_gets_exempt_key", 1},
							 });


	// �浹ü �߰�
	CColliderBox* box = AddCollider<CColliderBox>("Key");
	box->SetExtent(54.f, 45.f);
	box->SetOffset(0.f, -23.f);
	box->SetCollisionProfile(ECollision_Profile::Object);
	box->SetCollisionBeginFunction<CKey>(this, &CKey::CollisionBegin);
	box->SetCollisionEndFunction<CKey>(this, &CKey::CollisionEnd);

	return true;
}

void CKey::Update(float deltaTime) {
	if (mOwner) {
		if (mOwner->CheckDead()) {
			mOwner = nullptr;
			return;
		}
		mLookLeft = mOwner->CheckLookLeft();
	}
}

void CKey::PostUpdate(float deltaTime) {
	if (mOwner) {
		const Vector2& ownerPos = mOwner->GetPos();
		if (mPlayerHave) {
			mPos.y = ownerPos.y - 10.f;
			mPos.x = ownerPos.x + (mOwner->CheckLookLeft() ? -20.f : 20.f);
		} else {
			// TODO �ϵ��ڵ� �����ϱ�
			mPos.y = ownerPos.y - 10.f;
			mPos.x = ownerPos.x + (mOwner->CheckLookLeft() ? -20.f : 20.f);
		}
	}

	mSize.x = mUsed ? 58.f : 54.f;
}

void CKey::Render(HDC hdc, float deltaTime) {
	Vector2	renderLT = GetWorldToCameraPos() - mPivot * mSize;
	int index = mLookLeft ? 0 : 1;
	
	RenderTexture(hdc, mTexture, renderLT, mSize, 0, 0, mUsed ? index + 2 : index);

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CKey::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(int) * 1 + sizeof(float) * 1 + 
						sizeof(Vector2) * 2 + sizeof(char*) * 1;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bvalue = mListCollider.begin()->Get()->GetEnable();
	bvalue = bvalue << 1 | mUsed;
	bvalue = bvalue << 1 | mPlayerHave;
	bvalue = bvalue << 1 | mLookLeft;
	data[offset] = bvalue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mZOrder, sizeof(int));		offset += sizeof(int);
	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mSize, sizeof(Vector2));		offset += sizeof(Vector2);

	memcpy(data + offset, &mOwner, sizeof(char*));		offset += sizeof(char*);

	return true;
}
bool CKey::Deserialize(UINT8* data) {
	int offset = 0;

	// boolean
	byte bvalue = data[offset];
	mLookLeft = bvalue & 0x01;
	bvalue >>= 1;
	mPlayerHave = bvalue & 0x01;
	bvalue >>= 1;
	mUsed = bvalue & 0x01;
	bvalue >>= 1;
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		(*iter)->SetEnable(bvalue & 0x01);
	}
	++offset;

	// CGameObject
	memcpy(&mZOrder, data + offset, sizeof(int));		offset += sizeof(int);
	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mSize, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	memcpy(&mOwner, data + offset, sizeof(char*));		offset += sizeof(char*);

	return true;
}
#pragma warning( pop )



void CKey::UnlockGate(CColliderBox* box) {
	mUsed = true;
	mOwner = nullptr;
	float x = mLookLeft ? box->GetInfo().RB.x + 20.f :
						  box->GetInfo().LT.x - 20.f;
	SetPos(x, box->GetInfo().RB.y);
	mListCollider.begin()->Get()->SetEnable(false);

	mScene->GetResource()->SoundPlay("KeyBreak");
}

void CKey::CollisionBegin(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type == ECollision_Profile::Player) {
		if (!mOwner || mOwner->GetTypeID() != typeid(CPlayer).hash_code()) {
			mOwner = (CPlayer*)dest->GetOwner();
			mPlayerHave = true;
		}
	} else if (dest->GetProfile()->type == ECollision_Profile::Monster) {
		if (!mOwner) {
			mOwner = (CCharacter*)dest->GetOwner();
			mPlayerHave = false;
		}
	}
}

void CKey::CollisionEnd(CCollider* src, CCollider* dest) {
}
