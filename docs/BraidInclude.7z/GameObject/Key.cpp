
#include "Key.h"

#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"

#include "../Collision/ColliderBox.h"
#include "Character.h"
#include "Player.h"

CKey::CKey() {
	SetTypeID<CKey>();
}
CKey::~CKey() {
}

void CKey::SetObjectTexture(bool immutable) {
	std::vector<const TCHAR*> path{TEXT("Object/key1Left.bmp"), TEXT("Object/key1Right.bmp"),
								   TEXT("Object/key2Left.bmp"), TEXT("Object/key2Right.bmp")};

	if (immutable) {
		SetTextureWithDIB("KeyDIB", path);
		SetImmutableObject();
	} else {
		SetTexture("Key", path);
	}
	SetColorKeyAll(255, 0, 255);

	mSize = mTexture->GetSize();
}

bool CKey::Init() {
	CGameObject::Init();
	//SetSize(54.f, 45.f);
	SetPivot(0.5f, 1.f);

	mZOrder = (int)ERender_ZOrder::Foothold - 1;
	SetPhysicsSimulate(false);

	CGameObject::CreateSound({
		{ESound_Group::Effect, "KeyBreak", "key_break", 1},
		{ESound_Group::Effect, "PlayerGetsKey", "player_gets_key", 1},
		{ESound_Group::Effect, "MonsterGetsKey", "monstar_gets_key", 1},
		{ESound_Group::Effect, "PlayerGetsExemptKey", "player_gets_exempt_key", 1},
							 });


	// �浹ü �߰�
	CColliderBox* box = AddCollider<CColliderBox>("Key");
	box->SetExtent(54.f, 45.f);
	box->SetOffset(0.f, -23.f);
	box->SetCollisionProfile(ECollision_Profile::MoveObj);
	box->SetCollisionBeginFunction<CKey>(this, &CKey::CollisionBegin);
	box->SetCollisionEndFunction<CKey>(this, &CKey::CollisionEnd);

	return true;
}

void CKey::Update(float deltaTime) {
	if (mOwner) {
		if (mOwner->CheckDead()) {
			Drop();
			return;
		}
		mLookLeft = mOwner->CheckLookLeft();
	}

	CMovableObject::Update(deltaTime);
}

void CKey::PostUpdate(float deltaTime) {
	mSize.x = mUsed ? 58.f : 54.f;

	if (!mOwner)
		return;

	const Vector2& ownerPos = mOwner->GetPos();
	if (!mPlayerHave) {
		mPos.y = ownerPos.y - 10.f;
		mPos.x = ownerPos.x + (mOwner->CheckLookLeft() ? -40.f : 40.f);
		return;
	}

	ECharacter_AnimType type = ((CPlayer*)mOwner)->GetCurrentAnimType();
	int frameNum = ((CPlayer*)mOwner)->GetCurrentAnimFrame();
	Vector2 offset{20.f, -10.f};
	Vector2 keyOffset{26.f, 22.f};
	if (type == ECharacter_AnimType::Run) {
		// �ǹ��� �ȹٲٰ� ���� ��ǥ�� �����Ѵ�.
		offset = RunMotionPos[frameNum] + keyOffset;
	} else if (type == ECharacter_AnimType::Jump) {
		offset = JumpMotionPos[frameNum] + keyOffset;
	} else if (type == ECharacter_AnimType::JumpForward) {
		offset = JumpForwardMotionPos[frameNum] + keyOffset;
	} else if (type == ECharacter_AnimType::BoundLow) {
		offset = BoundMotionPos[frameNum] + keyOffset;
	} else if (type == ECharacter_AnimType::BoundForwardLow) {
		offset = BoundForwardMotionPos[frameNum] + keyOffset;
	} else if (type == ECharacter_AnimType::Fall) {
		offset = FallMotionPos[frameNum] + keyOffset;
	} else if (type == ECharacter_AnimType::Ladder) {
		// �̳��� �¿찡 ��� ����ó��
		offset = LadderMotionPos[frameNum];
		offset.y += 22.f;
		mPos = ownerPos + offset;
		return;
	} else if (type == ECharacter_AnimType::LadderAside) {
		offset = LadderAsideMotionPos[frameNum];
		offset.y += 22.f;
	} else {
		offset.x = 16.f + keyOffset.x;
		offset.y = -23.f + keyOffset.y;
	}
	mPos.x = ownerPos.x + (mOwner->CheckLookLeft() ? -offset.x : offset.x);
	mPos.y = ownerPos.y + offset.y;
}

void CKey::Render(HDC hdc, float deltaTime) {
	int index = mLookLeft ? 0 : 1;
	
	RenderTexture(hdc, mUsed ? index + 2 : index);

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CKey::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(float) * 1 + sizeof(Vector2) * 2 + sizeof(char*) * 1;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mListCollider.front()->GetEnable();
	bValue = bValue << 1 | mPhysicsSimulate;
	bValue = bValue << 1 | mUsed;
	bValue = bValue << 1 | mPlayerHave;
	bValue = bValue << 1 | mLookLeft;
	data[offset] = bValue;
	++offset;

	memcpy(data + offset, &mTimeScale, sizeof(float));	offset += sizeof(float);
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(data + offset, &mSize, sizeof(Vector2));		offset += sizeof(Vector2);

	memcpy(data + offset, &mOwner, sizeof(char*));		offset += sizeof(char*);

	return true;
}
bool CKey::Deserialize(const UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mLookLeft = bValue & 0x01;
	bValue >>= 1;
	mPlayerHave = bValue & 0x01;
	bValue >>= 1;
	mUsed = bValue & 0x01;
	bValue >>= 1;
	mPhysicsSimulate = bValue & 0x01;
	bValue >>= 1;
	bool enable = bValue & 0x01;
	CCollider* col = mListCollider.front();
	col->SetEnable(enable);
	if (!enable)
		col->ClearCollisionList();

	//auto iter = mListCollider.begin();
	//auto iterEnd = mListCollider.end();
	//for (; iter != iterEnd; ++iter) {
	//	(*iter)->SetEnable(enable);
	//	if (!enable)
	//		(*iter)->ClearCollisionList();
	//}
	++offset;

	memcpy(&mTimeScale, data + offset, sizeof(float));  offset += sizeof(float);
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	memcpy(&mSize, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);

	memcpy(&mOwner, data + offset, sizeof(char*));		offset += sizeof(char*);

	return true;
}
#pragma warning( pop )



void CKey::UnlockGate(CColliderBox* box) {
	Drop();

	mUsed = true;
	mPos.x = mLookLeft ? box->GetInfo().RB.x + 20.f :
						  box->GetInfo().LT.x - 20.f;

	mScene->GetResource()->SoundPlay("KeyBreak");
}

void CKey::Drop() {
	if (mOwner) {
		mOwner = nullptr;
		mPlayerHave = false;
		if (!mReserveCollider)
			mPhysicsSimulate = true;
		mZOrder = (int)ERender_ZOrder::Foothold - 1;
	}
}

void CKey::Bound(CCollider* terrain) {
	mVelocity.y *= 0.4f;
	mPos.y = terrain->GetTopY(mPos.x);

	if (mVelocity.y > mMaxIgnoreVelocity) {
		mVelocity.y = -mVelocity.y;
	} else {
		if (mUsed) {
			CCollider* box = mListCollider.front();
			box->SetEnable(false);
			box->ClearCollisionList();
		}
		mPhysicsSimulate = false;
		mVelocity = 0.f;
	}
}

void CKey::CollisionBegin(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type == ECollision_Profile::Player) {
		if (!mUsed &&
			(!mOwner || mOwner->GetTypeID() != typeid(CPlayer).hash_code())) {
			mOwner = (CPlayer*)dest->GetOwner();
			mPlayerHave = true;
			mZOrder = mOwner->GetZOrder() - 1;
			if (!mScene->CheckRewinding())
				mScene->GetResource()->SoundPlay("PlayerGetsKey");
		}
	} else if (dest->GetProfile()->type == ECollision_Profile::Monster) {
		if (!mUsed && !mOwner) {
			mOwner = (CCharacter*)dest->GetOwner();
			mPlayerHave = false;
			mZOrder = mOwner->GetZOrder() - 1;
			if (!mScene->CheckRewinding())
				mScene->GetResource()->SoundPlay("MonsterGetsKey");
		}
	} else if (dest->GetProfile()->type == ECollision_Profile::StaticObj) {
		if (!strstr(dest->GetName().data(), "Spike"))
			return;
		mPhysicsSimulate = false;
		mVelocity = 0.f;
	} else if (dest->GetProfile()->type == ECollision_Profile::Terrain) {
		if (strstr(dest->GetName().data(), "Gate"))
			return;
		if (mOwner) {
			mReserveCollider = dest;
			return;
		}
		// ���� �ݶ��̴��� ������ �ٴ� �浹�̴�
		if (dest->GetColliderType() == ECollider_Type::Line) {
			Bound(dest);
			return;
		}

		float leftOffset = src->GetHitPoint().x - ((CColliderBox*)src)->GetInfo().LT.x;
		float rightOffset = ((CColliderBox*)src)->GetInfo().RB.x - src->GetHitPoint().x;
		float topOffset = src->GetHitPoint().y - ((CColliderBox*)src)->GetInfo().LT.y;
		float bottomOffset = ((CColliderBox*)src)->GetInfo().RB.y - src->GetHitPoint().y;

		bool leftCollision = leftOffset > rightOffset; // ������Ʈ�� ����, ���� ������


		const Vector2& terrainLT = ((CColliderBox*)dest)->GetInfo().LT;
		const Vector2& terrainRB = ((CColliderBox*)dest)->GetInfo().RB;

		if (topOffset < bottomOffset) { // õ�� �浹
			// ��ġ�� ������ ���� ���̰� ���� ���̺��� ���.
			if ((leftCollision && rightOffset > topOffset) ||
				(!leftCollision && leftOffset > topOffset)) {
				mPos.y = dest->GetBottom();
				src->ClearCollisionList();
				if (mVelocity.y < 0.f)
					mVelocity.y = -mVelocity.y;
				return;
			}
		} else { // �ٴ� �浹
			if (leftOffset == rightOffset ||
				(leftCollision && rightOffset > bottomOffset) ||
				(!leftCollision && leftOffset > bottomOffset)) {
				Bound(dest);
				return;
			}
		}

		// ���� �浹
		if (leftCollision) {
			mPos.x = ((CColliderBox*)dest)->GetInfo().LT.x - mTexture->GetWidth(mUsed ? 0 : 2) * .5f;
			if (mVelocity.x > 0.f)
				mVelocity.x = -mVelocity.x;
		} else {
			mPos.x = ((CColliderBox*)dest)->GetInfo().RB.x + mTexture->GetWidth(mUsed ? 0 : 2) * .5f;
			if (mVelocity.x < 0.f)
				mVelocity.x = -mVelocity.x;
		}
	}
}

void CKey::CollisionEnd(CCollider* src, CCollider* dest) {
	if (mReserveCollider)
		mReserveCollider = nullptr;
}
