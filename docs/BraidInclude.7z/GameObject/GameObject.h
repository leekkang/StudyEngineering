#pragma once

#include "../Ref.h"
#include "../Animation/Animation.h"
#include "../Resource/Texture/Texture.h"
#include "../Widget/WidgetComponent.h"

class CGameObject : public CRef {
	friend class CScene;
	friend class CInput;

protected:
	CGameObject();
	CGameObject(const CGameObject& obj);
	virtual ~CGameObject();
	 
protected:
	class CScene* mScene = nullptr;

protected:
	ERender_Layer	mRenderLayer = ERender_Layer::Default;
	int				mZOrder = 0;
	float			mTimeScale = 1.f;

	Vector2		mPos;
	Vector2		mSize;
	Vector2		mPivot;

	// �Һ� ������Ʈ Ȯ��. true�� rewind�� ������ ���� �ʴ´�.
	bool mImmutable = false;


	CAnimation*								mAnimation = nullptr;
	CSharedPtr<class CTexture>				mTexture;
	std::list<CSharedPtr<class CCollider>>	mListCollider;
	std::list<CSharedPtr<CWidgetComponent>>	mListWidgetComponent;

public:
	ERender_Layer GetRenderLayer() const {
		return mRenderLayer;
	}
	int GetZOrder() const {
		return mZOrder;
	}
	float GetTimeScale()	const {
		return mTimeScale;
	}
	bool GetImmutable()	const {
		return mImmutable;
	}

	const Vector2& GetPos()	const {
		return mPos;
	}
	const Vector2& GetSize()	const {
		return mSize;
	}
	const Vector2& GetPivot()	const {
		return mPivot;
	}

public:
	void SetImmutableObject();

	void SetTimeScale(float scale) {
		mTimeScale = scale;
	}
	void SetZOrder(int order) {
		mZOrder = order;
	}

	void SetPos(float x, float y) {
		mPos.x = x;
		mPos.y = y;
	}
	void SetPos(const Vector2& pos) {
		mPos = pos;
	}

	void SetSize(float x, float y) {
		mSize.x = x;
		mSize.y = y;
	}
	void SetSize(const Vector2& size) {
		mSize = size;
	}

	void SetPivot(float x, float y) {
		mPivot.x = x;
		mPivot.y = y;
	}
	void SetPivot(const Vector2& pivot) {
		mPivot = pivot;
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	// Ȯ���� ��ġ�� ������ �̹����� �׸���.
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(UINT8* data);

	// ī�޶� �ø�
	bool OutOfCamera(class CCamera* cam);


protected:
	Vector2 GetWorldToCameraPos();
	void RenderTexture(HDC hdc, const CTexture* texture, const Vector2& pos, const Vector2& size,
					   int imageX = 0, int imageY = 0, int imageIndex = 0, bool allowMix = true);
	void RenderAlphaTexture(HDC hdc, const CTexture* texture, UINT8 alphaValue, const Vector2& pos, const Vector2& size,
							int imageX = 0, int imageY = 0, int imageIndex = 0);

public:
	class CCollider* FindCollider(const std::string& name);

	template <typename T>
	T* AddCollider(const std::string& name) {
		T* collider = new T;
		collider->SetName(name);
		collider->mOwner = this;
		collider->mScene = mScene;

		if (!collider->Init()) {
			SAFE_DELETE(collider);
			return nullptr;
		}

		mListCollider.push_back(collider);
		return collider;
	}

	CWidgetComponent* FindWidgetComponent(const std::string& name) {
		auto	iter = mListWidgetComponent.begin();
		auto	iterEnd = mListWidgetComponent.end();
		for (; iter != iterEnd; ++iter) {
			// �ݶ��̴� ������ Ȱ��ȭ ���θ� üũ�Ѵ�.
			if ((*iter)->GetName() == name)
				return *iter;
		}
		return nullptr;
	}

	template <typename T>
	CWidgetComponent* CreateWidgetComponent(const std::string& name) {
		CWidgetComponent* widget = FindWidgetComponent(name);
		if (widget)
			return widget;

		widget = new CWidgetComponent;
		widget->SetName(name);
		widget->mOwner = this;
		widget->mScene = mScene;

		if (!widget->Init()) {
			SAFE_DELETE(widget);
			return nullptr;
		}
		widget->CreateWidget<T>(name);

		mListWidgetComponent.push_back(widget);
		return widget;
	}

public:
	// �ݶ��̴��� Update �Լ��� ȣ���ϰ� �浹 Ȯ���� ���� ���� �ݶ��̴� ����Ʈ�� �߰��Ѵ�.
	void UpdateCollider(float deltaTime);
	void PostUpdateCollider(float deltaTime);
	void RenderCollider(HDC hdc, float deltaTime);

	void UpdateWidgetComponent(float deltaTime);
	void PostUpdateWidgetComponent(float deltaTime);


public:
	void SetTextureWithDIB(const std::string& name, const TCHAR* fileName);
	void SetTextureWithDIB(const std::string& name, const std::vector<std::wstring>& vecFileName);

public:
	void SetTexture(class CTexture* texture);
	void SetTexture(const std::string& name);
	void SetTexture(const std::string& name, const TCHAR* fileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const TCHAR* fullPath);

#ifdef UNICODE

	void SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath);

#else

	void SetTexture(const std::string& name, const std::vector<std::string>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath);

#endif // UNICODE

	void SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index = 0);
	void SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b);

	void CreateSound(const std::vector<std::tuple<ESound_Group, const char*, const char*, int>>& soundInfo);

	// ������ �̸�, �ؽ��� �̸�, ��� + ���� �̸�, ũ��, ���� (ETexture_Type::Frame)
	void CreateAnimationSequence(
		const std::vector<std::tuple<const std::string, const std::string, const TCHAR*, Vector2, int>>& animInfo,
		const std::vector<const TCHAR*>& vecPath, bool frameType = true, bool createDIB = true);

public:
	void CreateAnimation() {
		mAnimation = new CAnimation;

		mAnimation->mOwner = this;
		mAnimation->mScene = mScene;
	}

	void AddAnimationInfo(const std::string& sequenceName,
						  float playInterval = 1.f, bool loop = true, float playScale = 1.f, bool reverse = false) {
		mAnimation->AddAnimationInfo(sequenceName, playInterval, loop, playScale, reverse);
	}

	void AddAnimationInfo(const std::string& infoName, const std::string& sequenceName,
						  float playInterval = 1.f, bool loop = true, float playScale = 1.f, bool reverse = false) {
		mAnimation->AddAnimationInfo(infoName, sequenceName, playInterval, loop, playScale, reverse);
	}

	void SetIntervalType(const std::string& name, EAnimation_Interval type) {
		mAnimation->SetIntervalType(name, type);
	}
	void SetLoopStartFrame(const std::string& name, int startFrame) {
		mAnimation->SetLoopStartFrame(name, startFrame);
	}
	void SetPlayInterval(const std::string& name, float playInterval) {
		mAnimation->SetPlayInterval(name, playInterval);
	}
	void SetPlayScale(const std::string& name, float playScale) {
		mAnimation->SetPlayScale(name, playScale);
	}
	void SetPlayLoop(const std::string& name, bool loop) {
		mAnimation->SetPlayLoop(name, loop);
	}
	void SetPlayReverse(const std::string& name, bool reverse) {
		mAnimation->SetPlayReverse(name, reverse);
	}
	void SetCurrentAnimation(std::string& name) {
		mAnimation->SetCurrentAnimation(name);
	}
	void ChangeAnimation(const std::string& name) {
		mAnimation->ChangeAnimation(name);
	}
	bool CheckCurrentAnimation(const std::string& name) {
		return mAnimation->CheckCurrentAnimation(name);
	}

	
	template <typename T>
	void SetAnimationEndFunction(const std::string& name, T* obj, void(T::* func)()) {
		if (mAnimation)
			mAnimation->SetAnimationEndFunction<T>(name, obj, func);
	}
	template <typename T>
	void AddNotify(const std::string& name, int frame, T* obj, void(T::* func)()) {
		if (mAnimation)
			mAnimation->AddNotify<T>(name, frame, obj, func);
	}
};