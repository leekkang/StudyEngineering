#pragma once

#include "GameObject.h"

class CAlphaObject : public CGameObject {
	friend class CScene;

protected:
	CAlphaObject();
	CAlphaObject(const CAlphaObject& obj);
	virtual ~CAlphaObject();

protected:
	int mAlphaValue = 255;

public:
	void SetAlphaValue(int value) {
		mAlphaValue = value;
	}
	void SetTexture(int alphaValue, const std::string& name, const TCHAR* fileName);

public:
	virtual bool Init();
	virtual void Render(HDC hdc, float deltaTime);
};