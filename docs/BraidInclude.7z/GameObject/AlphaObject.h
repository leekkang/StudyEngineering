#pragma once

#include "GameObject.h"

class CAlphaObject : public CGameObject {
	friend class CScene;

protected:
	CAlphaObject();
	CAlphaObject(const CAlphaObject& obj);
	virtual ~CAlphaObject();


protected:
    UINT8 mAlphaValue = 255; // 0 �̸� ������ ���°� �ȴ�.
    float mAlphaTime = 0.f;

    bool mTwinkle = false;
    UINT8 mRange = 250;
    float mCycleTime = 0.f;

public:
    void SetTwinkle(bool twinkle) {
        mTwinkle = twinkle;
    }
    void SetAlphaValue(UINT8 alpha) {
        mAlphaValue = alpha;
    }
    void SetRenderRange(UINT8 range) {
        mRange = range;
    }
    void SetCycleTime(float time) {
        mCycleTime = time;
    }

	void SetTexture(int alphaValue, const std::string& name, const TCHAR* fileName);

public:
	virtual bool Init();
	virtual void Render(HDC hdc, float deltaTime);
    virtual bool Serialize(UINT8*& data);
    virtual bool Deserialize(UINT8* data);
};