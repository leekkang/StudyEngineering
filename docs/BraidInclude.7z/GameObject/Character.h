#pragma once
#include "GameObject.h"

class CCharacter : public CGameObject {
	friend class CScene;

protected:
	CCharacter();
	CCharacter(const CCharacter& obj);
	virtual ~CCharacter();

protected:
	bool  mDead		= false;
	bool  mJump		= false;
	int   mLookDir  = 1;	// x�ప �ٶ󺸴� ����. -1 == ����, 1 == ������

protected:
	int GetAnimationDirIndex() const {
		return mLookDir == -1 ? 1/*����*/ : 0/*������*/;
	}

public:
	void SetDead() {
		mDead = true;
	}

	void Jump(float speedY) {
		if (mJump || mFloating)
			return;

		mJump = true;
		mFloating = true;
		mVelocity.y -= speedY;
	}

	void Falling() {
		mJump = false;
		CGameObject::Falling();
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
};

