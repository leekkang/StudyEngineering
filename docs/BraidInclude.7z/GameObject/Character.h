#pragma once

#include "MovableObject.h"

enum class ECharacter_AnimType : UINT8 {
	Idle = 0,
	Run,
	Jump,
	JumpForward,
	BoundLow,
	BoundMid,
	BoundHigh,
	BoundForwardLow,
	BoundForwardMid,
	BoundForwardHigh,
	Ladder,
	LadderAside,
	Fall,
	Dead,
	Clear,
	StareUp,
	StareDown,
	StareUpDown,
	Attack,
	MAX
};

class CCharacter : public CMovableObject {
	friend class CScene;

protected:
	CCharacter();
	CCharacter(const CCharacter& obj);
	virtual ~CCharacter();

protected:
	bool  mDead		= false;
	bool  mJump		= false;
	int   mLookDir  = 1;	// x�ప �ٶ󺸴� ����. -1 == ����, 1 == ������

	ECharacter_AnimType mCurrentAnimType = ECharacter_AnimType::Idle;
	std::vector<std::string> mVecAnimationKey[2];
	// �� ĳ���͸��� �ٸ� �ִϸ��̼� �������� ã���ִ� �ε��� ������ �Ѵ�.
	UINT8 mVecAnimTypeIndex[static_cast<int>(ECharacter_AnimType::MAX)] {};

	CCollider* mFloorCollider = nullptr;
	CCollider* mFloorNextCollider = nullptr;


protected:
	int GetAnimationDirIndex() const {
		return mLookDir == -1 ? 1/*����*/ : 0/*������*/;
	}

public:
	bool CheckLookLeft() const {
		return mLookDir == -1;
	}
	bool CheckDead() const {
		return mDead;
	}

	ECharacter_AnimType GetCurrentAnimType() const {
		return mCurrentAnimType;
	}
	int GetCurrentAnimFrame() const {
		return mAnimation->GetCurrentFrameNumber();
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(const UINT8* data);


public:
	virtual void Dead(bool randomX, bool ignorePlayerVelocity);
	virtual void DeadByCannon(float xV, float yV);
	virtual void Landing(class CCollider* col, bool addSlopeAccel = false);

	void Jump(float speedY) {
		mVelocity.y = -speedY;

		mJump = true;
		mFloating = true;
		mFloorNextCollider = mFloorCollider;
		mFloorCollider = nullptr;
	}

	void Falling() {
		mJump = false;
		CMovableObject::Falling();
	}

protected:
	bool SetCurrentAnimationReverse(ECharacter_AnimType type) {
		return mAnimation->CheckCurrentAnimation(mVecAnimationKey[0][mVecAnimTypeIndex[(int)type]]) ||
			mAnimation->CheckCurrentAnimation(mVecAnimationKey[1][mVecAnimTypeIndex[(int)type]]);
	}
	bool CheckCurrentAnimation(ECharacter_AnimType type) {
		return mAnimation->CheckCurrentAnimation(mVecAnimationKey[0][mVecAnimTypeIndex[(int)type]]) ||
			mAnimation->CheckCurrentAnimation(mVecAnimationKey[1][mVecAnimTypeIndex[(int)type]]);
	}
	void ChangeAnimation(ECharacter_AnimType type, bool succeed = false) {
		mAnimation->ChangeAnimation(mVecAnimationKey[GetAnimationDirIndex()][mVecAnimTypeIndex[(int)type]], succeed);
		mCurrentAnimType = type;
		// �ִϸ��̼��� �̹��� ũ��� ����� �ٽ� �����ش�.
		const AnimationFrameData& frameData = mAnimation->GetCurrentFrameData();
		mSize = frameData.end - frameData.start;
	}
	void ResetCurrentAnimation() {
		mAnimation->ResetCurrentAnimation();
	}


	void DeadProcess();
	bool CheckFootsteping(CCollider* col); // �ݶ��̴��� x ������ ������Ʈ ���͸� �����ϴ��� Ȯ���ϴ� �Լ�
	bool CheckLandingFoothold(); // ���� �÷ξ �������� ������ Ȯ���ϴ� �Լ�
	bool CheckFloorIsMover();
};