#pragma once
#include "Character.h"

class CMonster : public CCharacter {
public:
	friend class CScene;

protected:
	CMonster();
	CMonster(const CMonster& obj);
	virtual ~CMonster();

protected:
	float	mFireTime = 0.f;
	Vector2 mDirection {};


public:
	void SetDirection(float angle) {
		mDirection.x = cosf(DegreeToRadian(angle));
		mDirection.y = sinf(DegreeToRadian(angle));
	}
	void SetDirection(const Vector2& dir) {
		mDirection = dir;
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);

private:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);
};