#pragma once

#include "GameObject.h"

class CTerrain : public CGameObject {
	friend class CScene;

protected:
	CTerrain();
	virtual ~CTerrain();
	DISALLOW_COPY_AND_ASSIGN(CTerrain)

private:
	UINT8 mAlphaValue = 255;
	float mAlphaTime = 0.f;

	int mPortalIndex = -1;
	std::vector<std::pair<Vector2, std::function<void()>>> mVecPortal;

	class CPlayer* mPlayer = nullptr;
	class CAlphaObject* mPortalWidget = nullptr;

	std::vector<CGameObject*> mVecFoothold;

public:
	void SetPortal(float x, float y, const std::function<void()>& func) {
		mVecPortal.emplace_back(Vector2(x, y), func);
	}

	const Vector2& GetPrevPortal() const {
		return mVecPortal[0].first;
	}
	const Vector2& GetNextPortal() const {
		return mVecPortal[mVecPortal.size() - 1].first;
	}

	int GetColliderListSize() const {
		return (int)mListCollider.size();
	}
	class CCollider* GetCollider(int index);
	void SetCollider(int index, const char* name, const Vector2& lt, const Vector2& rb,
					 ECollider_Type type, ECollision_Profile profile);
	void DeleteCollider(int index);

	void SetInput();

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);

public:
	void SetFoothold(const char* terrainFileName);
	void SetSpikeCallback();

public:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);

public:
	virtual void Save(FILE* file);
	virtual void Load(FILE* file);
};
