#pragma once

#include "GameObject.h"

class CTerrain : public CGameObject {
	friend class CScene;

protected:
	CTerrain();
	CTerrain(const CTerrain& obj);
	virtual ~CTerrain();

private:
	std::vector<CGameObject*> mVecFoothold;

public:
	int GetColliderListSize() const {
		return (int)mListCollider.size();
	}
	class CCollider* GetCollider(int index);
	void SetCollider(int index, const char* name, const Vector2& lt, const Vector2& rb,
					 ECollider_Type type, ECollision_Profile profile);
	void DeleteCollider(int index);

public:
	virtual bool Init();
	virtual void Render(HDC hdc, float deltaTime);

public:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);

public:
	virtual void Save(FILE* file);
	virtual void Load(FILE* file);
};
