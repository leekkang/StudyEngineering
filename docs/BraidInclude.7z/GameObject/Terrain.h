#pragma once

#include "GameObject.h"

class CTerrain : public CGameObject {
	friend class CScene;

protected:
	CTerrain();
	CTerrain(const CTerrain& obj);
	virtual ~CTerrain();

public:
	virtual bool Init();
	virtual void Render(HDC hdc, float deltaTime);

public:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);
};
