#pragma once

#include "GameObject.h"

class CTerrain : public CGameObject {
	friend class CScene;

protected:
	CTerrain();
	virtual ~CTerrain();
	DISALLOW_COPY_AND_ASSIGN(CTerrain);

private:
	bool mPlayerPortal = false;

	UINT8 mAlphaValue = 255;
	float mAlphaTime = 0.f;

	Vector2 mPrevPortal;
	Vector2 mNextPortal;

	class CPlayer* mPlayer = nullptr;
	class CTexture* mWidgetTexture = nullptr;

	std::vector<CGameObject*> mVecFoothold;

public:
	void SetPrevPortalPos(float x, float y) {
		mPrevPortal.x = x;
		mPrevPortal.y = y;
	}
	void SetNextPortalPos(float x, float y) {
		mNextPortal.x = x;
		mNextPortal.y = y;
	}

	int GetColliderListSize() const {
		return (int)mListCollider.size();
	}
	class CCollider* GetCollider(int index);
	void SetCollider(int index, const char* name, const Vector2& lt, const Vector2& rb,
					 ECollider_Type type, ECollision_Profile profile);
	void DeleteCollider(int index);

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);

public:
	void SetSpikeCallback();
	void SetFoothold(const char* terrainFileName);

public:
	void CollisionBegin(CCollider* src, CCollider* dest);
	void CollisionEnd(CCollider* src, CCollider* dest);

public:
	virtual void Save(FILE* file);
	virtual void Load(FILE* file);

private:
	void SetCollider();
};
