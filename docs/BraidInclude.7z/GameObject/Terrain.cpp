
#include "Terrain.h"

#include "../GameManager.h"
#include "../Input.h"
#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"

#include "../Scene/MainScene.h"

#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderLine.h"

#include "Foothold.h"
#include "../GameObject/Player.h"
#include "../GameObject/AlphaObject.h"

CTerrain::CTerrain() {
	SetTypeID<CTerrain>();
	mRenderLayer = ERender_Layer::Terrain;
}

CTerrain::~CTerrain() {
}

CCollider* CTerrain::GetCollider(int index) {
	if (index < 0 || index >= mListCollider.size())
		return nullptr;

	auto iter = mListCollider.begin();
	for (int i = 0; i < index; ++i)
		++iter;
	return *iter;
}

void CTerrain::SetCollider(int index, const char* name, const Vector2& lt, const Vector2& rb,
						   ECollider_Type type, ECollision_Profile profile) {
	CCollider* col = nullptr;
	if (index == -1) {
		if (type == ECollider_Type::Box) {
			CColliderBox* box = AddCollider<CColliderBox>(name);
			box->SetRectWithOffset(lt, rb);
			box->SetCollisionProfile(profile);
			col = box;
		} else {
			CColliderLine* line = AddCollider<CColliderLine>(name);
			line->SetLineWithOffset(lt, rb);
			line->SetCollisionProfile(profile);
			col = line;
		}
	} else if (index < mListCollider.size()) {
		auto iter = mListCollider.begin();
		for (int i = 0; i < index; ++i)
			++iter;

		bool create = type != (*iter)->GetColliderType();
		if (type == ECollider_Type::Box) {
			if (create) {
				CColliderBox* box = CreateCollider<CColliderBox>(name);
				box->SetRectWithOffset(lt, rb);
				box->SetCollisionProfile(profile);
				*iter = box;
				col = box;
			} else {
				CColliderBox* box = (CColliderBox*)iter->Get();
				box->SetName(name);
				box->SetRectWithOffset(lt, rb);
				box->SetCollisionProfile(profile);
			}
		} else {
			if (create) {
				CColliderLine* line = CreateCollider<CColliderLine>(name);
				line->SetLineWithOffset(lt, rb);
				line->SetCollisionProfile(profile);
				*iter = line;
				col = line;
			} else {
				CColliderLine* line = (CColliderLine*)iter->Get();
				line->SetName(name);
				line->SetLineWithOffset(lt, rb);
				line->SetCollisionProfile(profile);
			}
		}
	}
}

void CTerrain::DeleteCollider(int index) {
	if (index >= mListCollider.size())
		return;

	auto iter = mListCollider.begin();
	for (int i = 0; i < index; ++i)
		++iter;

	mListCollider.erase(iter);
}

void CTerrain::SetInput() {
	auto attachUpKey = [&]() {
		if (mPortalIndex == -1)
			return;
		if (mScene->CheckRewinding())
			return;
		mPlayer->PlayDoorOpenSound();
		CSceneManager::GetInst()->StartChangeScene(mVecPortal[mPortalIndex].second);
	};
	CInput::GetInst()->AddBindFunction("Up", Input_Type::Down, mScene, attachUpKey);
	CInput::GetInst()->AddBindFunction("ArrowUp", Input_Type::Down, mScene, attachUpKey);
}

bool CTerrain::Init() {
	SetPos(0.f, 0.f);
	SetPivot(0.f, 0.f);

	CGameObject::CreateSound({
		{ESound_Group::Effect, "PlayerSpike", "player_hits_spikes", 4, false},
		{ESound_Group::Effect, "OtherSpike", "other_hits_spikes", 4, false},
							 });

	mPlayer = mScene->GetPlayer();

	mPortalWidget = mScene->CreateObject<CAlphaObject>("Terrain");
	mPortalWidget->SetTexture(255, "PortalWidget", TEXT("Widget/portal.bmp"));
	mPortalWidget->SetTwinkle(true);
	mPortalWidget->SetCycleTime(1.f);
	mPortalWidget->SetRenderRange(230);
	mPortalWidget->SetColorKey(255, 0, 255);
	mPortalWidget->SetZOrder((int)ERender_ZOrder::UI);
	mPortalWidget->SetPivot(0.5f, 1.f);

	mScene->SetTerrain(this);

	SetInput();

	return true;
}

void CTerrain::Update(float deltaTime) {
	if (CGameManager::GetInst()->GetEditMode())
		return;

	mPortalIndex = -1;
	int size = (int)mVecPortal.size();
	for (int i = 0; i < size; ++i) {
		const Vector2& portal = mVecPortal[i].first;
		if (portal.y != 0.f &&
			fabs(mPlayer->GetPos().x - portal.x) < 30.f &&
			fabs(mPlayer->GetPos().y - portal.y) < 5.f) {
			if (!dynamic_cast<CMainScene*>(mScene))
				mPortalIndex = i;
			else if (i <= CMainScene::mClearIndex)
				mPortalIndex = i;
			break;
		}
	}

	if (mPortalIndex != -1 && mScene && !mScene->CheckRewinding()) {
		mPortalWidget->SetEnable(true);
		mPortalWidget->SetPos(mPlayer->GetPos().x, mPlayer->GetPos().y - 94.f);
	} else 
		mPortalWidget->SetEnable(false);
}

void CTerrain::Render(HDC hdc, float deltaTime) {
	Vector2	renderLT = GetCameraPos();
	if (mTexture) {
		TransparentBlt(hdc, 0, 0, 1600, 900, mTexture->GetDC(),
					   (int)renderLT.x, (int)renderLT.y, 1600, 900, mTexture->GetColorKey());
	}

	RenderCollider(hdc, deltaTime);
}


void CTerrain::SetFoothold(const char* terrainFileName) {
	std::vector<std::tuple<Vector2, int, bool, bool>> footholdInfo;
	if (strstr(terrainFileName, "stageTutorial")) {
		footholdInfo.push_back({{5724.f, 452.f}, 47, true, true});
		footholdInfo.push_back({{5927.f, 606.f}, 5, false, true});
		footholdInfo.push_back({{6172.f, 638.f}, 5, true, true});
		footholdInfo.push_back({{6393.f, 638.f}, 33, true, true});
		footholdInfo.push_back({{6756.f, 452.f}, 45, true, true});
		footholdInfo.push_back({{7123.f, 637.f}, 8, true, false});
		footholdInfo.push_back({{8355.f, 481.f}, 29, true, true});
		footholdInfo.push_back({{9407.f, 484.f}, 29, true, true});
		footholdInfo.push_back({{10888.f, 630.f}, 7, true, false});
		footholdInfo.push_back({{10855.f, 545.f}, 9, true, false});
		footholdInfo.push_back({{10812.f, 465.f}, 12, true, false});
		footholdInfo.push_back({{11267.f, 315.f}, 4, true, false});
	} else if (strstr(terrainFileName, "stageHunt")) {
		footholdInfo.push_back({{825.f, 674.f}, 24, true, true});
		footholdInfo.push_back({{28.f, 674.f}, 32, false, true});
		footholdInfo.push_back({{30.f, 462.f}, 4, false, false});
		footholdInfo.push_back({{1215.f, 460.f}, 11, true, false});
		footholdInfo.push_back({{1184.f, 176.f}, 4, true, false});
	} else {

	}

	CFoothold* foothold = nullptr;
	size_t size = footholdInfo.size();
	for (size_t i = 0; i < size; ++i) {
		auto info = footholdInfo[i];
		foothold = mScene->CreateObject<CFoothold>("Foothold");
		foothold->SetPos(std::get<0>(info));
		foothold->SetLength(std::get<1>(info));
		if (!std::get<2>(info))
			foothold->SetLeftEnd(false);
		if (!std::get<3>(info))
			foothold->SetRightEnd(false);
	}
}

void CTerrain::SetSpikeCallback() {
	auto iter = mListCollider.begin();
	auto iterEnd = mListCollider.end();
	for (; iter != iterEnd; ++iter) {
		if ((*iter)->GetName() == "Spike") {
			(*iter)->SetCollisionBeginFunction<CTerrain>(this, &CTerrain::CollisionBegin);
			(*iter)->SetCollisionEndFunction<CTerrain>(this, &CTerrain::CollisionEnd);
		}
	}
}


void CTerrain::CollisionBegin(CCollider* src, CCollider* dest) {
	// ĳ���Ͱ� ���ÿ� ���̸� �״´�.
	if (dynamic_cast<CCharacter*>(dest->GetOwner())) {
		((CCharacter*)dest->GetOwner())->Dead(true, true);
		if (dynamic_cast<CPlayer*>(dest->GetOwner()))
			mScene->GetResource()->SoundPlay("PlayerSpike" + std::to_string(rand() % 4));
		else
			mScene->GetResource()->SoundPlay("OtherSpike" + std::to_string(rand() % 4));
	}
}

void CTerrain::CollisionEnd(CCollider* src, CCollider* dest) {
}

void CTerrain::Save(FILE* file) {
	CGameObject::Save(file);
}

void CTerrain::Load(FILE* file) {
	CGameObject::Load(file);
}

//void CTerrain::SetCollider() {
	// 1. �ٴ��� �ڽ�, ���� �ݶ��̴��� �����ȴ�.
	// 2. ������ ������ ���� �ݶ��̴� �̴�.
	// 3. ���߿� ���ִ� �ٴ��� �� ���� ������ �ڽ� �ݶ��̴� �̴�.
	// 4. ĳ���Ͱ� �پ��� �� �ε����� õ��, ���� ������ �ڽ� �ݶ��̴� �̴�.

	// Box  : Type,    LT Point,  RB Point, Profile, Name
	// Line : Type, Start Point, End Point, Profile, Name
	//std::vector<std::tuple<const char* , Vector2, Vector2, ECollider_Type, ECollision_Profile>> info{
	//	{"Wall", {0, 0}, {360, 844}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Floor", {300, 750},{1500, 850}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Floor", {1500, 751}, {1900, 725}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Stair", {1895, 660},  {2055, 726}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Stair", {2035, 590},  {2205, 730}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Stair", {2182, 517},  {2472, 723}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Floor", {2430, 590},  {2700, 610}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Floor", {2655, 530},  {2725, 610}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Hill", {2725, 530}, {3047, 568}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Hill", {3047, 568}, {3393, 664}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Floor", {3393, 664}, {3971, 784}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Wirefence", {3524, 112}, {3956, 664}, ECollider_Type::Box, ECollision_Profile::StaticObj},

	//	{"Wall", {3885, 214}, {4122, 784}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Hill", {4122, 214}, {4380, 268}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Hill", {4380, 268}, {4742, 476}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Floor", {4742, 476}, {5212, 530}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Wirefence", {4770, 130}, {5090, 476}, ECollider_Type::Box, ECollision_Profile::StaticObj},

	//	{"Wall", {5180, 338}, {5406, 470}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Stair", {5372, 417},  {5492, 535}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Stair", {5458, 483},  {5586, 579}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Floor", {5574, 567}, {5682, 543}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Floor", {5682, 543},  {5846, 569}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Wall", {5830, 455}, {5942, 680}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Ladder", {5766, 345}, {5806, 600}, ECollider_Type::Box, ECollision_Profile::StaticObj},

	//	{"Foothold", {5725, 452}, {6603, 452}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Stone", {6308, 384}, {6402, 452}, ECollider_Type::Box, ECollision_Profile::Terrain}, // 94, 68
	//	{"Foothold", {5936, 607}, {6088, 607}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Foothold", {6760, 452}, {7600, 452}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Foothold", {6172, 638}, {6305, 638}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Foothold", {6405, 638}, {7023, 638}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Foothold", {7123, 638}, {7337, 638}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Spike", {5947, 710}, {7329, 780}, ECollider_Type::Box, ECollision_Profile::StaticObj},

	//	{"Floor", {7337, 638}, {7477, 674}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Ladder", {7377, 354}, {7417, 638}, ECollider_Type::Box, ECollision_Profile::StaticObj},
	//	{"Floor", {7466, 547},  {8124, 653}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Floor", {8124, 615}, {8294, 637}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Floor", {8294, 637},  {8878, 667}, ECollider_Type::Box, ECollision_Profile::Terrain},

	//	{"Ladder", {8398, 384}, {8438, 636}, ECollider_Type::Box, ECollision_Profile::StaticObj},
	//	{"Ladder", {8829, 384}, {8869, 636}, ECollider_Type::Box, ECollision_Profile::StaticObj},
	//	{"Stone", {8267, 452}, {8361, 520}, ECollider_Type::Box, ECollision_Profile::Terrain}, // 94, 68
	//	{"Foothold", {8358, 481}, {8905, 481}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Stone", {8907, 456}, {9085, 523}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Cannon", {8973, 385}, {9091, 455}, ECollider_Type::Box, ECollision_Profile::Terrain},

	//	{"Hill", {8878, 637},  {9116, 687}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Hill", {8878, 637},  {9116, 687}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Hill", {9116, 687},  {9298, 709}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Hill", {9298, 687},  {9705, 663}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Hill", {9705, 663}, {10155, 633},  ECollider_Type::Line, ECollision_Profile::Terrain},

	//	{"Ladder", {9451, 396}, {9491, 656}, ECollider_Type::Box, ECollision_Profile::StaticObj},
	//	{"Ladder", {9882, 398}, {9922, 656}, ECollider_Type::Box, ECollision_Profile::StaticObj},
	//	{"Stone", {9320, 454}, {9414, 522}, ECollider_Type::Box, ECollision_Profile::Terrain}, // 94, 68
	//	{"Foothold", {9411, 483}, {9958, 483}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Stone", {9950, 455}, {10133, 523}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Cannon", {10020, 383}, {10136, 455}, ECollider_Type::Box, ECollision_Profile::Terrain},

	//	{"Hill", {10154, 633},  {10300, 660}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Hill", {10300, 633},  {10524, 659}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Hill", {10524, 659}, {10834, 719}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Hill", {10834, 719}, {11074, 751}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Wall", {11073, 465}, {11380, 731}, ECollider_Type::Box, ECollision_Profile::Terrain},

	//	{"Foothold", {10889, 630}, {11072, 630}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Foothold", {10856, 545}, {11072, 545}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Foothold", {10814, 465}, {11072, 465}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Stair", {11272, 381}, {11402, 719}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Foothold", {11268, 315}, {11396, 315}, ECollider_Type::Line, ECollision_Profile::Terrain},
	//	{"Stair", {11396, 315}, {11656, 413}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Wall", {11616, 0}, {11810, 413}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//	{"Cliff", {11302, 0}, {11652, 163}, ECollider_Type::Box, ECollision_Profile::Terrain},
	//};

	//CCollider* col = nullptr;
	//size_t size = info.size();
	//for (size_t i = 0; i < size; ++i) {
	//	if (std::get<3>(info[i]) == ECollider_Type::Box) {
	//		col = AddCollider<CColliderBox>(std::get<0>(info[i]));
	//		((CColliderBox*)col)->SetRectWithOffset(std::get<1>(info[i]), std::get<2>(info[i]));
	//	} else {
	//		col = AddCollider<CColliderLine>(std::get<0>(info[i]));
	//		((CColliderLine*)col)->SetLineWithOffset(std::get<1>(info[i]), std::get<2>(info[i]));
	//	}
	//	col->SetCollisionProfile(std::get<4>(info[i]));
	//	if (std::get<0>(info[i]) == "Spike") {
	//		col->SetCollisionBeginFunction<CTerrain>(this, &CTerrain::CollisionBegin);
	//		col->SetCollisionEndFunction<CTerrain>(this, &CTerrain::CollisionEnd);
	//	}
	//}
//}
