#pragma once

#include "GameObject.h"

class CLever : public CGameObject {
	friend class CScene;

private:
	CLever();
	~CLever();
	DISALLOW_COPY_AND_ASSIGN(CLever)


private:
	bool mLeverOn	  = false;
	bool mPlayerTouch = false;

	UINT8 mAlphaValue = 255;
	float mAlphaTime  = 0.f;

	class CPlatform* mPlatform = nullptr;
	class CPlayer* mPlayer = nullptr;
	CSharedPtr<class CTexture> mWidgetTexture;

private:
	void SetInput();

public:
	void SetPlatform(CPlatform* obj) {
		mPlatform = obj;
	}
	void SetObjectTexture(bool immutable);

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Serialize(UINT8*& data);
	virtual bool Deserialize(UINT8* data);

public:
	void ToggleLever();

private:
	void AttachUpKey();
};