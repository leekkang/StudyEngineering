
#include "Cloud.h"

#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneResource.h"

#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderLine.h"

#include "../GameObject/Character.h"

CCloud::CCloud() {
	SetTypeID<CCloud>();
}
CCloud::~CCloud() {
}

void CCloud::SetDirection(bool left) {
	mLookLeft = left;
	auto col = mListCollider.begin();
	(*col)->SetOffset(left ? 79.f : 144.f, 2.f);
	++col;
	(*col)->SetOffset(left ? 8.f : 215.f, 7.f);
}

void CCloud::SetObjectTexture(bool immutable) {
	std::vector<const TCHAR*> path{TEXT("Object/cloudLeft.bmp"), TEXT("Object/cloudRight.bmp")};

	if (immutable) {
		SetTextureWithDIB("CloudDIB", path);
		SetImmutableObject();
	} else {
		SetTexture("Cloud", path);
	}
	SetColorKeyAll(255, 0, 255);
	mTexture->InitAlphaBlend();

	mSize = mTexture->GetSize();
}

bool CCloud::Init() {
	CGameObject::Init();
	//SetSize(223.f, 91.f);
	SetPivot(0.5f, 0.f);

	SetPhysicsSimulate(false);

	CGameObject::CreateSound({
		{ESound_Group::Effect, "CloudPop", "cloud_pop", 2, false},
							 });


	// �浹ü �߰�
	CColliderLine* line = AddCollider<CColliderLine>("Cloud");
	line->SetCollisionProfile(ECollision_Profile::Terrain);
	line->SetLinePoint(74.f, 0.f);	// ���� 148.f
	//line->SetOffset(0.f, 2.f);	// ���� ���� �� �ٲ��.
	//line->SetCollisionBeginFunction([&](CCollider* src, CCollider* dest) {
	//	if (dest->GetName() == "PlayerCenter")
	//		mStandOn = (CCharacter*)dest->GetOwner();
	//	});
	//line->SetCollisionEndFunction([&](CCollider* src, CCollider* dest) {
	//	if (dest->GetName() == "PlayerCenter")
	//		mStandOn = nullptr;
	//								});

	CColliderBox* box = AddCollider<CColliderBox>("CloudFront");
	box->SetCollisionProfile(ECollision_Profile::MoveObj);
	box->SetExtent(6.f, 10.f);
	//box->SetOffset(0.f, 2.f);	// ���� ���� �� �ٲ��.
	box->SetCollisionBeginFunction<CCloud>(this, &CCloud::CollisionBegin);
	box->SetCollisionEndFunction<CCloud>(this, &CCloud::CollisionEnd);

	return true;
}

void CCloud::Update(float deltaTime) {
	CMovableObject::Update(deltaTime);

	if (mFade) {
		mFadeTime -= deltaTime;
		if (mFadeTime < 0.f) {
			SetEnable(false);
		}
	}
}

void CCloud::Render(HDC hdc, float deltaTime) {
	Vector2 renderLT = GetWorldToCameraPos(mPos);
	UINT8 alphaValue = mFade ? (UINT8)(255 * (mFadeTime * 2.f)) : 255;

	if (mLookLeft) {
		if (mPos.x < mRenderLimitPoint) {
			if (mPos.x + mSize.x > mRenderLimitPoint)
				RenderAlphaTexture(hdc, mTexture, alphaValue, renderLT, {(mRenderLimitPoint - mPos.x), mSize.y});
			else
				RenderAlphaTexture(hdc, mTexture, alphaValue, renderLT, mSize);
		}
	} else {

		if ((mPos.x + mSize.x) > mRenderLimitPoint) {
			if (mPos.x < mRenderLimitPoint) {
				int imageX = (int)(mRenderLimitPoint - mPos.x);
				RenderAlphaTexture(hdc, mTexture, alphaValue,
								   {mRenderLimitPoint - GetCameraPos().x, renderLT.y}, {mSize.x - imageX, mSize.y}, imageX, 0, 1);
			} else {
				RenderAlphaTexture(hdc, mTexture, alphaValue, renderLT, mSize, 0, 0, 1);
			}
		}
	}

	RenderCollider(hdc, deltaTime);
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool CCloud::Serialize(UINT8*& data) {
	if (!data) {
		size_t size = sizeof(byte) + sizeof(Vector2) * 2 + sizeof(float) * 1;
		data = new UINT8[size];
	}
	int offset = 0;

	// boolean
	byte bValue = mListCollider.front()->GetEnable();
	bValue = bValue << 1 | mEnable;
	bValue = bValue << 1 | mFade;
	data[offset] = bValue;
	++offset;

	// CGameObject
	memcpy(data + offset, &mPos, sizeof(Vector2));		offset += sizeof(Vector2);
	// CMovableObject
	memcpy(data + offset, &mVelocity, sizeof(Vector2));	offset += sizeof(Vector2);
	// CCloud
	memcpy(data + offset, &mFadeTime, sizeof(float));	offset += sizeof(float);

	return true;
}
bool CCloud::Deserialize(const UINT8* data) {
	int offset = 0;

	// boolean
	byte bValue = data[offset];
	mFade = bValue & 0x01;
	bValue >>= 1;
	mEnable = bValue & 0x01;
	bValue >>= 1;
	bool enable = bValue & 0x01;
	CCollider* col = mListCollider.front();
	col->SetEnable(enable);
	if (!enable)
		col->ClearCollisionList();

	//auto iter = mListCollider.begin();
	//auto iterEnd = mListCollider.end();
	//for (; iter != iterEnd; ++iter) {
	//	(*iter)->SetEnable(enable);
	//	if (!enable)
	//		(*iter)->ClearCollisionList();
	//}
	++offset;

	// CGameObject
	memcpy(&mPos, data + offset, sizeof(Vector2));		offset += sizeof(Vector2);
	// CMovableObject
	memcpy(&mVelocity, data + offset, sizeof(Vector2)); offset += sizeof(Vector2);
	// CCloud
	memcpy(&mFadeTime, data + offset, sizeof(float));	offset += sizeof(float);

	return true;
}
#pragma warning( pop )



void CCloud::ResetForBullet(const Vector2& velocity) {
	mFade = false;
	mVelocity = velocity;

	mListCollider.front()->SetEnable(true);
}

void CCloud::Fadeout() {
	mFade = true;
	mFadeTime = 0.5f;
	mVelocity.x = 0.f;

	mListCollider.front()->SetEnable(false);
	mListCollider.front()->ClearCollisionListWithCallFunc();

	if (mStandOn && mStandOn->GetPos().y == mPos.y + 2.f)
		mStandOn->Falling();

	SoundPlay(std::string("CloudPop") + (mImmutable ? '0' : '1'), 30);
}

void CCloud::CollisionBegin(CCollider* src, CCollider* dest) {
	if (dest->GetProfile()->type == ECollision_Profile::Terrain) {
		// �������� ������ �ִ� ��쿡�� �����Ѵ�.
		if (dest->GetName() != "Cannon" && dest->GetName() != "Foothold")
 			Fadeout();
	}
}

void CCloud::CollisionEnd(CCollider* src, CCollider* dest) {
}
