#pragma once

#include "GameInfo.h"
#include "SingletonMacro.h"

enum class Input_Type {
	Down,
	Push,
	Up,
	End
};

struct KeyState {
	unsigned char	key;
	bool			down;	// ������ �����Ҷ�
	bool			push;	// ������ ������
	bool			up;		// ������ �ִ� Ű�� �ö�ö�

	KeyState() :
		key(0),
		down(false),
		push(false),
		up(false) {
	}
};

struct BindFunction {
	class CScene* scene = nullptr;
	void* obj			= nullptr;
	std::function<void()>	func;

	BindFunction(){ 
	}
};

struct BindKey {
	std::string	name;	// �̸�
	KeyState* key;	// � Ű�� ����ϴ���.
	bool		ctrl;
	bool		alt;
	bool		shift;

	std::vector<BindFunction*>	vecFunction[(int)Input_Type::End];

	BindKey() :
		key(nullptr),
		ctrl(false),
		alt(false),
		shift(false) {
	}
};

class CInput {
	DECLARE_SINGLE(CInput)

private:
	std::unordered_map<unsigned char, KeyState*>	mMapKeyState;
	std::unordered_map<std::string, BindKey*>		mMapBindKey;
	bool	mCtrl		 = false;
	bool	mAlt		 = false;
	bool	mShift		 = false;


	bool	mMouseLDown  = false;
	bool	mMouseLPush  = false;
	bool	mMouseLUp    = false;
	HWND	mHWnd		 = 0;
	Vector2 mMousePos;				// ������ â������ ��ġ
	Vector2 mMouseWorldPos;			// ���� ���������� ���콺 ��ġ
	Vector2 mMouseMove;
	CollisionProfile* mMouseProfile = nullptr;

	bool	mShowCursor  = false;

public:
	bool GetShiftStatus() const {
		return mShift;
	}

	bool GetMouseLDown() const {
		return mMouseLDown;
	}
	bool GetMouseLPush() const {
		return mMouseLPush;
	}
	bool GetMouseLUp() const {
		return mMouseLUp;
	}
	CollisionProfile* GetMouseProfile()	const {
		return mMouseProfile;
	}
	const Vector2& GetMousePos() const {
		return mMousePos;
	}
	const Vector2& GetMouseWorldPos()	const {
		return mMouseWorldPos;
	}
	const Vector2& GetMouseMove()	const {
		return mMouseMove;
	}

public:
	void ComputeWorldMousePos(const Vector2& cameraPos);

public:
	bool Init(HWND hWnd);
	void Update(float deltaTime);
	//void PostUpdate(float deltaTime);
	//void Render(HDC hdc, float deltaTime);

private:
	void UpdateMouse(float deltaTime);
	void UpdateKeyState(float deltaTime);
	void UpdateBindKey(float deltaTime);

	void SetKeyCtrl(const std::string& name, bool ctrl = true);
	void SetKeyAlt(const std::string& name, bool alt = true);
	void SetKeyShift(const std::string& name, bool shift = true);

	KeyState* FindKeyState(unsigned char key);
	BindKey* FindBindKey(const std::string& name);

public:
	bool AddBindKey(const std::string& name, unsigned char key);
	void ClearCallback();
	void ClearCallback(class CScene* scene);

public:
	template <typename T>
	void AddBindFunction(const std::string& keyName,
						 Input_Type type, class CScene* scene,
						 T* object, void (T::* func)()) {
		BindKey* key = FindBindKey(keyName);
		if (!key)
			return;

		BindFunction* function = new BindFunction;

		function->scene = scene;
		function->obj = object;
		// ����Լ��� ����Ҷ� �Լ��ּ�, ��ü�ּҸ� ����ؾ� �Ѵ�.
		function->func = std::bind(func, object);

		key->vecFunction[(int)type].push_back(function);
	}
};

