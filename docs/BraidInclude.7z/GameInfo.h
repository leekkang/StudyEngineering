#pragma once

// �� ��������� ���ӿ��� �������� ���Ǵ� ������� ��Ƶΰ�
// Include�ؼ� ����� �������� ���۵Ǿ���.
#include <Windows.h>
#include <crtdbg.h>
#include <typeinfo>
#include <time.h>

// STL
#include <list>
#include <vector>
#include <unordered_map>
#include <stack>

#include <string>
#include <functional>
#include <algorithm>

#include "Vector2.h"
#include "SharedPtr.h"
#include "Flag.h"
#include "FMOD/fmod.hpp"

#define GRAVITY 9.8f

#pragma comment(lib, "msimg32.lib")

#pragma comment(lib, "../Bin/fmod64_vc.lib")

#define TITLE_NAME		"Braid"

#define ROOT_PATH		"RootPath"
#define TEXTURE_PATH	"TexturePath"
#define SOUND_PATH		"SoundPath"
#define	FONT_PATH		"FontPath"

#define	SAFE_DELETE(p)	if(p)	{ delete p; p = nullptr; }
#define	SAFE_DELETE_ARRAY(p)	if(p)	{ delete[] p; p = nullptr; }
#define	SAFE_RELEASE(p)	if(p)	{ p->Release(); p = nullptr; }


#ifdef _DEBUG
extern bool gDebugMode;
#endif // _DEBUG

#define EPSILON 0.0001f
#define CLAMP(v, min, max) if(v > max) \
							   v = max; \
						   else if (v < min) \
							   v = min;


float RadianToDegree(float Radian);
float DegreeToRadian(float Degree);

#define DELTA_TIME CGameManager::GetInst()->GetDeltaTime()

struct Resolution {
	int width;
	int height;
};

struct AnimationFrameData {
	Vector2	start;	// Left, Top
	Vector2	end;	// Right, Bottom
};

struct CollisionProfile {
	ECollision_Profile		type	= ECollision_Profile::None;
	ECollision_Channel		channel = ECollision_Channel::Default;
	bool					enable  = true;
	std::vector<ECollision_Interaction>	vecCollisionInteraction;
};

struct BoxInfo {
	Vector2	LT;
	Vector2	RB;
};

struct CircleInfo {
	float radius;
	Vector2 center;
};

struct LineInfo {
	Vector2	p1;
	Vector2	p2;
};