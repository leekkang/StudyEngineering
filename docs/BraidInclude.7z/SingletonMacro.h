#pragma once

#if _HAS_CXX17

#define	DECLARE_SINGLE(Type)	\
private:\
	inline static Type*	mInst = nullptr;\
public:\
	static Type* GetInst()\
	{\
		if (!mInst)\
			mInst = new Type;\
		return mInst;\
	}\
	static void DestroyInst()\
	{\
		if(mInst)\
		{\
			delete mInst;\
			mInst = nullptr;\
		}\
	}\
private:\
	Type();\
	~Type();

#define	DEFINITION_SINGLE(Type)	

#else

#define	DECLARE_SINGLE(Type)	\
private:\
	static Type*	mInst;\
public:\
	static Type* GetInst()\
	{\
		if (!mInst)\
			mInst = new Type;\
		return mInst;\
	}\
	static void DestroyInst()\
	{\
		if(mInst)\
		{\
			delete mInst;\
			mInst = nullptr;\
		}\
	}\
private:\
	Type();\
	~Type();

#define	DEFINITION_SINGLE(Type)	Type* Type::mInst = nullptr;

#endif // _HAS_CXX17

