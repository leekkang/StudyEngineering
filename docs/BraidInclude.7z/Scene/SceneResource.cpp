
#include "SceneResource.h"
#include "../Resource/ResourceManager.h"
#include "../Resource/Texture/Texture.h"
#include "../Resource/Animation/AnimationSequence.h"
#include "../Resource/Sound/Sound.h"

CSceneResource::CSceneResource() {
}

CSceneResource::~CSceneResource() {
	{
		auto	iter = mMapTexture.begin();
		auto	iterEnd = mMapTexture.end();
		for (; iter != iterEnd;) {
			std::string	key = iter->first;

			iter = mMapTexture.erase(iter);
			iterEnd = mMapTexture.end();

			CResourceManager::GetInst()->ReleaseTexture(key);
		}
	}
	{
		auto	iter = mMapAnimationSequence.begin();
		auto	iterEnd = mMapAnimationSequence.end();
		for (; iter != iterEnd;) {
			std::string	key = iter->first;

			iter = mMapAnimationSequence.erase(iter);
			iterEnd = mMapAnimationSequence.end();

			CResourceManager::GetInst()->ReleaseAnimation(key);
		}
	}
	{
		auto	iter = mMapSound.begin();
		auto	iterEnd = mMapSound.end();
		for (; iter != iterEnd;) {
			std::string	key = iter->first;

			iter = mMapSound.erase(iter);
			iterEnd = mMapSound.end();

			CResourceManager::GetInst()->ReleaseSound(key);
		}
	}
}

bool CSceneResource::LoadTextureWithDIB(const std::string& name, const TCHAR* fileName) {
	if (FindTexture(name))
		return false;

	if (!CResourceManager::GetInst()->LoadTextureWithDIB(name, fileName))
		return false;

	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
	return true;
}
bool CSceneResource::LoadTextureWithDIB(const std::string& name, const std::vector<const TCHAR*>& vecFileName) {
	if (FindTexture(name))
		return false;

	if (!CResourceManager::GetInst()->LoadTextureWithDIB(name, vecFileName))
		return false;

	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
	return true;
}
bool CSceneResource::CreateAnimSeqWithDIB(const std::string& name, const std::string& textureName, const TCHAR* fileName) {
	if (FindAnimationSeq(name))
		return false;
	if (!CResourceManager::GetInst()->CreateAnimSeqWithDIB(name, textureName, fileName))
		return false;
	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
	return true;
}
bool CSceneResource::CreateAnimSeqWithDIB(const std::string& name, const std::string& textureName,
														const std::vector<const TCHAR*>& vecFileName) {
	if (FindAnimationSeq(name))
		return false;
	if (!CResourceManager::GetInst()->CreateAnimSeqWithDIB(name, textureName, vecFileName))
		return false;
	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
	return true;
}


bool CSceneResource::LoadTexture(const std::string& name, const TCHAR* fileName, const std::string& pathName) {
	if (FindTexture(name))
		return false;

	if (!CResourceManager::GetInst()->LoadTexture(name, fileName, pathName))
		return false;

	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
	return true;
}
bool CSceneResource::LoadTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	if (FindTexture(name))
		return false;

	if (!CResourceManager::GetInst()->LoadTextureFullPath(name, fullPath))
		return false;

	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
	return true;
}

bool CSceneResource::LoadTexture(const std::string& name,
								 const std::vector<const TCHAR*>& vecFileName, const std::string& pathName) {
	if (FindTexture(name))
		return false;

	if (!CResourceManager::GetInst()->LoadTexture(name, vecFileName, pathName))
		return false;

	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
	return true;
}
bool CSceneResource::LoadTextureFullPath(const std::string& name,
										 const std::vector<const TCHAR*>& vecFullPath) {
	if (FindTexture(name))
		return false;

	if (!CResourceManager::GetInst()->LoadTextureFullPath(name, vecFullPath))
		return false;

	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
	return true;
}

//#ifdef UNICODE
//
//bool CSceneResource::LoadTexture(const std::string& name,
//								 const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
//	if (FindTexture(name))
//		return false;
//
//	if (!CResourceManager::GetInst()->LoadTexture(name, vecFileName, pathName))
//		return false;
//
//	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
//	return true;
//}
//bool CSceneResource::LoadTextureFullPath(const std::string& name,
//										 const std::vector<std::wstring>& vecFullPath) {
//	if (FindTexture(name))
//		return false;
//
//	if (!CResourceManager::GetInst()->LoadTextureFullPath(name, vecFullPath))
//		return false;
//
//	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
//	return true;
//}
//
//#else
//
//bool CSceneResource::LoadTexture(const std::string& name,
//								 const std::vector<std::string>& vecFileName, const std::string& pathName) {
//	if (FindTexture(name))
//		return false;
//
//	if (!CResourceManager::GetInst()->LoadTexture(name, vecFileName, pathName))
//		return false;
//
//	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
//	return true;
//}
//bool CSceneResource::LoadTextureFullPath(const std::string& name,
//										 const std::vector<std::string>& vecFullPath) {
//	if (FindTexture(name))
//		return false;
//
//	if (!CResourceManager::GetInst()->LoadTextureFullPath(name, vecFullPath))
//		return false;
//
//	mMapTexture[name] = CResourceManager::GetInst()->FindTexture(name);
//	return true;
//}
//
//#endif

CTexture* CSceneResource::LoadTexture(FILE* file) {
	CTexture* texture = CResourceManager::GetInst()->LoadTexture(file);
	if (!texture)
		return nullptr;

	if (!FindTexture(texture->GetName()))
		mMapTexture.insert(std::make_pair(texture->GetName(), texture));

	return texture;
}

void CSceneResource::SetColorKey(const std::string& name, unsigned char r, unsigned char g, unsigned char b, int index) {
	CResourceManager::GetInst()->SetColorKey(name, r, g, b, index);
}
void CSceneResource::SetColorKeyAll(const std::string& name, unsigned char r, unsigned char g, unsigned char b) {
	CResourceManager::GetInst()->SetColorKeyAll(name, r, g, b);
}

CTexture* CSceneResource::FindTexture(const std::string& name) {
	auto iter = mMapTexture.find(name);
	if (iter == mMapTexture.end()) {
		CTexture* texture = CResourceManager::GetInst()->FindTexture(name);
		if (!texture)
			return nullptr;

		mMapTexture.insert(std::make_pair(name, texture));
		return texture;
	}
	return iter->second;
}


bool CSceneResource::CreateAnimationSequence(const std::string& name, CTexture* texture) {
	if (FindAnimationSeq(name))
		return false;

	if (!CResourceManager::GetInst()->CreateAnimationSequence(name, texture))
		return false;

	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
	return true;
}
bool CSceneResource::CreateAnimationSequence(const std::string& name, const std::string& textureName) {
	if (FindAnimationSeq(name))
		return false;

	if (!CResourceManager::GetInst()->CreateAnimationSequence(name, textureName))
		return false;

	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
	return true;
}
bool CSceneResource::CreateAnimationSequence(const std::string& name, const std::string& textureName,
											 const TCHAR* fileName, const std::string& pathName) {
	if (FindAnimationSeq(name))
		return false;

	if (!CResourceManager::GetInst()->CreateAnimationSequence(name, textureName, fileName, pathName))
		return false;

	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
	return true;
}
bool CSceneResource::CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName,
													 const TCHAR* fullPath) {
	if (FindAnimationSeq(name))
		return false;

	if (!CResourceManager::GetInst()->CreateAnimationSequenceFullPath(name, textureName, fullPath))
		return false;

	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
	return true;
}

bool CSceneResource::CreateAnimationSequence(const std::string& name, const std::string& textureName,
											 const std::vector<const TCHAR*>& vecFileName,
											 const std::string& pathName) {
	if (FindAnimationSeq(name))
		return false;

	if (!CResourceManager::GetInst()->CreateAnimationSequence(name, textureName, vecFileName, pathName))
		return false;

	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
	return true;
}
bool CSceneResource::CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName,
													 const std::vector<const TCHAR*>& vecFullPath) {
	if (FindAnimationSeq(name))
		return false;

	if (!CResourceManager::GetInst()->CreateAnimationSequenceFullPath(name, textureName, vecFullPath))
		return false;

	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
	return true;
}

//#ifdef UNICODE
//
//bool CSceneResource::CreateAnimationSequence(const std::string& name, const std::string& textureName,
//											 const std::vector<std::wstring>& vecFileName,
//											 const std::string& pathName) {
//	if (FindAnimationSeq(name))
//		return false;
//
//	if (!CResourceManager::GetInst()->CreateAnimationSequence(name, textureName, vecFileName, pathName))
//		return false;
//
//	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
//	return true;
//}
//bool CSceneResource::CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName,
//													 const std::vector<std::wstring>& vecFullPath) {
//	if (FindAnimationSeq(name))
//		return false;
//
//	if (!CResourceManager::GetInst()->CreateAnimationSequenceFullPath(name, textureName, vecFullPath))
//		return false;
//
//	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
//	return true;
//}
//
//#else
//
//bool CSceneResource::CreateAnimationSequence(const std::string& name, const std::string& textureName,
//											 const std::vector<std::string>& vecFileName,
//											 const std::string& pathName) {
//	if (FindAnimationSeq(name))
//		return false;
//
//	if (!CResourceManager::GetInst()->CreateAnimationSequence(name, textureName, vecFileName, pathName))
//		return false;
//
//	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
//	return true;
//}
//bool CSceneResource::CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName,
//													 const std::vector<std::string>& vecFullPath) {
//	if (FindAnimationSeq(name))
//		return false;
//
//	if (!CResourceManager::GetInst()->CreateAnimationSequenceFullPath(name, textureName, vecFullPath))
//		return false;
//
//	mMapAnimationSequence[name] = CResourceManager::GetInst()->FindAnimationSeq(name);
//	return true;
//}
//
//#endif

void CSceneResource::AddAnimationFrame(const std::string& name, const Vector2& start, const Vector2& end) {
	auto iter = mMapAnimationSequence.find(name);
	if (iter != mMapAnimationSequence.end())
		iter->second->AddFrame(start, end);
}
void CSceneResource::AddAnimationFrame(const std::string& name, float posX, float posY, float sizeX, float sizeY) {
	auto iter = mMapAnimationSequence.find(name);
	if (iter != mMapAnimationSequence.end())
		iter->second->AddFrame(posX, posY, sizeX, sizeY);
}

void CSceneResource::AddAnimationFullFrame(const std::string& name, const Vector2& size, int xNum, int yNum) {
	auto iter = mMapAnimationSequence.find(name);
	if (iter == mMapAnimationSequence.end())
		return;

	for (int j = 0; j < yNum; ++j) {
		for (int i = 0; i < xNum; ++i) {
			iter->second->AddFrame(size.x * i, size.y * j, size.x, size.y);
		}
	}
}

CAnimationSequence* CSceneResource::FindAnimationSeq(const std::string& name) {
	auto iter = mMapAnimationSequence.find(name);
	if (iter == mMapAnimationSequence.end()) {
		CAnimationSequence* animation = CResourceManager::GetInst()->FindAnimationSeq(name);
		if (!animation)
			return nullptr;

		mMapAnimationSequence.insert(std::make_pair(name, animation));
		return animation;
	}
	return iter->second;
}



bool CSceneResource::CreateSoundChannel(ESound_Group type) {
	return CResourceManager::GetInst()->CreateSoundChannel(type);
}

bool CSceneResource::LoadSound(ESound_Group type, const std::string& name, bool loop, const char* fileName, const std::string& pathName) {
	if (FindSound(name))
		return false;

	if (!CResourceManager::GetInst()->LoadSound(type, name, loop, fileName, pathName))
		return false;

	mMapSound[name] = CResourceManager::GetInst()->FindSound(name);
	return true;
}

void CSceneResource::SetMasterVolume(int volume) {
	return CResourceManager::GetInst()->SetMasterVolume(volume);
}
void CSceneResource::SetVolume(ESound_Group type, int volume) {
	return CResourceManager::GetInst()->SetVolume(type, volume);
}

bool CSceneResource::SoundPlay(const std::string& name) {
	if (mMapSound.count(name) == 0)
		return false;

	mMapSound[name]->Play();
	return true;
}
bool CSceneResource::SoundStop(const std::string& name) {
	if (mMapSound.count(name) == 0)
		return false;

	mMapSound[name]->Stop();
	return true;
}
bool CSceneResource::SoundPause(const std::string& name) {
	if (mMapSound.count(name) == 0)
		return false;

	mMapSound[name]->Pause();
	return true;
}
bool CSceneResource::SoundResume(const std::string& name) {
	if (mMapSound.count(name) == 0)
		return false;

	mMapSound[name]->Resume();
	return true;
}

FMOD::ChannelGroup* CSceneResource::FindChannelGroup(ESound_Group type) {
	return CResourceManager::GetInst()->FindChannelGroup(type);
}

CSound* CSceneResource::FindSound(const std::string& name) {
	auto iter = mMapSound.find(name);
	if (iter == mMapSound.end()) {
		CSound* sound = CResourceManager::GetInst()->FindSound(name);
		if (!sound)
			return nullptr;

		mMapSound.insert(std::make_pair(name, sound));
		return sound;
	}
	return iter->second;
}



bool CSceneResource::LoadFont(const std::string& name, const TCHAR* fontName, int width, int height) {
	return CResourceManager::GetInst()->LoadFont(name, fontName, width, height);
}
bool CSceneResource::LoadFont(const TCHAR* fontFileName, const std::string& pathName) {
	return CResourceManager::GetInst()->LoadFont(fontFileName, pathName);
}
void CSceneResource::SetFont(const std::string& name, HDC hdc) {
	CResourceManager::GetInst()->SetFont(name, hdc);
}
void CSceneResource::ResetFont(const std::string& name, HDC hdc) {
	CResourceManager::GetInst()->ResetFont(name, hdc);
}

CFont* CSceneResource::FindFont(const std::string& name) {
	return CResourceManager::GetInst()->FindFont(name);
}
