#pragma once

#include "../GameInfo.h"

class CSceneCollision {
	friend class CScene;

private:
	CSceneCollision();
	~CSceneCollision();


private:
	std::vector<class CCollider*>	  mVecCollider;
	std::vector<class CWidgetWindow*> mVecWidgetWindow;
	class CCollider* mMouseCollision		= nullptr;
	class CWidget*   mMouseCollisionWidget  = nullptr;

public:
	void Reset();
	void AddCollider(class CCollider* collider);
	void AddWidgetWindow(class CWidgetWindow* window);
	void CollisionMouse(float deltaTime);
	void Collision(float deltaTime);

private:
	static bool SortY(class CCollider* src, class CCollider* dest);
	static bool SortWindow(class CWidgetWindow* src, class CWidgetWindow* dest);
};

