
#include "StageTutorial.h"

#include "SceneManager.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageBoss.h"

#include "Camera.h"
#include "../Input.h"
#include "../GameManager.h"

#include "../WidgetWindow/MainWindow.h"

#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/Foothold.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"
#include "../GameObject/Mimic.h"

#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"
#include "../GameObject/Lever.h"
#include "../GameObject/Cannon.h"
#include "../GameObject/Bullet.h"

CStageTutorial::CStageTutorial() {
}

CStageTutorial::~CStageTutorial() {
}


bool CStageTutorial::Init() {
	CreateSound();

	// ���� ������
	CreateWidgetWindow<CMainWindow>("StartWidgetWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageTutorial.tmp", TEXT("bg_4_01.bmp"));

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(475.f, 750.f, []() {
		CSceneManager::GetInst()->CreateScene<CMainScene>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
									  });
	((CTerrain*)*mTerrain)->SetPortal(11505.f, 315.f, []() {
		CSceneManager::GetInst()->CreateScene<CStageBoss>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
		CMainScene::mClearIndex = max(CMainScene::mClearIndex, 1);
									  });

	// ����
	CMonstar* monstar = CreateObject<CMonstar>("Monstar");
	monstar->SetPos(7502.f, 547.f);
	monstar->SetDirection(1);
	monstar->SetPatrolArea(7502.f, 8088.f);
	CMimic* mimic = CreateObject<CMimic>("Mimic");
	mimic->SetPos(8586.f, 637.f);
	mimic->SetDirection();
	mimic->SetAlertXPos(8286.f);
	mimic->SetChaseRadius(1000.f);

	// ������Ʈ
	CKey* key = CreateObject<CKey>("Key");
	key->SetPos(575.f, 750.f);
	key->SetObjectTexture(true);
	CGate* gate = CreateObject<CGate>("Gate");
	gate->SetPos(775.f, 750.f);
	gate->SetObjectTexture(true);
	CLever* lever = CreateObject<CLever>("Lever");
	lever->SetPos(975.f, 750.f);
	lever->SetObjectTexture(false);

	CCannon* cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(9035.f, 415.f);
	cannon->SetSpawnPos(8995.f, 442.f);
	cannon->SetObjectTexture(TEXT("Object/Cannon/cannonTuto1.bmp"), "cannonTuto1", false);
	cannon->SetCannonType(ECannon_Type::Monstar);
	cannon->SetBulletCount(1);
	cannon->SetBulletVelocity(-300.f, 20.f);
	cannon->SetSpawnTime(3.f);
	cannon->InitBullet();

	cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(10080.f, 413.f);
	cannon->SetSpawnPos(10040.f, 440.f); // ��Ÿ�� �ǹ��� ���ʿ� �ִ�
	cannon->SetObjectTexture(TEXT("Object/Cannon/cannonTuto2.bmp"), "cannonTuto2", false);
	cannon->SetCannonType(ECannon_Type::Monstar);
	cannon->SetBulletCount(2);
	cannon->SetBulletVelocity(-300.f, 20.f);
	cannon->SetSpawnTime(3.f);
	cannon->InitBullet();

	//cannon = CreateObject<CCannon>("Cannon");
	//cannon->SetPos(10080.f, 583.f);
	//cannon->SetSpawnPos(10040.f, 583.f);
	//cannon->SetObjectTexture(TEXT("Object/cannon1-1_2.bmp"), "cannon1-1_2", false);
	//cannon->SetCannonType(ECannon_Type::Bullet);
	//cannon->SetBulletCount(3);
	//cannon->SetBulletVelocity(-400.f, 0.f);
	//cannon->SetSpawnTime(2.f);
	//cannon->InitBullet();

	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(20);

	return CScene::Init();
}

void CStageTutorial::CreateSound() {
	GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, "MainBgm.mp3");

	std::vector<std::tuple<ESound_Group, const char*, const char*, int>> soundInfo{
		{ESound_Group::Effect, "OtherBounce", "other_bounce", 1},
		{ESound_Group::Effect, "BulletHitWall", "bullet_hits_wall", 3},
		{ESound_Group::Effect, "BulletHitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "BulletHitBullet", "bullet_hits_bullet", 1},
	};

	size_t	size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
									 (std::string(std::get<2>(info)) + ".wav").c_str());
			continue;
		}

		for (int j = 0; j < count; ++j) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j), false,
									 (std::get<2>(info) + std::to_string(j + 1) + ".wav").c_str());
		}
	}
}