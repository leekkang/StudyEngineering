
#include "StageTutorial.h"

#include "../GameManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Camera.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageHole.h"

#include "../WidgetWindow/MainWindow.h"
#include "../WidgetWindow/DefaultStageWindow.h"


#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/Foothold.h"
#include "../GameObject/Puzzle.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"
//#include "../GameObject/Mimic.h"

#include "../GameObject/Cannon.h"
//#include "../GameObject/Lever.h"
//#include "../GameObject/Bullet.h"

CStageTutorial::CStageTutorial() {
}

CStageTutorial::~CStageTutorial() {
}


bool CStageTutorial::Init() {
	// ����
	//GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, true, "MainBgm", ".mp3");

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(ESound_Group::BGM, 20);

	// ���� ������
	CDefaultStageWindow* stage = CreateWidgetWindow<CDefaultStageWindow>("StageTutorialWindow");
	GetResource()->LoadTexture("StageTutorialTexture", TEXT("Widget/stageTutorial.bmp"));
	stage->SetStageTexture("StageTutorialTexture");
	stage->SetStageText(TEXT("������ ����"), 705.f);
	CreateWidgetWindow<CMainWindow>("MainWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageTutorial.tmp", TEXT("bgTutorial.bmp"));

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(475.f, 750.f, [&]() {
		SavePuzzle('0');
		CSceneManager::GetInst()->CreateScene<CMainScene>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
									  });
	((CTerrain*)*mTerrain)->SetPortal(11505.f, 315.f, [&]() {
		SavePuzzle('0');
		CSceneManager::GetInst()->CreateScene<CStageHole>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
		CMainScene::mClearIndex = max(CMainScene::mClearIndex, 1);
									  });

	// ����
	mPuzzleCount = 3;
	mVecPuzzleStatus.resize(mPuzzleCount);
	LoadPuzzle('0');

	CPuzzle* puzzle = CreateObject<CPuzzle>("Puzzle");
	puzzle->SetObjectTexture(TEXT("Object/Puzzle/tutorial1"), false);
	puzzle->SetPos(5967.f, 508.f);
	puzzle->SetObtainLevel(0);
	puzzle->SetPieceOrder(1);
	puzzle->SetObtained(mVecPuzzleStatus[1]);

	puzzle = CreateObject<CPuzzle>("Puzzle");
	puzzle->SetObjectTexture(TEXT("Object/Puzzle/tutorial2"), false);
	puzzle->SetPos(8594.f, 232.f);
	puzzle->SetObtainLevel(0);
	puzzle->SetPieceOrder(2);
	puzzle->SetObtained(mVecPuzzleStatus[2]);

	puzzle = CreateObject<CPuzzle>("Puzzle");
	puzzle->SetObjectTexture(TEXT("Object/Puzzle/tutorial3"), false);
	puzzle->SetPos(9630.f, 162.f);
	puzzle->SetObtainLevel(1);
	puzzle->SetPieceOrder(0);
	puzzle->SetObtained(mVecPuzzleStatus[0]);


	// ����
	CMonstar* monstar = CreateObject<CMonstar>("Monstar");
	monstar->SetPos(7502.f, 547.f);
	monstar->SetDirection(1);
	monstar->SetPatrolArea(7502.f, 8088.f);
	//CMimic* mimic = CreateObject<CMimic>("Mimic");
	//mimic->SetPos(8586.f, 637.f);
	//mimic->SetDirection();
	//mimic->SetAlertXPos(8286.f);
	//mimic->SetChaseRadius(1000.f);


	// ������Ʈ
	//CLever* lever = CreateObject<CLever>("Lever");
	//lever->SetPos(975.f, 750.f);
	//lever->SetObjectTexture(false);

	CCannon* cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(9035.f, 415.f);
	cannon->SetSpawnPos(8995.f, 442.f);
	cannon->SetObjectTexture(TEXT("Object/Cannon/cannonTuto1.bmp"), false);
	cannon->SetCannonType(ECannon_Type::Monstar);
	cannon->SetBulletCount(1);
	cannon->SetBulletVelocity(-300.f, 20.f);
	cannon->SetSpawnTime(3.f);
	cannon->InitBullet();

	cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(10080.f, 413.f);
	cannon->SetSpawnPos(10040.f, 440.f); // ��Ÿ�� �ǹ��� ���ʿ� �ִ�
	cannon->SetObjectTexture(TEXT("Object/Cannon/cannonTuto2.bmp"), false);
	cannon->SetCannonType(ECannon_Type::Monstar);
	cannon->SetBulletCount(2);
	cannon->SetBulletVelocity(-300.f, 20.f);
	cannon->SetSpawnTime(3.f);
	cannon->InitBullet();

	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(20);

	return CScene::Init();
}