#pragma once

#include "Scene.h"

class CStageBoss : public CScene {
	friend class CSceneManager;

private:
	CStageBoss();
	virtual ~CStageBoss();
	DISALLOW_COPY_AND_ASSIGN(CStageBoss)


public:
	class CBoss* mBoss = nullptr;

	class CBoss* GetBoss() const {
		return mBoss;
	}

public:
	bool Init();

private:
	void CreateSound();
};

