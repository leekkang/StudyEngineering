#pragma once

#include "Scene.h"

class CStageStatic : public CScene {
	friend class CSceneManager;

private:
	CStageStatic();
	virtual ~CStageStatic();
	DISALLOW_COPY_AND_ASSIGN(CStageStatic)


public:
	bool Init();
};

