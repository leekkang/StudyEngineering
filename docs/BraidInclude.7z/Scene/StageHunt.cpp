
#include "StageHunt.h"

#include "../GameManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Camera.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageTutorial.h"
#include "StageHole.h"

#include "../WidgetWindow/MainWindow.h"
#include "../WidgetWindow/StageHuntWindow.h"


#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"

#include "../GameObject/Gate.h"
#include "../GameObject/Puzzle.h"

CStageHunt::CStageHunt() {
}

CStageHunt::~CStageHunt() {
}


int CStageHunt::GetStageMonstarCount() const {
	int count = 0;
	for (int i = 0; i < mMonstarCount; ++i) {
		if (!mMonstar[i]->CheckDead())
			++count;
	}
	return count;
}

bool CStageHunt::Init() {
	// ����
	//GetResource()->LoadSound(ESound_Group::BGM, "HuntBGM", true, true, "04-Romanesca", ".mp3");

	//GetResource()->SoundPlay("HuntBGM");
	//GetResource()->SetVolume(ESound_Group::BGM, 80);

	// ���� ������
	CStageHuntWindow* stage = CreateWidgetWindow<CStageHuntWindow>("StageHuntWindow");
	GetResource()->LoadTexture("StageHuntTexture", TEXT("Widget/stageHunt.bmp"));
	stage->SetStageTexture("StageHuntTexture");
	stage->SetStageText(TEXT("���!"), 760.f);
	CreateWidgetWindow<CMainWindow>("MainWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageHunt.tmp", TEXT("bgSky.bmp"));

	// �÷��̾� �տ� ������ ����
	//SetTopography({
	//	{TEXT("stageBoss/topography1.bmp"), Vector2(16.f, 343.f)},
	//			  });

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(131.f, 860.f, [&]() {
		SavePuzzle('1');
		CSceneManager::GetInst()->CreateScene<CStageTutorial>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });
	((CTerrain*)*mTerrain)->SetPortal(1416.f, 809.f, [&]() {
		SavePuzzle('1');
		CSceneManager::GetInst()->CreateScene<CStageHole>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
		CMainScene::mClearIndex = max(CMainScene::mClearIndex, 2);
									  });

	// ����
	mPuzzleCount = 1;
	mVecPuzzleStatus.resize(mPuzzleCount);
	LoadPuzzle('1');

	CPuzzle* puzzle = CreateObject<CPuzzle>("Puzzle");
	puzzle->SetObjectTexture(TEXT("Object/Puzzle/3"), false);
	puzzle->SetPos(1470.f, 86.f);
	puzzle->SetObtainLevel(2);
	puzzle->SetPieceOrder(0);
	puzzle->SetObtained(mVecPuzzleStatus[0]);


	// ����
	mMonstar[0] = CreateObject<CMonstar>("Monstar");
	mMonstar[0]->SetPos(850.f, 860.f);
	mMonstar[0]->SetPatrolArea(0.f, 1600.f);
	mMonstar[0]->SetDirection(1);
	mMonstar[1] = CreateObject<CMonstar>("Monstar");
	mMonstar[1]->SetPos(1250.f, 674.f);
	mMonstar[1]->SetPatrolArea(855.f, 1270.f);
	mMonstar[1]->SetDirection(-1);
	mMonstar[2] = CreateObject<CMonstar>("Monstar");
	mMonstar[2]->SetPos(150.f, 674.f);
	mMonstar[2]->SetPatrolArea(0.f, 630.f);
	mMonstar[2]->SetDirection(1);
	mMonstar[3] = CreateObject<CMonstar>("Monstar");
	mMonstar[3]->SetPos(600.f, 463.f);
	mMonstar[3]->SetPatrolArea(0.f, 855.f);
	mMonstar[3]->SetDirection(1);
	mMonstar[4] = CreateObject<CMonstar>("Monstar");
	mMonstar[4]->SetPos(1500.f, 460.f);
	mMonstar[4]->SetPatrolArea(1247.f, 1600.f);
	mMonstar[4]->SetDirection(-1);
	mMonstar[5] = CreateObject<CMonstar>("Monstar");
	mMonstar[5]->SetPos(1000.f, 177.f);
	mMonstar[5]->SetPatrolArea(0.f, 1600.f);
	mMonstar[5]->SetDirection(-1);

	// ������Ʈ
	mGate = CreateObject<CGate>("Gate");
	mGate->SetPos(1390.f, 193.f);
	mGate->SetObjectTexture(false);

	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	return CScene::Init();
}

void CStageHunt::Update(float deltaTime) {
	CScene::Update(deltaTime);

	if (GetStageMonstarCount() == 0 && !mGate->CheckUnlock())
		mGate->UnlockGate();
}
