#pragma once

#include "Scene.h"

class CStageCloud : public CScene {
	friend class CSceneManager;

private:
	CStageCloud();
	virtual ~CStageCloud();
	DISALLOW_COPY_AND_ASSIGN(CStageCloud)


public:
	bool Init();
};