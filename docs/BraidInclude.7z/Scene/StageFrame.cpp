
#include "StageFrame.h"

#include "../GameManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Camera.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageHole.h"
#include "StageCloud.h"

#include "../WidgetWindow/MainWindow.h"
#include "../WidgetWindow/DefaultStageWindow.h"


#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/Puzzle.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"

#include "../GameObject/Cannon.h"
#include "../GameObject/Platform.h"
#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"

CStageFrame::CStageFrame() {
}

CStageFrame::~CStageFrame() {
}


bool CStageFrame::Init() {
	// ����
	GetResource()->LoadSound(ESound_Group::BGM, "FrameBGM", true, true, "06-TheDarkeningGround", ".mp3");

	GetResource()->SoundPlay("FrameBGM");
	GetResource()->SetVolume(ESound_Group::BGM, 40);

	// ���� ������
	CDefaultStageWindow* stage = CreateWidgetWindow<CDefaultStageWindow>("StageFrameWindow");
	GetResource()->LoadTexture("StageFrameTexture", TEXT("Widget/stageFrame.bmp"));
	stage->SetStageTexture("StageFrameTexture");
	stage->SetStageText(TEXT("������ ����"), 705.f);
	CreateWidgetWindow<CMainWindow>("MainWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageFrame.tmp", TEXT("bgShine.bmp"));

	// �÷��̾� �տ� ������ ����
	SetTopography({
		{TEXT("Topography/stageFrame1.bmp"), Vector2(1061.f, 0.f)},
		{TEXT("Topography/stageFrame2.bmp"), Vector2(286.f, 674.f)},
		{TEXT("Topography/stageFrame3.bmp"), Vector2(584.f, 482.f)},
		{TEXT("Topography/stageFrame4.bmp"), Vector2(280.f, 262.f)},
				  });

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(117.f, 830.f, [&]() {
		SavePuzzle('3');
		CSceneManager::GetInst()->CreateScene<CStageHole>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });
	((CTerrain*)*mTerrain)->SetPortal(1414.f, 860.f, [&]() {
		SavePuzzle('3');
		SaveClear('4');
		CSceneManager::GetInst()->CreateScene<CStageCloud>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
		CMainScene::mClearIndex = max(CMainScene::mClearIndex, 4);
									  });

	// ����
	mPuzzleCount = 1;
	mVecPuzzleStatus.resize(mPuzzleCount);
	LoadPuzzle('3');

	CPuzzle* puzzle = CreateObject<CPuzzle>("Puzzle");
	puzzle->SetObjectTexture(TEXT("Object/Puzzle/8"), false);
	puzzle->SetPos(1400.f, 590.f);
	puzzle->SetObtainLevel(2);
	puzzle->SetPieceOrder(0);
	puzzle->SetObtained(mVecPuzzleStatus[0]);


	// ������Ʈ
	CCannon* cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(337.f, 66.f);
	cannon->SetSpawnPos(350.f, 120.f);
	cannon->SetObjectTexture(TEXT("Object/Cannon/frame.bmp"), false);
	cannon->SetTimerPos(-90.f, -60.f);
	cannon->SetCannonType(ECannon_Type::Monstar);
	cannon->SetBulletCount(5);
	cannon->SetBulletVelocity(350.f, 200.f);
	cannon->SetSpawnTime(3.f);
	cannon->InitBullet();

	CPlatform* platform = CreateObject<CPlatform>("Platform");
	platform->SetPos(1162.f, 153.f);
	platform->SetObjectTexture(TEXT("Object/planeFrame.bmp"), false);
	platform->SetDirection(true);
	platform->SetMinPos(150.f);
	platform->SetMaxPos(677.f);
	platform->SetSpeed(10.f);
	platform->SetColliderSize((float)platform->GetTexture()->GetWidth() - 2.f, 
							  (float)platform->GetTexture()->GetHeight());
	platform->StartMove(true);

	CKey* key = CreateObject<CKey>("Key");
	key->SetPos(370.f, 270.f);
	key->SetObjectTexture(true);
	key->SetLookLeft(true);
	CGate* gate = CreateObject<CGate>("Gate");
	gate->SetPos(1267.f, 685.f);
	gate->SetObjectTexture(true);
	gate->SetColliderSize(95.f, 152.f);


	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);


	return CScene::Init();
}