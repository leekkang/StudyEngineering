#pragma once

#include "../GameObject/GameObject.h"

class CCamera {
	friend class CScene;

private:
	CCamera();
	~CCamera();

private:
	Vector2	mPos;						// ī�޶� ��ġ
	Vector2	mResolution;				// ������ â�� �ػ�
	Vector2	mWorldResolution;			// ��ü ������ �ػ�

	CSharedPtr<CGameObject>	mTarget;	// ī�޶� ����ٴ� Ÿ��
	Vector2	mTargetOffset;				// Ÿ�����κ��� �󸶳� ������ ������
	Vector2	mTargetPivot;				// Ÿ���� ȭ�鿡�� ��ũ�Ѹ� �ɶ��� ����

public:
	Vector2 GetPos()	const {
		return mPos;
	}

	Vector2 GetResolution()	const {
		return mResolution;
	}

	Vector2 GetWorldResolution()	const {
		return mWorldResolution;
	}

	CGameObject* GetTarget()	const {
		return mTarget;
	}

	Vector2 GetTargetOffset()	const {
		return mTargetOffset;
	}

	Vector2 GetTargetPivot()	const {
		return mTargetPivot;
	}


public:
	void SetPos(const Vector2& pos) {
		mPos = pos;
	}
	void SetPos(float x, float y) {
		mPos = Vector2(x, y);
	}

	void SetResolution(const Vector2& resolution) {
		mResolution = resolution;
	}
	void SetResolution(float x, float y) {
		mResolution = Vector2(x, y);
	}

	void SetWorldResolution(const Vector2& worldResolution) {
		mWorldResolution = worldResolution;
	}
	void SetWorldResolution(float x, float y) {
		mWorldResolution = Vector2(x, y);
	}

	void SetTargetOffset(const Vector2& targetOffset) {
		mTargetOffset = targetOffset;
	}
	void SetTargetOffset(float x, float y) {
		mTargetOffset = Vector2(x, y);
	}

	void SetTargetPivot(const Vector2& targetPivot) {
		mTargetPivot = targetPivot;
	}
	void SetTargetPivot(float x, float y) {
		mTargetPivot = Vector2(x, y);
	}

	void SetTarget(CGameObject* target) {
		mTarget = target;
	}

public:
	void Update(float deltaTime);
};

