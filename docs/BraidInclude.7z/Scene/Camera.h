#pragma once

#include "../GameObject/GameObject.h"

class CCamera {
	friend class CScene;

private:
	CCamera();
	~CCamera();

private:
	Vector2	mPos;						// ī�޶� ��ġ

	CSharedPtr<CGameObject>	mTarget;	// ī�޶� ����ٴ� Ÿ��
	Vector2	mTargetOffset;				// Ÿ�����κ��� �󸶳� ������ ������
	Vector2	mTargetPivot;				// Ÿ���� ȭ�鿡�� ��ũ�Ѹ� �ɶ��� ����

	Resolution	mResolution		{};		// ������ â�� �ػ�
	Resolution	mWorldResolution{};		// ��ü ������ �ػ�

public:
	Vector2 GetPos()	const {
		return mPos;
	}

	Resolution GetResolution()	const {
		return mResolution;
	}

	Resolution GetWorldResolution()	const {
		return mWorldResolution;
	}

	CGameObject* GetTarget()	const {
		return mTarget;
	}

	Vector2 GetTargetOffset()	const {
		return mTargetOffset;
	}

	Vector2 GetTargetPivot()	const {
		return mTargetPivot;
	}


public:
	void SetPos(const Vector2& pos) {
		mPos = pos;
	}
	void SetPos(float x, float y) {
		mPos = Vector2(x, y);
	}

	void SetResolution(const Resolution& resolution) {
		mResolution = resolution;
	}
	void SetResolution(int w, int h) {
		mResolution.width = w;
		mResolution.height = h;
	}
	void SetResolution(const Vector2& resolution) {
		mResolution.width = (int)resolution.x;
		mResolution.height = (int)resolution.y;
	}

	void SetWorldResolution(const Resolution& worldResolution) {
		mWorldResolution = worldResolution;
	}
	void SetWorldResolution(int w, int h) {
		mWorldResolution.width = w;
		mWorldResolution.height = h;
	}
	void SetWorldResolution(const Vector2& worldResolution) {
		mResolution.width = (int)worldResolution.x;
		mResolution.height = (int)worldResolution.y;
	}

	void SetTargetOffset(const Vector2& targetOffset) {
		mTargetOffset = targetOffset;
	}
	void SetTargetOffset(float x, float y) {
		mTargetOffset = Vector2(x, y);
	}

	void SetTargetPivot(const Vector2& targetPivot) {
		mTargetPivot = targetPivot;
	}
	void SetTargetPivot(float x, float y) {
		mTargetPivot = Vector2(x, y);
	}

	void SetTarget(CGameObject* target) {
		mTarget = target;
	}

public:
	void Update(float deltaTime);
};

