
#include "SceneManager.h"
#include "MainScene.h"
#include "../Input.h"
#include "../GameManager.h"

DEFINITION_SINGLE(CSceneManager)

CSceneManager::CSceneManager() {
}

CSceneManager::~CSceneManager() {
	SAFE_DELETE(mNextScene);
	SAFE_DELETE(mScene);
}


bool CSceneManager::Init() {
	if (!CreateScene<CMainScene>()) {
		return false;
	}
	return true;
}

bool CSceneManager::Update(float deltaTime) {
	mScene->Update(deltaTime);

	return ChangeScene();
}

void CSceneManager::Collision(float deltaTime) {
	mScene->Collision(deltaTime);
}

bool CSceneManager::PostUpdate(float deltaTime) {
	mScene->PostUpdate(deltaTime);

	return ChangeScene();
}

void CSceneManager::Render(HDC hdc, float deltaTime) {
	mScene->Render(hdc, deltaTime);
}

bool CSceneManager::ChangeScene() {
	if (mNextScene) {
		CInput::GetInst()->ClearCallback(mScene);
		SAFE_DELETE(mScene);

		mScene = mNextScene;
		mNextScene = nullptr;

		return true;
	}

	return false;
}


bool CSceneManager::BlurEffect(HDC hdc, HBITMAP bmp, int radius) {
	BITMAPINFO info{0};
	info.bmiHeader.biSize = sizeof(info.bmiHeader);

	if (0 == GetDIBits(hdc, bmp, 0, 0, nullptr, &info, DIB_RGB_COLORS)) {
		return false;
	}
	char* bits = new char[info.bmiHeader.biSizeImage];

	info.bmiHeader.biCompression = BI_RGB;

	if (0 == GetDIBits(hdc, bmp, 0, info.bmiHeader.biHeight, bits, &info, DIB_RGB_COLORS)) {
		return false;
	}

	int w = info.bmiHeader.biWidth;
	int h = info.bmiHeader.biHeight;
	float rs = ceil(radius * 2.57f);
	for (int i = 0; i < h; ++i) {
		for (int j = 0; j < w; ++j) {
			double r = 0, g = 0, b = 0;
			double count = 0;

			for (int iy = (int)(i - rs); iy < i + rs + 1; ++iy) {
				for (int ix = (int)(j - rs); ix < j + rs + 1; ++ix) {
					auto x = min(static_cast<int>(w) - 1, max(0, ix));
					auto y = min(static_cast<int>(h) - 1, max(0, iy));

					auto dsq = ((ix - j) * (ix - j)) + ((iy - i) * (iy - i));
					auto wght = std::exp(-dsq / (2.0 * radius * radius)) / (3.14 * 2.0 * radius * radius);

					rgb32* temp = reinterpret_cast<rgb32*>(bits);
					rgb32* pixel = &temp[(h - 1 - y) * w + x];

					r += pixel->r * wght;
					g += pixel->g * wght;
					b += pixel->b * wght;
					count += wght;
				}
			}

			rgb32* temp = reinterpret_cast<rgb32*>(bits);
			rgb32* pixel = &temp[(h - 1 - i) * w + j];
			pixel->r = (unsigned char)std::round(r / count);
			pixel->g = (unsigned char)std::round(g / count);
			pixel->b = (unsigned char)std::round(b / count);
		}
	}

	if (0 == SetDIBits(hdc, bmp, 0, info.bmiHeader.biHeight, bits, &info, DIB_RGB_COLORS))
		return false;

	return true;
}
