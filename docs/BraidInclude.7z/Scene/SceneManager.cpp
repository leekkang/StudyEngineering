
#include "SceneManager.h"
#include "MainScene.h"
#include "../Input.h"
#include "../GameManager.h"

DEFINITION_SINGLE(CSceneManager)

CSceneManager::CSceneManager() {
}

CSceneManager::~CSceneManager() {
	SAFE_DELETE(mNextScene);
	SAFE_DELETE(mScene);
}


bool CSceneManager::Init() {
	if (!CreateScene<CMainScene>()) {
		return false;
	}

	mScene->SetInput();
	return true;
}

bool CSceneManager::Update(float deltaTime) {
	mScene->Update(deltaTime);

	return ChangeScene();
}

void CSceneManager::Collision(float deltaTime) {
	mScene->Collision(deltaTime);
}

bool CSceneManager::PostUpdate(float deltaTime) {
	mScene->PostUpdate(deltaTime);

	return ChangeScene();
}

void CSceneManager::Render(HDC hdc, float deltaTime) {
	mScene->Render(hdc, deltaTime);
}

bool CSceneManager::ChangeScene() {
	if (mNextScene) {
		// ���� ����� �����Ѵ�.
		SAFE_DELETE(mScene);
		CInput::GetInst()->ClearCallback();

		mScene = mNextScene;
		mNextScene = nullptr;

		mScene->SetInput();
#ifdef _DEBUG
		CInput::GetInst()->AddBindFunction<CGameManager>("Debug", Input_Type::Down, 
														 CGameManager::GetInst(), &CGameManager::SetDebugMode);
#endif // _DEBUG

		return true;
	}

	return false;
}
