
#include "Camera.h"
#include "../Input.h"

CCamera::CCamera() {
}

CCamera::~CCamera() {
}

void CCamera::Update(float deltaTime) {
	if (mTarget) {
		if (!mTarget->GetActive()) {
			mTarget = nullptr;
		} else {
			mPos = mTarget->GetPos() + mTargetOffset;
			mPos.x -= mTargetPivot.x * mResolution.width;
			mPos.y -= mTargetPivot.y * mResolution.height;
		}
	}

	// ī�޶� ���带 ����� ���ϵ��� ������ش�.
	if (mPos.x < 0.f)
		mPos.x = 0.f;

	else if (mPos.x + mResolution.width > mWorldResolution.width)
		mPos.x = (float)(mWorldResolution.width - mResolution.width);

	if (mPos.y < 0.f)
		mPos.y = 0.f;

	else if (mPos.y + mResolution.height > mWorldResolution.height)
		mPos.y = (float)(mWorldResolution.height - mResolution.height);

	CInput::GetInst()->ComputeWorldMousePos(mPos);
}
