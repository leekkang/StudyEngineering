
#include "Camera.h"
#include "../Input.h"

CCamera::CCamera() {
}

CCamera::~CCamera() {
}

void CCamera::Update(float deltaTime) {
	if (mTarget) {
		if (!mTarget->GetActive())
			mTarget = nullptr;

		else
			mPos = mTarget->GetPos() - mTargetPivot * mResolution + mTargetOffset;
	}

	// ī�޶� ���带 ����� ���ϵ��� ������ش�.
	if (mPos.x < 0.f)
		mPos.x = 0.f;

	else if (mPos.x + mResolution.x > mWorldResolution.x)
		mPos.x = mWorldResolution.x - mResolution.x;

	if (mPos.y < 0.f)
		mPos.y = 0.f;

	else if (mPos.y + mResolution.y > mWorldResolution.y)
		mPos.y = mWorldResolution.y - mResolution.y;

	CInput::GetInst()->ComputeWorldMousePos(mPos);
}
