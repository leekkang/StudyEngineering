
#include "EditScene.h"

#include "../GameManager.h"
#include "SceneResource.h"
#include "Camera.h"

#include "../Input.h"
#include "../Resource/Texture/Texture.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/BackObj.h"

#include "EditDlg.h"
#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderLine.h"


CEditScene::CEditScene() {
}

CEditScene::~CEditScene() {
	CGameManager::GetInst()->SetEditMode(false);
	SAFE_DELETE(mEditDlg);
}

void CEditScene::SetInput() {
	CScene::SetInput();

	CInput::GetInst()->AddBindFunction<CEditScene>(
		"Up", Input_Type::Push, this, this, &CEditScene::MoveUp);
	CInput::GetInst()->AddBindFunction<CEditScene>(
		"Down", Input_Type::Push, this, this, &CEditScene::MoveDown);
	CInput::GetInst()->AddBindFunction<CEditScene>(
		"Right", Input_Type::Push, this, this, &CEditScene::MoveRight);
	CInput::GetInst()->AddBindFunction<CEditScene>(
		"Left", Input_Type::Push, this, this, &CEditScene::MoveLeft);
	CInput::GetInst()->AddBindFunction<CEditScene>(
		"OpenMapEditor", Input_Type::Down, this, this, &CEditScene::OpenMapEditor);
	CInput::GetInst()->AddBindFunction<CEditScene>(
		"MouseL", Input_Type::Push, this, this, &CEditScene::MouseLButtonDrag);
}

int CEditScene::GetColliderListSize() const {
	if (mTerrain) {
		return GetTerrain()->GetColliderListSize();
	}
	return 0;
}

CCollider* CEditScene::GetCollider(int index) const {
	if (mTerrain) {
		return GetTerrain()->GetCollider(index);
	}
	return nullptr;
}

CCollider* CEditScene::GetSelectedCollider() const {
	if (mTerrain) {
		return GetTerrain()->GetCollider(mEditDlg->GetSelectedColliderIndex());
	}
	return nullptr;
}

void CEditScene::SetCameraPos(float x, float y) {
	GetCamera()->SetPos(x, y);
}

void CEditScene::PlayEscapeSound() {
	GetResource()->SoundPlay("MenuEscape");
}

bool CEditScene::Init() {
	GetResource()->LoadSound(ESound_Group::UI, "MenuEscape", false, "menu_escape.wav");

	CBackObj* back = CreateObject<CBackObj>("BackObj");
	back->SetTexture("BG", TEXT("bg_4_01.bmp"));
	back->SetSize(1600.f, 900.f);

	GetCamera()->SetResolution((float)CGameManager::GetInst()->GetResolution().width,
							   (float)CGameManager::GetInst()->GetResolution().height);
	GetCamera()->SetWorldResolution(1600.f, 900.f);
	GetCamera()->SetTargetPivot(0.5f, 0.5f);
	GetCamera()->SetTarget(nullptr);

	CGameManager::GetInst()->SetEditMode(true);

	SetInput();

	OpenMapEditor();

	return true;
}

void CEditScene::CreateTerrain(const char* name) {
	if (!mTerrain)
		mTerrain = CreateObject<CTerrain>("Terrain");

	CTexture* texture = GetResource()->FindTexture(name);
	int width = texture->GetWidth();
	int height = texture->GetHeight();

	mTerrain->SetTexture(texture);

	mWorldRS.width = width;
	mWorldRS.height = height;

	CGameObject* back = FindObject("BackObj");
	back->SetSize((float)width, (float)height);

	GetCamera()->SetWorldResolution((float)width, (float)height);
}

void CEditScene::LoadTerrain(const char* fullPath) {
	if (!mTerrain)
		mTerrain = CreateObject<CTerrain>("Terrain");
	mTerrain->LoadFullPath(fullPath);

	char fileName[128]{};
	_splitpath_s(fullPath, nullptr, 0, nullptr, 0, fileName, 128, nullptr, 0);
	((CTerrain*)*mTerrain)->SetFoothold(fileName);

	CTexture* texture = mTerrain->GetTexture();
	int width = texture->GetWidth();
	int height = texture->GetHeight();

	mWorldRS.width = width;
	mWorldRS.height = height;

	CGameObject* back = FindObject("BackObj");
	back->SetSize((float)width, (float)height);

	GetCamera()->SetWorldResolution((float)width, (float)height);
}

void CEditScene::SetCollider(int index, const char* name, const Vector2& lt, const Vector2& rb,
							 ECollider_Type type, ECollision_Profile profile) {
	if (mTerrain)
		GetTerrain()->SetCollider(index, name, lt, rb, type, profile);
}

void CEditScene::DeleteCollider(int index) {
	if (mTerrain)
		GetTerrain()->DeleteCollider(index);
}

void CEditScene::MoveLeft() {
	Vector2 CameraPos = GetCamera()->GetPos();
	GetCamera()->SetPos(CameraPos + Vector2(-500.f * DELTA_TIME, 0.f));
}

void CEditScene::MoveRight() {
	Vector2 CameraPos = GetCamera()->GetPos();
	GetCamera()->SetPos(CameraPos + Vector2(500.f * DELTA_TIME, 0.f));
}

void CEditScene::MoveUp() {
	Vector2 CameraPos = GetCamera()->GetPos();
	GetCamera()->SetPos(CameraPos + Vector2(0.f, -500.f * DELTA_TIME));
}

void CEditScene::MoveDown() {
	Vector2 CameraPos = GetCamera()->GetPos();
	GetCamera()->SetPos(CameraPos + Vector2(0.f, 500.f * DELTA_TIME));
}

void CEditScene::OpenMapEditor() {
	if (!mEditDlg) {
		mEditDlg = new CEditDlg;

		mEditDlg->mScene = this;
		mEditDlg->Init();
		mShowDialogue = true;
	} else {
		mShowDialogue = !mShowDialogue;
		ShowWindow(mEditDlg->GetDialogueHandle(), mShowDialogue ? SW_SHOW : SW_HIDE);
	}
}

void CEditScene::MouseLButtonDrag() {
	//Vector2	MousePos = CInput::GetInst()->GetMousePos();
	//CCamera* Camera = GetCamera();

	//if (MousePos.x < 0.f || MousePos.x > Camera->GetResolution().x ||
	//	MousePos.y < 0.f || MousePos.y > Camera->GetResolution().y)
	//	return;
}