
#include "Scene.h"

#include "../GameManager.h"
#include "../Input.h"

#include "../GameObject/GameObject.h"
#include "../GameObject/Player.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/BackObj.h"

#include "Camera.h"
#include "SceneResource.h"
#include "SceneCollision.h"
#include "SceneRewinder.h"

CScene::CScene() {
	mCamera = new CCamera;
	mResource = new CSceneResource;
	mCollision = new CSceneCollision;
	mRewinder = new CSceneRewinder(this);
}

CScene::~CScene() {
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		mListObject[i].clear();
	}

	SAFE_DELETE(mCamera);
	SAFE_DELETE(mResource);
	SAFE_DELETE(mCollision);
	SAFE_DELETE(mRewinder);
}

bool CScene::CheckRewinding() const {
	return mRewinder->mRewind;
}

void CScene::SetTerrain(CGameObject* terrain) {
	mTerrain = terrain;
}

void CScene::SetInput() {
#ifdef _DEBUG
	CInput::GetInst()->AddBindFunction<CGameManager>("Debug", Input_Type::Down, this,
													 CGameManager::GetInst(), &CGameManager::SetDebugMode);
#endif // _DEBUG
}

void CScene::SetTerrain(const char* terrainFileName, const TCHAR* backFileName) {
	mTerrain = CreateObject<CTerrain>("Terrain");
	mTerrain->LoadFileName(terrainFileName, MAP_PATH);
	((CTerrain*)*mTerrain)->SetSpikeCallback();
	((CTerrain*)*mTerrain)->SetFoothold(terrainFileName);

	CTexture* texture = mTerrain->GetTexture();
	int width = texture->GetWidth();
	int height = texture->GetHeight();

	mWorldRS.width = width;
	mWorldRS.height = height;

	// ���
	CBackObj* back = CreateObject<CBackObj>("BackObj");
	back->SetTexture("BG", backFileName);
	back->SetSize((float)width, (float)height);
}

bool CScene::Init() {
	if (!mRewinder->Init())
		return false;

	return true;
}

void CScene::Update(float deltaTime) {
	if (!mStopScene) {
		for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
			auto iter = mListObject[i].begin();
			auto iterEnd = mListObject[i].end();
			for (; iter != iterEnd;) {
				if (!(*iter)->GetActive()) {
					iter = mListObject[i].erase(iter);
					iterEnd = mListObject[i].end();
					continue;
				} else if (!(*iter)->GetEnable()) {
					++iter;
					continue;
				}

				if (!mRewinder->mRewind)
					(*iter)->Update(deltaTime);
				else if ((*iter)->mImmutable)
					(*iter)->Update(deltaTime);

				// �ݶ��̴� ������Ʈ�� �����Ѵ�.
				(*iter)->UpdateCollider(deltaTime);
				(*iter)->UpdateWidgetComponent(deltaTime);

				++iter;
			}
		}
	}

	auto iter = mVecWidgetWindow.begin();
	auto iterEnd = mVecWidgetWindow.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mVecWidgetWindow.erase(iter);
			iterEnd = mVecWidgetWindow.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->Update(deltaTime);
		// UI�� Ȱ��ȭ üũ�� �����ϰ� �ص� �Ǳ� ������ ���⼭ �Ѵ�.
		mCollision->AddWidgetWindow(*iter);
		++iter;
	}

	mRewinder->Update(deltaTime);

	mCamera->Update(deltaTime);
}

void CScene::Collision(float deltaTime) {

	mCollision->CollisionMouse(deltaTime);

	mCollision->Collision(deltaTime);
}

CGameObject* CScene::FindObject(const std::string& name) {
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		auto iter = mListObject[i].begin();
		auto iterEnd = mListObject[i].end();
		for (; iter != iterEnd; ++iter) {
			if ((*iter)->GetName() == name)
				return *iter;
		}
	}

	return nullptr;
}

void CScene::PostUpdate(float deltaTime) {
	if (!mStopScene) {
		for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
			auto iter = mListObject[i].begin();
			auto iterEnd = mListObject[i].end();

			for (; iter != iterEnd;) {
				if (!(*iter)->GetActive()) {
					iter = mListObject[i].erase(iter);
					iterEnd = mListObject[i].end();
					continue;
				} else if (!(*iter)->GetEnable()) {
					++iter;
					continue;
				}

				if (!mRewinder->mRewind)
					(*iter)->PostUpdate(deltaTime);
				else if ((*iter)->mImmutable)
					(*iter)->PostUpdate(deltaTime);

				// ������ ���ӻ��� ����
				//(*iter)->PostUpdateCollider(deltaTime);
				(*iter)->PostUpdateWidgetComponent(deltaTime);

				++iter;
			}
		}

		if (!CGameManager::GetInst()->GetEditMode())
			mRewinder->PostUpdate(deltaTime);
	}

	auto iter = mVecWidgetWindow.begin();
	auto iterEnd = mVecWidgetWindow.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mVecWidgetWindow.erase(iter);
			iterEnd = mVecWidgetWindow.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->PostUpdate(deltaTime);
		++iter;
	}
}

void CScene::Render(HDC hdc, float deltaTime) {
	// �Һ� ������Ʈ ����Ʈ Ÿ�� ���
	mEasingTime += deltaTime;
	if (mEasingTime < 0.f)
		mImmutableValue = 0;
	else if (mEasingTime < .7f)
		mImmutableValue = (UINT8)(mEasingTime * 230);
	else if (mEasingTime < 1.4f)
		mImmutableValue = (UINT8)((1.4f - mEasingTime) * 230);
	else
		mEasingTime = 0.f;
	
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		// ��� ����� �����Ѵ�. (Z ���� -> Y����)
		mListObject[i].sort(SortRender);

		auto iter = mListObject[i].begin();
		auto iterEnd = mListObject[i].end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mListObject[i].erase(iter);
				iterEnd = mListObject[i].end();
				continue;
			} else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			// ī�޶� �ø�
			if (!(*iter)->OutOfCamera(mCamera)) {
				if (mRewinder->GetRewind() && !(*iter)->mImmutable)
					mRewinder->RenderShadow(hdc, *iter);
				(*iter)->Render(hdc, deltaTime);
			}
			++iter;
		}
	}

#ifdef _DEBUG
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		auto iter = mListObject[i].begin();
		auto iterEnd = mListObject[i].end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mListObject[i].erase(iter);
				iterEnd = mListObject[i].end();
				continue;
			} else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			if (!(*iter)->OutOfCamera(mCamera)) {
				(*iter)->RenderCollider(hdc, deltaTime);
			}
			++iter;
		}
	}
#endif

	// TODO ī�޶� ��ü�� ������ �־����� (���� ������) -> ������ ������ �ȵɵ�
	//GdiAlphaBlend

	// WidgetComponent ���
	// ���ŵ� ���� ������Ʈ�� �����Ѵ�.
	{
		auto	iter = mListWidgetComponent.begin();
		auto	iterEnd = mListWidgetComponent.end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mListWidgetComponent.erase(iter);
				iterEnd = mListWidgetComponent.end();
				continue;
			}
			++iter;
		}

		// �����Ѵ�.
		mListWidgetComponent.sort(SortYWidgetComponent);

		iter = mListWidgetComponent.begin();
		iterEnd = mListWidgetComponent.end();
		for (; iter != iterEnd; ++iter) {
			if (!(*iter)->GetEnable()) {
				continue;
			}
			(*iter)->Render(hdc, deltaTime);
		}
	}

	// ���� ������ ��ü�� ��µ� ���Ŀ� UI�� ����Ѵ�.
	if (mVecWidgetWindow.size() > 1)
		std::sort(mVecWidgetWindow.begin(), mVecWidgetWindow.end(), CScene::SortWindow);

	{
		auto iter = mVecWidgetWindow.begin();
		auto iterEnd = mVecWidgetWindow.end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mVecWidgetWindow.erase(iter);
				iterEnd = mVecWidgetWindow.end();
				continue;
			} else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			(*iter)->Render(hdc, deltaTime);
			++iter;
		}
	}

	if (CGameManager::GetInst()->GetEditMode())
		return;

	// ��� ������ ���� �� �����ε� üũ�� �ؼ� ���� �����Ӻ��� �����Ѵ�.
		mRewinder->CheckRewind(deltaTime);

#ifdef _DEBUG
	if (gDebugMode) {
		SetBkMode(hdc, TRANSPARENT);
		char str[64]{};

		float value = mRewinder->mSceneTime;
		sprintf_s(str, "mSceneTime : %.3f", value);
		SetTextColor(hdc, 0x00000000);
		TextOutA(hdc, 1001, 10, str, (int)strlen(str));
		TextOutA(hdc, 999, 10, str, (int)strlen(str));
		TextOutA(hdc, 1000, 11, str, (int)strlen(str));
		TextOutA(hdc, 1000, 9, str, (int)strlen(str));
		SetTextColor(hdc, 0x00ffffff);
		TextOutA(hdc, 1000, 10, str, (int)strlen(str));

		int ivalue = mRewinder->mRewindScale;
		sprintf_s(str, "mRewindScale : %d", ivalue);
		SetTextColor(hdc, 0x00000000);
		TextOutA(hdc, 1001, 30, str, (int)strlen(str));
		TextOutA(hdc, 999, 30, str, (int)strlen(str));
		TextOutA(hdc, 1000, 31, str, (int)strlen(str));
		TextOutA(hdc, 1000, 29, str, (int)strlen(str));
		SetTextColor(hdc, 0x00ffffff);
		TextOutA(hdc, 1000, 30, str, (int)strlen(str));

		ivalue = mRewinder->mCurIterator->first;
		sprintf_s(str, "mCurIterator : %d", ivalue);
		SetTextColor(hdc, 0x00000000);
		TextOutA(hdc, 1001, 50, str, (int)strlen(str));
		TextOutA(hdc, 999, 50, str, (int)strlen(str));
		TextOutA(hdc, 1000, 51, str, (int)strlen(str));
		TextOutA(hdc, 1000, 49, str, (int)strlen(str));
		SetTextColor(hdc, 0x00ffffff);
		TextOutA(hdc, 1000, 50, str, (int)strlen(str));

		ivalue = mRewinder->mMaxSceneIndex;
		sprintf_s(str, "mMaxSceneIndex : %d", ivalue);
		SetTextColor(hdc, 0x00000000);
		TextOutA(hdc, 1001, 70, str, (int)strlen(str));
		TextOutA(hdc, 999, 70, str, (int)strlen(str));
		TextOutA(hdc, 1000, 71, str, (int)strlen(str));
		TextOutA(hdc, 1000, 69, str, (int)strlen(str));
		SetTextColor(hdc, 0x00ffffff);
		TextOutA(hdc, 1000, 70, str, (int)strlen(str));
	}
#endif
}

bool CScene::SortRender(const CSharedPtr<CGameObject>& src, const CSharedPtr<CGameObject>& dest) {
	if (src->GetZOrder() != dest->GetZOrder()) {
		return src->GetZOrder() < dest->GetZOrder();
	} else {
		// �߹� �������� ������ �����ؾ� �ϱ� ������ �߹��� Y�� �����ش�.
		float srcY = src->GetPos().y + (1.f - src->GetPivot().y) * src->GetSize().y;
		float destY = dest->GetPos().y + (1.f - dest->GetPivot().y) * dest->GetSize().y;
		return srcY < destY;
	}
}

bool CScene::SortYWidgetComponent(const CSharedPtr<class CWidgetComponent>& src, 
								  const CSharedPtr<class CWidgetComponent>& dest) {
	return src->GetBottom() < dest->GetBottom();
}

bool CScene::SortWindow(const CSharedPtr<CWidgetWindow>& src, const CSharedPtr<CWidgetWindow>& dest) {
	return src->GetZOrder() < dest->GetZOrder();
}