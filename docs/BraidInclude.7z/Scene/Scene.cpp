
#include "Scene.h"

#include "../GameManager.h"
#include "../Input.h"

#include "../GameObject/GameObject.h"
#include "../GameObject/Player.h"

#include "Camera.h"
#include "SceneResource.h"
#include "SceneCollision.h"
#include "SceneRewinder.h"

CScene::CScene() {
	mCamera = new CCamera;
	mResource = new CSceneResource;
	mCollision = new CSceneCollision;
	mRewinder = new CSceneRewinder(this);
}

CScene::~CScene() {
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		mListObject[i].clear();
	}

	SAFE_DELETE(mCamera);
	SAFE_DELETE(mResource);
	SAFE_DELETE(mCollision);
	SAFE_DELETE(mRewinder);
}

bool CScene::CheckRewinding() const {
	return mRewinder->mRewind;
}

bool CScene::Init(CScene* prev) {
	if (!mRewinder->Init())
		return false;

	return true;
}

void CScene::Update(float deltaTime) {
	if (!mStopScene) {
		for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
			auto iter = mListObject[i].begin();
			auto iterEnd = mListObject[i].end();
			for (; iter != iterEnd;) {
				if (!(*iter)->GetActive()) {
					iter = mListObject[i].erase(iter);
					iterEnd = mListObject[i].end();
					continue;
				} else if (!(*iter)->GetEnable()) {
					++iter;
					continue;
				}

				if (!mRewinder->mRewind)
					(*iter)->Update(deltaTime);
				else if ((*iter)->mImmutable)
					(*iter)->Update(deltaTime);

				// �ݶ��̴� ������Ʈ�� �����Ѵ�.
				(*iter)->UpdateCollider(deltaTime);
				(*iter)->UpdateWidgetComponent(deltaTime);

				++iter;
			}
		}
	}

	auto iter = mVecWidgetWindow.begin();
	auto iterEnd = mVecWidgetWindow.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mVecWidgetWindow.erase(iter);
			iterEnd = mVecWidgetWindow.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->Update(deltaTime);
		// UI�� Ȱ��ȭ üũ�� �����ϰ� �ص� �Ǳ� ������ ���⼭ �Ѵ�.
		mCollision->AddWidgetWindow(*iter);
		++iter;
	}

	mRewinder->Update(mStopScene ? 0 : deltaTime);

	mCamera->Update(deltaTime);
}

void CScene::Collision(float deltaTime) {

	mCollision->CollisionMouse(deltaTime);

	mCollision->Collision(deltaTime);
}

void CScene::PostUpdate(float deltaTime) {
	if (!mStopScene) {
		for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
			auto iter = mListObject[i].begin();
			auto iterEnd = mListObject[i].end();

			for (; iter != iterEnd;) {
				if (!(*iter)->GetActive()) {
					// ����Ʈ���� �����ϴ� ���� SharedPtr�� �Ҹ��ڰ� ȣ��Ǿ� ī��Ʈ�� �����Ѵ�.
					iter = mListObject[i].erase(iter);
					iterEnd = mListObject[i].end();
					continue;
				} else if (!(*iter)->GetEnable()) {
					++iter;
					continue;
				}

				if (!mRewinder->mRewind)
					(*iter)->PostUpdate(deltaTime);
				else if ((*iter)->mImmutable)
					(*iter)->PostUpdate(deltaTime);

				// ������ ���ӻ��� ����
				//(*iter)->PostUpdateCollider(deltaTime);
				(*iter)->PostUpdateWidgetComponent(deltaTime);

				++iter;
			}
		}
	}

	auto iter = mVecWidgetWindow.begin();
	auto iterEnd = mVecWidgetWindow.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetActive()) {
			iter = mVecWidgetWindow.erase(iter);
			iterEnd = mVecWidgetWindow.end();
			continue;
		} else if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}

		(*iter)->PostUpdate(deltaTime);
		++iter;
	}
}

void CScene::Render(HDC hdc, float deltaTime) {
	// �Һ� ������Ʈ ����Ʈ Ÿ�� ���
	mEasingTime += deltaTime;
	if (mEasingTime < 0.f) {
		mImmutableValue = 0;
	} else if (mEasingTime < .7f) {
		mImmutableValue = (UINT8)(mEasingTime * 230);
	} else if (mEasingTime < 1.4f) {
		mImmutableValue = (UINT8)((1.4f - mEasingTime) * 230);
	} else {
		mEasingTime = 0.f;
	}

	// ��� ����� �����Ѵ�. (Z ���� -> Y����)
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		mListObject[i].sort(SortRender);

		auto iter = mListObject[i].begin();
		auto iterEnd = mListObject[i].end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				// ����Ʈ���� �����ϴ� ���� SharedPtr�� �Ҹ��ڰ� ȣ��Ǿ� ī��Ʈ�� �����Ѵ�.
				iter = mListObject[i].erase(iter);
				iterEnd = mListObject[i].end();
				continue;
			} else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			// ī�޶� �ø�
			if (!(*iter)->OutOfCamera(mCamera)) {
				if (mRewinder->GetRewind() && !(*iter)->mImmutable)
					mRewinder->RenderShadow(hdc, *iter);
				(*iter)->Render(hdc, deltaTime);
			}

			++iter;
		}
	}

	// TODO ī�޶� ��ü�� ������ �־����� (���� ������) -> ������ ������ �ȵɵ�
	//GdiAlphaBlend

	// WidgetComponent ���
	// ���ŵ� ���� ������Ʈ�� �����Ѵ�.
	{
		auto	iter = mListWidgetComponent.begin();
		auto	iterEnd = mListWidgetComponent.end();

		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mListWidgetComponent.erase(iter);
				iterEnd = mListWidgetComponent.end();
				continue;
			}

			++iter;
		}

		// �����Ѵ�.
		mListWidgetComponent.sort(SortYWidgetComponent);

		iter = mListWidgetComponent.begin();
		iterEnd = mListWidgetComponent.end();

		for (; iter != iterEnd; ++iter) {
			if (!(*iter)->GetEnable()) {
				continue;
			}

			(*iter)->Render(hdc, deltaTime);
		}
	}

	// ���� ������ ��ü�� ��µ� ���Ŀ� UI�� ����Ѵ�.
	if (mVecWidgetWindow.size() > 1) {
		std::sort(mVecWidgetWindow.begin(), mVecWidgetWindow.end(), CScene::SortWindow);
	}
	{
		auto iter = mVecWidgetWindow.begin();
		auto iterEnd = mVecWidgetWindow.end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mVecWidgetWindow.erase(iter);
				iterEnd = mVecWidgetWindow.end();
				continue;
			}

			else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			(*iter)->Render(hdc, deltaTime);
			++iter;
		}
	}

#ifdef _DEBUG
	SetBkMode(hdc, TRANSPARENT);
	char str[64]{};

	float value = mRewinder->mSceneTime;
	sprintf_s(str, "mSceneTime : %.3f", value);
	SetTextColor(hdc, 0x00000000);
	TextOutA(hdc, 1001, 10, str, (int)strlen(str));
	TextOutA(hdc, 999, 10, str, (int)strlen(str));
	TextOutA(hdc, 1000, 11, str, (int)strlen(str));
	TextOutA(hdc, 1000, 9, str, (int)strlen(str));
	SetTextColor(hdc, 0x00ffffff);
	TextOutA(hdc, 1000, 10, str, (int)strlen(str));

	int ivalue = mRewinder->mRewindScale;
	sprintf_s(str, "mRewindScale : %d", ivalue);
	SetTextColor(hdc, 0x00000000);
	TextOutA(hdc, 1001, 30, str, (int)strlen(str));
	TextOutA(hdc, 999, 30, str, (int)strlen(str));
	TextOutA(hdc, 1000, 31, str, (int)strlen(str));
	TextOutA(hdc, 1000, 29, str, (int)strlen(str));
	SetTextColor(hdc, 0x00ffffff);
	TextOutA(hdc, 1000, 30, str, (int)strlen(str));

	ivalue = mRewinder->mCurIterator->first;
	sprintf_s(str, "mCurIterator : %d", ivalue);
	SetTextColor(hdc, 0x00000000);
	TextOutA(hdc, 1001, 50, str, (int)strlen(str));
	TextOutA(hdc, 999, 50, str, (int)strlen(str));
	TextOutA(hdc, 1000, 51, str, (int)strlen(str));
	TextOutA(hdc, 1000, 49, str, (int)strlen(str));
	SetTextColor(hdc, 0x00ffffff);
	TextOutA(hdc, 1000, 50, str, (int)strlen(str));

	ivalue = mRewinder->mMaxSceneIndex;
	sprintf_s(str, "mMaxSceneIndex : %d", ivalue);
	SetTextColor(hdc, 0x00000000);
	TextOutA(hdc, 1001, 70, str, (int)strlen(str));
	TextOutA(hdc, 999, 70, str, (int)strlen(str));
	TextOutA(hdc, 1000, 71, str, (int)strlen(str));
	TextOutA(hdc, 1000, 69, str, (int)strlen(str));
	SetTextColor(hdc, 0x00ffffff);
	TextOutA(hdc, 1000, 70, str, (int)strlen(str));

	float vel = mPlayer->GetPos().x;
	float vel2 = mPlayer->GetPos().y;
	sprintf_s(str, "mPos x : %.3f, y : %.3f", vel, vel2);
	SetTextColor(hdc, 0x00000000);
	TextOutA(hdc, 11, 130, str, (int)strlen(str));
	TextOutA(hdc, 9, 130, str, (int)strlen(str));
	TextOutA(hdc, 10, 131, str, (int)strlen(str));
	TextOutA(hdc, 10, 129, str, (int)strlen(str));
	SetTextColor(hdc, 0x00ffffff);
	TextOutA(hdc, 10, 130, str, (int)strlen(str));
#endif

	// ��� ������ ���� �� �����ε� üũ�� �ؼ� ���� �����Ӻ��� �����Ѵ�.
	mRewinder->CheckRewind(deltaTime);
}

void CScene::SetInput() {
	mRewinder->SetInput();

	size_t size = mVecObjectInputFunc.size();
	for (size_t i = 0; i < size; ++i)
		mVecObjectInputFunc[i]();

#ifdef _DEBUG
	CInput::GetInst()->AddBindFunction<CGameManager>("Debug", Input_Type::Down,
													 CGameManager::GetInst(), &CGameManager::SetDebugMode);
#endif // _DEBUG
}

bool CScene::SortRender(const CSharedPtr<CGameObject>& src, const CSharedPtr<CGameObject>& dest) {
	if (src->GetZOrder() != dest->GetZOrder()) {
		return src->GetZOrder() < dest->GetZOrder();
	} else {
		// �߹� �������� ������ �����ؾ� �ϱ� ������ �߹��� Y�� �����ش�.
		float srcY = src->GetPos().y + (1.f - src->GetPivot().y) * src->GetSize().y;
		float destY = dest->GetPos().y + (1.f - dest->GetPivot().y) * dest->GetSize().y;
		return srcY < destY;
	}
}

bool CScene::SortYWidgetComponent(const CSharedPtr<class CWidgetComponent>& src, 
								  const CSharedPtr<class CWidgetComponent>& dest) {
	return src->GetBottom() < dest->GetBottom();
}

bool CScene::SortWindow(const CSharedPtr<CWidgetWindow>& src, const CSharedPtr<CWidgetWindow>& dest) {
	return src->GetZOrder() < dest->GetZOrder();
}