
#include "Scene.h"
#include "../GameObject/GameObject.h"
#include "SceneResource.h"
#include "SceneCollision.h"
#include "Camera.h"

CScene::CScene() : mPlayer{} {
	mCamera = new CCamera;
	mResource = new CSceneResource;
	mCollision = new CSceneCollision;
}

CScene::~CScene() {
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		mObjList[i].clear();
	}

	SAFE_DELETE(mCamera);
	SAFE_DELETE(mResource);
	SAFE_DELETE(mCollision);
}

void CScene::SetPlayer(CGameObject* player) {
	mPlayer = player;
}

bool CScene::Init(CScene* prev) {
	return true;
}

void CScene::Update(float deltaTime) {
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		auto iter = mObjList[i].begin();
		auto iterEnd = mObjList[i].end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mObjList[i].erase(iter);
				iterEnd = mObjList[i].end();
				continue;
			} else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			(*iter)->Update(deltaTime);

			++iter;
		}
	}
	{
		auto iter = mVecWidgetWindow.begin();
		auto iterEnd = mVecWidgetWindow.end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mVecWidgetWindow.erase(iter);
				iterEnd = mVecWidgetWindow.end();
				continue;
			} else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			(*iter)->Update(deltaTime);
			// UI�� Ȱ��ȭ üũ�� �����ϰ� �ص� �Ǳ� ������ ���⼭ �Ѵ�.
			mCollision->AddWidgetWindow(*iter);
			++iter;
		}
	}

	mCamera->Update(deltaTime);
}

void CScene::Collision(float deltaTime) {

	mCollision->CollisionMouse(deltaTime);

	mCollision->Collision(deltaTime);
}

void CScene::PostUpdate(float deltaTime) {
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		auto iter = mObjList[i].begin();
		auto iterEnd = mObjList[i].end();

		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				// ����Ʈ���� �����ϴ� ���� SharedPtr�� �Ҹ��ڰ� ȣ��Ǿ� ī��Ʈ�� �����Ѵ�.
				iter = mObjList[i].erase(iter);
				iterEnd = mObjList[i].end();
				continue;
			} else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			(*iter)->PostUpdate(deltaTime);
			++iter;
		}
	}
	{
		auto iter = mVecWidgetWindow.begin();
		auto iterEnd = mVecWidgetWindow.end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mVecWidgetWindow.erase(iter);
				iterEnd = mVecWidgetWindow.end();
				continue;
			} else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			(*iter)->PostUpdate(deltaTime);
			++iter;
		}
	}
}

void CScene::Render(HDC hdc, float deltaTime) {
	// ��� ����� �����Ѵ�. (Y����)
	for (int i = 0; i < (int)ERender_Layer::Max; ++i) {
		mObjList[i].sort(SortY);

		auto	iter = mObjList[i].begin();
		auto	iterEnd = mObjList[i].end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				// ����Ʈ���� �����ϴ� ���� SharedPtr�� �Ҹ��ڰ� ȣ��Ǿ� ī��Ʈ�� �����Ѵ�.
				iter = mObjList[i].erase(iter);
				iterEnd = mObjList[i].end();
				continue;
			} else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			// ī�޶� �ø�
			if (!(*iter)->OutOfCamera(mCamera))
				(*iter)->Render(hdc, deltaTime);

			++iter;
		}
	}

	// WidgetComponent ���
	// ���ŵ� ���� ������Ʈ�� �����Ѵ�.
	{
		auto	iter = mListWidgetComponent.begin();
		auto	iterEnd = mListWidgetComponent.end();

		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mListWidgetComponent.erase(iter);
				iterEnd = mListWidgetComponent.end();
				continue;
			}

			++iter;
		}

		// �����Ѵ�.
		mListWidgetComponent.sort(SortYWidgetComponent);

		iter = mListWidgetComponent.begin();
		iterEnd = mListWidgetComponent.end();

		for (; iter != iterEnd; ++iter) {
			if (!(*iter)->GetEnable()) {
				continue;
			}

			(*iter)->Render(hdc, deltaTime);
		}
	}

	// ���� ������ ��ü�� ��µ� ���Ŀ� UI�� ����Ѵ�.
	if (mVecWidgetWindow.size() > 1) {
		std::sort(mVecWidgetWindow.begin(), mVecWidgetWindow.end(), CScene::SortWindow);
	}
	{
		auto iter = mVecWidgetWindow.begin();
		auto iterEnd = mVecWidgetWindow.end();
		for (; iter != iterEnd;) {
			if (!(*iter)->GetActive()) {
				iter = mVecWidgetWindow.erase(iter);
				iterEnd = mVecWidgetWindow.end();
				continue;
			}

			else if (!(*iter)->GetEnable()) {
				++iter;
				continue;
			}

			(*iter)->Render(hdc, deltaTime);
			++iter;
		}
	}
}

bool CScene::SortY(const CSharedPtr<CGameObject>& src, const CSharedPtr<CGameObject>& dest) {
	// �߹� �������� ������ �����ؾ� �ϱ� ������ �߹��� Y�� �����ش�.
	float srcY = src->GetPos().y + (1.f - src->GetPivot().y) * src->GetSize().y;
	float destY = dest->GetPos().y + (1.f - dest->GetPivot().y) * dest->GetSize().y;

	return srcY < destY;
}

bool CScene::SortYWidgetComponent(const CSharedPtr<class CWidgetComponent>& src, 
								  const CSharedPtr<class CWidgetComponent>& dest) {
	return src->GetBottom() < dest->GetBottom();
}

bool CScene::SortWindow(const CSharedPtr<CWidgetWindow>& src, const CSharedPtr<CWidgetWindow>& dest) {
	return src->GetZOrder() < dest->GetZOrder();
}