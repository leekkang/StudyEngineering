
#include "SceneRewinder.h"
#include "Scene.h"
#include "../Input.h"
#include "../GameObject/Player.h"
#include "../GameObject/Character.h"
#include "../GameObject/MovableObject.h"
#include "../Collision/Collider.h"
#include "../Animation/AnimationInfo.h"

CSceneRewinder::CSceneRewinder(CScene* scene) :
	mScene{scene}
{
}

CSceneRewinder::~CSceneRewinder() {
}

void CSceneRewinder::CheckRewind(float deltaTime) {
	mRewindDeltaTime -= deltaTime;

	if (CInput::GetInst()->GetShiftStatus()) {
		if (!mRewind && mRewindDeltaTime < 0.f) {
			mRewindDeltaTime = mRewindCoolTime;
			mRewind = true;

			// ���� �ǰ��� ������ -1�� �̴�.
			mRewindScale = -1;
			mSceneTime = (mCurIterator->first) * mSaveUnitTime;
		}
	} else {
		if (mRewind && mRewindDeltaTime < 0.f) {
			mRewindDeltaTime = mRewindCoolTime;
			mRewind = false;

			mMaxSceneIndex = mCurIterator->first + 1;
			mSceneTime = (mCurIterator->first) * mSaveUnitTime;
		}
	}
}

bool CSceneRewinder::Init() {
	if (!mScene)
		return false;
	if (mRewindObjectCount == 0)
		return false;

	SaveObjects(0);
	mMaxSceneIndex = 1;
	mCurIterator = mListSerializer.begin();

	return true;
}

void CSceneRewinder::Update(float deltaTime) {
	if (mScene->GetStopScene())
		return;

	if (!mRewind) {
		mSceneTime += deltaTime;
		if (mSceneTime > mMaxSceneIndex * mSaveUnitTime) {
			SaveObjects(mMaxSceneIndex);
			++mMaxSceneIndex;
			++mCurIterator;
		}
		return;
	}

	if (mRewindScale == 0)
		return;

	if (mRewindScale < 0) {
		if (mCurIterator->first == 2)
			return;

		mSceneTime += (deltaTime * mRewindScale);
		// 0���� �ݶ��̴��� �̻��ϰ� �����Ѵ�. 1������ ������Ʈ�� ����� �ȵȴ�. 2������ ����ϵ��� ����.
		// �� 1���� ������Ʈ�� ����� �ȵǳ�?? ��� ���� ���������� ���� ���� Ȯ���ߴµ� (TransparentBlt)
		if (mSceneTime <= 2 * mSaveUnitTime) {
			SetIterator(2);

			LoadObjects();
			mSceneTime = 2 * mSaveUnitTime;
		} else {
			int prev = mCurIterator->first;
			while (mSceneTime < (mCurIterator->first - 1) * mSaveUnitTime) {
				--mCurIterator;
			}
			if (prev != mCurIterator->first)
				LoadObjects();
		}
	} else {
		int endIndex = mMaxSceneIndex - 1;
		if (mCurIterator->first == endIndex)
			return;

		mSceneTime += (deltaTime * mRewindScale);
		if (mSceneTime >= endIndex * mSaveUnitTime) {
			// mMaxSceneIndex�� ����Ʈ�� ���� �ƴ� ��찡 �ֱ� ������ while�� ������ ���ͷ����͸� ã���ش�.
			SetIterator(endIndex);

			LoadObjects();
			mSceneTime = endIndex * mSaveUnitTime;
		} else {
			int prev = mCurIterator->first;
			while (mSceneTime > (mCurIterator->first + 1) * mSaveUnitTime) {
				++mCurIterator;
			}
			if (prev != mCurIterator->first)
				LoadObjects();
		}
	}
}

void CSceneRewinder::SetInput() {
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindUp", Input_Type::Down, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindDown", Input_Type::Down, this, &CSceneRewinder::AttachDownKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindArrowUp", Input_Type::Down, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindArrowDown", Input_Type::Down, this, &CSceneRewinder::AttachDownKey);
}

void CSceneRewinder::RenderShadow(HDC hdc, CGameObject* object) {
	if (!dynamic_cast<CCharacter*>(object))
		return;


}

//void CSceneRewinder::SaveObjects(int index) {
//	auto iter = mCurIterator;
//	bool makeNew = index == 0 || ++iter == mListSerializer.end();
//
//	std::vector<SerializedObject>* pVec;
//	if (makeNew) {
//		std::vector<SerializedObject> vec(mRewindObjectCount);
//		pVec = &vec;
//	} else {
//		pVec = &(mCurIterator->second);
//	}
//
//	int i = 0;
//	auto list = mScene->mListObject[(int)ERender_Layer::Default];
//	for (const auto& e : list) {
//		if (e->GetImmutable())
//			continue;
//
//		if (makeNew) {
//			SerializedObject serializer;
//			serializer.Serialize(e);
//			pVec->push_back(std::move(serializer));
//		} else {
//			(*pVec)[i].Serialize(e);
//			++i;
//		}
//	}
//
//	if (makeNew)
//		mListSerializer.push_back({index, std::move(*pVec)});
//}
void CSceneRewinder::SaveObjects(int index) {
	auto iter = mCurIterator;
	bool makeNew = index == 0 || ++iter == mListSerializer.end();

	int i = 0;
	auto list = mScene->mListObject[(int)ERender_Layer::Default];
	if (makeNew) {
		std::vector<SerializedObject> vec(mRewindObjectCount);
		for (const auto& e : list) {
			if (e->GetImmutable())
				continue;

			vec[i].Serialize(e);
		}
		mListSerializer.push_back({index, std::move(vec)});
	} else {
		SetIterator(index);
		auto& vec = mCurIterator->second;
		for (const auto& e : list) {
			if (e->GetImmutable())
				continue;

			vec[i].Serialize(e);
			++i;
		}
	}
}

void CSceneRewinder::LoadObjects() {
	for (int i = 0; i < mRewindObjectCount; ++i) {
		(mCurIterator->second)[i].Deserialize();
	}
}

void CSceneRewinder::AttachUpKey() {
	if (!mRewind)
		return;
	
	if (mRewindScale < -1)
		mRewindScale = (int)(mRewindScale * 0.5f);
	else if (mRewindScale == -1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = 1;
	else if (mRewindScale < 8)
		mRewindScale *= 2;
	else
		mRewindScale = 8;
}

void CSceneRewinder::AttachDownKey() {
	if (!mRewind)
		return;

	if (mRewindScale > 1)
		mRewindScale = (int)(mRewindScale * 0.5f);
	else if (mRewindScale == 1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = -1;
	else if (mRewindScale > -8)
		mRewindScale *= 2;
	else
		mRewindScale = -8;
}

void CSceneRewinder::SetIterator(int index) {
	while (mCurIterator->first != index) {
		if (mCurIterator->first < index)
			++mCurIterator;
		else
			--mCurIterator;
	}
}

#pragma warning( push )
#pragma warning( disable : 4805 )
bool SerializedObject::Serialize(CGameObject* obj) {
	auto SerializePlayer = [this](CPlayer* player) -> bool {
		// int x 3 + float x 9 + Vector2 x 5 + pointer x 5 + byte x 3
		if (!data) {
			size_t size = sizeof(int) * 3 + sizeof(float) * 9 +
				sizeof(Vector2) * 5 + sizeof(char*) * 5 + sizeof(byte) * 3;
			data = new UINT8[size];
		}
		int offset = 0;

		// boolean
		byte bvalue = player->mPhysicsSimulate;
		bvalue = bvalue << 1 | player->mFloating;
		bvalue = bvalue << 1 | player->mDead;
		bvalue = bvalue << 1 | player->mJump;
		data[offset] = bvalue;
		++offset;

		bvalue = player->mOnLadder;
		bvalue = bvalue << 1 | player->mIsLadder;
		bvalue = bvalue << 1 | player->mOffLadder;
		bvalue = bvalue << 1 | player->mListCollider.begin()->Get()->GetEnable();
		bvalue = bvalue << 1 | (player->mLookDir == -1);
		bvalue = bvalue << 1 | (player->mLookDir == 1);
		bvalue = bvalue << 1 | (player->mOnWall == -1);
		bvalue = bvalue << 1 | (player->mOnWall == 1);
		data[offset] = bvalue;
		++offset;

		// CGameObject
		memcpy(data + offset, &player->mZOrder, sizeof(int));
		offset += sizeof(int);
		memcpy(data + offset, &player->mTimeScale, sizeof(float));
		offset += sizeof(float);
		memcpy(data + offset, &player->mPos, sizeof(Vector2));
		offset += sizeof(Vector2);
		memcpy(data + offset, &player->mSize, sizeof(Vector2));
		offset += sizeof(Vector2);
		CAnimationInfo* info = player->mAnimation->GetCurrentAnimationInfo();
		memcpy(data + offset, &info, sizeof(char*));
		offset += sizeof(char*);
		memcpy(data + offset, &info->mFrame, sizeof(int));
		offset += sizeof(int);
		memcpy(data + offset, &info->mCurInterval, sizeof(float));
		offset += sizeof(float);

		// CMovableObject
		memcpy(data + offset, &player->mFallTime, sizeof(float));
		offset += sizeof(float);
		memcpy(data + offset, &player->mFallStartY, sizeof(float));
		offset += sizeof(float);
		memcpy(data + offset, &player->mMove, sizeof(Vector2));
		offset += sizeof(Vector2);
		memcpy(data + offset, &player->mPrevPos, sizeof(Vector2));
		offset += sizeof(Vector2);
		memcpy(data + offset, &player->mVelocity, sizeof(Vector2));
		offset += sizeof(Vector2);

		// CPlayer
		memcpy(data + offset, &player->mInputLeftTime, sizeof(float));
		offset += sizeof(float);
		memcpy(data + offset, &player->mInputRightTime, sizeof(float));
		offset += sizeof(float);
		memcpy(data + offset, &player->mInputUpTime, sizeof(float));
		offset += sizeof(float);
		memcpy(data + offset, &player->mInputDownTime, sizeof(float));
		offset += sizeof(float);
		memcpy(data + offset, &player->mLadderCoolTime, sizeof(float));
		offset += sizeof(float);
		memcpy(data + offset, &player->mBoundLevel, sizeof(int));
		offset += sizeof(int);
		memcpy(data + offset, &player->mCurrentAnimType, sizeof(UINT8));
		offset += sizeof(UINT8);
		//memcpy(data + offset, &player->mWallCollider, sizeof(char*));
		//offset += sizeof(char*);
		//memcpy(data + offset, &player->mLadderCollider, sizeof(char*));
		//offset += sizeof(char*);
		//memcpy(data + offset, &player->mFloorCollider, sizeof(char*));
		//offset += sizeof(char*);
		//memcpy(data + offset, &player->mFloorNextCollider, sizeof(char*));
		//offset += sizeof(char*);

		return true;
	};

	target = obj;
	if (obj->GetTypeID() == typeid(CPlayer).hash_code()) {
		return SerializePlayer((CPlayer*)obj);
	} else {
		if (!data)
			data = new UINT8[sizeof(CGameObject)];
		memcpy(data, obj, sizeof(CGameObject));
	}

	return true;
}

bool SerializedObject::Deserialize() {
	if (!target || !data)
		return false;

	auto DeserializePlayer = [this](CPlayer* player) -> bool {
		int offset = 0;

		// boolean
		byte bvalue = data[offset];
		player->mJump = bvalue & 0x01;
		bvalue >>= 1;
		player->mDead = bvalue & 0x01;
		bvalue >>= 1;
		player->mFloating = bvalue & 0x01;
		bvalue >>= 1;
		player->mPhysicsSimulate = bvalue & 0x01;
		++offset;

		bvalue = data[offset];
		player->mOnWall = bvalue & 0x01 ? 1 : 0;
		bvalue >>= 1;
		player->mOnWall = bvalue & 0x01 ? -1 : player->mOnWall;
		bvalue >>= 1;
		player->mLookDir = bvalue & 0x01 ? 1 : 0;
		bvalue >>= 1;
		player->mLookDir = bvalue & 0x01 ? -1 : player->mLookDir;
		bvalue >>= 1;
		auto iter = player->mListCollider.begin();
		auto iterEnd = player->mListCollider.end();
		for (; iter != iterEnd; ++iter) {
			(*iter)->SetEnable(bvalue & 0x01);
		}
		bvalue >>= 1;
		player->mOffLadder = bvalue & 0x01;
		bvalue >>= 1;
		player->mIsLadder = bvalue & 0x01;
		bvalue >>= 1;
		player->mOnLadder = bvalue & 0x01;
		++offset;

		// CGameObject
		memcpy(&player->mZOrder, data + offset, sizeof(int));
		offset += sizeof(int);
		memcpy(&player->mTimeScale, data + offset, sizeof(float));
		offset += sizeof(float);
		memcpy(&player->mPos, data + offset, sizeof(Vector2));
		offset += sizeof(Vector2);
		memcpy(&player->mSize, data + offset, sizeof(Vector2));
		offset += sizeof(Vector2);
		CAnimationInfo* info;
		memcpy(&info, data + offset, sizeof(char*));
		offset += sizeof(char*);
		memcpy(&info->mFrame, data + offset, sizeof(int));
		offset += sizeof(int);
		memcpy(&info->mCurInterval, data + offset, sizeof(float));
		offset += sizeof(float);
		player->mAnimation->SetCurrentAnimationInfo(info);

		// CMovableObject
		memcpy(&player->mFallTime, data + offset, sizeof(float));
		offset += sizeof(float);
		memcpy(&player->mFallStartY, data + offset, sizeof(float));
		offset += sizeof(float);
		memcpy(&player->mMove, data + offset, sizeof(Vector2));
		offset += sizeof(Vector2);
		memcpy(&player->mPrevPos, data + offset, sizeof(Vector2));
		offset += sizeof(Vector2);
		memcpy(&player->mVelocity, data + offset, sizeof(Vector2));
		offset += sizeof(Vector2);

		// CPlayer
		memcpy(&player->mInputLeftTime, data + offset, sizeof(float));
		offset += sizeof(float);
		memcpy(&player->mInputRightTime, data + offset, sizeof(float));
		offset += sizeof(float);
		memcpy(&player->mInputUpTime, data + offset, sizeof(float));
		offset += sizeof(float);
		memcpy(&player->mInputDownTime, data + offset, sizeof(float));
		offset += sizeof(float);
		memcpy(&player->mLadderCoolTime, data + offset, sizeof(float));
		offset += sizeof(float);
		memcpy(&player->mBoundLevel, data + offset, sizeof(int));
		offset += sizeof(int);
		memcpy(&player->mCurrentAnimType, data + offset, sizeof(UINT8));
		offset += sizeof(UINT8);
		//memcpy(&player->mWallCollider, data + offset, sizeof(char*));
		//offset += sizeof(char*);
		//memcpy(&player->mLadderCollider, data + offset, sizeof(char*));
		//offset += sizeof(char*);
		//memcpy(&player->mFloorCollider, data + offset, sizeof(char*));
		//offset += sizeof(char*);
		//memcpy(&player->mFloorNextCollider, data + offset, sizeof(char*));
		//offset += sizeof(char*);


		player->mInputRight = false;
		player->mInputLeft = false;
		player->mInputDown = false;
		player->mInputUp = false;
		player->mInputRightTime = 0.f;
		player->mInputLeftTime = 0.f;
		player->mInputDownTime = 0.f;
		player->mInputUpTime = 0.f;

		return true;
	};

	bool returnValue = false;
	if (target->GetTypeID() == typeid(CPlayer).hash_code()) {
		returnValue = DeserializePlayer((CPlayer*)target);
	} else {
		if (data)
			memcpy(target, data, sizeof(CPlayer));
		returnValue = true;
	}

	auto iter = target->mListCollider.begin();
	auto iterEnd = target->mListCollider.end();
	for (; iter != iterEnd;) {
		if (!(*iter)->GetEnable()) {
			++iter;
			continue;
		}
		(*iter)->Update(0.f);
		++iter;
	}

	return returnValue;
}

#pragma warning( pop )