
#include "SceneRewinder.h"
#include "Scene.h"

#include "../GameManager.h"
#include "../Input.h"

#include "../GameObject/Player.h"

CSceneRewinder::CSceneRewinder(CScene* scene) :
	mScene{scene}
{
}

CSceneRewinder::~CSceneRewinder() {
}

void CSceneRewinder::CheckRewind(float deltaTime) {
	mRewindDeltaTime -= deltaTime;

	if (CInput::GetInst()->GetShiftStatus()) {
		if (!mRewind && mRewindDeltaTime < 0.f) {
			mRewindDeltaTime = mRewindCoolTime;
			mRewind = true;

			// ���� �ǰ��� ������ -1�� �̴�.
			mRewindScale = -1;
			mSceneTime = (mCurIterator->first) * mSaveUnitTime;
			((CPlayer*)(*mScene->mPlayer))->SetRewindWidget(mRewindScale);
		}
	} else {
		if (mRewind && mRewindDeltaTime < 0.f) {
			mRewindDeltaTime = mRewindCoolTime;
			mRewind = false;

			mMaxSceneIndex = mCurIterator->first + 1;
			mSceneTime = (mCurIterator->first) * mSaveUnitTime;
			((CPlayer*)(*mScene->mPlayer))->SetRewindWidgetEnable(false);
		}
	}
}

void CSceneRewinder::SetInput() {
	CInput::GetInst()->AddBindFunction<CSceneRewinder>(
		"RewindUp", Input_Type::Down, mScene, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>(
		"RewindDown", Input_Type::Down, mScene, this, &CSceneRewinder::AttachDownKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>(
		"RewindArrowUp", Input_Type::Down, mScene, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>(
		"RewindArrowDown", Input_Type::Down, mScene, this, &CSceneRewinder::AttachDownKey);
}

bool CSceneRewinder::Init() {
	if (!mScene)
		return false;

	auto list = mScene->mListObject[(int)ERender_Layer::Default];
	for (const auto& e : list) {
		if (e->GetImmutable())
			continue;
		const char* name = e->GetName().data();
		if (strcmp(name, "Foothold") == 0 || strcmp(name, "Terrain") == 0)
			continue;

		mVecRewindableObject.push_back(e);
	}
	list = mScene->mListObject[(int)ERender_Layer::Effect];
	for (const auto& e : list) {
		if (e->GetImmutable())
			continue;

		mVecRewindableObject.push_back(e);
	}

	size_t	size = mVecRewindableObject.size();
	if (size == 0)
		return false;


	std::vector<SerializedObject> vec(size);
	for (size_t i = 0; i < size; ++i) {
		vec[i].target = mVecRewindableObject[i];
		vec[i].target->Serialize(vec[i].data);
	}
	mListSerializer.push_back({0, std::move(vec)});

	mCurIterator = mListSerializer.begin();
	mMaxSceneIndex = 1;

	SetInput();

	return true;
}

void CSceneRewinder::Update(float deltaTime) {
	if (!mRewind)
		return;

	if (mRewindScale == 0)
		return;

	if (mRewindScale < 0) {
		if (mCurIterator->first == 2)
			return;

		mSceneTime += (deltaTime * mRewindScale);
		// 0���� �ݶ��̴��� �̻��ϰ� �����Ѵ�. 1������ ������Ʈ�� ����� �ȵȴ�. 2������ ����ϵ��� ����.
		// �� 1���� ������Ʈ�� ����� �ȵǳ�?? ��� ���� ���������� ���� ���� Ȯ���ߴµ� (TransparentBlt)
		if (mSceneTime <= 2 * mSaveUnitTime) {
			SetIterator(2);

			LoadObjects();
			mSceneTime = 2 * mSaveUnitTime;
		} else {
			//int prev = mCurIterator->first;
			while (mSceneTime < (mCurIterator->first - 1) * mSaveUnitTime) {
				--mCurIterator;
			}
			//if (prev != mCurIterator->first)
				LoadObjects();
		}
	} else {
		int endIndex = mMaxSceneIndex - 1;
		if (mCurIterator->first == endIndex)
			return;

		mSceneTime += (deltaTime * mRewindScale);
		if (mSceneTime >= endIndex * mSaveUnitTime) {
			// mMaxSceneIndex�� ����Ʈ�� ���� �ƴ� ��찡 �ֱ� ������ while�� ������ ���ͷ����͸� ã���ش�.
			SetIterator(endIndex);

			LoadObjects();
			mSceneTime = endIndex * mSaveUnitTime;
		} else {
			//int prev = mCurIterator->first;
			while (mSceneTime > (mCurIterator->first + 1) * mSaveUnitTime) {
				++mCurIterator;
			}
			//if (prev != mCurIterator->first)
				LoadObjects();
		}
	}

	mScene->RestartScene();
}

void CSceneRewinder::PostUpdate(float deltaTime) {
	if (mRewind)
		return;

	mSceneTime += deltaTime;
	if (mSceneTime >= mMaxSceneIndex * mSaveUnitTime) {
		SaveObjects(mCurIterator->first == mListSerializer.back().first);
		++mMaxSceneIndex;
	}
}

void CSceneRewinder::RenderScreen(HDC hdc) {
	if (!mRewind)
		return;

	UINT8 r = mRewindScale > 0 ? 0	 : 255;
	UINT8 g = mRewindScale > 0 ? 0	 : 255;
	UINT8 b = mRewindScale > 0 ? 255 : 0;
	UINT8 mixValue = mRewindScale != 0 ? min(60, (UINT8)(mPostProcessMixValue * fabs(mRewindScale))) : mPostProcessMixValue;

	CGameManager::GetInst()->PostProcessMixColor(mixValue, r, g, b);
}

void CSceneRewinder::RenderShadow(HDC hdc, CGameObject* object) {
	if (!dynamic_cast<CCharacter*>(object))
		return;


}

//void CSceneRewinder::SaveObjects(int index) {
//	auto iter = mCurIterator;
//	bool makeNew = index == 0 || ++iter == mListSerializer.end();
//
//	std::vector<SerializedObject>* pVec;
//	if (makeNew) {
//		std::vector<SerializedObject> vec(mRewindObjectCount);
//		pVec = &vec;
//	} else {
//		pVec = &(mCurIterator->second);
//	}
//
//	int i = 0;
//	auto list = mScene->mListObject[(int)ERender_Layer::Default];
//	for (const auto& e : list) {
//		if (e->GetImmutable())
//			continue;
//
//		if (makeNew) {
//			SerializedObject serializer;
//			serializer.Serialize(e);
//			pVec->push_back(std::move(serializer));
//		} else {
//			(*pVec)[i].Serialize(e);
//			++i;
//		}
//	}
//
//	if (makeNew)
//		mListSerializer.push_back({index, std::move(*pVec)});
//}
void CSceneRewinder::SaveObjects(bool makeNew) {
	size_t	size = mVecRewindableObject.size();
	if (makeNew) {
		std::vector<SerializedObject> vec(size);
		for (size_t i = 0; i < size; ++i) {
			vec[i].target = mVecRewindableObject[i];
			vec[i].target->Serialize(vec[i].data);
		}
		mListSerializer.push_back({mMaxSceneIndex, std::move(vec)});
		++mCurIterator;
	} else {
		auto& vec = (++mCurIterator)->second;
		for (size_t i = 0; i < size; ++i) {
			vec[i].target = mVecRewindableObject[i];
			vec[i].target->Serialize(vec[i].data);
		}
	}
}

void CSceneRewinder::LoadObjects() {
	size_t	size = mVecRewindableObject.size();
	for (size_t i = 0; i < size; ++i) {
		SerializedObject& obj = (mCurIterator->second)[i];
		obj.target->Deserialize(obj.data);
		obj.target->UpdateCollider(0.f);
	}
}

void CSceneRewinder::AttachUpKey() {
	if (!mRewind)
		return;

	if (mRewindScale < -1)
		mRewindScale = (int)(mRewindScale * 0.5f);
	else if (mRewindScale == -1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = 1;
	else if (mRewindScale < 8)
		mRewindScale *= 2;
	else
		mRewindScale = 8;

	((CPlayer*)(*mScene->mPlayer))->SetRewindWidget(mRewindScale);
}

void CSceneRewinder::AttachDownKey() {
	if (!mRewind)
		return;

	if (mRewindScale > 1)
		mRewindScale = (int)(mRewindScale * 0.5f);
	else if (mRewindScale == 1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = -1;
	else if (mRewindScale > -8)
		mRewindScale *= 2;
	else
		mRewindScale = -8;

	((CPlayer*)(*mScene->mPlayer))->SetRewindWidget(mRewindScale);
}

void CSceneRewinder::SetIterator(int index) {
	while (mCurIterator->first != index) {
		if (mCurIterator->first < index)
			++mCurIterator;
		else
			--mCurIterator;
	}
}