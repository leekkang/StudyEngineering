
#include "SceneRewinder.h"

#include "../GameManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Scene.h"
#include "SceneResource.h"

#include "../Resource/Sound/Sound.h"
#include "../GameObject/Player.h"


CSceneRewinder::CSceneRewinder(CScene* scene) :
	mScene{scene}
{
}

CSceneRewinder::~CSceneRewinder() {
}

void CSceneRewinder::CheckRewind(float deltaTime) {
	mRewindDeltaTime -= deltaTime;
	if (CSceneManager::GetInst()->CheckSceneChanging())
		return;

	if (CInput::GetInst()->GetShiftStatus()) {
		if (!mRewind && mRewindDeltaTime < 0.f) {
			mRewindDeltaTime = mRewindCoolTime;
			mRewind = true;

			// ���� �ǰ��� ������ -1�� �̴�.
			mRewindScale = -1;
			mSceneTime = (mCurIterator->first) * mSaveUnitTime;
			((CPlayer*)(*mScene->mPlayer))->SetRewindWidget(mRewindScale);

			// ���� �ӵ� ����
			ChangeSoundSpeed(-1);
			mSoundStop = false;
		}
	} else {
		if (mRewind && mRewindDeltaTime < 0.f) {
			mRewindDeltaTime = mRewindCoolTime;
			mRewind = false;

			mMaxSceneIndex = mCurIterator->first + 1;
			mSceneTime = (mCurIterator->first) * mSaveUnitTime;
			((CPlayer*)(*mScene->mPlayer))->SetRewindWidgetEnable(false);

			// ���� �ӵ� ����
			ChangeSoundSpeed(1);
			mSoundStop = false;
		}
	}
}

void CSceneRewinder::SetInput() {
	CInput::GetInst()->AddBindFunction<CSceneRewinder>(
		"RewindUp", Input_Type::Down, mScene, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>(
		"RewindDown", Input_Type::Down, mScene, this, &CSceneRewinder::AttachDownKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>(
		"RewindArrowUp", Input_Type::Down, mScene, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>(
		"RewindArrowDown", Input_Type::Down, mScene, this, &CSceneRewinder::AttachDownKey);
}

bool CSceneRewinder::Init() {
	if (!mScene)
		return false;

	auto list = mScene->mListObject[(int)ERender_Layer::Default];
	for (const auto& e : list) {
		if (e->CheckImmutable())
			continue;
		const char* name = e->GetName().data();
		if (strcmp(name, "Foothold") == 0 || strcmp(name, "Terrain") == 0)
			continue;

		mVecRewindableObject.push_back(e);
	}
	list = mScene->mListObject[(int)ERender_Layer::Effect];
	for (const auto& e : list) {
		if (e->CheckImmutable())
			continue;

		mVecRewindableObject.push_back(e);
	}

	size_t	size = mVecRewindableObject.size();
	if (size == 0)
		return false;

	auto map = mScene->GetResource()->GetSoundMap();
	for (const auto& e : map) {
		if (e.second->CheckReversible())
			mVecRewindableSound.push_back(e.second);
	}
	mVecPrevSoundEndCount.resize(mVecRewindableSound.size(), 0);

	std::vector<SerializedObject> vec(size + 1); // ���� �ø���������� ���� �ϳ� �߰��Ѵ�.
	for (size_t i = 0; i < size; ++i) {
		vec[i].target = mVecRewindableObject[i];
		vec[i].target->Serialize(vec[i].data);
	}
	SerializeSound(vec[size].data, true);
	mPrevSoundStatus = &(vec[size]);

	mListSerializer.push_back({0, std::move(vec)});

	mCurIterator = mListSerializer.begin();
	mMaxSceneIndex = 1;

	SetInput();

	return true;
}

void CSceneRewinder::Update(float deltaTime) {
	if (!mRewind)
		return;

	if (mRewindScale == 0)
		return;

	if (mRewindScale < 0) {
		if (mCurIterator->first == 2) {
			if (!mSoundStop) {
				ChangeSoundSpeed(0);
				mSoundStop = true;
			}
			return;
		}

		mSceneTime += (deltaTime * mRewindScale);
		// 0���� �ݶ��̴��� �̻��ϰ� �����Ѵ�. 1������ ������Ʈ�� ����� �ȵȴ�. 2������ ����ϵ��� ����.
		// �� 1���� ������Ʈ�� ����� �ȵǳ�?? ��� ���� ���������� ���� ���� Ȯ���ߴµ� (TransparentBlt)
		if (mSceneTime <= 2 * mSaveUnitTime) {
			SetIterator(2);

			LoadObjects();
			mSceneTime = 2 * mSaveUnitTime;
		} else {
			//int prev = mCurIterator->first;
			while (mSceneTime < (mCurIterator->first - 1) * mSaveUnitTime) {
				--mCurIterator;
			}
			//if (prev != mCurIterator->first)
				LoadObjects();
		}
	} else {
		int endIndex = mMaxSceneIndex - 1;
		if (mCurIterator->first == endIndex) {
			if (!mSoundStop) {
				ChangeSoundSpeed(0);
				mSoundStop = true;
			}
			return;
		}

		mSceneTime += (deltaTime * mRewindScale);
		if (mSceneTime >= endIndex * mSaveUnitTime) {
			// mMaxSceneIndex�� ����Ʈ�� ���� �ƴ� ��찡 �ֱ� ������ while�� ������ ���ͷ����͸� ã���ش�.
			SetIterator(endIndex);

			LoadObjects();
			mSceneTime = endIndex * mSaveUnitTime;
		} else {
			//int prev = mCurIterator->first;
			while (mSceneTime > (mCurIterator->first + 1) * mSaveUnitTime) {
				++mCurIterator;
			}
			//if (prev != mCurIterator->first)
				LoadObjects();
		}
	}

	mScene->RestartScene();
}

void CSceneRewinder::PostUpdate(float deltaTime) {
	if (mRewind)
		return;

	mSceneTime += deltaTime;
	if (mSceneTime >= mMaxSceneIndex * mSaveUnitTime) {
		SaveObjects(mCurIterator->first == mListSerializer.back().first);
		++mMaxSceneIndex;
	}
}

void CSceneRewinder::RenderScreen(HDC hdc) {
	if (!mRewind)
		return;

	UINT8 r = mRewindScale > 0 ? 0	 : 255;
	UINT8 g = mRewindScale > 0 ? 0	 : 255;
	UINT8 b = mRewindScale > 0 ? 255 : 0;
	UINT8 mixValue = mRewindScale != 0 ? min(60, (UINT8)(mPostProcessMixValue * fabs(mRewindScale))) : mPostProcessMixValue;

	CGameManager::GetInst()->PostProcessMixColor(mixValue, r, g, b);
}

void CSceneRewinder::RenderShadow(HDC hdc, CGameObject* object) {
	if (!dynamic_cast<CCharacter*>(object))
		return;


}

//void CSceneRewinder::SaveObjects(int index) {
//	auto iter = mCurIterator;
//	bool makeNew = index == 0 || ++iter == mListSerializer.end();
//
//	std::vector<SerializedObject>* pVec;
//	if (makeNew) {
//		std::vector<SerializedObject> vec(mRewindObjectCount);
//		pVec = &vec;
//	} else {
//		pVec = &(mCurIterator->second);
//	}
//
//	int i = 0;
//	auto list = mScene->mListObject[(int)ERender_Layer::Default];
//	for (const auto& e : list) {
//		if (e->CheckImmutable())
//			continue;
//
//		if (makeNew) {
//			SerializedObject serializer;
//			serializer.Serialize(e);
//			pVec->push_back(std::move(serializer));
//		} else {
//			(*pVec)[i].Serialize(e);
//			++i;
//		}
//	}
//
//	if (makeNew)
//		mListSerializer.push_back({index, std::move(*pVec)});
//}
void CSceneRewinder::SaveObjects(bool makeNew) {
	size_t	size = mVecRewindableObject.size();
	if (makeNew) {
		std::vector<SerializedObject> vec(size + 1);
		for (size_t i = 0; i < size; ++i) {
			vec[i].target = mVecRewindableObject[i];
			vec[i].target->Serialize(vec[i].data);
		}
		SerializeSound(vec[size].data);
		mPrevSoundStatus = &(vec[size]);
		mListSerializer.push_back({mMaxSceneIndex, std::move(vec)});
		++mCurIterator;
	} else {
		auto& vec = (++mCurIterator)->second;
		for (size_t i = 0; i < size; ++i) {
			vec[i].target = mVecRewindableObject[i];
			vec[i].target->Serialize(vec[i].data);
		}
		SerializeSound(vec[size].data);
		mPrevSoundStatus = &(vec[size]);
	}
}

void CSceneRewinder::LoadObjects() {
	size_t	size = mVecRewindableObject.size();
	for (size_t i = 0; i < size; ++i) {
		SerializedObject& obj = (mCurIterator->second)[i];
		obj.target->Deserialize(obj.data);
		obj.target->UpdateCollider(0.f);
	}
	DeserializeSound((mCurIterator->second)[size].data);
}

void CSceneRewinder::AttachUpKey() {
	if (!mRewind)
		return;

	if (mRewindScale < -1)
		mRewindScale = (int)(mRewindScale * 0.5f);
	else if (mRewindScale == -1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = 1;
	else if (mRewindScale < 8)
		mRewindScale *= 2;
	else
		mRewindScale = 8;

	((CPlayer*)(*mScene->mPlayer))->SetRewindWidget(mRewindScale);
	int curIndex = mCurIterator->first;
	if ((curIndex == 2 && mRewindScale <= 0) ||
		((curIndex == mMaxSceneIndex - 1) && mRewindScale >= 0)) {
		if (!mSoundStop) {
			mSoundStop = true;
			ChangeSoundSpeed(0);
		}
	} else {
		ChangeSoundSpeed(mRewindScale);
		mSoundStop = false;
	}
}

void CSceneRewinder::AttachDownKey() {
	if (!mRewind)
		return;

	if (mRewindScale > 1)
		mRewindScale = (int)(mRewindScale * 0.5f);
	else if (mRewindScale == 1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = -1;
	else if (mRewindScale > -8)
		mRewindScale *= 2;
	else
		mRewindScale = -8;

	((CPlayer*)(*mScene->mPlayer))->SetRewindWidget(mRewindScale);
	int curIndex = mCurIterator->first;
	if ((curIndex == 2 && mRewindScale <= 0) ||
		((curIndex == mMaxSceneIndex - 1) && mRewindScale >= 0)) {
		if (!mSoundStop) {
			mSoundStop = true;
			ChangeSoundSpeed(0);
		}
	} else {
		ChangeSoundSpeed(mRewindScale);
		mSoundStop = false;
	}
}

void CSceneRewinder::SetIterator(int index) {
	while (mCurIterator->first != index) {
		if (mCurIterator->first < index)
			++mCurIterator;
		else
			--mCurIterator;
	}
}

void CSceneRewinder::ChangeSoundSpeed(int speed) {
	size_t size = mVecRewindableSound.size();
	for (size_t i = 0; i < size; ++i) {
		mVecRewindableSound[i]->ChangeSpeed(speed);
	}
}

#pragma warning( push )
#pragma warning( disable : 6386 ) // ���� ������ ���. ���ڸ����� �����̱� ������ �����Ѵ�.
bool CSceneRewinder::SerializeSound(UINT8*& data, bool first) {
	size_t vecSize = mVecRewindableSound.size();
	if (!data) {
		size_t size = vecSize * (sizeof(byte) * 2 + sizeof(unsigned int) * 3 + sizeof(float));
		data = new UINT8[size];
	}
	if (first) {
		memset(data, 0, vecSize * (sizeof(byte) * 2 + sizeof(unsigned int) * 3 + sizeof(float)));
		return true;
	}

	int offset = 0, prevOffset = 0;
	UINT8* prevData = mPrevSoundStatus->data;
	for (size_t i = 0; i < vecSize; ++i) {
		CSound* sound = mVecRewindableSound[i];
		sound->Reset();

		// ���� �������� ���� ������ ������ �Ҹ��� ���� ������ �Ǵ��Ѵ�.
		bool prevStart = prevData[prevOffset++] == 1;
		unsigned int prevPos, prevCount, prevEndCount;
		float prevVolume;
		memcpy(&prevPos, prevData + prevOffset, sizeof(unsigned int));		prevOffset += sizeof(unsigned int);
		memcpy(&prevCount, prevData + prevOffset, sizeof(unsigned int));	prevOffset += sizeof(unsigned int);
		memcpy(&prevEndCount, prevData + prevOffset, sizeof(unsigned int));			prevOffset += sizeof(unsigned int);
		memcpy(&prevVolume, prevData + prevOffset, sizeof(float));			prevOffset += sizeof(float);

		bool playing = sound->CheckPlaying();

		unsigned int position = 0;
		if (playing) {
			FMOD_RESULT result = sound->mChannel->getPosition(&position, FMOD_TIMEUNIT_MS);
			// �Ҹ� ����� ������.
			if (result != FMOD_OK)
				playing = false;
			// �Ҹ� ����� �� ������
			else if (position > sound->mLength) {
				position = sound->mLength;
			}
			// �׽�Ʈ : �÷��� ���߿� ���� �����Ǻ��� ���� �������� ���� ��찡 �������� Ȯ��
			if (prevPos > position) {
				++mVecPrevSoundEndCount[i];
			}
		} else {
			// ���� �������� ���� �����Ǻ��� ������ ����� ���� ���̴�.
			if (prevPos > position) {
				++mVecPrevSoundEndCount[i];
			}
		}

		unsigned int count = sound->GetPlayCount();
		unsigned int endCount = mVecPrevSoundEndCount[i];
		float volume = sound->GetVolume();

		//bool start = prevCount < count;
		//bool end = prevData[prevOffset + 1] == 1;

		data[offset] = playing ? 1 : 0;
		++offset;

		memcpy(data + offset, &position, sizeof(unsigned int));	offset += sizeof(unsigned int);
		memcpy(data + offset, &count, sizeof(unsigned int));	offset += sizeof(unsigned int);
		memcpy(data + offset, &endCount, sizeof(unsigned int));			offset += sizeof(unsigned int);
		memcpy(data + offset, &volume, sizeof(float));			offset += sizeof(float);
	}

	return true;
}

bool CSceneRewinder::DeserializeSound(const UINT8* data) {
	int offset = 0;

	size_t vecSize = mVecRewindableSound.size();
	for (size_t i = 0; i < vecSize; ++i) {
		CSound* sound = mVecRewindableSound[i];
		sound->Reset();

		bool playing = data[offset] == 1;
		++offset;
		unsigned int position, count, endCount;
		float volume;
		memcpy(&position, data + offset, sizeof(unsigned int));	offset += sizeof(unsigned int);
		memcpy(&count, data + offset, sizeof(unsigned int));	offset += sizeof(unsigned int);
		memcpy(&endCount, data + offset, sizeof(int));			offset += sizeof(int);
		memcpy(&volume, data + offset, sizeof(float));			offset += sizeof(float);
		//if (!playing)
		//	continue;
		if (!sound->mLoop) {
			if (mRewindScale < 0) { // �����̸� position�� ���̸� ���������� ����Ѵ�.
				if (endCount < mVecPrevSoundEndCount[i]) {
					sound->PlayForRewind(mRewindScale, volume, sound->mLength - position);
				}
			} else {				// ���������̸� count�� ���������� ����Ѵ�.
				if (count > sound->GetPlayCount()) {
					sound->PlayForRewind(mRewindScale, volume, position);
				}
			}
		}

		sound->SetPlayCount(count);
		mVecPrevSoundEndCount[i] = endCount;
		//// FMOD ���� �ð��� async�ϰ� �귯���� ������ ���� �÷��� ���ΰ��� Ȯ���ϸ� �ȵȴ�.
		//// ������ ����� ���� �������� �������
		//bool curPlaying = sound->CheckPlaying();
		//// ���� �÷��� �������̰� �ٸ� �Ҹ��� ������� �ʾ����� ����
		//if (curPlaying && count == sound->GetPlayCount())
		//	continue;

		//// ���� �Ҹ��� ���
		//if (!curPlaying) { 
		//	sound->PlayForRewind(mRewindScale, volume);
		//	sound->SetPlayCount(count);
		//} 
		//// ������ ����Ǵ� �Ҹ��� �ٽ� ���
		//else if (count != sound->GetPlayCount()) {
		//	if (mRewindScale < 0)
		//		position = sound->GetLength() - position;
		//	sound->PlayForRewind(mRewindScale, volume, position);
		//	sound->SetPlayCount(count);
		//}
	}

	return true;
}
#pragma warning( pop )
