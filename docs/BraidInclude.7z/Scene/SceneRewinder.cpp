
#include "SceneRewinder.h"
#include "Scene.h"
#include "../Input.h"
#include "../GameObject/Player.h"
#include "../GameObject/Character.h"

CSceneRewinder::CSceneRewinder(CScene* scene) :
	mScene{scene}
{
}

CSceneRewinder::~CSceneRewinder() {
}

void CSceneRewinder::CheckRewind(float deltaTime) {
	mRewindTime -= deltaTime;

	if (CInput::GetInst()->GetShiftStatus()) {
		if (!mRewind && mRewindTime < 0.f) {
			mRewindScale = -1;
			mRewindTime = mRewindCoolTime;
			mRewind = true;

			// �Ųٷ� ���� �� ��Ÿ�� Ʈ����
			mSceneTime -= mSaveTime;
			mSaveTime = 0.f;
		}
	} else {
		if (mRewind && mRewindTime < 0.f) {
			mRewindTime = mRewindCoolTime;
			mRewind = false;

			// ��Ÿ�� Ʈ����
			if (mRewindScale < 0)
				mSceneTime += (mSaveUnitTime - mSaveTime);
			else
				mSceneTime -= mSaveTime;
			mSaveTime = 0.f;
		}
	}
}

bool CSceneRewinder::Init(CScene* cur) {
	return true;
}

void CSceneRewinder::Update(float deltaTime) {
	if (mScene->GetStopScene())
		return;

	if (!mRewind) {
		mSceneTime += deltaTime;
		mSaveTime += deltaTime;
		if (mSaveTime > mSaveUnitTime) {
			mSaveTime -= mSaveUnitTime;
			mSceneUnitTime = mSceneTime - mSaveTime;
			SaveObjects();
		}
		return;
	}

	if (mRewindScale == 0)
		return;

	if (mRewindScale > 0 && !mLastNode && mSceneUnitTime > mSceneTime)
		return;
	if (mRewindScale < 0 && !mLastNode && mSceneUnitTime < 0.f)
		return;

	// ������ �ش� ������Ʈ�� ������Ʈ
	mSceneTime += (deltaTime * mRewindScale);
	if (mRewindScale < 0) {

	}

}

void CSceneRewinder::SetInput() {
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindUp", Input_Type::Down, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindDown", Input_Type::Down, this, &CSceneRewinder::AttachDownKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindArrowUp", Input_Type::Down, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindArrowDown", Input_Type::Down, this, &CSceneRewinder::AttachDownKey);
}

void CSceneRewinder::RenderShadow(HDC hdc, CGameObject* object) {
	if (!dynamic_cast<CCharacter*>(object))
		return;


}

void CSceneRewinder::SaveObjects() {
}

void CSceneRewinder::AttachUpKey() {
	if (!mRewind)
		return;

	int prevScale = mRewindScale;
	
	if (mRewindScale < -1)
		mRewindScale *= 0.5f;
	else if (mRewindScale == -1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = 1;
	else if (mRewindScale < 8)
		mRewindScale *= 2;
	else
		mRewindScale = 8;

	mSceneUnitTime += (mRewindScale - prevScale) * mSaveUnitTime;
}

void CSceneRewinder::AttachDownKey() {
	if (!mRewind)
		return;

	int prevScale = mRewindScale;

	if (mRewindScale > 1)
		mRewindScale *= 0.5f;
	else if (mRewindScale == 1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = -1;
	else if (mRewindScale > -8)
		mRewindScale *= 2;
	else
		mRewindScale = -8;

	mSceneUnitTime += (mRewindScale - prevScale) * mSaveUnitTime;
}

template<>
bool ObjectSerializer::Serialize(CPlayer* player) {
	target = player;
	data = new UINT8[sizeof(CPlayer)];
	memcpy(data, player, sizeof(CPlayer));

	return true;
}

template<>
bool ObjectSerializer::Deserialize(CPlayer* player) {
	if (target && data)
		memcpy(player, data, sizeof(CPlayer));

	return true;
}