
#include "SceneRewinder.h"
#include "Scene.h"
#include "../Input.h"
#include "../GameObject/Player.h"

CSceneRewinder::CSceneRewinder(CScene* scene) :
	mScene{scene}
{
}

CSceneRewinder::~CSceneRewinder() {
}

void CSceneRewinder::CheckRewind(float deltaTime) {
	mRewindTime -= deltaTime;

	if (CInput::GetInst()->GetShiftStatus()) {
		if (!mRewind && mRewindTime < 0.f) {
			mRewindScale = -1;
			mRewindTime = mRewindCoolTime;
			mRewind = true;
		}
	} else {
		if (mRewind && mRewindTime < 0.f) {
			mRewindTime = mRewindCoolTime;
			mRewind = false;
		}
	}
}

bool CSceneRewinder::Init(CScene* cur) {
	return true;
}

void CSceneRewinder::Update(float deltaTime) {
	if (mScene->GetStopScene())
		return;

	if (!mRewind) {
		mSceneDeltaTime += deltaTime;
		return;
	}

	if (mRewindScale == 0)
		return;


}

void CSceneRewinder::SetInput() {
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindUp", Input_Type::Down, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindDown", Input_Type::Down, this, &CSceneRewinder::AttachDownKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindArrowUp", Input_Type::Down, this, &CSceneRewinder::AttachUpKey);
	CInput::GetInst()->AddBindFunction<CSceneRewinder>("RewindArrowDown", Input_Type::Down, this, &CSceneRewinder::AttachDownKey);
}

void CSceneRewinder::AttachUpKey() {
	if (!mRewind)
		return;

	if (mRewindScale < -1)
		mRewindScale *= 0.5f;
	else if (mRewindScale == -1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = 1;
	else if (mRewindScale < 8)
		mRewindScale *= 2;
	else
		mRewindScale = 8;
}

void CSceneRewinder::AttachDownKey() {
	if (!mRewind)
		return;

	if (mRewindScale > 1)
		mRewindScale *= 0.5f;
	else if (mRewindScale == 1)
		mRewindScale = 0;
	else if (mRewindScale == 0)
		mRewindScale = -1;
	else if (mRewindScale > -8)
		mRewindScale *= 2;
	else
		mRewindScale = -8;
}

template<>
bool ObjectSerializer::Serialize(CPlayer* player) {
	target = player;
	data = new UINT8[sizeof(CPlayer)];
	memcpy(data, player, sizeof(CPlayer));

	return true;
}

template<>
bool ObjectSerializer::Deserialize(CPlayer* player) {
	if (target && data)
		memcpy(player, data, sizeof(CPlayer));

	return true;
}