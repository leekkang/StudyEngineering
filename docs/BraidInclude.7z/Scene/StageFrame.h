#pragma once

#include "Scene.h"

class CStageFrame : public CScene {
	friend class CSceneManager;

private:
	CStageFrame();
	virtual ~CStageFrame();
	DISALLOW_COPY_AND_ASSIGN(CStageFrame)


public:
	bool Init();
};