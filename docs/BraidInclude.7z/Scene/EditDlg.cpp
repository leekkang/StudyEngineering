
#include "EditDlg.h"

#include "../resource.h"
#include "../GameManager.h"
#include "../PathManager.h"

#include "SceneManager.h"
#include "EditScene.h"
#include "MainScene.h"
#include "SceneResource.h"

#include "../Resource/Texture/Texture.h"
#include "../GameObject/Terrain.h"
#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderLine.h"

CEditDlg* gDlg = nullptr;

CEditDlg::CEditDlg() {
	gDlg = this;
}

CEditDlg::~CEditDlg() {
}


void CEditDlg::PlayEscapeSound() {
	mScene->PlayEscapeSound();
}

bool CEditDlg::Init() {
	CGameManager::GetInst()->SetEditMode(true);

	mHDlg = CreateDialog(CGameManager::GetInst()->GetWindowInstance(),
						 MAKEINTRESOURCE(IDD_DIALOG_EDIT), 
						 CGameManager::GetInst()->GetWindowHandle(), CEditDlg::WndProc);

	ShowWindow(mHDlg, SW_SHOW);

	SetDlgItemText(mHDlg, IDC_EDIT_NAME, TEXT(""));
	SetDlgItemInt(mHDlg, IDC_EDIT_LEFT, 0, TRUE);
	SetDlgItemInt(mHDlg, IDC_EDIT_TOP, 0, TRUE);
	SetDlgItemInt(mHDlg, IDC_EDIT_RIGHT, 0, TRUE);
	SetDlgItemInt(mHDlg, IDC_EDIT_BOTTOM, 0, TRUE);

	mHColliderListBox = GetDlgItem(mHDlg, IDC_LIST_COLLIDER);
	mHColliderTypeCombo = GetDlgItem(mHDlg, IDC_COMBO_COLLIDER_TYPE);
	mHProfileTypeCombo = GetDlgItem(mHDlg, IDC_COMBO_PROFILE_TYPE);

	SendMessage(mHColliderTypeCombo, CB_ADDSTRING, 0, (LPARAM)TEXT("BoxCollider"));
	SendMessage(mHColliderTypeCombo, CB_ADDSTRING, 0, (LPARAM)TEXT("LineCollider"));
	SendMessage(mHColliderTypeCombo, CB_SETCURSEL, 0, 0);

	SendMessage(mHProfileTypeCombo, CB_ADDSTRING, 0, (LPARAM)TEXT("Terrain"));
	SendMessage(mHProfileTypeCombo, CB_ADDSTRING, 0, (LPARAM)TEXT("Object"));
	SendMessage(mHProfileTypeCombo, CB_SETCURSEL, 0, 0);

	return true;
}

void CEditDlg::CreateTerrain() {
	TCHAR filePath[MAX_PATH] = {};

	OPENFILENAME openFile = {};
	openFile.lStructSize = sizeof(OPENFILENAME);
	openFile.hwndOwner = mHDlg;
	openFile.lpstrFilter = TEXT("�������\0*.*\0BmpFile\0*.bmp");
	openFile.lpstrFile = filePath;	// filePath �� Ǯ��ΰ� ���´�.
	openFile.nMaxFile = MAX_PATH;
	openFile.lpstrInitialDir = CPathManager::GetInst()->FindPath(TEXTURE_PATH)->path;

	if (GetOpenFileName(&openFile) != 0) {
		TCHAR	fileName[128] = {};
		_wsplitpath_s(filePath, nullptr, 0, nullptr, 0, fileName, 128, nullptr, 0);

		char textureName[128] = {};
#ifdef UNICODE
		int	pathLength = WideCharToMultiByte(CP_ACP, 0, fileName, -1, 0, 0, 0, 0);
		WideCharToMultiByte(CP_ACP, 0, fileName, -1, textureName, pathLength, 0, 0);
#else
		strcpy_s(textureName, fileName);
#endif // UNICODE

		if (!mScene->GetResource()->LoadTextureFullPath(textureName, filePath))
			return;
		mScene->GetResource()->SetColorKey(textureName, 255, 0, 255);
		mScene->CreateTerrain(textureName);


		SetDlgItemText(mHDlg, IDC_STATIC_MAP_NAME, fileName);

		CTexture* texture = mScene->GetTerrain()->GetTexture();
		TCHAR tmpData[32] = {};
		wsprintf(tmpData, TEXT("%d , %d"), texture->GetWidth(), texture->GetHeight());
		SetDlgItemText(mHDlg, IDC_STATIC_MAP_SIZE, tmpData);
	}
}

void CEditDlg::SelectCollider() {
	// ����Ʈ�ڽ����� ���� ���õ� ���� �ε����� �������� �Ѵ�.
	mSelectColliderIndex = (int)SendMessage(mHColliderListBox, LB_GETCURSEL, 0, 0);

	if (mSelectColliderIndex != -1) {
		CCollider* col = mScene->GetCollider(mSelectColliderIndex);
		ECollider_Type type = col->GetColliderType();
		ECollision_Profile profile = col->GetProfile()->type;

		SendMessage(mHColliderTypeCombo, CB_SETCURSEL, type == ECollider_Type::Box ? 0 : 1, 0);
		SendMessage(mHProfileTypeCombo, CB_SETCURSEL, profile == ECollision_Profile::Terrain ? 0 : 1, 0);
		mSelectColliderType = type;
		mSelectProfileType = profile;

		const std::string& name = col->GetName();
		TCHAR	colName[32]{};
#ifdef UNICODE
		int	len = MultiByteToWideChar(CP_ACP, 0, name.c_str(), (int)name.length(), 0, 0);
		MultiByteToWideChar(CP_ACP, 0, name.c_str(), (int)name.length(), colName, len);
#else
		strcpy_s(colName, name.c_str());
#endif // UNICODE

		Vector2 LT, RB;
		if (type == ECollider_Type::Box) {
			LT = ((CColliderBox*)col)->GetInfo().LT;
			RB = ((CColliderBox*)col)->GetInfo().RB;
		} else {
			LT = ((CColliderLine*)col)->GetInfo().p1;
			RB = ((CColliderLine*)col)->GetInfo().p2;
		}
		SetDlgItemText(mHDlg, IDC_EDIT_NAME, colName);
		SetDlgItemInt(mHDlg, IDC_EDIT_LEFT, (int)LT.x, TRUE);
		SetDlgItemInt(mHDlg, IDC_EDIT_TOP, (int)LT.y, TRUE);
		SetDlgItemInt(mHDlg, IDC_EDIT_RIGHT, (int)RB.x, TRUE);
		SetDlgItemInt(mHDlg, IDC_EDIT_BOTTOM, (int)RB.y, TRUE);

		mScene->SetCameraPos(col->GetOffset().x - 800.f, col->GetOffset().y - 450.f);

		ChangeListBoxElement(colName, (int)LT.x, (int)LT.y, (int)RB.x, (int)RB.y);
	}
}

void CEditDlg::SelectColliderType() {
	int index = (int)SendMessage(mHColliderTypeCombo, CB_GETCURSEL, 0, 0);
	mSelectColliderType = index == 0 ? ECollider_Type::Box : ECollider_Type::Line;
}

void CEditDlg::SelectProfileType() {
	int index = (int)SendMessage(mHProfileTypeCombo, CB_GETCURSEL, 0, 0);
	mSelectProfileType = index == 0 ? ECollision_Profile::Terrain : ECollision_Profile::StaticObj;
}

void CEditDlg::CreateCollider() {
	TCHAR tmpData[32] = {};
	GetDlgItemText(mHDlg, IDC_EDIT_NAME, tmpData, 32);

	char colName[32] = {};
#ifdef UNICODE
	int	len = WideCharToMultiByte(CP_ACP, 0, tmpData, -1, 0, 0, 0, 0);
	WideCharToMultiByte(CP_ACP, 0, tmpData, -1, colName, 32, 0, 0);
#else
	strcpy_s(tmpData, colName);
#endif // UNICODE

	BOOL transfer = FALSE;
	int	left = (int)GetDlgItemInt(mHDlg, IDC_EDIT_LEFT, &transfer, TRUE);
	int	top = (int)GetDlgItemInt(mHDlg, IDC_EDIT_TOP, &transfer, TRUE);
	int	right = (int)GetDlgItemInt(mHDlg, IDC_EDIT_RIGHT, &transfer, TRUE);
	int	bottom = (int)GetDlgItemInt(mHDlg, IDC_EDIT_BOTTOM, &transfer, TRUE);

	mScene->SetCollider(-1, colName, {(float)left, (float)top}, {(float)right, (float)bottom},
						mSelectColliderType, mSelectProfileType);

	// ����Ʈ�� �ݶ��̴��� �߰��Ѵ�.
	AddColliderToListBox(tmpData, left, top, right, bottom);

	int index = mScene->GetColliderListSize() - 1;
	mSelectColliderIndex = index;
	SendMessage(mHColliderListBox, LB_SETCURSEL, (WPARAM)index, 0);
}

void CEditDlg::DeleteCollider() {
	mSelectColliderIndex = (int)SendMessage(mHColliderListBox, LB_GETCURSEL, 0, 0);
	if (mSelectColliderIndex != -1) {
		mScene->DeleteCollider(mSelectColliderIndex);
		SendMessage(mHColliderListBox, LB_DELETESTRING, mSelectColliderIndex, 0);
	}
}

void CEditDlg::SaveCollider() {
	// ����Ʈ�ڽ����� ���� ���õ� ���� �ε����� �������� �Ѵ�.
	mSelectColliderIndex = (int)SendMessage(mHColliderListBox, LB_GETCURSEL, 0, 0);

	if (mSelectColliderIndex != -1) {
		TCHAR tmpData[32] = {};
		GetDlgItemText(mHDlg, IDC_EDIT_NAME, tmpData, 32);

		char colName[32] = {};
#ifdef UNICODE
		int	len = WideCharToMultiByte(CP_ACP, 0, tmpData, -1, 0, 0, 0, 0);
		WideCharToMultiByte(CP_ACP, 0, tmpData, -1, colName, len, 0, 0);
#else
		strcpy_s(textureName, fileName);
#endif // UNICODE

		BOOL transfer = FALSE;
		int	left = (int)GetDlgItemInt(mHDlg, IDC_EDIT_LEFT, &transfer, TRUE);
		int	top = (int)GetDlgItemInt(mHDlg, IDC_EDIT_TOP, &transfer, TRUE);
		int	right = (int)GetDlgItemInt(mHDlg, IDC_EDIT_RIGHT, &transfer, TRUE);
		int	bottom = (int)GetDlgItemInt(mHDlg, IDC_EDIT_BOTTOM, &transfer, TRUE);

		mScene->SetCollider(mSelectColliderIndex, colName, {(float)left, (float)top}, {(float)right, (float)bottom},
							mSelectColliderType, mSelectProfileType);

		ChangeListBoxElement(tmpData, left, top, right, bottom);
	}
}

void CEditDlg::Save() {
	if (!mScene->GetTerrain())
		return;

	TCHAR filePath[MAX_PATH] = {};

	OPENFILENAME openFile = {};
	openFile.lStructSize = sizeof(OPENFILENAME);
	openFile.hwndOwner = mHDlg;
	openFile.lpstrFilter = TEXT("�������\0*.*\0TerrainFile\0*.tmp");
	openFile.lpstrFile = filePath;	// filePath �� Ǯ��ΰ� ���´�.
	openFile.nMaxFile = MAX_PATH;
	openFile.lpstrInitialDir = CPathManager::GetInst()->FindPath(MAP_PATH)->path;

	if (GetSaveFileName(&openFile) != 0) {
		char fullPath[MAX_PATH] = {};

#ifdef UNICODE
		int	len = WideCharToMultiByte(CP_ACP, 0, filePath, -1, 0, 0, 0, 0);
		WideCharToMultiByte(CP_ACP, 0, filePath, -1, fullPath, len, 0, 0);
#else
		strcpy_s(fullPath, FilePath);
#endif // UNICODE

		mScene->GetTerrain()->SaveFullPath(fullPath);

//#ifdef _DEBUG
//		char* ext = strstr(fullPath, "tmp");
//		if (ext) {
//			ext[1] = 'x';
//			ext[2] = 't';
//			mScene->GetTerrain()->SaveFullPath(fullPath);
//		}
//#endif // _DEBUG
	}
}

void CEditDlg::Load() {
	TCHAR filePath[MAX_PATH] = {};

	OPENFILENAME openFile = {};
	openFile.lStructSize = sizeof(OPENFILENAME);
	openFile.hwndOwner = mHDlg;
	openFile.lpstrFilter = TEXT("�������\0*.*\0TerrainFile\0*.tmp");
	openFile.lpstrFile = filePath;	// filePath �� Ǯ��ΰ� ���´�.
	openFile.nMaxFile = MAX_PATH;
	openFile.lpstrInitialDir = CPathManager::GetInst()->FindPath(MAP_PATH)->path;

	if (GetSaveFileName(&openFile) != 0) {
		char fullPath[MAX_PATH] = {};

#ifdef UNICODE
		int	len = WideCharToMultiByte(CP_ACP, 0, filePath, -1, 0, 0, 0, 0);
		WideCharToMultiByte(CP_ACP, 0, filePath, -1, fullPath, len, 0, 0);
#else
		strcpy_s(fullPath, FilePath);
#endif // UNICODE

		mScene->LoadTerrain(fullPath);

		int size = mScene->GetColliderListSize();
		for (int i = 0; i < size; ++i) {
			AddColliderToListBox(mScene->GetCollider(i));
		}

		TCHAR	fileName[128] = {};
		_wsplitpath_s(filePath, nullptr, 0, nullptr, 0, fileName, 128, nullptr, 0);
		SetDlgItemText(mHDlg, IDC_STATIC_MAP_NAME, fileName);

		CTexture* texture = mScene->GetTerrain()->GetTexture();
		TCHAR tmpData[32] = {};
		wsprintf(tmpData, TEXT("%d , %d"), texture->GetWidth(), texture->GetHeight());
		SetDlgItemText(mHDlg, IDC_STATIC_MAP_SIZE, tmpData);
	}
}

void CEditDlg::AddColliderToListBox(CCollider* col) {
	const std::string& name = col->GetName();

	TCHAR colName[32]{};
#ifdef UNICODE
	int	len = MultiByteToWideChar(CP_ACP, 0, name.c_str(), (int)name.length(), 0, 0);
	MultiByteToWideChar(CP_ACP, 0, name.c_str(), (int)name.length(), colName, len);
#else
	strcpy_s(colName, name.c_str());
#endif // UNICODE

	Vector2 LT, RB;
	if (col->GetColliderType() == ECollider_Type::Box) {
		LT = ((CColliderBox*)col)->GetInfo().LT;
		RB = ((CColliderBox*)col)->GetInfo().RB;
		if (RB.y == 0.f) {
			((CColliderBox*)col)->Update(0.f);
			LT = ((CColliderBox*)col)->GetInfo().LT;
			RB = ((CColliderBox*)col)->GetInfo().RB;
		}
	} else {
		LT = ((CColliderLine*)col)->GetInfo().p1;
		RB = ((CColliderLine*)col)->GetInfo().p2;
		if (RB.y == 0.f) {
			((CColliderLine*)col)->Update(0.f);
			LT = ((CColliderLine*)col)->GetInfo().p1;
			RB = ((CColliderLine*)col)->GetInfo().p2;
		}
	}

	TCHAR	listData[64] = {};
	wsprintf(listData, TEXT("%s (%d,%d)(%d,%d)"), colName, (int)LT.x, (int)LT.y, (int)RB.x, (int)RB.y);
	SendMessage(mHColliderListBox, LB_ADDSTRING, 0, (LPARAM)listData);
}

void CEditDlg::ChangeListBoxElement(const TCHAR* name, int left, int top, int right, int bottom) {
	TCHAR	listData[64] = {};
	wsprintf(listData, TEXT("%s (%d,%d)(%d,%d)"), name, left, top, right, bottom);

	if (mSelectColliderIndex == - 1) {
		SendMessage(mHColliderListBox, LB_ADDSTRING, 0, (LPARAM)listData);
	} else {
		SendMessage(mHColliderListBox, LB_DELETESTRING, mSelectColliderIndex, 0);
		SendMessage(mHColliderListBox, LB_INSERTSTRING, mSelectColliderIndex, (LPARAM)listData);
		SendMessage(mHColliderListBox, LB_SETCURSEL, mSelectColliderIndex, 0);
	}
}

LRESULT CEditDlg::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	switch (message) {
		case WM_CLOSE:
			DestroyWindow(hWnd);
			gDlg->PlayEscapeSound();
			CSceneManager::GetInst()->CreateScene<CMainScene>();
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				case IDC_BUTTON_CREATE_MAP:
					gDlg->CreateTerrain();
					break;
				case IDC_LIST_COLLIDER:
					switch (HIWORD(wParam)) {
						case LBN_SELCHANGE:
							gDlg->SelectCollider();
							break;
					}
					break;
				case IDC_COMBO_COLLIDER_TYPE:
					switch (HIWORD(wParam)) {
						case CBN_SELCHANGE:
							gDlg->SelectColliderType();
							break;
					}
					break;
				case IDC_COMBO_PROFILE_TYPE:
					switch (HIWORD(wParam)) {
						case CBN_SELCHANGE:
							gDlg->SelectProfileType();
							break;
					}
					break;
				case IDC_BUTTON_CREATE_COLLIDER:
					gDlg->CreateCollider();
					break;
				case IDC_BUTTON_DELETE_COLLIDER:
					gDlg->DeleteCollider();
					break;
				case IDC_BUTTON_SAVE_COLLIDER:
					gDlg->SaveCollider();
					break;
				case IDC_BUTTON_SAVE_MAP:
					gDlg->Save();
					break;
				case IDC_BUTTON_LOAD_MAP:
					gDlg->Load();
					break;
			}
			break;
		default:
			break;
	}

	return 0;
}
