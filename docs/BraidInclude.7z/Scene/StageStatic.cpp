
#include "StageStatic.h"

#include "../GameManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Camera.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageCloud.h"
#include "StageBoss.h"

#include "../WidgetWindow/MainWindow.h"
#include "../WidgetWindow/DefaultStageWindow.h"


#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/Puzzle.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"
#include "../GameObject/Mimic.h"

#include "../GameObject/Cannon.h"
#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"
#include "../GameObject/Lever.h"
#include "../GameObject/Platform.h"

CStageStatic::CStageStatic() {
}

CStageStatic::~CStageStatic() {
}


bool CStageStatic::Init() {
	// ����
	GetResource()->LoadSound(ESound_Group::BGM, "StaticBGM", true, true, "05-LongPastGone", ".mp3");

	GetResource()->SoundPlay("StaticBGM");
	GetResource()->SetVolume(ESound_Group::BGM, 40);

	// ���� ������
	CDefaultStageWindow* stage = CreateWidgetWindow<CDefaultStageWindow>("StageStaticWindow");
	GetResource()->LoadTexture("StageStaticTexture", TEXT("Widget/stageStatic.bmp"));
	stage->SetStageTexture("StageStaticTexture");
	stage->SetStageText(TEXT("�׳డ �ִ� ��"), 680.f);
	CreateWidgetWindow<CMainWindow>("MainWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageStatic.tmp", TEXT("bgGarden.bmp"));

	// �÷��̾� �տ� ������ ����
	SetTopography({
		{TEXT("Topography/stageStatic1.bmp"), Vector2(85.f, 593.f)},
		{TEXT("Topography/stageStatic2.bmp"), Vector2(611.f, 431.f)},
		{TEXT("Topography/stageStatic3.bmp"), Vector2(1466.f, 746.f)},
		{TEXT("Topography/stageStatic4.bmp"), Vector2(1458.f, 563.f)},
		{TEXT("Topography/stageStatic5.bmp"), Vector2(1116.f, 418.f)},
		{TEXT("Topography/stageStatic6.bmp"), Vector2(1793.f, 451.f)},
		{TEXT("Topography/stageStatic7.bmp"), Vector2(1965.f, 701.f)},
		{TEXT("Topography/stageStatic8.bmp"), Vector2(3528.f, 754.f)},
		{TEXT("Topography/stageStatic9.bmp"), Vector2(2427.f, 442.f)},
		{TEXT("Topography/stageStatic10.bmp"), Vector2(3725.f, 503.f)},
		{TEXT("Topography/stageStatic11.bmp"), Vector2(3763.f, 732.f)},
		{TEXT("Topography/stageStatic12.bmp"), Vector2(4234.f, 690.f)},
				  });

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(383.f, 765.f, [&]() {
		SavePuzzle('5');
		CSceneManager::GetInst()->CreateScene<CStageCloud>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });
	((CTerrain*)*mTerrain)->SetPortal(4355.f, 708.f, [&]() {
		SavePuzzle('5');
		SaveClear('6');
		CSceneManager::GetInst()->CreateScene<CStageBoss>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
		CMainScene::mClearIndex = max(CMainScene::mClearIndex, 6);
									  });

	// ����
	mPuzzleCount = 2;
	mVecPuzzleStatus.resize(mPuzzleCount);
	LoadPuzzle('5');

	CPuzzle* puzzle = CreateObject<CPuzzle>("Puzzle");
	puzzle->SetObjectTexture(TEXT("Object/Puzzle/11"), false);
	puzzle->SetPos(1640.f, 660.f);
	puzzle->SetObtainLevel(2);
	puzzle->SetPieceOrder(0);
	puzzle->SetObtained(mVecPuzzleStatus[0]);

	puzzle = CreateObject<CPuzzle>("Puzzle");
	puzzle->SetObjectTexture(TEXT("Object/Puzzle/12"), true);
	puzzle->SetPos(3555.f, 670.f);
	puzzle->SetObtainLevel(3);
	puzzle->SetPieceOrder(1);
	puzzle->SetObtained(mVecPuzzleStatus[1]);


	// ����
	CMonstar* monstar = CreateObject<CMonstar>("Monstar");
	monstar->SetPos(1300.f, 429.f);
	monstar->SetDirection(-1);
	monstar->SetPatrolArea(0.f, 1780.f);

	CMimic* mimic = CreateObject<CMimic>("Mimic");
	mimic->SetPos(2050.f, 744.f);
	mimic->SetDirection(1);
	mimic->SetAlertXPos(2400.f);
	mimic->SetChaseRadius(1000.f);

	mimic = CreateObject<CMimic>("Mimic");
	mimic->SetPos(2120.f, 748.f);
	mimic->SetDirection(1);
	mimic->SetAlertXPos(2400.f);
	mimic->SetChaseRadius(1000.f);

	mimic = CreateObject<CMimic>("Mimic");
	mimic->SetPos(2260.f, 755.f);
	mimic->SetDirection(1);
	mimic->SetAlertXPos(2400.f);
	mimic->SetChaseRadius(1000.f);


	// ������Ʈ
	CKey* key = CreateObject<CKey>("Key");
	key->SetPos(200.f, 765.f);
	key->SetObjectTexture(false);
	key->SetLookLeft(true);
	CGate* gate = CreateObject<CGate>("Gate");
	gate->SetPos(1553.f, 760.f);
	gate->SetObjectTexture(false);

	CLever* lever = CreateObject<CLever>("Lever");
	lever->SetPos(1045.f, 704.f);
	lever->SetObjectTexture(true); 
	lever->SetInitLeverStatus(true);
	CPlatform* platform = CreateObject<CPlatform>("Platform");
	lever->SetPlatform(platform);
	platform->SetPos(932.f, 762.f);
	platform->SetObjectTexture(TEXT("Object/planeStatic1.bmp"), true);
	platform->SetMinPos(591.f);
	platform->SetMaxPos(1488.f);
	platform->SetSpeed(150.f);
	platform->SetColliderSize((float)platform->GetTexture()->GetWidth(),
							  (float)platform->GetTexture()->GetHeight() - 6.f);

	lever = CreateObject<CLever>("Lever");
	lever->SetPos(3120.f, 755.f);
	lever->SetObjectTexture(true);
	platform = CreateObject<CPlatform>("Platform");
	lever->SetPlatform(platform);
	platform->SetPos(2616.f, 461.f);
	platform->SetObjectTexture(TEXT("Object/planeStatic2.bmp"), true);
	platform->SetMinPos(2616.f);
	platform->SetMaxPos(3642.f);
	platform->SetSpeed(250.f);
	platform->SetColliderSize((float)platform->GetTexture()->GetWidth(),
							  (float)platform->GetTexture()->GetHeight() - 6.f);


	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);


	return CScene::Init();
}