
#include "StageBoss.h"

#include "SceneManager.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageTutorial.h"

#include "Camera.h"
#include "../Input.h"
#include "../GameManager.h"

#include "../WidgetWindow/MainWindow.h"

#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/Foothold.h"

#include "../GameObject/Player.h"
#include "../GameObject/Boss.h"
#include "../GameObject/Monstar.h"

#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"
#include "../GameObject/Cannon.h"
#include "../GameObject/Chandelier.h"
#include "../GameObject/Bullet.h"

CStageBoss::CStageBoss() {
}

CStageBoss::~CStageBoss() {
}


bool CStageBoss::Init() {
	CreateSound();

	// ���� ������
	CreateWidgetWindow<CMainWindow>("StartWidgetWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageBoss.tmp", TEXT("bg_4_01.bmp"));

	// �÷��̾� �տ� ������ ����
	SetTopography({
		{TEXT("stageBoss/topography1.bmp"), Vector2(16.f, 343.f)},
		{TEXT("stageBoss/topography2.bmp"), Vector2(736.f, 518.f)},
		{TEXT("stageBoss/topography3.bmp"), Vector2(1519.f, 36.f)},
		{TEXT("stageBoss/topography4.bmp"), Vector2(1733.f, 68.f)},
		{TEXT("stageBoss/topography5.bmp"), Vector2(3144.f, 270.f)},
		{TEXT("stageBoss/topography6.bmp"), Vector2(3344.f, 500.f)},
				  });

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(128.f, 366.f, []() {
		CSceneManager::GetInst()->CreateScene<CStageTutorial>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });
	//((CTerrain*)*mTerrain)->SetPortal(4171.f, 530.f, []() {
	//	CSceneManager::GetInst()->CreateScene<CMainScene>();
	//	CScene* scene = CSceneManager::GetInst()->GetNextScene();
	//	scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
	//						 scene->GetTerrain()->GetNextPortal().y, true);
	//								  });
	((CTerrain*)*mTerrain)->SetPortal(3171.f, 530.f, []() {
		CSceneManager::GetInst()->CreateScene<CMainScene>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });

	// ����
	mBoss = CreateObject<CBoss>("Boss");
	mBoss->SetPos(2445.f, 700.f);

	// ����
	CMonstar* monstar = CreateObject<CMonstar>("Monstar");
	monstar->SetPos(950.f, 530.f);
	monstar->SetDirection(-1);

	// ������Ʈ
	CKey* key = CreateObject<CKey>("Key");
	key->SetPos(780.f, 545.f);
	key->SetObjectTexture(true);
	key->SetLookLeft(true);
	CGate* gate = CreateObject<CGate>("Gate");
	gate->SetPos(1030.f, 530.f);
	gate->SetObjectTexture(true); 
	gate = CreateObject<CGate>("Gate");
	gate->SetPos(3235.f, 761.f);
	gate->SetObjectTexture(true);

	CCannon* cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(3212.f, 218.f);
	cannon->SetSpawnPos(3192.f, 255.f);
	cannon->SetObjectTexture(TEXT("Object/Cannon/cannonBoss.bmp"), "cannonBoss", false);
	cannon->SetCannonType(ECannon_Type::Monstar);
	cannon->SetBulletCount(3);
	cannon->SetBulletVelocity(-800.f, -50.f);
	cannon->SetSpawnTime(4.f);
	cannon->InitBullet();

	CChandelier* chandelier = CreateObject<CChandelier>("Chandelier");
	chandelier->SetObjectTexture(true);
	chandelier->SetHangerXOffset(-11.f);
	chandelier->SetBodyYOffset(21.f);
	chandelier->SetOriginPos(2190.f, 130.f);


	chandelier = CreateObject<CChandelier>("Chandelier");
	chandelier->SetObjectTexture(false);
	chandelier->SetHangerXOffset(-8.f);
	chandelier->SetBodyYOffset(22.f);
	chandelier->SetOriginPos(2731.f, 113.f);


	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	return CScene::Init();
}

void CStageBoss::CreateSound() {
	GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, "MainBgm.mp3");

	std::vector<std::tuple<ESound_Group, const char*, const char*, int>> soundInfo{
		{ESound_Group::Effect, "OtherBounce", "other_bounce", 1},
		{ESound_Group::Effect, "BulletHitWall", "bullet_hits_wall", 3},
		{ESound_Group::Effect, "BulletHitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "BulletHitBullet", "bullet_hits_bullet", 1},
	};

	size_t	size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
									 (std::string(std::get<2>(info)) + ".wav").c_str());
			continue;
		}

		for (int j = 0; j < count; ++j) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j), false,
									 (std::get<2>(info) + std::to_string(j + 1) + ".wav").c_str());
		}
	}
}
