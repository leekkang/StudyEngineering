
#include "StageBoss.h"

#include "../GameManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Camera.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageStatic.h"

#include "../WidgetWindow/MainWindow.h"
#include "../WidgetWindow/StageBossWindow.h"


#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"

#include "../GameObject/Player.h"
#include "../GameObject/Boss.h"
#include "../GameObject/Monstar.h"

#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"
#include "../GameObject/Cannon.h"
#include "../GameObject/Chandelier.h"
#include "../GameObject/Bullet.h"

CStageBoss::CStageBoss() {
}

CStageBoss::~CStageBoss() {
}


bool CStageBoss::Init() {
	// ����
	GetResource()->LoadSound(ESound_Group::BGM, "BossBGM", true, true, "07-Undercurrent", ".mp3");

	GetResource()->SoundPlay("BossBGM");
	GetResource()->SetVolume(ESound_Group::BGM, 40);

	// ���� ������
	CStageBossWindow* stage = CreateWidgetWindow<CStageBossWindow>("StageBossWindow");
	GetResource()->LoadTexture("StageBossTexture", TEXT("Widget/stageBoss.bmp"));
	stage->SetStageTexture("StageBossTexture");
	stage->SetStageText(TEXT("������ ����"), 705.f);
	CreateWidgetWindow<CMainWindow>("MainWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageBoss.tmp", TEXT("bgBoss.bmp"));

	// �÷��̾� �տ� ������ ����
	SetTopography({
		{TEXT("Topography/stageBoss1.bmp"), Vector2(16.f, 343.f)},
		{TEXT("Topography/stageBoss2.bmp"), Vector2(736.f, 518.f)},
		{TEXT("Topography/stageBoss3.bmp"), Vector2(1519.f, 36.f)},
		{TEXT("Topography/stageBoss4.bmp"), Vector2(1733.f, 68.f)},
		{TEXT("Topography/stageBoss5.bmp"), Vector2(3144.f, 270.f)},
		{TEXT("Topography/stageBoss6.bmp"), Vector2(3344.f, 500.f)},
		{TEXT("Topography/stageBoss7.bmp"), Vector2(3178.f, 744.f)},
				  });

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(128.f, 366.f, []() {
		CSceneManager::GetInst()->CreateScene<CStageStatic>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });
	((CTerrain*)*mTerrain)->SetPortal(4171.f, 530.f, []() {
		CSceneManager::GetInst()->CreateScene<CMainScene>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });

	// ����
	mBoss = CreateObject<CBoss>("Boss");
	mBoss->SetPos(2445.f, 770.f);
	mBoss->SetPrevPos(2445.f, 770.f);

	// ����
	CMonstar* monstar = CreateObject<CMonstar>("Monstar");
	monstar->SetPos(950.f, 530.f);
	monstar->SetDirection(-1);

	// ������Ʈ
	CKey* key = CreateObject<CKey>("Key");
	key->SetPos(780.f, 546.f);
	key->SetObjectTexture(true);
	key->SetLookLeft(true);
	CGate* gate = CreateObject<CGate>("Gate");
	gate->SetPos(1033.f, 530.f);
	gate->SetObjectTexture(true);
	gate = CreateObject<CGate>("Gate");
	gate->SetPos(3235.f, 761.f);
	gate->SetObjectTexture(true);

	mKey = CreateObject<CKey>("BossKey");
	mKey->SetPos(2445.f, 770.f);
	mKey->SetObjectTexture(true);
	mKey->SetLookLeft(true);
	mKey->SetEnable(false);

	CCannon* cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(3212.f, 218.f);
	cannon->SetSpawnPos(3192.f, 255.f);
	cannon->SetObjectTexture(TEXT("Object/Cannon/boss.bmp"), false);
	cannon->SetCannonType(ECannon_Type::Monstar);
	cannon->SetBulletCount(3);
	cannon->SetBulletVelocity(-800.f, -50.f);
	cannon->SetSpawnTime(4.f);
	cannon->InitBullet();

	CChandelier* chandelier = CreateObject<CChandelier>("Chandelier");
	chandelier->SetObjectTexture(true);
	chandelier->SetHangerXOffset(-11.f);
	chandelier->SetBodyYOffset(21.f);
	chandelier->SetOriginPos(2190.f, 130.f);


	chandelier = CreateObject<CChandelier>("Chandelier");
	chandelier->SetObjectTexture(false);
	chandelier->SetHangerXOffset(-8.f);
	chandelier->SetBodyYOffset(22.f);
	chandelier->SetOriginPos(2731.f, 113.f);


	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	return CScene::Init();
}

void CStageBoss::Update(float deltaTime) {
	CScene::Update(deltaTime);

	bool render = mBoss->CheckAlert() && !mBoss->CheckDead();
	((CStageBossWindow*)(*mVecWidgetWindow[0]))->SetRenderHP(render);

	if (!mKey->CheckPlayerHave() && mKey->GetPos().y < 300.f) {
		mKey->SetPos(mKey->GetPos().x, 330.f);
		mKey->Drop();
	}
}
