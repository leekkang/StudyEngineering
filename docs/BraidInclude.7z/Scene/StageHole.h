#pragma once

#include "Scene.h"

class CStageHole : public CScene {
	friend class CSceneManager;

private:
	CStageHole();
	virtual ~CStageHole();
	DISALLOW_COPY_AND_ASSIGN(CStageHole)


public:
	bool Init();
};