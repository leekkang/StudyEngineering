
#include "MainScene.h"

#include "../GameManager.h"
#include "../PathManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Camera.h"
#include "SceneResource.h"

#include "StageTutorial.h"
#include "StageHole.h"
#include "StageBoss.h"

#include "../WidgetWindow/MainWindow.h"

#include "../Collision/ColliderBox.h"

#include "../GameObject/Player.h"
#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"

#include "../GameObject/AlphaObject.h"
#include "../GameObject/TextObject.h"

#include "../GameObject/Boss.h"


CMainScene::CMainScene() {
}

CMainScene::~CMainScene() {
}

float CMainScene::mPrevPosX = 0.f;
int CMainScene::mClearIndex = 0;
bool CMainScene::Init() {
	CreateSound();

	// ���� ������
	CreateWidgetWindow<CMainWindow>("StartWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");
	InitPlayerPos(mPrevPosX != 0.f ? mPrevPosX : 400.f, 800.f, false);

	// ����
	mTerrain = CreateObject<CTerrain>("Terrain");
	mTerrain->SetTexture("Terrain", TEXT("stageMain.bmp"));
	CTexture* texture = mTerrain->GetTexture();
	int width = texture->GetWidth();
	int height = texture->GetHeight();
	mWorldRS.width = width;
	mWorldRS.height = height;

	CColliderBox* box = mTerrain->AddCollider<CColliderBox>("Floor");
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetExtent(1600.f, 80.f);
	box->SetOffset(800.f, 840.f);
	box = mTerrain->AddCollider<CColliderBox>("Wall");
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetExtent(50.f, 900.f);
	box->SetOffset(-15.f, 450.f);
	box = mTerrain->AddCollider<CColliderBox>("Wall");
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetExtent(50.f, 900.f);
	box->SetOffset(1615.f, 450.f);

	// ���
	CBackObj* back = CreateObject<CBackObj>("BackObj");
	back->SetTexture("BG", TEXT("bgSky.bmp"));
	back->SetSize((float)width, (float)height);

	// ������ ����
	CAlphaObject* footObj = CreateObject<CAlphaObject>("Terrain");
	footObj->SetTexture(160, "FloorCloud", TEXT("stageMain/footCloud.bmp"));
	footObj->SetColorKey(255, 0, 255);
	footObj->SetZOrder((int)ERender_ZOrder::Foothold);
	footObj->SetSize(1600.f, 130.f);
	footObj->SetPivot(0.f, 1.f);
	footObj->SetPos(0.f, 900.f);

	// �� �ؽ���
	const int portalCount = 3;
	std::vector<int> vecPuzzle(portalCount, 0);
	LoadPuzzleCount(vecPuzzle);

	float vecPos[portalCount]{475.f, 700.f, 900.f};
	std::pair<const char*, const TCHAR*> vecImage[portalCount]{
		{"doorImageTuto", TEXT("stageMain/imageTuto.bmp")},
		{"doorImageHole", TEXT("stageMain/imageHole.bmp")},
		{"doorImageBoss", TEXT("stageMain/imageBoss.bmp")}
	};

	for (int i = 0; i < portalCount; ++i) {
		RenderDoor(i > mClearIndex, vecPos[i], vecPuzzle[i], vecImage[i]);
	}

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(vecPos[0], 800.f, []() {
		CSceneManager::GetInst()->CreateScene<CStageTutorial>();
		mPrevPosX = CSceneManager::GetInst()->GetScene()->GetPlayer()->GetPos().x;
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
									  });
	((CTerrain*)*mTerrain)->SetPortal(vecPos[1], 800.f, []() {
		CSceneManager::GetInst()->CreateScene<CStageHole>();
		mPrevPosX = CSceneManager::GetInst()->GetScene()->GetPlayer()->GetPos().x;
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
									  });
	((CTerrain*)*mTerrain)->SetPortal(vecPos[2], 800.f, []() {
		CSceneManager::GetInst()->CreateScene<CStageBoss>();
		mPrevPosX = CSceneManager::GetInst()->GetScene()->GetPlayer()->GetPos().x;
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
		//scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
		//					 scene->GetTerrain()->GetNextPortal().y, false);
									  });

	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(20);
	
	return CScene::Init();
}

void CMainScene::LoadPuzzleCount(std::vector<int>& vecPuzzleCount) {
	FILE* file = nullptr;
	char path[MAX_PATH]{};
	strcpy_s(path, CPathManager::GetInst()->FindPath(MAP_PATH)->pathMultibyte);
	strcat_s(path, "Puzzle.txt");

	fopen_s(&file, path, "r");
	if (!file)
		return;

	char line[32]{};
	int index = 0;
	int maxCount = 0, curCount = 0;
	while (!feof(file)) {
		memset(line, 0, 32);
		fgets(line, 32, file);
		if (line[0] < '0')
			continue;

		index = (int)(line[0] - '0');
		maxCount = (int)(line[2] - '0');
		for (int i = 0; i < maxCount; ++i) {
			//int obtained = 0;
			//sscanf_s(line + 4 + 2 * i, "%d", &obtained);
			//if (obtained)
			if (line[4 + 2 * i] == '1')
				++curCount;
		}
		vecPuzzleCount[index] = maxCount - curCount;
	}
	fclose(file);
}

void CMainScene::CreateSound() {
	GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, "MainBgm.mp3");

	std::vector<std::tuple<ESound_Group, const char*, const char*, int>> soundInfo{
		{ESound_Group::Effect, "OtherBounce", "other_bounce", 1},
		{ESound_Group::Effect, "BulletHitWall", "bullet_hits_wall", 3},
		{ESound_Group::Effect, "BulletHitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "BulletHitBullet", "bullet_hits_bullet", 1},
	};

	size_t	size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
									(std::string(std::get<2>(info)) + ".wav").c_str());
			continue;
		}

		for (int j = 0; j < count; ++j) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j), false,
									(std::get<2>(info) + std::to_string(j + 1) + ".wav").c_str());
		}
	}
}

void CMainScene::RenderDoor(bool alpha, float posX, int puzzle, const std::pair<const char*, const TCHAR*>& image) {
	if (alpha) {
		CAlphaObject* alphaObj = CreateObject<CAlphaObject>("Terrain");
		alphaObj->SetTexture(120, "DoorBody", TEXT("stageMain/doorBody.bmp"));
		alphaObj->SetColorKey(255, 0, 255);
		alphaObj->SetPivot(0.5f, 1.f);
		alphaObj->SetPos(posX, 800.f);
		return;
	}

	CGameObject* doorObj = CreateObject<CGameObject>("Terrain");
	doorObj->SetTexture("DoorBody", TEXT("stageMain/doorBody.bmp"));
	doorObj->SetColorKey(255, 0, 255);
	doorObj->SetSize(74.f, 111.f);
	doorObj->SetPivot(0.5f, 1.f);
	doorObj->SetPos(posX, 800.f);
	if (puzzle > 0) {
		doorObj = CreateObject<CGameObject>("Terrain");
		doorObj->SetTexture("DoorCap", TEXT("stageMain/doorCap.bmp"));
		doorObj->SetColorKey(255, 0, 255);
		doorObj->SetSize(74.f, 51.f);
		doorObj->SetPivot(0.5f, 1.f);
		doorObj->SetPos(posX, 706.f); // 800.f -111.f + 17.f
		doorObj->SetZOrder(1);

		doorObj = CreateObject<CTextObject>("Terrain");
		doorObj->SetPos(posX - 6.f, 666.f);
		doorObj->SetZOrder(2);
		((CTextObject*)doorObj)->SetFont("PuzzleFont");
#ifdef UNICODE
		((CTextObject*)doorObj)->SetText(std::to_wstring(puzzle).data());
#else
		((CTextObject*)doorObj)->SetText(std::to_string(puzzle).data());
#endif
		//((CTextObject*)doorObj)->EnableShadow(true);
		//((CTextObject*)doorObj)->SetTextShadowColor(0, 0, 0);
		//((CTextObject*)doorObj)->SetShadowOffset(0.f, 1.f);
	}
	doorObj = CreateObject<CGameObject>("Terrain");
	doorObj->SetTexture(image.first, image.second);
	doorObj->SetSize(42.f, 41.f);
	doorObj->SetPos(posX - 20.f, 716.f);
	doorObj->SetZOrder(2);
}