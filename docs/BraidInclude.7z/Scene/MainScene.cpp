
#include "MainScene.h"
#include "../GameObject/Player.h"
#include "../GameObject/Monster.h"
#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"
#include "SceneResource.h"
#include "Camera.h"
#include "../Input.h"
#include "../GameManager.h"
#include "../Widget/StartWindow.h"

CMainScene::CMainScene() {
}

CMainScene::~CMainScene() {
}

bool CMainScene::Init(CScene* prev) {
	mWorldRS.width = 11810;
	mWorldRS.height = 900;

	mPrevPortal = {475.f, 750.f};
	mNextPortal = {11505.f, 315.f}; 

	CreateAnimationSequence();
	CreateSound();

	// ����, ���
	CreateObject<CTerrain>("Terrain");
	CGameObject* back = CreateObject<CBackObj>("BackObj");
	back->SetSize((float)mWorldRS.width, (float)mWorldRS.height);

	// ����
	CreateWidgetWindow<CStartWindow>("StartWindow");

	// ������Ʈ
	mPlayer = CreateObject<CPlayer>("Player");
	//mPlayer->SetPos(mPrevPortal);
	mPlayer->SetPos(5305.f, 315.f);


	//CMonster* monster = CreateObject<CMonster>("Monster");
	//monster->SetPos(800.f, 800.f);
	//monster->SetDirection((float)(rand() % 360));


	// ī�޶� ����
	GetCamera()->SetResolution((float)CGameManager::GetInst()->GetResolution().width,
							   (float)CGameManager::GetInst()->GetResolution().height);
	GetCamera()->SetWorldResolution((float)mWorldRS.width, (float)mWorldRS.height);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(20);

	return true;
}

void CMainScene::SetInput() {
	CScene::SetInput();

	CInput::GetInst()->AddBindFunction<CMainScene>("HalfTimeScale", Input_Type::Down, this, &CMainScene::F3Key);
	CInput::GetInst()->AddBindFunction<CMainScene>("NormalTimeScale", Input_Type::Down, this, &CMainScene::F4Key);
}

void CMainScene::CreateAnimationSequence() {
	// ������ �̸�, �ؽ��� �̸�, ��� + ���� �̸�, ũ��, ���� (ETexture_Type::Frame)
	std::vector<std::tuple<const std::string, const std::string, const TCHAR*, Vector2, int>> frameAnimInfo{
		{"PlayerIdle", "PlayerIdle", TEXT("idle/idle"), {60.f, 84.f}, 21},
		{"PlayerRun", "PlayerRun", TEXT("run/run"), {90.f, 90.f}, 27},
		{"PlayerJump", "PlayerJump", TEXT("jump/jump"), {78.f, 87.f}, 9},
	};
	// ������ �̸�, �ؽ��� �̸�, ��� + ���� �̸�, ũ��, ���� (ETexture_Type::Sprite)
	std::vector < std::tuple<const std::string, const std::string, const TCHAR*, Vector2, int>> spriteAnimInfo{
		{"PlayerUp", "PlayerUp", TEXT("up.bmp"), {60.f, 84.f}, 1},
		{"PlayerUpDown", "PlayerUpDown", TEXT("up_down.bmp"), {60.f, 84.f}, 4},
	};

#ifdef UNICODE
	std::wstring arrPath[2]{TEXT("Tim/left/"), TEXT("Tim/right/")};
#else
	std::string arrPath[2]{TEXT("Tim/left/"), TEXT("Tim/right/")};
#endif
	// ���� �迭�� �̸� + postfix�� ���� �ִϸ��̼ǰ� �ؽ����� �̸��� �ȴ�.
	const char* postfix[] = {"Left", "Right"};

	size_t frameSize = frameAnimInfo.size();
	size_t spriteSize = spriteAnimInfo.size();
	for (int i = 0; i < 2; ++i) {
		// ETexture_Type::Frame
		for (size_t j = 0; j < frameSize; ++j) {
			const auto& info = frameAnimInfo[j];
			std::string name = std::get<0>(info) + postfix[i];
			std::string texName = std::get<1>(info) + postfix[i];
			int size = std::get<4>(info);

#ifdef UNICODE
			std::vector<std::wstring> vec(size, arrPath[i] + std::get<2>(info));
			for (int k = 0; k < size; ++k) {
				vec[k] += std::to_wstring(k);
#else
			std::vector<std::string> vec(size, arrPath[i] + std::get<2>(info));
			for (int k = 0; k < size; ++k) {
				vec[k] += std::to_string(k);
#endif
				vec[k] += TEXT(".bmp");
			}

			if (GetResource()->CreateAnimationSequence(name, texName, vec)) {
				for (int k = 0; k < size; ++k) {
					GetResource()->AddAnimationFrame(name, {0.f, 0.f}, std::get<3>(info));
				}
				GetResource()->SetColorKeyAll(texName, 255, 0, 255);
			}
		}

		// ETexture_Type::Sprite
		for (size_t j = 0; j < spriteSize; ++j) {
			auto& info = spriteAnimInfo[j];
			std::string name = std::get<0>(info) + postfix[i];
			std::string texName = std::get<1>(info) + postfix[i];

			if (GetResource()->CreateAnimationSequence(name, texName, (arrPath[i] + std::get<2>(info)).c_str())) {
				GetResource()->AddAnimationFullFrame(name, std::get<3>(info), std::get<4>(info), 1);
				GetResource()->SetColorKey(texName, 255, 0, 255);
			}
		}
	}
}

void CMainScene::CreateSound() {
	GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, "MainBgm.mp3");

	std::vector<std::tuple<ESound_Group, const char*, const char*, int>> soundInfo{
		{ESound_Group::Effect, "OtherBounce", "enemy_bounce", 1},
		{ESound_Group::Effect, "BulletHitWall", "bullet_hits_wall", 3},
		{ESound_Group::Effect, "BulletHitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "BulletHitBullet", "bullet_hits_bullet", 1},
	};

	size_t size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
											 (std::string(std::get<2>(info)) + ".wav").c_str());
		}

		for (int j = 1; j <= count; ++j) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j - 1), false,
											 (std::get<2>(info) + std::to_string(j) + ".wav").c_str());
		}
	}
}

void CMainScene::CreateAnimSeq() {
	std::tuple<const char*, const TCHAR*, Vector2, int> animInfo[] = {
		{"PlayerRightIdle", TEXT("Player/Right/astand.bmp"), {82.f, 73.f}, 6},
		{"PlayerRightWalk", TEXT("Player/Right/awalk.bmp"), {85.f, 75.f}, 4},
		{"PlayerRightShoot", TEXT("Player/Right/ashoot1.bmp"), {70.f, 81.f}, 3},
		{"PlayerRightAttack", TEXT("Player/Right/aswing.bmp"), {176.f, 89.f}, 3},
		{"PlayerLeftIdle", TEXT("Player/Left/astand_left.bmp"), {82.f, 73.f}, 6},
		{"PlayerLeftWalk", TEXT("Player/Left/awalk_left.bmp"), {85.f, 75.f}, 4},
		{"PlayerLeftShoot", TEXT("Player/Left/ashoot1_left.bmp"), {70.f, 81.f}, 3},
		{"PlayerLeftAttack", TEXT("Player/Left/aswing_left.bmp"), {176.f, 89.f}, 3},
		{"HitEffectLeft", TEXT("Hit.bmp"), {176.f, 164.f}, 6},
		{"HitEffectRight", TEXT("Hit2.bmp"), {178.f, 164.f}, 6},
	};
	{
		for (int i = 0; i < 10; ++i) {
			auto& anim = animInfo[i];
			const char* name = std::get<0>(anim);
			if (GetResource()->CreateAnimationSequence(name, name, std::get<1>(anim), TEXTURE_PATH)) {
				GetResource()->AddAnimationFullFrame(name, std::get<2>(anim), std::get<3>(anim), 1);
				GetResource()->SetColorKey(name, 255, 0, 255);
			}

			//Vector2 size = std::get<2>(anim);
			//int count = std::get<3>(anim);
			//for (int i = 0; i < count; ++i) {
			//	GetResource()->AddAnimationFrame(name, size.x * i, 0.f, size.x, size.y);
			//}

		}
	}

	// ETexture_Type::Frame Test
	//std::string name{"FrameTest"};

	//std::vector<std::wstring> vec(11, TEXT("Mouse/"));
	//for (int i = 0; i < 10; ++i) {
	//	vec[i].push_back(TEXT('0' + i));
	//	vec[i].append(TEXT(".bmp"));
	//}
	//vec[10].append(TEXT("10.bmp"));

	//GetResource()->CreateAnimationSequence(name, name, vec);
	//for (int i = 0; i < 11; ++i) {
	//	GetResource()->AddAnimationFrame(name, {0.f, 0.f}, {32.f, 31.f});
	//}
	//GetResource()->SetColorKeyAll(name, 255, 0, 255);

	//{
	//	GetResource()->CreateAnimationSequence("", "", TEXT(""), TEXTURE_PATH);
	//	Vector2 size{};
	//	for (int i = 0; i < 10; ++i) {
	//		for (int j = 0; j < 10; ++j) {
	//			GetResource()->AddAnimationFrame("", size.x * j, size.y * i, size.x, size.y);

	//		}
	//	}
	//	GetResource()->SetColorKey("", 255, 0, 255);
	//}
}

void CMainScene::F3Key() {
	CGameManager::GetInst()->SetTimeScale(0.5f);
}

void CMainScene::F4Key() {
	CGameManager::GetInst()->SetTimeScale(1.f);
}

