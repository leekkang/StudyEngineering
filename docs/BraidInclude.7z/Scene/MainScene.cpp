
#include "MainScene.h"
#include "SceneResource.h"
#include "SceneRewinder.h"
#include "Camera.h"
#include "../Input.h"
#include "../GameManager.h"
#include "../Widget/StartWindow.h"

#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"
#include "../GameObject/Mimic.h"

#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"
#include "../GameObject/Lever.h"

CMainScene::CMainScene() {
}

CMainScene::~CMainScene() {
}

void CMainScene::SetInput() {
	CScene::SetInput();

	CInput::GetInst()->AddBindFunction<CMainScene>("HalfTimeScale", Input_Type::Down, this, this, &CMainScene::F3Key);
	CInput::GetInst()->AddBindFunction<CMainScene>("NormalTimeScale", Input_Type::Down, this, this, &CMainScene::F4Key);
}

void CMainScene::SetTerrain() {
	mWorldRS.width = 11810;
	mWorldRS.height = 900;

	mPrevPortal = {475.f, 750.f};
	mNextPortal = {11505.f, 315.f};

	// ����, ���
	CBackObj* back = CreateObject<CBackObj>("BackObj");
	back->SetTexture(TEXT("bg_4_01.bmp"));
	back->SetSize((float)mWorldRS.width, (float)mWorldRS.height);

	mTerrain = CreateObject<CTerrain>("Terrain");
}

bool CMainScene::Init() {
	SetTerrain();

	CreateSound();

	// ����
	CreateWidgetWindow<CStartWindow>("StartWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");
	//mPlayer->SetPos(mPrevPortal);
	//((CPlayer*)*mPlayer)->SetPrevPos(mPrevPortal);
	mPlayer->SetPos(7305.f, 315.f);

	// ����
	CMonstar* monstar = CreateObject<CMonstar>("Monstar");
	monstar->SetPos(7502.f, 547.f);
	monstar->SetDirection(1);
	monstar->SetPatrolArea(7502.f, 8088.f);
	monstar->SetZOrder(1);
	CMimic* mimic = CreateObject<CMimic>("Mimic");
	mimic->SetPos(8586.f, 637.f);
	mimic->SetDirection();
	mimic->SetAlertXPos(8286.f);
	mimic->SetChaseRadius(600.f);
	mimic->SetZOrder(1);

	// ������Ʈ
	CKey* key = CreateObject<CKey>("Key");
	key->SetPos(575.f, 750.f);
	key->SetObjectTexture(true);
	CGate* gate = CreateObject<CGate>("Gate");
	gate->SetPos(775.f, 750.f);
	gate->SetObjectTexture(true);
	CLever* lever = CreateObject<CLever>("Lever");
	lever->SetPos(975.f, 750.f);
	lever->SetObjectTexture(false);

	// ī�޶� ����
	GetCamera()->SetResolution((float)CGameManager::GetInst()->GetResolution().width,
							   (float)CGameManager::GetInst()->GetResolution().height);
	GetCamera()->SetWorldResolution((float)mWorldRS.width, (float)mWorldRS.height);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(20);

	SetInput();

	return CScene::Init();
}

void CMainScene::CreateSound() {
	GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, "MainBgm.mp3");

	std::vector<std::tuple<ESound_Group, const char*, const char*, int>> soundInfo{
		{ESound_Group::Effect, "OtherBounce", "enemy_bounce", 1},
		{ESound_Group::Effect, "BulletHitWall", "bullet_hits_wall", 3},
		{ESound_Group::Effect, "BulletHitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "BulletHitBullet", "bullet_hits_bullet", 1},
	};

	size_t size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
											 (std::string(std::get<2>(info)) + ".wav").c_str());
		}

		for (int j = 1; j <= count; ++j) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j - 1), false,
											 (std::get<2>(info) + std::to_string(j) + ".wav").c_str());
		}
	}
}

void CMainScene::F3Key() {
	CGameManager::GetInst()->SetTimeScale(0.5f);
}

void CMainScene::F4Key() {
	CGameManager::GetInst()->SetTimeScale(1.f);
}

