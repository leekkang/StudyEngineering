
#include "MainScene.h"
#include "SceneResource.h"
#include "SceneRewinder.h"
#include "Camera.h"
#include "../Input.h"
#include "../GameManager.h"
#include "../Widget/StartWindow.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monster.h"
#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"
#include "../GameObject/Lever.h"

CMainScene::CMainScene() {
}

CMainScene::~CMainScene() {
}

bool CMainScene::Init(CScene* prev) {
	mWorldRS.width = 11810;
	mWorldRS.height = 900;

	mPrevPortal = {475.f, 750.f};
	mNextPortal = {11505.f, 315.f}; 

	CreateSound();

	// ����, ���
	CreateObject<CTerrain>("Terrain");
	CBackObj* back = CreateObject<CBackObj>("BackObj");
	back->SetTexture(TEXT("bg_4_01.bmp"));
	back->SetSize((float)mWorldRS.width, (float)mWorldRS.height);

	// ����
	CreateWidgetWindow<CStartWindow>("StartWindow");

	// ĳ����
	mPlayer = CreateObject<CPlayer>("Player");
	mPlayer->SetPos(mPrevPortal);
	((CPlayer*)*mPlayer)->SetPrevPos(mPrevPortal);
	//mPlayer->SetPos(5305.f, 315.f);

	mVecObjectInputFunc.push_back(std::bind(&CPlayer::SetInput, (CPlayer*)*mPlayer));

	//CMonster* monster = CreateObject<CMonster>("Monster");
	//monster->SetPos(800.f, 800.f);
	//monster->SetDirection((float)(rand() % 360));

	// ������Ʈ
	//CKey* key = CreateObject<CKey>("Key");
	//key->SetPos(575.f, 750.f);
	//key->SetObjectTexture(false);
	//CGate* gate = CreateObject<CGate>("Gate");
	//gate->SetPos(775.f, 750.f);
	//gate->SetObjectTexture(false);
	CLever* lever = CreateObject<CLever>("Lever");
	lever->SetPos(775.f, 750.f);
	lever->SetObjectTexture(true);
	mVecObjectInputFunc.push_back(std::bind(&CLever::SetInput, lever));

	// ī�޶� ����
	GetCamera()->SetResolution((float)CGameManager::GetInst()->GetResolution().width,
							   (float)CGameManager::GetInst()->GetResolution().height);
	GetCamera()->SetWorldResolution((float)mWorldRS.width, (float)mWorldRS.height);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(20);

	return CScene::Init(prev);
}

void CMainScene::SetInput() {
	CScene::SetInput();

	CInput::GetInst()->AddBindFunction<CMainScene>("HalfTimeScale", Input_Type::Down, this, &CMainScene::F3Key);
	CInput::GetInst()->AddBindFunction<CMainScene>("NormalTimeScale", Input_Type::Down, this, &CMainScene::F4Key);
}

void CMainScene::CreateSound() {
	GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, "MainBgm.mp3");

	std::vector<std::tuple<ESound_Group, const char*, const char*, int>> soundInfo{
		{ESound_Group::Effect, "OtherBounce", "enemy_bounce", 1},
		{ESound_Group::Effect, "BulletHitWall", "bullet_hits_wall", 3},
		{ESound_Group::Effect, "BulletHitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "BulletHitBullet", "bullet_hits_bullet", 1},
	};

	size_t size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
											 (std::string(std::get<2>(info)) + ".wav").c_str());
		}

		for (int j = 1; j <= count; ++j) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j - 1), false,
											 (std::get<2>(info) + std::to_string(j) + ".wav").c_str());
		}
	}
}

void CMainScene::F3Key() {
	CGameManager::GetInst()->SetTimeScale(0.5f);
}

void CMainScene::F4Key() {
	CGameManager::GetInst()->SetTimeScale(1.f);
}

