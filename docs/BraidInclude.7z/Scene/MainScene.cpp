
#include "MainScene.h"

#include "SceneManager.h"
#include "SceneResource.h"

#include "StageTutorial.h"
#include "StageBoss.h"

#include "Camera.h"
#include "../Input.h"
#include "../GameManager.h"
#include "../WidgetWindow/MainWindow.h"

#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"

#include "../GameObject/Player.h"
#include "../GameObject/AlphaObject.h"
#include "../GameObject/TextObject.h"
#include "../Collision/ColliderBox.h"

#include "../GameObject/Boss.h"

CMainScene::CMainScene() {
}

CMainScene::~CMainScene() {
}

float CMainScene::mPrevPosX = 0.f;
int CMainScene::mClearIndex = 1;
bool CMainScene::Init() {
	CreateSound();

	// ���� ������
	CreateWidgetWindow<CMainWindow>("StartWidgetWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");
	InitPlayerPos(mPrevPosX != 0.f ? mPrevPosX : 400.f, 800.f, false);

	// ����
	mTerrain = CreateObject<CTerrain>("Terrain");
	mTerrain->SetTexture("Terrain", TEXT("stageMain.bmp"));
	CTexture* texture = mTerrain->GetTexture();
	int width = texture->GetWidth();
	int height = texture->GetHeight();
	mWorldRS.width = width;
	mWorldRS.height = height;

	CColliderBox* box = mTerrain->AddCollider<CColliderBox>("Floor");
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetExtent(1600.f, 80.f);
	box->SetOffset(800.f, 840.f);
	box = mTerrain->AddCollider<CColliderBox>("Wall");
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetExtent(50.f, 900.f);
	box->SetOffset(-15.f, 450.f);
	box = mTerrain->AddCollider<CColliderBox>("Wall");
	box->SetCollisionProfile(ECollision_Profile::Terrain);
	box->SetExtent(50.f, 900.f);
	box->SetOffset(1615.f, 450.f);

	// ���
	CBackObj* back = CreateObject<CBackObj>("BackObj");
	back->SetTexture("BG", TEXT("bg_4_01.bmp"));
	back->SetSize((float)width, (float)height);

	// ������ ����
	CAlphaObject* footObj = CreateObject<CAlphaObject>("Terrain");
	footObj->SetTexture(160, "FloorCloud", TEXT("stageMain/footCloud.bmp"));
	footObj->SetColorKey(255, 0, 255);
	footObj->SetZOrder((int)ERender_ZOrder::Foothold);
	footObj->SetSize(1600.f, 130.f);
	footObj->SetPivot(0.f, 1.f);
	footObj->SetPos(0.f, 900.f);

	// �� �ؽ���
	int vecPuzzle[2]{2, 0}; // ���� ���� ����
	float vecPos[2]{475.f, 700.f};
	std::pair<const char*, const TCHAR*> vecImage[2]{
		{"doorImage1", TEXT("stageMain/image1.bmp")},
		{"doorImageBoss", TEXT("stageMain/imageBoss.bmp")}
	};
	for (int i = 0; i < 2; ++i) {
		RenderDoor(i > mClearIndex, vecPos[i], vecPuzzle[i], vecImage[i]);
	}

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(vecPos[0], 800.f, []() {
		CSceneManager::GetInst()->CreateScene<CStageTutorial>();
		mPrevPosX = CSceneManager::GetInst()->GetScene()->GetPlayer()->GetPos().x;
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
									  });
	((CTerrain*)*mTerrain)->SetPortal(vecPos[1], 800.f, []() {
		CSceneManager::GetInst()->CreateScene<CStageBoss>();
		mPrevPosX = CSceneManager::GetInst()->GetScene()->GetPlayer()->GetPos().x;
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		//scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
		//					 scene->GetTerrain()->GetPrevPortal().y, false);
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, false);
									  });

	CBoss* boss = CreateObject<CBoss>("Boss");
	boss->SetPos(1000.f, 500.f);

	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(20);
	
	return CScene::Init();
}

void CMainScene::CreateSound() {
	GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, "MainBgm.mp3");

	std::vector<std::tuple<ESound_Group, const char*, const char*, int>> soundInfo{
		{ESound_Group::Effect, "OtherBounce", "other_bounce", 1},
		{ESound_Group::Effect, "BulletHitWall", "bullet_hits_wall", 3},
		{ESound_Group::Effect, "BulletHitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "BulletHitBullet", "bullet_hits_bullet", 1},
	};

	size_t	size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
									(std::string(std::get<2>(info)) + ".wav").c_str());
			continue;
		}

		for (int j = 0; j < count; ++j) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j), false,
									(std::get<2>(info) + std::to_string(j + 1) + ".wav").c_str());
		}
	}
}

void CMainScene::RenderDoor(bool alpha, float posX, int puzzle, const std::pair<const char*, const TCHAR*>& image) {
	if (alpha) {
		CAlphaObject* alphaObj = CreateObject<CAlphaObject>("Terrain");
		alphaObj->SetTexture(120, "DoorBody", TEXT("stageMain/doorBody.bmp"));
		alphaObj->SetColorKey(255, 0, 255);
		alphaObj->SetPivot(0.5f, 1.f);
		alphaObj->SetPos(posX, 800.f);
		return;
	}

	CGameObject* doorObj = CreateObject<CGameObject>("Terrain");
	doorObj->SetTexture("DoorBody", TEXT("stageMain/doorBody.bmp"));
	doorObj->SetColorKey(255, 0, 255);
	doorObj->SetSize(74.f, 111.f);
	doorObj->SetPivot(0.5f, 1.f);
	doorObj->SetPos(posX, 800.f);
	if (puzzle > 0) {
		doorObj = CreateObject<CGameObject>("Terrain");
		doorObj->SetTexture("DoorCap", TEXT("stageMain/doorCap.bmp"));
		doorObj->SetColorKey(255, 0, 255);
		doorObj->SetSize(74.f, 51.f);
		doorObj->SetPivot(0.5f, 1.f);
		doorObj->SetPos(posX, 706.f); // 800.f -111.f + 17.f
		doorObj->SetZOrder(1);

		doorObj = CreateObject<CTextObject>("Terrain");
		doorObj->SetPos(posX - 6.f, 666.f);
		doorObj->SetZOrder(2);
		((CTextObject*)doorObj)->SetFont("PuzzleFont");
#ifdef UNICODE
		((CTextObject*)doorObj)->SetText(std::to_wstring(puzzle).data());
#else
		((CTextObject*)doorObj)->SetText(std::to_string(puzzle).data());
#endif
		//((CTextObject*)doorObj)->EnableShadow(true);
		//((CTextObject*)doorObj)->SetTextShadowColor(0, 0, 0);
		//((CTextObject*)doorObj)->SetShadowOffset(0.f, 1.f);
	}
	doorObj = CreateObject<CGameObject>("Terrain");
	doorObj->SetTexture(image.first, image.second);
	doorObj->SetSize(42.f, 41.f);
	doorObj->SetPos(posX - 20.f, 716.f);
	doorObj->SetZOrder(2);
}