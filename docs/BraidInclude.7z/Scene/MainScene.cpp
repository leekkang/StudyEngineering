
#include "MainScene.h"
#include "SceneResource.h"
#include "SceneRewinder.h"
#include "Camera.h"
#include "../Input.h"
#include "../GameManager.h"
#include "../Widget/StartWindow.h"

#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/Foothold.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"
#include "../GameObject/Mimic.h"

#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"
#include "../GameObject/Lever.h"
#include "../GameObject/Cannon.h"
#include "../GameObject/Bullet.h"

CMainScene::CMainScene() {
}

CMainScene::~CMainScene() {
}

void CMainScene::SetInput() {
	CScene::SetInput();

	CInput::GetInst()->AddBindFunction<CMainScene>("HalfTimeScale", Input_Type::Down, this, this, &CMainScene::F3Key);
	CInput::GetInst()->AddBindFunction<CMainScene>("NormalTimeScale", Input_Type::Down, this, this, &CMainScene::F4Key);
}


bool CMainScene::Init() {
	CreateSound();

	// ���� ������
	CreateWidgetWindow<CStartWindow>("StartWidgetWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");
	//mPlayer->SetPos(475.f, 750.f);
	//((CPlayer*)*mPlayer)->SetPrevPos(475.f, 750.f);
	//mPlayer->SetPos(7305.f, 315.f);
	mPlayer->SetPos(9305.f, 315.f);


	// ����
	SetTerrain("stage1-1.tmp", TEXT("bg_4_01.bmp"));
	//((CTerrain*)*mTerrain)->SetPrevPortalPos(475.f, 750.f);
	((CTerrain*)*mTerrain)->SetNextPortalPos(11505.f, 315.f);

	//CreateFoothold();

	// ����
	CMonstar* monstar = CreateObject<CMonstar>("Monstar");
	monstar->SetPos(7502.f, 547.f);
	monstar->SetDirection(1);
	monstar->SetPatrolArea(7502.f, 8088.f);
	monstar->SetZOrder(1);
	CMimic* mimic = CreateObject<CMimic>("Mimic");
	mimic->SetPos(8586.f, 637.f);
	mimic->SetDirection();
	mimic->SetAlertXPos(8286.f);
	mimic->SetChaseRadius(1000.f);
	mimic->SetZOrder(1);

	// ������Ʈ
	CKey* key = CreateObject<CKey>("Key");
	key->SetPos(575.f, 750.f);
	key->SetObjectTexture(true);
	CGate* gate = CreateObject<CGate>("Gate");
	gate->SetPos(775.f, 750.f);
	gate->SetObjectTexture(true);
	CLever* lever = CreateObject<CLever>("Lever");
	lever->SetPos(975.f, 750.f);
	lever->SetObjectTexture(false);

	CCannon* cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(9035.f, 415.f);
	cannon->SetSpawnPos(8995.f, 442.f);
	cannon->SetObjectTexture(TEXT("Object/cannon1-1_1.bmp"), "cannon1-1_1", false);
	cannon->SetCannonType(ECannon_Type::Monstar);
	cannon->SetBulletCount(1);
	cannon->SetBulletVelocity(-300.f, 20.f);
	cannon->SetSpawnTime(3.f);
	cannon->InitBullet();

	cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(10080.f, 413.f);
	cannon->SetSpawnPos(10040.f, 440.f); // ��Ÿ�� �ǹ��� ���ʿ� �ִ�
	cannon->SetObjectTexture(TEXT("Object/cannon1-1_2.bmp"), "cannon1-1_2", false);
	cannon->SetCannonType(ECannon_Type::Monstar);
	cannon->SetBulletCount(2);
	cannon->SetBulletVelocity(-300.f, 20.f);
	cannon->SetSpawnTime(3.f);
	cannon->InitBullet();

	//cannon = CreateObject<CCannon>("Cannon");
	//cannon->SetPos(10080.f, 583.f);
	//cannon->SetSpawnPos(10040.f, 583.f);
	//cannon->SetObjectTexture(TEXT("Object/cannon1-1_2.bmp"), "cannon1-1_2", false);
	//cannon->SetCannonType(ECannon_Type::Bullet);
	//cannon->SetBulletCount(3);
	//cannon->SetBulletVelocity(-400.f, 0.f);
	//cannon->SetSpawnTime(2.f);
	//cannon->InitBullet();

	// ī�޶� ����
	GetCamera()->SetResolution((float)CGameManager::GetInst()->GetResolution().width,
							   (float)CGameManager::GetInst()->GetResolution().height);
	GetCamera()->SetWorldResolution((float)mWorldRS.width, (float)mWorldRS.height);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(20);

	SetInput();

	return CScene::Init();
}

void CMainScene::CreateSound() {
	GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, "MainBgm.mp3");

	std::vector<std::tuple<ESound_Group, const char*, const char*, int>> soundInfo{
		{ESound_Group::Effect, "OtherBounce", "enemy_bounce", 1},
		{ESound_Group::Effect, "BulletHitWall", "bullet_hits_wall", 3},
		{ESound_Group::Effect, "BulletHitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "BulletHitBullet", "bullet_hits_bullet", 1},
	};

	size_t size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
									(std::string(std::get<2>(info)) + ".wav").c_str());
			continue;
		}

		for (int j = 0; j < count; ++j) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j), false,
									(std::get<2>(info) + std::to_string(j + 1) + ".wav").c_str());
		}
	}
}

void CMainScene::F3Key() {
	CGameManager::GetInst()->SetTimeScale(0.5f);
}

void CMainScene::F4Key() {
	CGameManager::GetInst()->SetTimeScale(1.f);
}

