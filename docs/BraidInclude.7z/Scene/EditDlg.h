#pragma once

#include "../GameInfo.h"

class CEditDlg {
	friend class CEditScene;

private:
	CEditDlg();
	~CEditDlg();

private:
	class CEditScene* mScene = nullptr;
	HWND mHDlg				 = 0;
	HWND mHColliderListBox	 = 0;
	HWND mHColliderTypeCombo = 0;
	HWND mHProfileTypeCombo  = 0;
	int mSelectColliderIndex = -1;

	ECollider_Type mSelectColliderType	  = ECollider_Type::Box;
	ECollision_Profile mSelectProfileType = ECollision_Profile::Terrain;

public:
	HWND GetDialogueHandle() const {
		return mHDlg;
	}
	int GetSelectedColliderIndex() const {
		return mSelectColliderIndex;
	}
	void PlayEscapeSound();

public:
	bool Init();
	void CreateTerrain();
	void SelectCollider();
	void SelectColliderType();
	void SelectProfileType();
	void CreateCollider();
	void DeleteCollider();
	void SaveCollider();
	void Save();
	void Load();

private:
	// ����Ʈ�� �ݶ��̴��� �߰��Ѵ�.
	void AddColliderToListBox(const TCHAR* name, int left, int top, int right, int bottom) {
		TCHAR	listData[64] = {};
		wsprintf(listData, TEXT("%s (%d,%d)(%d,%d)"), name, left, top, right, bottom);
		SendMessage(mHColliderListBox, LB_ADDSTRING, 0, (LPARAM)listData);
	}
	void AddColliderToListBox(class CCollider* col);
	void ChangeListBoxElement(const TCHAR* name, int left, int top, int right, int bottom);
	static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
};

