#pragma once

#include "Scene.h"

class CEditScene : public CScene {
	friend class CSceneManager;

protected:
	CEditScene();
	virtual ~CEditScene();

private:
	bool mShowDialogue = false;
	class CEditDlg* mEditDlg = nullptr;

private:
	void SetInput();

public:
	int GetColliderListSize() const;
	class CCollider* GetCollider(int index) const;
	class CCollider* GetSelectedCollider() const;

public:
	void SetCameraPos(float x, float y);
	void PlayEscapeSound();

public:
	bool Init();

public:
	void CreateTerrain(const char* name);
	void LoadTerrain(const char* fullPath);
	void SetCollider(int index, const char* name, const Vector2& lt, const Vector2& rb,
					 ECollider_Type type, ECollision_Profile profile);
	void DeleteCollider(int index);

public:
	void MoveLeft();
	void MoveRight();
	void MoveUp();
	void MoveDown();
	void OpenMapEditor();
	void MouseLButtonDrag();

};

