
#include "StageCloud.h"

#include "../GameManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Camera.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageFrame.h"
#include "StageBoss.h"

#include "../WidgetWindow/MainWindow.h"
#include "../WidgetWindow/DefaultStageWindow.h"


#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"
#include "../GameObject/Puzzle.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"

#include "../GameObject/Cannon.h"
#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"

CStageCloud::CStageCloud() {
}

CStageCloud::~CStageCloud() {
}


bool CStageCloud::Init() {
	// ����
	//GetResource()->LoadSound(ESound_Group::BGM, "FrameBGM", true, true, "04-Romanesca", ".mp3");

	//GetResource()->SoundPlay("FrameBGM");
	//GetResource()->SetVolume(ESound_Group::BGM, 80);

	// ���� ������
	CDefaultStageWindow* stage = CreateWidgetWindow<CDefaultStageWindow>("StageCloudWindow");
	GetResource()->LoadTexture("StageCloudTexture", TEXT("Widget/stageCloud.bmp"));
	stage->SetStageTexture("StageCloudTexture");
	stage->SetStageText(TEXT("���� ¡�˴ٸ�"), 685.f);
	CreateWidgetWindow<CMainWindow>("MainWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageCloud.tmp", TEXT("bgRain.bmp"));

	// �÷��̾� �տ� ������ ����
	SetTopography({
//		{TEXT("Topography/stageFrame1.bmp"), Vector2(1061.f, 0.f)}
				  });

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(170.f, 550.f, [&]() {
		SavePuzzle('4');
		CSceneManager::GetInst()->CreateScene<CStageFrame>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });
	((CTerrain*)*mTerrain)->SetPortal(4880.f, 725.f, [&]() {
		SavePuzzle('4');
		CSceneManager::GetInst()->CreateScene<CStageBoss>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
		CMainScene::mClearIndex = max(CMainScene::mClearIndex, 5);
									  });

	// ����
	mPuzzleCount = 2;
	mVecPuzzleStatus.resize(mPuzzleCount);
	LoadPuzzle('4');

	CPuzzle* puzzle = CreateObject<CPuzzle>("Puzzle");
	puzzle->SetObjectTexture(TEXT("Object/Puzzle/9"), false);
	puzzle->SetPos(1490.f, 170.f);
	puzzle->SetObtainLevel(2);
	puzzle->SetPieceOrder(0);
	puzzle->SetObtained(mVecPuzzleStatus[0]); 
	puzzle = CreateObject<CPuzzle>("Puzzle");
	puzzle->SetObjectTexture(TEXT("Object/Puzzle/10"), false);
	puzzle->SetPos(4010.f, 200.f);
	puzzle->SetObtainLevel(3);
	puzzle->SetPieceOrder(1);
	puzzle->SetObtained(mVecPuzzleStatus[1]);


	// ������Ʈ
	CCannon* cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(1518.f, 388.f);
	cannon->SetSpawnPos(1452.f, 344.f);
	cannon->SetTimerPos(80.f, -45.f);
	cannon->SetCannonType(ECannon_Type::Cloud);
	cannon->SetBulletCount(3);
	cannon->SetBulletVelocity(-80.f, 0.f);
	cannon->SetSpawnTime(8.5f);
	cannon->SetInitSpawnTime(2.f);
	cannon->InitBullet();

	cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(1649.f, 423.f);
	cannon->SetSpawnPos(1582.f, 387.f);
	cannon->SetObjectTexture(TEXT("Object/Cannon/cloud1.bmp"), true);
	cannon->SetCannonType(ECannon_Type::Cloud);
	cannon->SetBulletCount(3);
	cannon->SetBulletVelocity(-80.f, 0.f);
	cannon->SetSpawnTime(8.5f);
	cannon->SetInitSpawnTime(4.f);
	cannon->InitBullet();

	cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(4054.f, 383.f);
	cannon->SetSpawnPos(3988.f, 337.f);
	cannon->SetTimerPos(90.f, -50.f);
	cannon->SetCannonType(ECannon_Type::Cloud);
	cannon->SetBulletCount(3);
	cannon->SetBulletVelocity(-80.f, 0.f);
	cannon->SetSpawnTime(7.5f);
	cannon->InitBullet();

	cannon = CreateObject<CCannon>("Cannon");
	cannon->SetPos(4175.f, 417.f);
	cannon->SetSpawnPos(4110.f, 379.f);
	cannon->SetObjectTexture(TEXT("Object/Cannon/cloud2.bmp"), true);
	cannon->SetCannonType(ECannon_Type::Cloud);
	cannon->SetBulletCount(2);
	cannon->SetBulletVelocity(-80.f, 0.f);
	cannon->SetSpawnTime(15.f);
	cannon->SetInitSpawnTime(10.f);
	cannon->InitBullet();


	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);


	return CScene::Init();
}