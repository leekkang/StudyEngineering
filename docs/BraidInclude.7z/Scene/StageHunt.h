#pragma once

#include "Scene.h"

class CStageHunt : public CScene {
	friend class CSceneManager;

private:
	CStageHunt();
	virtual ~CStageHunt();
	DISALLOW_COPY_AND_ASSIGN(CStageHunt)


public:
	class CGate* mGate = nullptr;
	class CMonstar* mMonstar[6]{};

	int GetStageMonstarCount() const;

	const int mMonstarCount = 6;

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
};