#pragma once

#include "Scene.h"

class CStageTutorial : public CScene {
	friend class CSceneManager;

private:
	CStageTutorial();
	virtual ~CStageTutorial();
	DISALLOW_COPY_AND_ASSIGN(CStageTutorial)


public:
	bool Init();
};