
#include "StageHole.h"

#include "../GameManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Camera.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageTutorial.h"
#include "StageBoss.h"

#include "../WidgetWindow/MainWindow.h"
#include "../WidgetWindow/DefaultStageWindow.h"


#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"

#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"

CStageHole::CStageHole() {
}

CStageHole::~CStageHole() {
}


bool CStageHole::Init() {
	CreateSound();

	// ���� ������
	CDefaultStageWindow* stage = CreateWidgetWindow<CDefaultStageWindow>("StageHoleWindow");
	GetResource()->LoadTexture("StageHoleTexture", TEXT("Widget/stageHole.bmp"));
	stage->SetStageTexture("StageHoleTexture");
	stage->SetStageText(TEXT("������"), 755.f);
	CreateWidgetWindow<CMainWindow>("MainWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageHole.tmp", TEXT("bgShine.bmp"));

	// �÷��̾� �տ� ������ ����
	SetTopography({
		{TEXT("stageHole/topography1.bmp"), Vector2(0.f, 401.f)},
		{TEXT("stageHole/topography2.bmp"), Vector2(463.f, 396.f)},
		{TEXT("stageHole/topography3.bmp"), Vector2(1151.f, 384.f)},
				  });

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(175.f, 440.f, [&]() {
		CSceneManager::GetInst()->CreateScene<CStageTutorial>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });
	((CTerrain*)*mTerrain)->SetPortal(1465.f, 360.f, [&]() {
		CSceneManager::GetInst()->CreateScene<CStageBoss>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
		CMainScene::mClearIndex = max(CMainScene::mClearIndex, 2);
									  });


	// ����
	CMonstar* monstar = CreateObject<CMonstar>("Monstar");
	monstar->SetPos(1000.f, 842.f);
	monstar->SetDirection(-1);
	monstar->SetPatrolArea(0.f, (float)mWorldRS.width);

	// ������Ʈ
	CKey* key = CreateObject<CKey>("Key");
	key->SetPos(700.f, 842.f);
	key->SetObjectTexture(true);
	key->SetLookLeft(true);
	CGate* gate = CreateObject<CGate>("Gate");
	gate->SetPos(1245.f, 420.f);
	gate->SetObjectTexture(true);

	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);

	//GetResource()->SoundPlay("MainBGM");
	//GetResource()->SetVolume(20);

	return CScene::Init();
}

void CStageHole::CreateSound() {
	GetResource()->LoadSound(ESound_Group::BGM, "MainBGM", true, "MainBgm.mp3");

	std::vector<std::tuple<ESound_Group, const char*, const char*, int>> soundInfo{
		{ESound_Group::Effect, "OtherBounce", "other_bounce", 1},
		{ESound_Group::Effect, "BulletHitWall", "bullet_hits_wall", 3},
		{ESound_Group::Effect, "BulletHitOther", "bullet_hits_other", 1},
		{ESound_Group::Effect, "BulletHitBullet", "bullet_hits_bullet", 1},
	};

	size_t	size = soundInfo.size();
	for (size_t i = 0; i < size; ++i) {
		const auto& info = soundInfo[i];
		int count = std::get<3>(info);
		if (count == 1) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info), false,
									 (std::string(std::get<2>(info)) + ".wav").c_str());
			continue;
		}

		for (int j = 0; j < count; ++j) {
			GetResource()->LoadSound(std::get<0>(info), std::get<1>(info) + std::to_string(j), false,
									 (std::get<2>(info) + std::to_string(j + 1) + ".wav").c_str());
		}
	}
}
