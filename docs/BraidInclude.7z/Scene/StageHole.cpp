
#include "StageHole.h"

#include "../GameManager.h"
#include "../Input.h"

#include "SceneManager.h"
#include "Camera.h"
#include "SceneResource.h"

#include "MainScene.h"
#include "StageHunt.h"
#include "StageFrame.h"

#include "../WidgetWindow/MainWindow.h"
#include "../WidgetWindow/DefaultStageWindow.h"


#include "../GameObject/BackObj.h"
#include "../GameObject/Terrain.h"

#include "../GameObject/Player.h"
#include "../GameObject/Monstar.h"

#include "../GameObject/Key.h"
#include "../GameObject/Gate.h"

CStageHole::CStageHole() {
}

CStageHole::~CStageHole() {
}


bool CStageHole::Init() {
	// ����
	GetResource()->LoadSound(ESound_Group::BGM, "HoleBGM", true, true, "08-TellItByHeart", ".mp3");

	GetResource()->SoundPlay("HoleBGM");
	GetResource()->SetVolume(ESound_Group::BGM, 40);

	// ���� ������
	CDefaultStageWindow* stage = CreateWidgetWindow<CDefaultStageWindow>("StageHoleWindow");
	GetResource()->LoadTexture("StageHoleTexture", TEXT("Widget/stageHole.bmp"));
	stage->SetStageTexture("StageHoleTexture");
	stage->SetStageText(TEXT("������"), 755.f);
	CreateWidgetWindow<CMainWindow>("MainWindow");

	// �÷��̾�
	mPlayer = CreateObject<CPlayer>("Player");

	// ����
	CreateTerrain("stageHole.tmp", TEXT("bgShine.bmp"));

	// �÷��̾� �տ� ������ ����
	SetTopography({
		{TEXT("Topography/stageHole1.bmp"), Vector2(0.f, 401.f)},
		{TEXT("Topography/stageHole2.bmp"), Vector2(463.f, 396.f)},
		{TEXT("Topography/stageHole3.bmp"), Vector2(1151.f, 384.f)},
				  });

	// ��Ż
	((CTerrain*)*mTerrain)->SetPortal(175.f, 440.f, [&]() {
		CSceneManager::GetInst()->CreateScene<CStageHunt>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetNextPortal().x - 30.f,
							 scene->GetTerrain()->GetNextPortal().y, true);
									  });
	((CTerrain*)*mTerrain)->SetPortal(1465.f, 360.f, [&]() {
		SaveClear('3');
		CSceneManager::GetInst()->CreateScene<CStageFrame>();
		CScene* scene = CSceneManager::GetInst()->GetNextScene();
		scene->InitPlayerPos(scene->GetTerrain()->GetPrevPortal().x + 30.f,
							 scene->GetTerrain()->GetPrevPortal().y, false);
		CMainScene::mClearIndex = max(CMainScene::mClearIndex, 3);
									  });


	// ����
	CMonstar* monstar = CreateObject<CMonstar>("Monstar");
	monstar->SetPos(1000.f, 842.f);
	monstar->SetDirection(-1);
	monstar->SetPatrolArea(0.f, (float)mWorldRS.width);

	// ������Ʈ
	CKey* key = CreateObject<CKey>("Key");
	key->SetPos(700.f, 842.f);
	key->SetObjectTexture(true);
	key->SetLookLeft(true);
	CGate* gate = CreateObject<CGate>("Gate");
	gate->SetPos(1245.f, 420.f);
	gate->SetObjectTexture(true);

	// ī�޶� ����
	GetCamera()->SetResolution(CGameManager::GetInst()->GetResolution());
	GetCamera()->SetWorldResolution(mWorldRS);
	GetCamera()->SetPos(0.f, 0.f);
	GetCamera()->SetTargetPivot(.5f, .5f);

	GetCamera()->SetTarget(mPlayer);


	return CScene::Init();
}