#pragma once

#include "Scene.h"

class CMainScene : public CScene {
	friend class CSceneManager;

protected:
	CMainScene();
	virtual ~CMainScene();

private:
	void SetInput();

public:
	bool Init();

private:
	void CreateSound();

private:
	void F3Key();
	void F4Key();
};

