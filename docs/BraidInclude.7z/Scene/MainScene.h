#pragma once

#include "Scene.h"

class CMainScene : public CScene {
	friend class CSceneManager;

protected:
	CMainScene();
	virtual ~CMainScene();

public:
	bool Init(CScene* prev);

private:
	void CreatePlayerAnimation();
	void CreatePlayerSound();
	void CreateAnimSeq();

private:
	void Cam1Key();
	void Cam2Key(); 
	void F3Key();
	void F4Key();
};

