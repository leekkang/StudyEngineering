#pragma once

#include "Scene.h"

class CMainScene : public CScene {
	friend class CSceneManager;

protected:
	CMainScene();
	virtual ~CMainScene();
	DISALLOW_COPY_AND_ASSIGN(CMainScene)

private:
	static float mPrevPosX;
public:
	static int mClearIndex; // Ŭ���� �� �ִ� ���������� �ε��� ����


public:
	bool Init();
	void LoadPuzzleCount(std::vector<int>& vecPuzzleCount);

private:
	void CreateSound();
	void RenderDoor(bool alpha, float posX, int puzzle, const std::pair<const char*, const TCHAR*>& image);
};