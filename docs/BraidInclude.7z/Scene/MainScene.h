#pragma once

#include "Scene.h"

class CMainScene : public CScene {
	friend class CSceneManager;

protected:
	CMainScene();
	virtual ~CMainScene();
	DISALLOW_COPY_AND_ASSIGN(CMainScene)

private:
	static float mPrevPosX;
public:
	static size_t mClearIndex; // Ŭ���� �� �ִ� ���������� �ε��� ����


public:
	bool Init();

	int LoadClear();
	void LoadPuzzleCount(std::vector<int>& vecPuzzleCount);

private:
	void RenderDoor(bool alpha, float posX, int puzzle, const std::pair<const char*, const TCHAR*>& image);
};