#pragma once

#include "Scene.h"

class CMainScene : public CScene {
	friend class CSceneManager;

protected:
	CMainScene();
	virtual ~CMainScene();

public:
	bool Init(CScene* prev);
	void SetInput();

private:
	void CreateSound();

	void CreateAnimSeq();

private:
	void F3Key();
	void F4Key();
};

