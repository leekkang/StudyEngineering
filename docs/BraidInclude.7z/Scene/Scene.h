#pragma once

#include "../GameInfo.h"
#include "../Widget/WidgetWindow.h"
#include "../Widget/WidgetComponent.h"

class CScene {
	friend class CSceneManager;

protected:
	CScene();
	virtual ~CScene();

private:
	// shift�� ������ �ִ� ���� true�� �ȴ�.
	bool  mRewind = false;
	// �ǰ��� �� �ӵ� ����
	float mRewindScale = -1.0f;
	// ���� ������ ���� ��� �����Ǵ� �ð�. �ǰ��� �� ���� ���������� �ȴ�.
	float mSceneDeltaTime = 0.f;

	class CCamera* mCamera;
	class CSceneResource* mResource;
	class CSceneCollision* mCollision; // SceneManager�� �Űܵ� ���� �ʳ�? ���԰��� �����ΰ�?

protected:
	Resolution mWorldRS{};
	Vector2 mPrevPortal;
	Vector2 mNextPortal;

	std::list<CSharedPtr<class CGameObject>> mObjList[(int)ERender_Layer::Max];
	std::list<CSharedPtr<CWidgetComponent>> mListWidgetComponent;
	CSharedPtr<CGameObject> mPlayer;

	std::vector<CSharedPtr<CWidgetWindow>> mVecWidgetWindow;

public:

	class CCamera* GetCamera() const {
		return mCamera;
	}
	class CSceneResource* GetResource()	const {
		return mResource;
	}
	class CSceneCollision* GetCollision()	const {
		return mCollision;
	}

	class CGameObject* GetPlayer()	const {
		return mPlayer;
	}

	bool GetRewind() const {
		return mRewind;
	}

	void SetRewindScale(bool up) {
		// TODO ���� ���� �߰�
	}
	void SetPlayer(class CGameObject* player);

	void AddWidgetComponent(CWidgetComponent* widget) {
		mListWidgetComponent.push_back(widget);
	}

public:
	virtual bool Init(CScene* prev);
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);

	void Collision(float deltaTime);

public:
	template <typename T>
	T* CreateObject(const std::string& name = "GameObject") {
		T* obj = new T;
		obj->SetName(name);
		obj->mScene = this;

		if (!obj->Init()) {
			SAFE_DELETE(obj);
			return nullptr;
		}

		mObjList[(int)obj->GetRenderLayer()].push_back((CGameObject*)obj);
		return obj;
	}

	template <typename T>
	T* CreateWidgetWindow(const std::string& name = "Window") {
		T* window = new T;
		window->SetName(name);
		window->mScene = this;

		if (!window->Init()) {
			SAFE_DELETE(window);
			return nullptr;
		}

		mVecWidgetWindow.push_back(window);
		return (T*)window;
	}

	template <typename T>
	T* FindWidget(const std::string& name) {
		size_t size = mVecWidgetWindow.size();
		for (size_t i = 0; i < size; ++i) {
			if (mVecWidgetWindow[i]->GetName() == name)
				return (T*)mVecWidgetWindow[i].Get();
		}

		return nullptr;
	}

private:
	static bool SortY(const CSharedPtr<class CGameObject>& src, const CSharedPtr<class CGameObject>& dest);
	static bool SortYWidgetComponent(const CSharedPtr<class CWidgetComponent>& src, const CSharedPtr<class CWidgetComponent>& dest);
	static bool SortWindow(const CSharedPtr<CWidgetWindow>& src, const CSharedPtr<CWidgetWindow>& dest);
};
