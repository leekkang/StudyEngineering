#pragma once

#include "../GameInfo.h"
#include "../Widget/WidgetWindow.h"
#include "../Widget/WidgetComponent.h"

class CScene {
	friend class CSceneManager;
	friend class CSceneRewinder;

protected:
	CScene();
	virtual ~CScene();

private:
	// ������ ������ ��� ������Ʈ�� ����� (ĳ���� �׾�����, �޴� ���� ȣ������ ��)
	bool mStopScene = false;

	class CCamera*			mCamera;
	class CSceneResource*	mResource;
	class CSceneCollision*	mCollision;
	class CSceneRewinder*	mRewinder;

protected:
	Resolution mWorldRS{};
	Vector2 mPrevPortal;
	Vector2 mNextPortal;

	CSharedPtr<class CGameObject> mPlayer;
	std::list<CSharedPtr<class CGameObject>> mListObject[(int)ERender_Layer::Max];

	std::list<CSharedPtr<CWidgetComponent>> mListWidgetComponent;
	std::vector<CSharedPtr<CWidgetWindow>> mVecWidgetWindow;

	// ���� ���� ������Ʈ���� ������ �ִ� ��ǲ �Լ� ����
	std::vector<std::function<void()>> mVecObjectInputFunc;

public:
	class CCamera* GetCamera() const {
		return mCamera;
	}
	class CSceneResource* GetResource()	const {
		return mResource;
	}
	class CSceneCollision* GetCollision()	const {
		return mCollision;
	}
	class CSceneRewinder* GetRewinder()	const {
		return mRewinder;
	}
	class CPlayer* GetPlayer()	const {
		return (CPlayer*)*mPlayer;
	}

	void AddWidgetComponent(CWidgetComponent* widget) {
		mListWidgetComponent.push_back(widget);
	}

	bool CheckRewinding() const;

	bool GetStopScene() const {
		return mStopScene;
	}

public:
	virtual bool Init(CScene* prev);
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);

	void Collision(float deltaTime);

public:
	void SetInput();

	void StopAllObject() {
		mStopScene = true;
	}

private:

public:
	template <typename T>
	T* CreateObject(const std::string& name = "GameObject") {
		T* obj = new T;
		obj->SetName(name);
		obj->mScene = this;

		if (!obj->Init()) {
			SAFE_DELETE(obj);
			return nullptr;
		}

		mListObject[(int)obj->GetRenderLayer()].push_back((CGameObject*)obj);
		return obj;
	}

	template <typename T>
	T* CreateWidgetWindow(const std::string& name = "Window") {
		T* window = new T;
		window->SetName(name);
		window->mScene = this;

		if (!window->Init()) {
			SAFE_DELETE(window);
			return nullptr;
		}

		mVecWidgetWindow.push_back(window);
		return (T*)window;
	}

	template <typename T>
	T* FindWidget(const std::string& name) {
		size_t size = mVecWidgetWindow.size();
		for (size_t i = 0; i < size; ++i) {
			if (mVecWidgetWindow[i]->GetName() == name)
				return (T*)mVecWidgetWindow[i].Get();
		}

		return nullptr;
	}

private:
	static bool SortRender(const CSharedPtr<class CGameObject>& src, const CSharedPtr<class CGameObject>& dest);
	static bool SortYWidgetComponent(const CSharedPtr<class CWidgetComponent>& src, const CSharedPtr<class CWidgetComponent>& dest);
	static bool SortWindow(const CSharedPtr<CWidgetWindow>& src, const CSharedPtr<CWidgetWindow>& dest);
};
