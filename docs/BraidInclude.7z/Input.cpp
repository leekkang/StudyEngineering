
#include "Input.h"
#include "Collision/CollisionManager.h"
#include "Resource/ResourceManager.h"
#include "GameObject/GameObject.h"

DEFINITION_SINGLE(CInput)

CInput::CInput() {
}

CInput::~CInput() {
	{
		auto	iter = mMapKeyState.begin();
		auto	iterEnd = mMapKeyState.end();
		for (; iter != iterEnd; ++iter) {
			SAFE_DELETE(iter->second);
		}
		mMapKeyState.clear();
	}

	{
		auto	iter = mMapBindKey.begin();
		auto	iterEnd = mMapBindKey.end();
		for (; iter != iterEnd; ++iter) {
			for (int i = 0; i < (int)Input_Type::End; ++i) {
				size_t	Size = iter->second->vecFunction[i].size();
				for (size_t j = 0; j < Size; ++j) {
					SAFE_DELETE(iter->second->vecFunction[i][j]);
				}
			}
			SAFE_DELETE(iter->second);
		}
		mMapBindKey.clear();
	}
}

void CInput::ComputeWorldMousePos(const Vector2& cameraPos) {
	mMouseWorldPos = mMousePos + cameraPos;
}

bool CInput::Init(HWND hWnd) {
	mHWnd = hWnd;

	AddBindKey("Debug", VK_TAB);

	AddBindKey("Up", 'W');
	AddBindKey("Left", 'A');
	AddBindKey("Down", 'S');
	AddBindKey("Right", 'D');
	AddBindKey("ArrowUp", VK_UP);
	AddBindKey("ArrowLeft", VK_LEFT);
	AddBindKey("ArrowDown", VK_DOWN);
	AddBindKey("ArrowRight", VK_RIGHT);
	AddBindKey("Space", VK_SPACE);

	AddBindKey("Rewind", VK_SHIFT);
	SetKeyShift("Rewind");
	AddBindKey("RewindUp", 'W');
	SetKeyShift("RewindUp");
	AddBindKey("RewindDown", 'S');
	SetKeyShift("RewindDown");
	AddBindKey("RewindArrowUp", VK_UP);
	SetKeyShift("RewindArrowUp");
	AddBindKey("RewindArrowDown", VK_DOWN);
	SetKeyShift("RewindArrowDown");

	AddBindKey("SelfDead", '1');
	AddBindKey("HalfTimeScale", VK_F3);
	AddBindKey("NormalTimeScale", VK_F4);

	mCtrl = false;
	mAlt = false;
	mShift = false;

	mMouseProfile = CCollisionManager::GetInst()->FindProfile(ECollision_Profile::Mouse);

	std::vector<std::wstring>	vecFileName;
	for (int i = 0; i <= 10; ++i) {
		TCHAR	fileName[MAX_PATH] = {};
		wsprintf(fileName, TEXT("Mouse/%d.bmp"), i);
		vecFileName.push_back(fileName);
	}
	CResourceManager::GetInst()->CreateAnimationSequence("MouseDefault",
														 "MouseDefault", vecFileName, TEXTURE_PATH);
	for (int i = 0; i < 11; ++i) {
		CResourceManager::GetInst()->AddAnimationFrame("MouseDefault", 0.f, 0.f, 32.f, 31.f);
	}
	CResourceManager::GetInst()->SetColorKeyAll("MouseDefault", 255, 0, 255);

	//mMouseObj = new CGameObject;
	//mMouseObj->SetName("Mouse");
	//mMouseObj->Init();
	//mMouseObj->SetSize(32.f, 31.f);
	//mMouseObj->CreateAnimation();
	//mMouseObj->AddAnimationInfo("MouseDefault");

	//ShowCursor(FALSE);
	//mShowCursor = false;
	ShowCursor(TRUE);
	mShowCursor = true;

	return true;
}

void CInput::Update(float deltaTime) {
	UpdateMouse(deltaTime);

	UpdateKeyState(deltaTime);

	UpdateBindKey(deltaTime);
}

//void CInput::PostUpdate(float deltaTime) {
//	mMouseObj->PostUpdate(deltaTime);
//}
//
//void CInput::Render(HDC hdc, float deltaTime) {
//	mMouseObj->Render(hdc, deltaTime);
//}

void CInput::UpdateMouse(float deltaTime) {
	POINT ptMouse;

	// ��ũ�� ��ǥ
	GetCursorPos(&ptMouse);
	// ��ũ�� ��ǥ�� mHWnd �������� ��ǥ�� �����Ѵ�.
	ScreenToClient(mHWnd, &ptMouse);

	mMouseMove.x = (float)ptMouse.x - mMousePos.x;
	mMouseMove.y = (float)ptMouse.y - mMousePos.y;

	mMousePos.x = (float)ptMouse.x;
	mMousePos.y = (float)ptMouse.y;

	RECT	rc = {};
	GetClientRect(mHWnd, &rc);
	if (rc.left <= ptMouse.x && ptMouse.x <= rc.right &&
		rc.top <= ptMouse.y && ptMouse.y <= rc.bottom) {
		//if (mShowCursor) {
		//	mShowCursor = false;
		//	ShowCursor(FALSE);
		//}
	} else {
		if (!mShowCursor) {
			mShowCursor = true;
			ShowCursor(TRUE);
		}
	}

	if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) {
		if (!mMouseLDown && !mMouseLPush) {
			mMouseLDown = true;
			mMouseLPush = true;
		} else {
			mMouseLDown = false;
		}
	} else if (mMouseLPush) {
		mMouseLDown = false;
		mMouseLPush = false;
		mMouseLUp = true;
	} else if (mMouseLUp) {
		mMouseLUp = false;
	}

	//mMouseObj->SetPos(mMouseWorldPos.x, mMouseWorldPos.y);
	//mMouseObj->Update(deltaTime);
}

void CInput::UpdateKeyState(float deltaTime) {
	if (GetAsyncKeyState(VK_CONTROL) & 0x8000)
		mCtrl = true;
	else
		mCtrl = false;

	if (GetAsyncKeyState(VK_MENU) & 0x8000)
		mAlt = true;
	else
		mAlt = false;

	if (GetAsyncKeyState(VK_SHIFT) & 0x8000)
		mShift = true;
	else
		mShift = false;

	auto	iter = mMapKeyState.begin();
	auto	iterEnd = mMapKeyState.end();

	for (; iter != iterEnd; ++iter) {
		bool	KeyPush = false;

		if (GetAsyncKeyState(iter->second->key) & 0x8000) {
			KeyPush = true;
		}

		// Ű�� ������ ���
		if (KeyPush) {
			// down�� push ��� false��� �� Ű�� ���� ���� ���̴�.
			// �׷��Ƿ� �Ѵ� true�� �����Ѵ�.
			if (!iter->second->down && !iter->second->push) {
				iter->second->down = true;
				iter->second->push = true;
			}

			// down�� push ���� �ϳ��� true��� down�� false��
			// �Ǿ�� �Ѵ�. push�� �̹� ������ true�� ����Ǿ���.
			else
				iter->second->down = false;
		}

		// Ű�� �ȴ������� ��� push�� true���
		// ���� �����ӿ� Ű�� ������ �ִٰ� ���� �������ٴ� ���̴�.
		else if (iter->second->push) {
			iter->second->up = true;
			iter->second->push = false;
			iter->second->down = false;
		}

		else if (iter->second->up)
			iter->second->up = false;
	}
}

void CInput::UpdateBindKey(float deltaTime) {
	auto	iter = mMapBindKey.begin();
	auto	iterEnd = mMapBindKey.end();

	for (; iter != iterEnd; ++iter) {
		if (iter->second->key->down &&
			iter->second->ctrl == mCtrl &&
			iter->second->alt == mAlt &&
			iter->second->shift == mShift) {
			size_t	Size = iter->second->vecFunction[(int)Input_Type::Down].size();

			for (size_t i = 0; i < Size; ++i) {
				iter->second->vecFunction[(int)Input_Type::Down][i]->func();
			}
		}

		if (iter->second->key->push &&
			iter->second->ctrl == mCtrl &&
			iter->second->alt == mAlt &&
			iter->second->shift == mShift) {
			size_t	Size = iter->second->vecFunction[(int)Input_Type::Push].size();

			for (size_t i = 0; i < Size; ++i) {
				iter->second->vecFunction[(int)Input_Type::Push][i]->func();
			}
		}

		if (iter->second->key->up &&
			iter->second->ctrl == mCtrl &&
			iter->second->alt == mAlt &&
			iter->second->shift == mShift) {
			size_t	Size = iter->second->vecFunction[(int)Input_Type::Up].size();

			for (size_t i = 0; i < Size; ++i) {
				iter->second->vecFunction[(int)Input_Type::Up][i]->func();
			}
		}
	}
}

void CInput::SetKeyCtrl(const std::string& name, bool ctrl) {
	BindKey* key = FindBindKey(name);
	if (!key)
		return;

	key->ctrl = ctrl;
}

void CInput::SetKeyAlt(const std::string& name, bool alt) {
	BindKey* key = FindBindKey(name);
	if (!key)
		return;

	key->alt = alt;
}

void CInput::SetKeyShift(const std::string& name, bool shift) {
	BindKey* key = FindBindKey(name);
	if (!key)
		return;

	key->shift = shift;
}

KeyState* CInput::FindKeyState(unsigned char key) {
	auto	iter = mMapKeyState.find(key);

	// ��ã���� ���
	if (iter == mMapKeyState.end())
		return nullptr;

	// iter->first : key
	// iter->second : value
	return iter->second;
}

BindKey* CInput::FindBindKey(const std::string& name) {
	auto	iter = mMapBindKey.find(name);

	// ��ã���� ���
	if (iter == mMapBindKey.end())
		return nullptr;

	// iter->first : key
	// iter->second : value
	return iter->second;
}

bool CInput::AddBindKey(const std::string& name,
						unsigned char key) {
	// ���� �̸����� BindKey�� ��ϵǾ� ���� ���
	if (FindBindKey(name))
		return false;

	BindKey* newKey = new BindKey;

	// �ش� Ű�� �̹� KeyState�� ��ϵǾ� �ִ����� ã�´�.
	KeyState* state = FindKeyState(key);

	// ����� �ȵǾ� ���� ��� KeyState�� ���� ����Ѵ�.
	if (!state) {
		state = new KeyState;
		state->key = key;
		mMapKeyState.insert(std::make_pair(key, state));
	}

	newKey->key = state;
	newKey->name = name;
	mMapBindKey.insert(std::make_pair(name, newKey));

	return true;
}

void CInput::ClearCallback() {
	auto	iter = mMapBindKey.begin();
	auto	iterEnd = mMapBindKey.end();
	for (; iter != iterEnd; ++iter) {
		for (int i = 0; i < (int)Input_Type::End; ++i) {
			size_t size = iter->second->vecFunction[i].size();
			for (size_t j = 0; j < size; ++j) {
				SAFE_DELETE(iter->second->vecFunction[i][j]);
			}
			iter->second->vecFunction[i].clear();
		}
	}
}
