
#include "ColliderBox.h"
#include "../GameObject/GameObject.h"
#include "../GameManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/EditScene.h"

#include "CollisionManager.h"
#include "ColliderCircle.h"
#include "ColliderLine.h"

CColliderBox::CColliderBox() {
	SetTypeID<CColliderBox>();

	mColliderType = ECollider_Type::Box;
}

CColliderBox::CColliderBox(const CColliderBox& collider) :
	CCollider(collider),
	mWidth(collider.mWidth),
	mHeight(collider.mHeight),
	mInfo(collider.mInfo) {
}

CColliderBox::~CColliderBox() {
}

bool CColliderBox::Init() {
	if (!CCollider::Init())
		return false;

	return true;
}

void CColliderBox::Update(float deltaTime) {
	CCollider::Update(deltaTime);

	Vector2 pos = mOwner->GetPos();
	Vector2 size(mWidth, mHeight);

	mInfo.LT = pos + mOffset - size / 2.f;
	mInfo.RB = pos + mOffset + size / 2.f;

	mBottom = mInfo.RB.y;
}

void CColliderBox::PostUpdate(float deltaTime) {
	CCollider::PostUpdate(deltaTime);
}

void CColliderBox::Render(HDC hdc, float deltaTime) {
#ifdef _DEBUG
	if (!gDebugMode)
		return;

	Vector2 camPos = mScene->GetCamera()->GetPos();
	if (mOwner->OutOfCamera(mScene->GetCamera(), mInfo.LT - camPos, {mWidth, mHeight}))
		return;

	HBRUSH brush = CGameManager::GetInst()->GetBrush(EBrush_Type::Green);
	if (!mListCollision.empty() || mMouseCollision)
		brush = CGameManager::GetInst()->GetBrush(EBrush_Type::Red);
	if (CGameManager::GetInst()->GetEditMode() &&
		((CEditScene*)mScene)->GetSelectedCollider() == this)
		brush = CGameManager::GetInst()->GetBrush(EBrush_Type::Red);

	RECT renderRC{(long)(mInfo.LT.x - camPos.x), (long)(mInfo.LT.y - camPos.y),
					(long)(mInfo.RB.x - camPos.x), (long)(mInfo.RB.y - camPos.y)}; 

	FrameRect(hdc, &renderRC, brush);

	if (mOwner->GetName() != "Player") {
		SetBkMode(hdc, TRANSPARENT);
		char str[64]{};

		int x = (int)((mInfo.LT.x + mInfo.RB.x) * .5f);
		int y = (int)mInfo.RB.y;
		int w = (int)(mInfo.RB.x - mInfo.LT.x);
		sprintf_s(str, " x : %d, y : %d, width : %d", x, y, w);
		x = (int)(x - camPos.x);
		y = (int)(y - camPos.y);
		SetTextColor(hdc, 0x00000000);
		TextOutA(hdc, x + 1, y, str, (int)strlen(str));
		TextOutA(hdc, x - 1, y, str, (int)strlen(str));
		TextOutA(hdc, x, y + 1, str, (int)strlen(str));
		TextOutA(hdc, x, y - 1, str, (int)strlen(str));
		SetTextColor(hdc, 0x00ffffff);
		TextOutA(hdc, x, y, str, (int)strlen(str));
	}
#endif // _DEBUG
}

bool CColliderBox::Collision(CCollider* dest) {
	switch (dest->GetColliderType()) {
		case ECollider_Type::Box:
			return CCollisionManager::GetInst()->CollisionBoxToBox(this, (CColliderBox*)dest);
			break;
		case ECollider_Type::Circle:
			return CCollisionManager::GetInst()->CollisionBoxToCircle(this, (CColliderCircle*)dest);
			break;
		case ECollider_Type::Line:
			return CCollisionManager::GetInst()->CollisionLineToBox((CColliderLine*)dest, this);
			break;
	}

	return false;
}

bool CColliderBox::CollisionMouse(const Vector2& mouse) {
	return CCollisionManager::GetInst()->CollisionPointToBox(mHitPoint, mouse, mInfo);
}

void CColliderBox::Save(FILE* file) {
	CRef::Save(file);

	//UINT8 tmp = (UINT8)mProfile->type;
	//fwrite(&tmp, 1, 1, file);
	fwrite(&mProfile->type, sizeof(ECollision_Profile), 1, file);
	fwrite(&mOffset, sizeof(Vector2), 1, file);

	fwrite(&mWidth, sizeof(float), 1, file);
	fwrite(&mHeight, sizeof(float), 1, file);
	fwrite(&mInfo, sizeof(BoxInfo), 1, file);
}

void CColliderBox::Load(FILE* file) {
	CRef::Load(file);

	ECollision_Profile profile = ECollision_Profile::Default;
	//UINT8 tmp;
	//fread(&tmp, 1, 1, file);
	//profile = (ECollision_Profile)tmp;
	fread(&profile, sizeof(ECollision_Profile), 1, file);
	SetCollisionProfile(profile);
	fread(&mOffset, sizeof(Vector2), 1, file);

	fread(&mWidth, sizeof(float), 1, file);
	fread(&mHeight, sizeof(float), 1, file);
	fread(&mInfo, sizeof(BoxInfo), 1, file);
}
