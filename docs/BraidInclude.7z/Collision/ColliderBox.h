#pragma once

#include "Collider.h"

class CColliderBox : public CCollider {
	friend class CGameObject;

protected:
	CColliderBox();
	CColliderBox(const CColliderBox& collider);
	virtual ~CColliderBox();

protected:
	float   mWidth = 10.f;
	float   mHeight = 10.f;
	BoxInfo mInfo;

public:
	BoxInfo GetInfo() const {
		return mInfo;
	}
	float GetWidth() const {
		return mWidth;
	}
	float GetHeight() const {
		return mHeight;
	}

	void SetExtent(float width, float height) {
		mWidth = width;
		mHeight = height;
	}

	void SetRectWithOffset(const Vector2& lt, const Vector2& rb) {
		SetOffset((lt + rb) * .5f);
		mWidth = rb.x - lt.x;
		mHeight = rb.y - lt.y;
	}

	virtual float GetBottomY(float x) const {
		return mInfo.RB.y;
	}
	virtual float GetTopY(float x) const {
		return mInfo.LT.y;
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Collision(CCollider* dest);
	virtual bool CollisionMouse(const Vector2& mouse);
};

