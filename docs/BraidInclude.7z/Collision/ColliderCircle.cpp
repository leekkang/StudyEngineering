#include "ColliderCircle.h"
#include "../GameObject/GameObject.h"
#include "../GameManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "CollisionManager.h"
#include "ColliderBox.h"
#include "ColliderLine.h"

CColliderCircle::CColliderCircle() {
	SetTypeID<CColliderCircle>();

	mColliderType = ECollider_Type::Circle;
	mInfo.radius = 30.f;
}

CColliderCircle::CColliderCircle(const CColliderCircle& collider) :
	CCollider(collider),
	mInfo(collider.mInfo) {
}

CColliderCircle::~CColliderCircle() {
}

bool CColliderCircle::Init() {
	if (!CCollider::Init())
		return false;

	return true;
}

void CColliderCircle::Update(float deltaTime) {
	CCollider::Update(deltaTime);

	Vector2 pos = mOwner->GetPos();
	mInfo.center = pos + mOffset;

	mBottom = mInfo.center.y + mInfo.radius;
}

void CColliderCircle::PostUpdate(float deltaTime) {
	CCollider::PostUpdate(deltaTime);
}

void CColliderCircle::Render(HDC hdc, float deltaTime) {
#ifdef _DEBUG
	if (!gDebugMode)
		return;

	Vector2 camPos = mScene->GetCamera()->GetPos();
	Vector2 pos = mInfo.center - camPos;
	if (mOwner->OutOfCamera(mScene->GetCamera(), pos, {mInfo.radius * 2.f, mInfo.radius * 2.f}))
		return;

	HPEN pen = CGameManager::GetInst()->GetPen(EBrush_Type::Green);
	if (!mListCollision.empty() || mMouseCollision)
		pen = CGameManager::GetInst()->GetPen(EBrush_Type::Red);

	HPEN prevPen = (HPEN)SelectObject(hdc, pen);

	MoveToEx(hdc, (long)(pos.x + mInfo.radius), (long)pos.y, nullptr);
	for (int i = 12; i <= 360; i += 12) {
		Vector2 target{
			pos.x + cosf(DegreeToRadian((float)i)) * mInfo.radius,
			pos.y + sinf(DegreeToRadian((float)i)) * mInfo.radius
		};
		LineTo(hdc, (long)target.x, (long)target.y);
	}

	SelectObject(hdc, prevPen);

	if (mOwner->GetName() != "Player") {
		SetBkMode(hdc, TRANSPARENT);
		char str[64]{};

		int x = (int)mInfo.center.x;
		int y = (int)(mInfo.center.y + mInfo.radius);
		sprintf_s(str, " x : %d, y : %d", x, y);
		x = (int)(x - camPos.x);
		y = (int)(y - camPos.y);
		SetTextColor(hdc, 0x00000000);
		TextOutA(hdc, x + 1, y, str, (int)strlen(str));
		TextOutA(hdc, x - 1, y, str, (int)strlen(str));
		TextOutA(hdc, x, y + 1, str, (int)strlen(str));
		TextOutA(hdc, x, y - 1, str, (int)strlen(str));
		SetTextColor(hdc, 0x00ffffff);
		TextOutA(hdc, x, y, str, (int)strlen(str));
	}
#endif // _DEBUG
}

bool CColliderCircle::Collision(CCollider* dest) {
	switch (dest->GetColliderType()) {
		case ECollider_Type::Box:
			return CCollisionManager::GetInst()->CollisionBoxToCircle((CColliderBox*)dest, this);
			break;
		case ECollider_Type::Circle:
			return CCollisionManager::GetInst()->CollisionCircleToCircle(this, (CColliderCircle*)dest);
			break;
		case ECollider_Type::Line:
			return CCollisionManager::GetInst()->CollisionLineToCircle((CColliderLine*)dest, this);
			break;
	}

	return false;
}

bool CColliderCircle::CollisionMouse(const Vector2& mouse) {
	return CCollisionManager::GetInst()->CollisionPointToCircle(mHitPoint, mouse, mInfo);
}