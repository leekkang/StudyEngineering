#pragma once

#include "../GameInfo.h"
#include "../SingletonMacro.h"

class CCollisionManager {
	DECLARE_SINGLE(CCollisionManager)

private:
	std::unordered_map<ECollision_Profile, CollisionProfile*>	mMapProfile;


public:
	bool Init();

	bool CreateProfile(ECollision_Profile type, 
					   ECollision_Channel channel, bool enable,
					   ECollision_Interaction baseIteraction = ECollision_Interaction::Collision);
	CollisionProfile* FindProfile(ECollision_Profile type);


private:
	bool SetInteraction(ECollision_Profile type,
						ECollision_Channel channel,
						ECollision_Interaction interaction);

public:
	bool CollisionBoxToBox(class CColliderBox* src, class CColliderBox* dest);
	bool CollisionBoxToBox(Vector2& hitPoint, const BoxInfo& src, const BoxInfo& dest);

	bool CollisionCircleToCircle(class CColliderCircle* src, class CColliderCircle* dest);
	bool CollisionCircleToCircle(Vector2& hitPoint, const CircleInfo& src, const CircleInfo& dest);
	
	bool CollisionBoxToCircle(class CColliderBox* box, class CColliderCircle* circle);
	bool CollisionBoxToCircle(Vector2& hitPoint, const BoxInfo& box, const CircleInfo& circle);

	bool CollisionLineToLine(class CColliderLine* src, class CColliderLine* dest);
	bool CollisionLineToLine(Vector2& hitPoint, const LineInfo& src, const LineInfo& dest);

	bool CollisionLineToBox(class CColliderLine* line, class CColliderBox* box);
	bool CollisionLineToBox(Vector2& hitPoint, const LineInfo& line, const BoxInfo& box);

	bool CollisionLineToCircle(class CColliderLine* line, class CColliderCircle* circle);
	bool CollisionLineToCircle(Vector2& hitPoint, const LineInfo& line, const CircleInfo& circle);


	bool CollisionPointToBox(const Vector2& src, class CColliderBox* dest);
	bool CollisionPointToBox(Vector2& hitPoint, const Vector2& src, const BoxInfo& dest);

	bool CollisionPointToCircle(const Vector2& src, class CColliderCircle* dest);
	bool CollisionPointToCircle(Vector2& hitPoint, const Vector2& src, const CircleInfo& dest);

private:
	byte ComputeOutcode(const Vector2& point, const BoxInfo& box);
};

