
#include "ColliderLine.h"
#include "../GameObject/GameObject.h"
#include "../GameManager.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "CollisionManager.h"
#include "ColliderCircle.h"
#include "ColliderBox.h"

CColliderLine::CColliderLine() {
	SetTypeID<CColliderLine>();

	mColliderType = ECollider_Type::Line;
}

CColliderLine::CColliderLine(const CColliderLine& collider) :
	CCollider(collider),
	mInfo(collider.mInfo) {
}

CColliderLine::~CColliderLine() {
}

bool CColliderLine::Init() {
	if (!CCollider::Init())
		return false;

	return true;
}

void CColliderLine::Update(float deltaTime) {
	CCollider::Update(deltaTime);

	Vector2 pos = mOwner->GetPos();

	// p1�� x���� p2�� x������ �۴�.
	mInfo.p1 = pos + mOffset - mHalfDisplacePoint;
	mInfo.p2 = pos + mOffset + mHalfDisplacePoint;

	mBottom = mInfo.p2.y > mInfo.p1.y ? mInfo.p2.y : mInfo.p1.y;
}

void CColliderLine::PostUpdate(float deltaTime) {
	CCollider::PostUpdate(deltaTime);
}

void CColliderLine::Render(HDC hdc, float deltaTime) {
#ifdef _DEBUG
	if (gDebugMode) {

		HPEN pen = CGameManager::GetInst()->GetPen(EBrush_Type::Green);
		if (!mListCollision.empty() || mMouseCollision)
			pen = CGameManager::GetInst()->GetPen(EBrush_Type::Red);

		HPEN prevPen = (HPEN)SelectObject(hdc, pen);

		Vector2 camPos = mScene->GetCamera()->GetPos();
		MoveToEx(hdc, (long)(mInfo.p1.x - camPos.x), (long)(mInfo.p1.y - camPos.y), nullptr);
		LineTo(hdc, (long)(mInfo.p2.x - camPos.x), (long)(mInfo.p2.y - camPos.y));

		SelectObject(hdc, prevPen);


		SetBkMode(hdc, TRANSPARENT);
		char str[64]{};

		int x = (int)((mInfo.p1.x + mInfo.p2.x) * .5f);
		int y = (int)((mInfo.p1.y + mInfo.p2.y) * .5f);
		sprintf_s(str, " x : %d, y : %d", x, y);
		x = (int)(x - camPos.x);
		y = (int)(y - camPos.y);
		SetTextColor(hdc, 0x00000000);
		TextOutA(hdc, x + 1, y, str, (int)strlen(str));
		TextOutA(hdc, x - 1, y, str, (int)strlen(str));
		TextOutA(hdc, x, y + 1, str, (int)strlen(str));
		TextOutA(hdc, x, y - 1, str, (int)strlen(str));
		SetTextColor(hdc, 0x00ffffff);
		TextOutA(hdc, x, y, str, (int)strlen(str));
	}
#endif // _DEBUG
}

bool CColliderLine::Collision(CCollider* dest) {
	switch (dest->GetColliderType()) {
		case ECollider_Type::Box:
			return CCollisionManager::GetInst()->CollisionLineToBox(this, (CColliderBox*)dest);
			break;
		case ECollider_Type::Circle:
			return CCollisionManager::GetInst()->CollisionLineToCircle(this, (CColliderCircle*)dest);
			break;
		case ECollider_Type::Line:
			return CCollisionManager::GetInst()->CollisionLineToLine(this, (CColliderLine*)dest);
			break;
	}

	return false;
}
