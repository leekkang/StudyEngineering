#pragma once

#include "Collider.h"

class CColliderCircle : public CCollider {
	friend class CGameObject;

protected:
	CColliderCircle();
	CColliderCircle(const CColliderCircle& collider);
	virtual ~CColliderCircle();

protected:
	CircleInfo mInfo;

public:
	CircleInfo GetInfo() const {
		return mInfo;
	}
	float GetRadius() const {
		return mInfo.radius;
	}

	void SetRadius(float radius) {
		mInfo.radius = radius;
	}

	virtual float GetBottomY(float x) const {
		float xDist = fabs(x - mInfo.center.x);
		if (mInfo.radius < xDist)
			return 0.f;

		return mInfo.center.y + sqrtf((mInfo.radius * mInfo.radius) - xDist * xDist);
	}
	virtual float GetTopY(float x) const {
		float xDist = fabs(x - mInfo.center.x);
		if (mInfo.radius < xDist)
			return 0.f;

		return mInfo.center.y - sqrtf((mInfo.radius * mInfo.radius) - xDist * xDist);
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual bool Collision(CCollider* dest);
	virtual bool CollisionMouse(const Vector2& mouse);
};