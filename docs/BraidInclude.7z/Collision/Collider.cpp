
#include "Collider.h"
#include "CollisionManager.h"

CCollider::CCollider() {
}

CCollider::CCollider(const CCollider& col) :
	CRef(col),
	mScene(nullptr),
	mOwner(nullptr),
	mColliderType(col.mColliderType),
	mProfile(col.mProfile),
	mOffset(col.mOffset)
{
}

CCollider::~CCollider() {
	auto	iter = mListCollision.begin();
	auto	iterEnd = mListCollision.end();

	for (; iter != iterEnd; ++iter) {
		(*iter)->DeleteCollisionList(this);
	}
}


void CCollider::SetCollisionProfile(ECollision_Profile type) {
	mProfile = CCollisionManager::GetInst()->FindProfile(type);
}

void CCollider::AddCollisionList(CCollider* collider) {
	mListCollision.push_back(collider);
}

bool CCollider::CheckCollisionList(CCollider* collider) {
	auto	iter = mListCollision.begin();
	auto	iterEnd = mListCollision.end();

	for (; iter != iterEnd; ++iter) {
		if (*iter == collider)
			return true;
	}

	return false;
}

void CCollider::DeleteCollisionList(CCollider* collider) {
	auto	iter = mListCollision.begin();
	auto	iterEnd = mListCollision.end();

	for (; iter != iterEnd; ++iter) {
		if (*iter == collider) {
			mListCollision.erase(iter);
			return;
		}
	}
}

void CCollider::ClearCollisionList() {
	auto	iter = mListCollision.begin();
	auto	iterEnd = mListCollision.end();

	// �� �ݶ��̴��� �浹�� ��� �ݶ��̴��� �浹 ����Ʈ���� ���� �ݶ��̴��� ����
	for (; iter != iterEnd; ++iter) {
		(*iter)->DeleteCollisionList(this);
	}

	// ���� �ݶ��̴��� �浹 ����Ʈ ����
	mListCollision.clear();
}



void CCollider::CallCollisionBegin(CCollider* dest) {
	if (mCollisionBegin)
		mCollisionBegin(this, dest);
}
void CCollider::CallCollisionEnd(CCollider* dest) {
	if (mCollisionEnd)
		mCollisionEnd(this, dest);
}

void CCollider::CallMouseCollisionBegin(const Vector2& mousePos) {
	if (mMouseCollisionBegin)
		mMouseCollisionBegin(this, mousePos);
}

void CCollider::CallMouseCollisionEnd(const Vector2& mousePos) {
	if (mMouseCollisionEnd)
		mMouseCollisionEnd(this, mousePos);
}


bool CCollider::Init() {
	mProfile = CCollisionManager::GetInst()->FindProfile(ECollision_Profile::Default);

	return true;
}

void CCollider::Update(float deltaTime) {
}

void CCollider::PostUpdate(float deltaTime) {
}

void CCollider::Render(HDC hdc, float deltaTime) {
}

bool CCollider::CollisionMouse(const Vector2& mouse) {
	return false;
}

void CCollider::Save(FILE* file) {
}

void CCollider::Load(FILE* file) {
}
