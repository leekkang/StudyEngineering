
#include "Animation.h"
#include "../Resource/Animation/AnimationSequence.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"
#include "../Resource/ResourceManager.h"
#include "../GameObject/GameObject.h"
#include "../GameObject/MovableObject.h"

CAnimation::CAnimation() {
}

CAnimation::~CAnimation() {
	auto	iter = mMapAnimation.begin();
	auto	iterEnd = mMapAnimation.end();

	for (; iter != iterEnd; ++iter) {
		SAFE_DELETE(iter->second);
	}
}

const CAnimationSequence* CAnimation::GetCurrentSequence() const {
	return mCurrentAnimation->mSequence;
}
const AnimationFrameData& CAnimation::GetCurrentFrameData() const {
	return mCurrentAnimation->mSequence->GetFrame(mCurrentAnimation->mFrame);
}


void CAnimation::SetCurrentReverse(bool reverse) {
	mCurrentAnimation->mReverse = reverse;

	if (mCurrentAnimation->mCurInterval == 0.f &&
		mCurrentAnimation->mFrame == mCurrentAnimation->mLoopStartFrame) {
		mCurrentAnimation->mCurInterval = mCurrentAnimation->mFrameInterval;
		mCurrentAnimation->mFrame = mCurrentAnimation->mSequence->GetFrameCount() - 1;
	}
}

void CAnimation::Update(float deltaTime) {
	float scale = mCurrentAnimation->mReverse ? -mCurrentAnimation->mPlayScale : mCurrentAnimation->mPlayScale;

	if (mCurrentAnimation->mIntervalType == EAnimation_Interval::XPos)
		mCurrentAnimation->mCurInterval += fabs(((CMovableObject*)mOwner)->GetMove().x) * scale;
	else if (mCurrentAnimation->mIntervalType == EAnimation_Interval::YPos)
		mCurrentAnimation->mCurInterval += fabs(((CMovableObject*)mOwner)->GetMove().y) * scale;
	else if (mCurrentAnimation->mIntervalType == EAnimation_Interval::Time)
		mCurrentAnimation->mCurInterval += deltaTime * scale;

	bool animationEnd = false;
	if (mCurrentAnimation->mReverse) {
		if (mCurrentAnimation->mCurInterval <= 0.f) {
			mCurrentAnimation->mCurInterval += mCurrentAnimation->mFrameInterval;

			--mCurrentAnimation->mFrame;
			// ������ �� mLoopStartFrame �Ʒ��� �������� ������� �ʴ´�.
			if (mCurrentAnimation->mFrame == mCurrentAnimation->mLoopStartFrame - 1)
				animationEnd = true;
		}
	} else {
		if (mCurrentAnimation->mCurInterval >= mCurrentAnimation->mFrameInterval) {
			mCurrentAnimation->mCurInterval -= mCurrentAnimation->mFrameInterval;

			++mCurrentAnimation->mFrame;
			if (mCurrentAnimation->mFrame == mCurrentAnimation->mSequence->GetFrameCount())
				animationEnd = true;
		}
	}

	size_t	size = mCurrentAnimation->mVecNotify.size();
	for (size_t i = 0; i < size; ++i) {
		// ���� ����� ��Ƽ���̰� ȣ���� �ȵǾ��� �����ӿ� �����ߴٸ� ȣ���Ѵ�.
		if (!mCurrentAnimation->mVecNotify[i]->call &&
			mCurrentAnimation->mVecNotify[i]->frame == mCurrentAnimation->mFrame) {
			mCurrentAnimation->mVecNotify[i]->call = true;
			mCurrentAnimation->mVecNotify[i]->function();
		}
	}

	if (animationEnd) {
		if (mCurrentAnimationEndFunc)
			mCurrentAnimationEndFunc();

		if (mCurrentAnimation->mReverse)
			mCurrentAnimation->mFrame = mCurrentAnimation->mLoop ? 
				mCurrentAnimation->mSequence->GetFrameCount() - 1 :
				mCurrentAnimation->mLoopStartFrame;
		else
			mCurrentAnimation->mFrame = mCurrentAnimation->mLoop ?
				mCurrentAnimation->mLoopStartFrame :
				mCurrentAnimation->mSequence->GetFrameCount() - 1;

		// End Function ȣ��
		if (mCurrentAnimation->mEndFunction)
			mCurrentAnimation->mEndFunction();

		for (size_t i = 0; i < size; ++i) {
			mCurrentAnimation->mVecNotify[i]->call = false;
		}
	}
}

void CAnimation::AddAnimationInfo(const std::string& sequenceName, float playInterval,
								  bool loop, float playScale, bool reverse) {
	AddAnimationInfo(sequenceName, sequenceName, playInterval, loop, playScale, reverse);
}
void CAnimation::AddAnimationInfo(const std::string& infoName, const std::string& sequenceName, 
								  float playInterval, bool loop, float playScale, bool reverse) {
	if (FindInfo(infoName))
		return;

	CAnimationSequence* sequence = nullptr;

	if (mScene)
		sequence = mScene->GetResource()->FindAnimationSeq(sequenceName);
	else
		sequence = CResourceManager::GetInst()->FindAnimationSeq(sequenceName);

	if (!sequence)
		return;

	CAnimationInfo* info = new CAnimationInfo;
	info->mSequence = sequence;
	info->mLoop = loop;
	info->mPlayInterval = playInterval;
	info->mPlayScale = playScale;
	info->mReverse = reverse;
	info->mFrameInterval = info->mPlayInterval / sequence->GetFrameCount();

	// ó�� �߰��Ǵ� �ִϸ��̼��� ��� ���� ��� �ִϸ��̼����� �⺻ �������ش�.
	if (mMapAnimation.empty())
		mCurrentAnimation = info;

	mMapAnimation.insert(std::make_pair(infoName, info));
}

void CAnimation::SetIntervalType(const std::string& infoName, EAnimation_Interval type) {
	CAnimationInfo* info = FindInfo(infoName);
	if (!info)
		return;
	info->mIntervalType = type;
}

void CAnimation::SetLoopStartFrame(const std::string& infoName, int startFrame) {
	CAnimationInfo* info = FindInfo(infoName);
	if (!info)
		return;
	info->mLoopStartFrame = startFrame;
}

void CAnimation::SetPlayInterval(const std::string& infoName, float playInterval) {
	CAnimationInfo* info = FindInfo(infoName);
	if (!info)
		return;
	info->mPlayInterval = playInterval;
}

void CAnimation::SetPlayScale(const std::string& infoName, float playScale) {
	CAnimationInfo* info = FindInfo(infoName);
	if (!info)
		return;
	info->mPlayScale = playScale;
}

void CAnimation::SetPlayLoop(const std::string& infoName, bool loop) {
	CAnimationInfo* info = FindInfo(infoName);
	if (!info)
		return;
	info->mLoop = loop;
}

void CAnimation::SetPlayReverse(const std::string& infoName, bool reverse) {
	CAnimationInfo* info = FindInfo(infoName);
	if (!info)
		return;
	info->mReverse = reverse;
}

void CAnimation::SetCurrentAnimation(const std::string& infoName) {
	CAnimationInfo* info = FindInfo(infoName);
	if (!info)
		return;

	info->Reset();
	mCurrentAnimation = info;
}

void CAnimation::ChangeAnimation(const std::string& infoName, bool succeed) {
	CAnimationInfo* info = mMapAnimation[infoName];
	if (mCurrentAnimation == info)
		return;
	if (!info)
		return;

	if (succeed) {
		info->Copy(mCurrentAnimation);
		mCurrentAnimation->Reset();
	} else {
		info->Reset();
		// ������ �����ϴ� �ִϸ��̼��� �ʱ�ȭ�Ѵ�.
		mCurrentAnimation->Reset();
	}

	mCurrentAnimation = info;
}
