#pragma once

#include "AnimationInfo.h"

class CAnimation {
	friend class CGameObject;

private:
	CAnimation();
	~CAnimation();

private:
	class CScene*		mScene			  = nullptr;
	class CGameObject*  mOwner			  = nullptr;
	CAnimationInfo*		mCurrentAnimation = nullptr;

	std::unordered_map<std::string, CAnimationInfo*> mMapAnimation;


public:
	const class CAnimationSequence* GetCurrentSequence() const;
	const		AnimationFrameData& GetCurrentFrameData() const;

	EAnimation_Interval GetCurrentIntervalType() {
		return mCurrentAnimation->mIntervalType;
	}

	CAnimationInfo* GetCurrentAnimationInfo() const {
		return mCurrentAnimation;
	}
	bool GetCurrentAnimationEnd() const {
		return mCurrentAnimation->mAnimationEnd;
	}
	float GetCurrentInterval() const {
		return mCurrentAnimation->mCurInterval;
	}
	int GetCurrentFrameNumber() const {
		return mCurrentAnimation->mFrame;
	}

	void SetCurrentAnimationInfo(CAnimationInfo* info) {
		mCurrentAnimation = info;
	}
	void SetCurrentFrameNumber(int frameNum) {
		mCurrentAnimation->mFrame = frameNum;
	}

	void SetCurrentReverse(bool reverse);

	void AddAnimationInterval(float val) {
		mCurrentAnimation->mCurInterval += mCurrentAnimation->mReverse ?
			-val * mCurrentAnimation->mPlayScale :
			val * mCurrentAnimation->mPlayScale;
	}

	bool CheckCurrentAnimation(const std::string& infoName) {
		return mCurrentAnimation == mMapAnimation[infoName];
	}

public:
	void Update(float deltaTime);
	void AddAnimationInfo(const std::string& sequenceName, 
						  float playInterval = 1.f, bool loop = true,  float playScale = 1.f, bool reverse = false);
	void AddAnimationInfo(const std::string& infoName, const std::string& sequenceName, 
						  float playInterval = 1.f, bool loop = true, float playScale = 1.f, bool reverse = false);

public:
	void SetIntervalType(const std::string& infoName, EAnimation_Interval type);
	void SetLoopStartFrame(const std::string& infoName, int startFrame);

	void SetPlayInterval(const std::string& infoName, float playInterval);
	void SetPlayScale(const std::string& infoName, float playScale);
	void SetPlayLoop(const std::string& infoName, bool loop);
	void SetPlayReverse(const std::string& infoName, bool reverse);
	void SetCurrentAnimation(const std::string& infoName);

	void ChangeAnimation(const std::string& infoName, bool succeed = false);


private:
	CAnimationInfo* FindInfo(const std::string& infoName) {
		auto iter = mMapAnimation.find(infoName);
		if (iter == mMapAnimation.end())
			return nullptr;

		return iter->second;
	}

public:
	template <typename T>
	void SetAnimationEndFunction(const std::string& infoName, T* obj, void(T::* func)()) {
		CAnimationInfo* Info = FindInfo(infoName);
		if (!Info)
			return;

		Info->SetAnimationEndFunction<T>(obj, func);
	}

	template <typename T>
	void AddNotify(const std::string& infoName, int frame, T* obj, void(T::* func)()) {
		CAnimationInfo* Info = FindInfo(infoName);
		if (!Info)
			return;

		Info->AddNotify<T>(frame, obj, func);
	}

};

