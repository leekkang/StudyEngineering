

#include "AnimationInfo.h"
#include "../Resource/Animation/AnimationSequence.h"


CAnimationInfo::CAnimationInfo() {
}

CAnimationInfo::~CAnimationInfo() {
	size_t	size = mVecNotify.size();
	for (size_t i = 0; i < size; ++i) {
		SAFE_DELETE(mVecNotify[i]);
	}
}

CTexture* CAnimationInfo::GetTexture() const {
	return mSequence->GetTexture();
}

void CAnimationInfo::Reset() {
	mFrame = 0;
	mCurInterval = 0.f;

	size_t	size = mVecNotify.size();
	for (size_t i = 0; i < size; ++i) {
		mVecNotify[i]->call = false;
	}
}

void CAnimationInfo::Copy(CAnimationInfo* info) {
	mFrame = mSequence->GetFrameCount() == info->mSequence->GetFrameCount() ? info->mFrame : 0;
	mCurInterval = mFrameInterval == info->mFrameInterval ? info->mCurInterval : 0.f;

	size_t	size = mVecNotify.size();
	size_t	size2 = info->mVecNotify.size();
	if (size == size2) {
		for (size_t i = 0; i < size; ++i) {
			mVecNotify[i]->call = info->mVecNotify[i]->call;
		}
	} else {
		for (size_t i = 0; i < size; ++i) {
			mVecNotify[i]->call = false;
		}
	}
}
