
#include "ProgressBar.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"

#include "../WidgetWindow/WidgetWindow.h"

CProgressBar::CProgressBar() {
	SetTypeID<CProgressBar>();
}

CProgressBar::CProgressBar(const CProgressBar& widget) :
	CWidget(widget) {
}

CProgressBar::~CProgressBar() {
}


bool CProgressBar::Init() {
	return true;
}

void CProgressBar::Update(float deltaTime) {
	mBarSize = mSize;
	mBarPos = mPos;

	switch (mDir) {
		case EProgressBar_Dir::LeftToRight:
			mBarSize.x = mValue * mSize.x;
			break;
		case EProgressBar_Dir::RightToLeft:
			mBarSize.x = mValue * mSize.x;
			mBarPos.x = mPos.x + (1.f - mValue) * mSize.x;
			break;
		case EProgressBar_Dir::BottomToTop:
			mBarSize.y = mValue * mSize.y;
			mBarPos.y = mPos.y + (1.f - mValue) * mSize.y;
			break;
		case EProgressBar_Dir::TopToBottom:
			mBarSize.y = mValue * mSize.y;
			break;
	}
}

void CProgressBar::PostUpdate(float deltaTime) {
}

void CProgressBar::Render(HDC hdc, float deltaTime) {
	Render(hdc, mBarPos + mOwner->GetPos(), deltaTime);
}

void CProgressBar::SetBarTexture(const std::string& name, const TCHAR* fileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, fileName, pathName);
	mBarTexture = mScene->GetResource()->FindTexture(name);
}
void CProgressBar::SetBarTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, fullPath);
	mBarTexture = mScene->GetResource()->FindTexture(name);
}

void CProgressBar::SetBarTexture(const std::string& name,
								 const std::vector<const TCHAR*>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mBarTexture = mScene->GetResource()->FindTexture(name);
}
void CProgressBar::SetBarTextureFullPath(const std::string& name, const std::vector<const TCHAR*>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mBarTexture = mScene->GetResource()->FindTexture(name);
}

//#ifdef UNICODE
//
//void CProgressBar::SetBarTexture(const std::string& name, 
//								 const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
//	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
//	mBarTexture = mScene->GetResource()->FindTexture(name);
//}
//void CProgressBar::SetBarTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath) {
//	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
//	mBarTexture = mScene->GetResource()->FindTexture(name);
//}
//
//#else
//
//void CProgressBar::SetBarTexture(const std::string& name, 
//							  const std::vector<std::string>& vecFileName, const std::string& pathName) {
//	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
//	mBarTexture = mScene->GetResource()->FindTexture(name);
//}
//void CProgressBar::SetBarTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath) {
//	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
//	mBarTexture = mScene->GetResource()->FindTexture(name);
//}
//
//#endif // UNICODE


void CProgressBar::SetBarColorKey(unsigned char r, unsigned char g, unsigned char b) {
	if (mBarTexture)
		mBarTexture->SetColorKey(r, g, b);
}

