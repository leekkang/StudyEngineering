
#include "ProgressBar.h"
#include "WidgetWindow.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"

CProgressBar::CProgressBar() {
	SetTypeID<CProgressBar>();
}

CProgressBar::CProgressBar(const CProgressBar& widget) :
	CWidget(widget) {
}

CProgressBar::~CProgressBar() {
}


bool CProgressBar::Init() {
	return true;
}

void CProgressBar::Update(float deltaTime) {
	mBarSize = mSize;
	mBarPos = mPos;

	switch (mDir) {
		case EProgressBar_Dir::LeftToRight:
			mBarSize.x = mValue * mSize.x;
			break;
		case EProgressBar_Dir::RightToLeft:
			mBarSize.x = mValue * mSize.x;
			mBarPos.x = mPos.x + (1.f - mValue) * mSize.x;
			break;
		case EProgressBar_Dir::BottomToTop:
			mBarSize.y = mValue * mSize.y;
			mBarPos.y = mPos.y + (1.f - mValue) * mSize.y;
			break;
		case EProgressBar_Dir::TopToBottom:
			mBarSize.y = mValue * mSize.y;
			break;
	}
}

void CProgressBar::PostUpdate(float deltaTime) {
}

void CProgressBar::Render(HDC hdc, float deltaTime) {
	Render(hdc, mBarPos + mOwner->GetPos(), deltaTime);
}
void CProgressBar::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	for (int i = 0; i < (int)EProgressBar_Texture_Type::End; ++i) {
		if (mTexture[i]) {
			RenderTexture(hdc, mTexture[i], pos, mBarSize);
		}
	}
}


void CProgressBar::SetTexture(EProgressBar_Texture_Type type, const std::string& name, 
							  const TCHAR* fileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, fileName, pathName);
	mTexture[(int)type] = mScene->GetResource()->FindTexture(name);
}
void CProgressBar::SetTextureFullPath(EProgressBar_Texture_Type type, const std::string& name, const TCHAR* fullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, fullPath);
	mTexture[(int)type] = mScene->GetResource()->FindTexture(name);
}

#ifdef UNICODE

void CProgressBar::SetTexture(EProgressBar_Texture_Type type, const std::string& name, 
							  const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture[(int)type] = mScene->GetResource()->FindTexture(name);
}
void CProgressBar::SetTextureFullPath(EProgressBar_Texture_Type type, const std::string& name, const std::vector<std::wstring>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture[(int)type] = mScene->GetResource()->FindTexture(name);
}

#else

void CProgressBar::SetTexture(EProgressBar_Texture_Type type, const std::string& name, 
							  const std::vector<std::string>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture[(int)type] = mScene->GetResource()->FindTexture(name);
}
void CProgressBar::SetTextureFullPath(EProgressBar_Texture_Type type, const std::string& name, 
									  const std::vector<std::string>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture[(int)type] = mScene->GetResource()->FindTexture(name);
}

#endif // UNICODE

void CProgressBar::SetColorKey(EProgressBar_Texture_Type type, unsigned char r, unsigned char g, unsigned char b) {
	if (mTexture[(int)type])
		mTexture[(int)type]->SetColorKey(r, g, b);
}

