
#include "Number.h"
#include "WidgetWindow.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"

CNumber::CNumber() {
}

CNumber::CNumber(const CNumber& widget) :
	CWidget(widget) {
}

CNumber::~CNumber() {
}


bool CNumber::Init() {
	return true;
}

void CNumber::Update(float deltaTime) {
	if (mNumber == 0) {
		mVecNumber.clear();
		mVecNumber.push_back(0);
		return;
	}

	int num = mNumber;
	std::stack<int> numberStack;

	while (num > 0) {
		numberStack.push(num % 10);
		num /= 10;
	}

	mVecNumber.clear();

	while (!numberStack.empty()) {
		mVecNumber.push_back(numberStack.top());
		numberStack.pop();
	}
}

void CNumber::PostUpdate(float deltaTime) {
}

void CNumber::Render(HDC hdc, float deltaTime) {
	if (mVecNumber.empty())
		return;
	if (!mTexture)
		return;
	
	Render(hdc, mPos + mOwner->GetPos(), deltaTime);
}

void CNumber::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	size_t size = mVecNumber.size();
	for (size_t i = 0; i < size; ++i) {
		if (mTexture->GetTextureType() == ETexture_Type::Sprite) {
			RenderTexture(hdc, mTexture, {pos.x + i * mSize.x, pos.y}, mSize, (int)(mVecNumber[i] * mSize.x));
		} else {
			RenderTexture(hdc, mTexture, {pos.x + i * mSize.x, pos.y}, mSize, 0, 0, mVecNumber[i]);
		}
	}
}



void CNumber::SetTexture(const std::string& name, const TCHAR* fileName,
							  const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, fileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}
void CNumber::SetTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, fullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

#ifdef UNICODE

void CNumber::SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}
void CNumber::SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

#else

void CNumber::SetTexture(const std::string& name, const std::vector<std::string>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}
void CNumber::SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

#endif // UNICODE

void CNumber::SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index) {
	if (mTexture)
		mTexture->SetColorKey(r, g, b, index);
}
void CNumber::SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b) {
	if (mTexture)
		mTexture->SetColorKeyAll(r, g, b);
}
