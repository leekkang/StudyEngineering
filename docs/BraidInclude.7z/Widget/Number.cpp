
#include "Number.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"

#include "../WidgetWindow/WidgetWindow.h"

CNumber::CNumber() {
	SetTypeID<CNumber>();
}

CNumber::CNumber(const CNumber& widget) :
	CWidget(widget) {
}

CNumber::~CNumber() {
}


bool CNumber::Init() {
	return true;
}

void CNumber::Update(float deltaTime) {
	if (mNumber == 0) {
		mVecNumber.clear();
		mVecNumber.push_back(0);
		return;
	}

	int num = mNumber;
	std::stack<int> numberStack;

	while (num > 0) {
		numberStack.push(num % 10);
		num /= 10;
	}

	mVecNumber.clear();

	while (!numberStack.empty()) {
		mVecNumber.push_back(numberStack.top());
		numberStack.pop();
	}
}

void CNumber::PostUpdate(float deltaTime) {
}

void CNumber::Render(HDC hdc, float deltaTime) {
	if (mVecNumber.empty())
		return;
	if (!mTexture)
		return;
	
	Render(hdc, mPos + mOwner->GetPos(), deltaTime);
}

void CNumber::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	size_t	size = mVecNumber.size();
	for (size_t i = 0; i < size; ++i) {
		if (mTexture->GetTextureType() == ETexture_Type::Sprite) {
			RenderTexture(hdc, mTexture, {pos.x + i * mSize.x, pos.y}, mSize, (int)(mVecNumber[i] * mSize.x));
		} else {
			RenderTexture(hdc, mTexture, {pos.x + i * mSize.x, pos.y}, mSize, 0, 0, mVecNumber[i]);
		}
	}
}