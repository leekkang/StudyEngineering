#pragma once

#include "Widget.h"

class CText : public CWidget {
	friend class CWidgetWindow;
	friend class CWidgetComponent;

protected:
	CText();
	CText(const CText& obj);
	virtual ~CText();

protected:
	TCHAR* mText = nullptr;
	CSharedPtr<class CFont> mFont;

	int mCount	  = 0;
	int mCapacity = 32;
	COLORREF mTextColor   = RGB(0, 0, 0);
	COLORREF mShadowColor = RGB(30, 30, 30);

	bool mShadow  = false;
	Vector2 mShadowOffset{1.f, 1.f};


public:
	void SetTextColor(unsigned char r, unsigned char g, unsigned char b) {
		mTextColor = RGB(r, g, b);
	}
	void SetTextShadowColor(unsigned char r, unsigned char g, unsigned char b) {
		mShadowColor = RGB(r, g, b);
	}

	void EnableShadow(bool shadow) {
		mShadow = shadow;
	}

	void SetShadowOffset(float x, float y) {
		mShadowOffset.x = x;
		mShadowOffset.y = y;
	}

	void SetText(const TCHAR* text) {
		int len = lstrlen(text);

		if (len + 1 > mCapacity) {
			mCapacity = len + 1;
			SAFE_DELETE_ARRAY(mText);

			mText = new TCHAR[mCapacity]{};
			//memset(mText, 0, sizeof(TCHAR) * mCapacity);
		}

		lstrcpy(mText, text);
		mCount = lstrlen(mText);
	}

	void AddText(const TCHAR text) {
		int len = mCount + 1;

		if (len + 1 > mCapacity) {
			mCapacity = len + 1;
			TCHAR* newText = new TCHAR[mCapacity]{};
			//memset(newText, 0, sizeof(TCHAR) * mCapacity);

			lstrcpy(newText, mText);
			SAFE_DELETE_ARRAY(mText);
			mText = newText;
		}

		mText[mCount] = text;
		++mCount;
	}

	void AddText(const TCHAR* text) {
		int len = mCount + lstrlen(text);

		if (len + 1 > mCapacity) {
			mCapacity = len + 1;
			TCHAR* newText = new TCHAR[mCapacity]{};
			//memset(newText, 0, sizeof(TCHAR) * mCapacity);

			lstrcpy(newText, mText);
			SAFE_DELETE_ARRAY(mText);
			mText = newText;
		}

		lstrcat(mText, text);
		mCount += lstrlen(text);
	}

	void pop_back() {
		--mCount;
		mText[mCount] = 0;
	}

	void clear() {
		mCount = 0;
		mText[mCount] = 0;
	}

	void SetFont(const std::string& name);

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);
};