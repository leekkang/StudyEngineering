 #pragma once

#include "../Ref.h"
#include "../Resource/Texture/Texture.h"

class CWidget : public CRef {
	friend class CWidgetWindow;
	friend class CWidgetComponent;

protected:
	CWidget();
	CWidget(const CWidget& obj);
	virtual ~CWidget();

protected:
	class CScene*		 mScene = nullptr;
	class CWidgetWindow* mOwner = nullptr;

	int  mZOrder	   = 0;
	bool mMouseHovered = false;

	Vector2 mPos;
	Vector2 mSize;

	CSharedPtr<CTexture> mTexture;

public:
	int GetZOrder() const {
		return mZOrder;
	}
	class CTexture* GetTexture() const {
		return mTexture;
	}

	const Vector2& GetPos()	const {
		return mPos;
	}
	const Vector2& GetSize()	const {
		return mSize;
	}

public:
	void SetZOrder(int order) {
		mZOrder = order;
	}

	void SetPos(float x, float y) {
		mPos.x = x;
		mPos.y = y;
	}
	void SetPos(const Vector2& pos) {
		mPos = pos;
	}

	void SetSize(float x, float y) {
		mSize.x = x;
		mSize.y = y;
	}
	void SetSize(const Vector2& size) {
		mSize = size;
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);
	virtual void Render(HDC hdc, const Vector2& pos, float deltaTime, int imageIndex);

protected:
	void RenderTexture(HDC hdc, const CTexture* texture, const Vector2& pos, const Vector2& size,
					   int imageX = 0, int imageY = 0, int imageIndex = 0) {
		if (texture->GetEnableColorKey(imageIndex)) {
			TransparentBlt(hdc, (int)pos.x, (int)pos.y, (int)size.x, (int)size.y,
						   texture->GetDC(imageIndex), imageX, imageY, (int)size.x, (int)size.y,
						   texture->GetColorKey(imageIndex));
		} else {
			BitBlt(hdc, (int)pos.x, (int)pos.y, (int)size.x, (int)size.y,
				   texture->GetDC(imageIndex), imageX, imageY, SRCCOPY);
		}
	}
	void RenderAlphaTexture(HDC hdc, const CTexture* texture, int alphaValue, const Vector2& pos, const Vector2& size,
							int imageX = 0, int imageY = 0, int imageIndex = 0) {
		BLENDFUNCTION bf;
		memset(&bf, 0, sizeof BLENDFUNCTION);
		bf.SourceConstantAlpha = alphaValue;
		if (texture->GetEnableColorKey(imageIndex)) {
			HDC alphaDC = texture->GetAlphaDC(imageIndex);
			BitBlt(alphaDC, 0, 0, (int)mSize.x, (int)mSize.y, hdc, (int)pos.x, (int)pos.y, SRCCOPY);
			TransparentBlt(alphaDC, 0, 0, (int)mSize.x, (int)mSize.y, 
						   texture->GetDC(imageIndex), 0, 0, (int)mSize.x, (int)mSize.y, 
						   texture->GetColorKey(imageIndex));

			AlphaBlend(hdc, (int)pos.x, (int)pos.y, (int)mSize.x, (int)mSize.y,
					   alphaDC, 0, 0, (int)mSize.x, (int)mSize.y, bf);
		} else {
			AlphaBlend(hdc, (int)pos.x, (int)pos.y, (int)mSize.x, (int)mSize.y,
					   texture->GetDC(imageIndex), 0, 0, (int)mSize.x, (int)mSize.y, bf);
		}
	}

public:
	bool CollisionMouse(const Vector2& pos);

public:
	virtual void CollisionMouseHoveredCallback(const Vector2& pos);
	virtual void CollisionMouseReleaseCallback();


public:
	void SetTexture(const std::string& name, const TCHAR* fileName, const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const TCHAR* fullPath);
	void SetTexture(const std::string& name, const std::vector<const TCHAR*>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const std::vector<const TCHAR*>& vecFullPath);


//#ifdef UNICODE
//
//	void SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName,
//					const std::string& pathName = TEXTURE_PATH);
//	void SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath);
//
//#else
//
//	void SetTexture(const std::string& name, const std::vector<std::string>& vecFileName,
//					const std::string& pathName = TEXTURE_PATH);
//	void SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath);
//
//#endif // UNICODE

	void SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index = 0);
	void SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b);
};

