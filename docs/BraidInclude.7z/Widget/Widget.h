 #pragma once

#include "../Ref.h"
#include "../Resource/Texture/Texture.h"

class CWidget : public CRef {
	friend class CWidgetWindow;
	friend class CWidgetComponent;

protected:
	CWidget();
	CWidget(const CWidget& obj);
	virtual ~CWidget();

protected:
	class CScene*		 mScene = nullptr;
	class CWidgetWindow* mOwner = nullptr;

	int  mZOrder	   = 0;
	bool mMouseHovered = false;

	Vector2 mPos;
	Vector2 mSize;

public:
	const Vector2& GetPos()	const {
		return mPos;
	}
	const Vector2& GetSize()	const {
		return mSize;
	}
	int GetZOrder() const {
		return mZOrder;
	}

public:
	void SetPos(float x, float y) {
		mPos.x = x;
		mPos.y = y;
	}
	void SetPos(const Vector2& pos) {
		mPos = pos;
	}

	void SetSize(float x, float y) {
		mSize.x = x;
		mSize.y = y;
	}
	void SetSize(const Vector2& size) {
		mSize = size;
	}

	void SetZOrder(int order) {
		mZOrder = order;
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);

protected:
	void RenderTexture(HDC hdc, const CTexture* texture, const Vector2& pos, const Vector2& size,
					   int imageX = 0, int imageY = 0, int imageIndex = 0) {
		if (texture->GetEnableColorKey(imageIndex)) {
			TransparentBlt(hdc,
						   (int)pos.x, (int)pos.y, (int)size.x, (int)size.y, texture->GetDC(imageIndex),
						   imageX, imageY, (int)size.x, (int)size.y, texture->GetColorKey(imageIndex));
		} else {
			BitBlt(hdc, (int)pos.x, (int)pos.y, (int)size.x, (int)size.y,
				   texture->GetDC(imageIndex), imageX, imageY, SRCCOPY);
		}
	}

public:
	bool CollisionMouse(const Vector2& pos);

public:
	virtual void CollisionMouseHoveredCallback(const Vector2& pos);
	virtual void CollisionMouseReleaseCallback();
};

