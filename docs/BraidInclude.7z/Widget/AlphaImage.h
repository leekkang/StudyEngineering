#pragma once

#include "Widget.h"

class CAlphaImage : public CWidget {
    friend class CWidgetWindow;
    friend class CWidgetComponent;

protected:
    CAlphaImage();
    CAlphaImage(const CAlphaImage& widget);
    virtual ~CAlphaImage();

protected:
    bool mTwinkle     = false;
    UINT8 mRange      = 250;
    float mCycleTime  = 0.f;

    UINT8 mAlphaValue = 0;
    float mAlphaTime  = 0.f;

public:
    void SetTwinkle(bool twinkle) {
        mTwinkle = twinkle;
    }
    void SetAlphaValue(UINT8 twinkle) {
        mTwinkle = twinkle;
    }
    void SetRenderRange(UINT8 range) {
        mRange = range;
    }
    void SetCycleTime(float time) {
        mCycleTime = time;
    }

public:
    virtual bool Init();
    virtual void Update(float deltaTime);
    virtual void PostUpdate(float deltaTime);
    virtual void Render(HDC hdc, float deltaTime);
    virtual void Render(HDC hdc, const Vector2& pos, float deltaTime) {
        Render(hdc, pos, deltaTime, 0);
    }
    virtual void Render(HDC hdc, const Vector2& pos, float deltaTime, int imageIndex);
};