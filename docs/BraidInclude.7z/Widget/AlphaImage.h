#pragma once

#include "Widget.h"

class CAlphaImage : public CWidget {
    friend class CWidgetWindow;
    friend class CWidgetComponent;

protected:
    CAlphaImage();
    CAlphaImage(const CAlphaImage& widget);
    virtual ~CAlphaImage();

protected:
    float mCycleTime  = 0.f;
    float mAlphaTime  = 0.f;
    int   mAlphaValue = 0;

public:
    void SetCycleTime(float time) {
        mCycleTime = time;
    }

public:
    virtual bool Init();
    virtual void Update(float deltaTime);
    virtual void PostUpdate(float deltaTime);
    virtual void Render(HDC hdc, float deltaTime);
    virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);
};