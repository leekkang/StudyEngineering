
#include "DraggedIcon.h"
#include "WidgetWindow.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"
#include "../Resource/Sound/Sound.h"
#include "../Input.h"


CDraggedIcon::CDraggedIcon() {
	SetTypeID<CDraggedIcon>();
}

CDraggedIcon::CDraggedIcon(const CDraggedIcon& obj) :
	CWidget(obj) {
}

CDraggedIcon::~CDraggedIcon() {
}


void CDraggedIcon::StartDragCallback() {
	mMouseOffset = CInput::GetInst()->GetMousePos() - mPos + (5.f, 5.f);
}

void CDraggedIcon::EndDragCallback() {
	mPos = CInput::GetInst()->GetMousePos() - mMouseOffset + (5.f, 5.f);
}


bool CDraggedIcon::Init() {
	return true;
}

void CDraggedIcon::Update(float deltaTime) {
	if (mMouseHovered) {
		// �巡��
		if (CInput::GetInst()->GetMouseLDown()) {
			mIconState = EButton_State::Click;
			if (mStateSound[(int)EButton_Sound_State::Click])
				mStateSound[(int)EButton_Sound_State::Click]->Play();

			if (mCallback[(int)EButton_Sound_State::Click])
				mCallback[(int)EButton_Sound_State::Click]();
		}
		// ������
		else if (mIconState == EButton_State::Click && CInput::GetInst()->GetMouseLUp()) {
			if (mStateSound[(int)EButton_Sound_State::MouseHovered])
				mStateSound[(int)EButton_Sound_State::MouseHovered]->Play();

			if (mCallback[(int)EButton_Sound_State::MouseHovered])
				mCallback[(int)EButton_Sound_State::MouseHovered]();
			mIconState = EButton_State::MouseHovered;
		}

		else if (mIconState == EButton_State::Click && CInput::GetInst()->GetMouseLPush()) {
			mPos = CInput::GetInst()->GetMousePos() - mMouseOffset;
			mIconState = EButton_State::Click;
		}

		else {
			mIconState = EButton_State::MouseHovered;
		}

	} else {
		mIconState = EButton_State::Normal;
	}
}

void CDraggedIcon::PostUpdate(float deltaTime) {
}

void CDraggedIcon::Render(HDC hdc, float deltaTime) {
	Render(hdc, mPos + mOwner->GetPos(), deltaTime);
}
void CDraggedIcon::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	if (mTexture) {
		RenderTexture(hdc, mTexture, pos, mSize);
	} else {
		Rectangle(hdc, (int)pos.x, (int)pos.y,
				  (int)(pos.x + mSize.x), (int)(pos.y + mSize.y));
	}
}


void CDraggedIcon::SetSound(EButton_Sound_State state, const std::string& name) {
	mStateSound[(int)state] = mScene->GetResource()->FindSound(name);
}

void CDraggedIcon::CollisionMouseHoveredCallback(const Vector2& pos) {
	CWidget::CollisionMouseHoveredCallback(pos);
}

void CDraggedIcon::CollisionMouseReleaseCallback() {
	CWidget::CollisionMouseReleaseCallback();
}
