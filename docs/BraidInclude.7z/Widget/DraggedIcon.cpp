
#include "DraggedIcon.h"
#include "WidgetWindow.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"
#include "../Resource/Sound/Sound.h"
#include "../Input.h"


CDraggedIcon::CDraggedIcon() {
	SetTypeID<CDraggedIcon>();
}

CDraggedIcon::CDraggedIcon(const CDraggedIcon& obj) :
	CWidget(obj) {
}

CDraggedIcon::~CDraggedIcon() {
}

void CDraggedIcon::StartDragCallback() {
	mMouseOffset = CInput::GetInst()->GetMousePos() - mPos + (5.f, 5.f);
}

void CDraggedIcon::EndDragCallback() {
	mPos = CInput::GetInst()->GetMousePos() - mMouseOffset + (5.f, 5.f);
}

bool CDraggedIcon::Init() {
	return true;
}

void CDraggedIcon::Update(float deltaTime) {
	if (mMouseHovered) {
		// �巡��
		if (CInput::GetInst()->GetMouseLDown()) {
			mIconState = EButton_State::Click;
			if (mStateSound[(int)EButton_Sound_State::Click])
				mStateSound[(int)EButton_Sound_State::Click]->Play();

			if (mCallback[(int)EButton_Sound_State::Click])
				mCallback[(int)EButton_Sound_State::Click]();
		}
		// ������
		else if (mIconState == EButton_State::Click && CInput::GetInst()->GetMouseLUp()) {
			if (mStateSound[(int)EButton_Sound_State::MouseHovered])
				mStateSound[(int)EButton_Sound_State::MouseHovered]->Play();

			if (mCallback[(int)EButton_Sound_State::MouseHovered])
				mCallback[(int)EButton_Sound_State::MouseHovered]();
			mIconState = EButton_State::MouseHovered;
		}

		else if (mIconState == EButton_State::Click && CInput::GetInst()->GetMouseLPush()) {
			mPos = CInput::GetInst()->GetMousePos() - mMouseOffset;
			mIconState = EButton_State::Click;
		}

		else {
			mIconState = EButton_State::MouseHovered;
		}

	} else {
		mIconState = EButton_State::Normal;
	}
}

void CDraggedIcon::PostUpdate(float deltaTime) {
}

void CDraggedIcon::Render(HDC hdc, float deltaTime) {
	Render(hdc, mPos + mOwner->GetPos(), deltaTime);
}
void CDraggedIcon::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	if (mTexture) {
		RenderTexture(hdc, mTexture, pos, mSize);
	} else {
		Rectangle(hdc, (int)pos.x, (int)pos.y,
				  (int)(pos.x + mSize.x), (int)(pos.y + mSize.y));
	}
}


void CDraggedIcon::SetTexture(const std::string& name, const TCHAR* fileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, fileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}
void CDraggedIcon::SetTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, fullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

#ifdef UNICODE

void CDraggedIcon::SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}
void CDraggedIcon::SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

#else

void CDraggedIcon::SetTexture(const std::string& name, const std::vector<std::string>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}
void CDraggedIcon::SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

#endif // UNICODE

void CDraggedIcon::SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index) {
	if (mTexture)
		mTexture->SetColorKey(r, g, b, index);
}

void CDraggedIcon::SetSound(EButton_Sound_State state, const std::string& name) {
	mStateSound[(int)state] = mScene->GetResource()->FindSound(name);
}

void CDraggedIcon::CollisionMouseHoveredCallback(const Vector2& pos) {
	CWidget::CollisionMouseHoveredCallback(pos);
}

void CDraggedIcon::CollisionMouseReleaseCallback() {
	CWidget::CollisionMouseReleaseCallback();
}
