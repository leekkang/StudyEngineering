
#include "ImageWidget.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"


CImageWidget::CImageWidget() {
	SetTypeID<CImageWidget>();
}

CImageWidget::CImageWidget(const CImageWidget& widget) :
	CWidget(widget) {
}

CImageWidget::~CImageWidget() {
}


bool CImageWidget::Init() {
	return true;
}

void CImageWidget::Update(float deltaTime) {
}

void CImageWidget::PostUpdate(float deltaTime) {
}

void CImageWidget::Render(HDC hdc, float deltaTime) {
	Render(hdc, mPos + mOwner->GetPos(), deltaTime);
}
void CImageWidget::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	if (mTexture) {
		RenderTexture(hdc, mTexture, pos, mSize);
	} else {
		Rectangle(hdc, (int)pos.x, (int)pos.y,
				  (int)(pos.x + mSize.x), (int)(pos.y + mSize.y));
	}
}