
#include "ImageWidget.h"
#include "WidgetWindow.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"

CImageWidget::CImageWidget() {
	SetTypeID<CImageWidget>();
}

CImageWidget::CImageWidget(const CImageWidget& widget) :
	CWidget(widget) {
}

CImageWidget::~CImageWidget() {
}


bool CImageWidget::Init() {
	return true;
}

void CImageWidget::Update(float deltaTime) {
}

void CImageWidget::PostUpdate(float deltaTime) {
}

void CImageWidget::Render(HDC hdc, float deltaTime) {
	Render(hdc, mPos + mOwner->GetPos(), deltaTime);
}
void CImageWidget::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	if (mTexture) {
		RenderTexture(hdc, mTexture, pos, mSize);
	} else {
		Rectangle(hdc, (int)pos.x, (int)pos.y,
				  (int)(pos.x + mSize.x), (int)(pos.y + mSize.y));
	}
}


void CImageWidget::SetTexture(const std::string& name, const TCHAR* fileName,
							  const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, fileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}
void CImageWidget::SetTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, fullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

#ifdef UNICODE

void CImageWidget::SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}
void CImageWidget::SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

#else

void CImageWidget::SetTexture(const std::string& name, const std::vector<std::string>& vecFileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
}
void CImageWidget::SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
}

#endif // UNICODE

void CImageWidget::SetColorKey(unsigned char r, unsigned char g, unsigned char b) {
	if (mTexture)
		mTexture->SetColorKey(r, g, b);
}
