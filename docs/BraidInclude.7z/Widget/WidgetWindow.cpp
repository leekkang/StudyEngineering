
#include "WidgetWindow.h"


CWidgetWindow::CWidgetWindow() {
}

CWidgetWindow::~CWidgetWindow() {
}

bool CWidgetWindow::Init() {
	return true;
}

void CWidgetWindow::Update(float deltaTime) {
	size_t	size = mVecWidget.size();
	for (size_t i = 0; i < size; ++i) {
		if (!mVecWidget[i]->GetEnable())
			continue;

		mVecWidget[i]->Update(deltaTime);
	}
}

void CWidgetWindow::PostUpdate(float deltaTime) {
	size_t	size = mVecWidget.size();
	for (size_t i = 0; i < size; ++i) {
		if (!mVecWidget[i]->GetEnable())
			continue;

		mVecWidget[i]->PostUpdate(deltaTime);
	}
}

void CWidgetWindow::Render(HDC hdc, float deltaTime) {
	size_t	size = mVecWidget.size();
	if (size > 1)
		std::sort(mVecWidget.begin(), mVecWidget.end(), CWidgetWindow::SortWidget);

	for (size_t i = 0; i < size; ++i) {
		if (!mVecWidget[i]->GetEnable())
			continue;

		mVecWidget[i]->Render(hdc, deltaTime);
	}
}

void CWidgetWindow::SortCollision() {
	if (mVecWidget.size() > 1) {
		std::sort(mVecWidget.begin(), mVecWidget.end(), CWidgetWindow::SortCollisionWidget);
	}
}

bool CWidgetWindow::CollisionMouse(CWidget** widget, const Vector2& pos) {
	if (pos.x < mPos.x)
		return false;
	else if (pos.y < mPos.y)
		return false;
	else if (pos.x > mPos.x + mSize.x)
		return false;
	else if (pos.y > mPos.y + mSize.y)
		return false;

	size_t	count = mVecWidget.size();
	for (size_t i = 0; i < count; ++i) {
		if (mVecWidget[i]->CollisionMouse(pos)) {
			*widget = mVecWidget[i];
			return true;
		}
	}

	return false;
}

bool CWidgetWindow::SortCollisionWidget(const CSharedPtr<CWidget>& src, const CSharedPtr<CWidget>& dest) {
	return src->GetZOrder() > dest->GetZOrder();
}

bool CWidgetWindow::SortWidget(const CSharedPtr<class CWidget>& src, const CSharedPtr<class CWidget>& dest) {
	return src->GetZOrder() < dest->GetZOrder();
}

