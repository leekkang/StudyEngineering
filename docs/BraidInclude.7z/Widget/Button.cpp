
#include "Button.h"
#include "WidgetWindow.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"
#include "../Resource/Sound/Sound.h"
#include "../Input.h"


CButton::CButton() {
	SetTypeID<CButton>();
}

CButton::CButton(const CButton& obj) :
	CWidget(obj) {
}

CButton::~CButton() {
}

bool CButton::Init() {
	return true;
}

void CButton::Update(float deltaTime) {
	mSize = mStateData[(int)mButtonState].end - mStateData[(int)mButtonState].start;

	if (mButtonState == EButton_State::Disable)
		return;

	if (mMouseHovered) {
		if (CInput::GetInst()->GetMouseLDown())
			mButtonState = EButton_State::Click;

		// ��ư ��� ����.
		else if (mButtonState == EButton_State::Click && CInput::GetInst()->GetMouseLUp()) {
			if (mStateSound[(int)EButton_Sound_State::Click])
				mStateSound[(int)EButton_Sound_State::Click]->Play();

			if (mCallback[(int)EButton_Sound_State::Click])
				mCallback[(int)EButton_Sound_State::Click]();

			mButtonState = EButton_State::MouseHovered;
		}

		else if (mButtonState == EButton_State::Click && CInput::GetInst()->GetMouseLPush())
			mButtonState = EButton_State::Click;

		else {
			mButtonState = EButton_State::MouseHovered;
		}

	} else {
		mButtonState = EButton_State::Normal;
	}
}

void CButton::PostUpdate(float deltaTime) {
}

void CButton::Render(HDC hdc, float deltaTime) {
	Render(hdc, mPos + mOwner->GetPos(), deltaTime);
}
void CButton::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	if (mTexture) {
		int frameIndex = mTexture->GetTextureType() == ETexture_Type::Frame ? (int)mButtonState : 0;
		RenderTexture(hdc, mTexture, pos, mSize,
					  (int)mStateData[(int)mButtonState].start.x,
					  (int)mStateData[(int)mButtonState].start.y, frameIndex);
	} else {
		Rectangle(hdc, (int)pos.x, (int)pos.y,
				  (int)(pos.x + mSize.x), (int)(pos.y + mSize.y));
	}
}


void CButton::SetButtonStateData(EButton_State state, const Vector2& start, const Vector2& end) {
	mStateData[(int)state].start = start;
	mStateData[(int)state].end = end;
}

void CButton::SetButtonStateDataAll(const Vector2& start, const Vector2& end) {
	for (int i = 0; i < (int)EButton_State::Max; ++i) {
		mStateData[i].start = start;
		mStateData[i].end = end;
	}
}

void CButton::SetSound(EButton_Sound_State state, const std::string & name) {
	mStateSound[(int)state] = mScene->GetResource()->FindSound(name);
}

void CButton::CollisionMouseHoveredCallback(const Vector2& pos) {
	CWidget::CollisionMouseHoveredCallback(pos);

	if (mStateSound[(int)EButton_Sound_State::MouseHovered])
		mStateSound[(int)EButton_Sound_State::MouseHovered]->Play();
	if (mCallback[(int)EButton_Sound_State::MouseHovered])
		mCallback[(int)EButton_Sound_State::MouseHovered]();
}

void CButton::CollisionMouseReleaseCallback() {
	CWidget::CollisionMouseReleaseCallback();
}
