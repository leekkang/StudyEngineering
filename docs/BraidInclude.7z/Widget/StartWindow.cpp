

#include "StartWindow.h"

#include "../GameManager.h"

#include "../Scene/SceneManager.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"
#include "../Scene/MainScene.h"
#include "../Scene/EditScene.h"

#include "../Input.h"
#include "Button.h"
#include "ImageWidget.h"
#include "DraggedIcon.h"
#include "Text.h"
#include "Number.h"


CStartWindow::CStartWindow() {
	SetTypeID<CStartWindow>();
}

CStartWindow::~CStartWindow() {
}

bool CStartWindow::Init() {
	if (!CWidgetWindow::Init())
		return false;

	mScene->GetResource()->LoadSound(ESound_Group::UI, "ButtonHovered", false, "player_lands1.wav");
	mScene->GetResource()->LoadSound(ESound_Group::UI, "ButtonClick", false, "player_jump5.wav");

	SetSize(1600.f, 900.f);

	//CImageWidget* back = CreateWidget<CImageWidget>("Back");
	//back->SetTexture("StartBack", TEXT("GameBack.bmp"));
	//back->SetSize(1280.f, 720.f);


	CButton* startButton = CreateWidget<CButton>("Stage2-1");

	std::vector<std::wstring> vec{L"2-1.bmp", L"2-1.bmp", L"2-2.bmp", L"2-2.bmp"};

	startButton->SetTexture("Stage2-1", vec);
	startButton->SetColorKey(255, 0, 255);
	startButton->SetColorKey(255, 0, 255, 1);
	startButton->SetColorKey(255, 0, 255, 2);
	startButton->SetColorKey(255, 0, 255, 3);
	startButton->SetPos(50.f, 50.f);

	startButton->SetButtonStateData(EButton_State::Normal, Vector2(0.f, 0.f), Vector2(324.f, 316.f));
	startButton->SetButtonStateData(EButton_State::MouseHovered, Vector2(0.f, 0.f), Vector2(324.f, 316.f));
	startButton->SetButtonStateData(EButton_State::Click, Vector2(0.f, 0.f), Vector2(324.f, 316.f));
	startButton->SetButtonStateData(EButton_State::Disable, Vector2(0.f, 0.f), Vector2(324.f, 316.f));

	startButton->SetSound(EButton_Sound_State::MouseHovered, "ButtonHovered");
	startButton->SetSound(EButton_Sound_State::Click, "ButtonClick");
	
	//startButton->SetCallback<CButton>(EButton_Sound_State::Click, startButton, &CButton::SetToggle);
	//startButton->SetCallback<CStartWindow>(EButton_Sound_State::Click,
	//									   this, &CStartWindow::StartButtonCallback);
	startButton->SetZOrder(1);
	startButton->SetEnable(false);

	CDraggedIcon* icon = CreateWidget<CDraggedIcon>("Stage2-1");
	icon->SetTexture("Icon2-1", TEXT("2-1.bmp"));
	icon->SetSize(324.f, 316.f);
	icon->SetColorKey(255, 0, 255);
	icon->SetPos(50.f, 50.f);
	icon->SetSound(EButton_Sound_State::Click, "ButtonClick");
	icon->SetSound(EButton_Sound_State::MouseHovered, "ButtonHovered");
	icon->SetCallback<CDraggedIcon>(EButton_Sound_State::Click, icon, &CDraggedIcon::StartDragCallback);
	icon->SetCallback<CDraggedIcon>(EButton_Sound_State::MouseHovered, icon, &CDraggedIcon::EndDragCallback);
	icon->SetEnable(false);


	CButton* endButton = CreateWidget<CButton>("Stage2-2");
	endButton->SetTexture("Stage2-2", TEXT("2-2.bmp"));
	endButton->SetColorKey(255, 0, 255);

	endButton->SetButtonStateData(EButton_State::Normal, Vector2(0.f, 0.f), Vector2(324.f, 316.f));
	endButton->SetButtonStateData(EButton_State::MouseHovered, Vector2(0.f, 0.f), Vector2(324.f, 316.f));
	endButton->SetButtonStateData(EButton_State::Click, Vector2(0.f, 0.f), Vector2(324.f, 316.f));
	endButton->SetButtonStateData(EButton_State::Disable, Vector2(0.f, 0.f), Vector2(324.f, 316.f));

	endButton->SetSound(EButton_Sound_State::MouseHovered, "ButtonHovered");
	endButton->SetSound(EButton_Sound_State::Click, "ButtonClick");

	endButton->SetPos(1280.f, 570.f);
	endButton->SetCallback<CStartWindow>(EButton_Sound_State::Click,
										   this, &CStartWindow::EndButtonCallback);
	endButton->SetZOrder(1);


	mHour = CreateWidget<CNumber>("Hour");
	mMinute = CreateWidget<CNumber>("Minute");
	mSecond = CreateWidget<CNumber>("Second");

	CImageWidget* colon = CreateWidget<CImageWidget>("Colon");
	colon->SetTexture("Colon", TEXT("Number/Colon.bmp"));
	colon->SetSize(29.f, 48.f);
	colon->SetColorKey(255, 255, 255); 
	colon->SetPos(1416.f, 10.f);

	colon = CreateWidget<CImageWidget>("Colon");
	colon->SetTexture("Colon", TEXT("Number/Colon.bmp"));
	colon->SetSize(29.f, 48.f);
	colon->SetColorKey(255, 255, 255);
	colon->SetPos(1503.f, 10.f);

	std::vector<std::wstring>	vecFileName;
	for (int i = 0; i < 10; ++i) {
		TCHAR	FileName[MAX_PATH] = {};
		// %d�� i�� ���� ���ԵǾ� ���ڿ��� ��������� �ȴ�.
		wsprintf(FileName, TEXT("Number/%d.bmp"), i);
		vecFileName.push_back(FileName);
	}

	mHour->SetTexture("Number", vecFileName);
	mHour->SetSize(29.f, 48.f);
	mHour->SetColorKeyAll(255, 255, 255);
	mMinute->SetTexture("Number", vecFileName);
	mMinute->SetSize(29.f, 48.f);
	mMinute->SetColorKeyAll(255, 255, 255);
	mSecond->SetTexture("Number", vecFileName);
	mSecond->SetSize(29.f, 48.f);
	mSecond->SetColorKeyAll(255, 255, 255);



	mHour->SetPos(1358.f, 10.f);
	mMinute->SetPos(1445.f, 10.f);
	mSecond->SetPos(1532.f, 10.f);

	//mHour->SetEnable(false);
	//mMinute->SetEnable(false);
	//mSecond->SetEnable(false);

	return true;
}

void CStartWindow::Update(float deltaTime) {
	CWidgetWindow::Update(deltaTime);

	SYSTEMTIME	Time;

	GetLocalTime(&Time);

	mHour->SetNumber(Time.wHour);
	mMinute->SetNumber(Time.wMinute);
	mSecond->SetNumber(Time.wSecond);

}

void CStartWindow::StartButtonCallback() {
	//CInput::GetInst()->ClearCallback();
	//CSceneManager::GetInst()->CreateScene<CMainScene>();
}

void CStartWindow::EndButtonCallback() {
	CSceneManager::GetInst()->CreateScene<CEditScene>();
	//CGameManager::GetInst()->Exit();
}
