#pragma once

#include "Widget.h"

class CButton : public CWidget {
	friend class CWidgetWindow;
	friend class CWidgetComponent;

protected:
	CButton();
	CButton(const CButton& obj);
	virtual ~CButton();

protected:
	EButton_State	mButtonState = EButton_State::Normal;

	CSharedPtr<class CTexture> mTexture;
	AnimationFrameData		   mStateData [static_cast<int>(EButton_State::Max)] {};

	CSharedPtr<class CSound>   mStateSound[static_cast<int>(EButton_Sound_State::Max)];
	std::function<void()>      mCallback  [static_cast<int>(EButton_Sound_State::Max)];


public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);



public:
	void SetTexture(const std::string& name, const TCHAR* fileName, 
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const TCHAR* fullPath);

#ifdef UNICODE

	void SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath);

#else

	void SetTexture(const std::string& name, const std::vector<std::string>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath);

#endif // UNICODE

	void SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index = 0);
	void SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b);


	void SetButtonStateData(EButton_State state, const Vector2& start, const Vector2& end);
	void EnableButton(bool enable) {
		mButtonState = enable ? EButton_State::Normal : EButton_State::Disable;
	}

	void SetSound(EButton_Sound_State state, const std::string& name);



public:
	virtual void CollisionMouseHoveredCallback(const Vector2& pos);
	virtual void CollisionMouseReleaseCallback();

public:
	template <typename T>
	void SetCallback(EButton_Sound_State state, T* obj, void(T::* func)()) {
		mCallback[(int)state] = std::bind(func, obj);
	}
};

