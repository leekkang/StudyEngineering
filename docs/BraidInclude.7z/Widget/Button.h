#pragma once

#include "Widget.h"

class CButton : public CWidget {
	friend class CWidgetWindow;
	friend class CWidgetComponent;

protected:
	CButton();
	CButton(const CButton& obj);
	virtual ~CButton();

protected:
	EButton_State	mButtonState = EButton_State::Normal;
	AnimationFrameData		   mStateData [static_cast<int>(EButton_State::Max)] {};

	CSharedPtr<class CSound>   mStateSound[static_cast<int>(EButton_Sound_State::Max)];
	std::function<void()>      mCallback  [static_cast<int>(EButton_Sound_State::Max)];


public:
	void SetButtonEnable(bool enable) {
		mButtonState = enable ? EButton_State::Normal : EButton_State::Disable;
	}


public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);


	void SetButtonStateData(EButton_State state, const Vector2& start, const Vector2& end);
	void SetButtonStateDataAll(const Vector2& start, const Vector2& end);

	void SetSound(EButton_Sound_State state, const std::string& name);


public:
	virtual void CollisionMouseHoveredCallback(const Vector2& pos);
	virtual void CollisionMouseReleaseCallback();

public:
	void SetCallback(EButton_Sound_State state, const std::function<void()>& func) {
		mCallback[(int)state] = func;
	}
	template <typename T>
	void SetCallback(EButton_Sound_State state, T* obj, void(T::* func)()) {
		mCallback[(int)state] = std::bind(func, obj);
	}
};

