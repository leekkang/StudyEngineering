#pragma once

#include "Widget.h"

class CNumber : public CWidget {
	friend class CWidgetWindow;
	friend class CWidgetComponent;

protected:
	CNumber();
	CNumber(const CNumber& obj);
	virtual ~CNumber();

protected:
	int mNumber = 0;
	std::vector<int> mVecNumber;

public:
	void SetNumber(int num) {
		mNumber = num;
	}
	void AddNumber(int num) {
		mNumber += num;
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);
};

