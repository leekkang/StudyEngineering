#pragma once

#include "Widget.h"

enum class EProgressBar_Texture_Type {
	Back,
	Bar,
	End
};

enum class EProgressBar_Dir {
	LeftToRight,
	RightToLeft,
	BottomToTop,
	TopToBottom,
	End
};

class CProgressBar : public CWidget {
	friend class CWidgetWindow;
	friend class CWidgetComponent;

protected:
	CProgressBar();
	CProgressBar(const CProgressBar& widget);
	virtual ~CProgressBar();

protected:
	CSharedPtr<class CTexture>  mTexture[(int)EProgressBar_Texture_Type::End];

	EProgressBar_Dir mDir     = EProgressBar_Dir::LeftToRight;
	float            mValue	  = 1.f;    // 0 ~ 1 ������ ��
	Vector2          mBarSize;
	Vector2          mBarPos;

public:
	void SetBarDir(EProgressBar_Dir dir) {
		mDir = dir;
	}

	void SetValue(float value) {
		mValue = value;

		if (mValue > 1.f)
			mValue = 1.f;
		else if (mValue < 0.f)
			mValue = 0.f;
	}
	void AddValue(float value) {
		mValue += value;

		if (mValue > 1.f)
			mValue = 1.f;
		else if (mValue < 0.f)
			mValue = 0.f;
	}


public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);


public:
	void SetTexture(EProgressBar_Texture_Type type, const std::string& name, const TCHAR* fileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(EProgressBar_Texture_Type type, const std::string& name, const TCHAR* fullPath);

#ifdef UNICODE

	void SetTexture(EProgressBar_Texture_Type type, const std::string& name, const std::vector<std::wstring>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(EProgressBar_Texture_Type type, const std::string& name, const std::vector<std::wstring>& vecFullPath);

#else

	void SetTexture(EProgressBar_Texture_Type type, const std::string& name, const std::vector<std::string>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(EProgressBar_Texture_Type type, const std::string& name, const std::vector<std::string>& vecFullPath);

#endif

	void SetColorKey(EProgressBar_Texture_Type type, unsigned char r, unsigned char g, unsigned char b);
};

