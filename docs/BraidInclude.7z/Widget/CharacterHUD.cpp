
#include "CharacterHUD.h"
#include "Button.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"
#include "../GameManager.h"
#include "../Scene/MainScene.h"
#include "../Scene/SceneManager.h"
#include "../Input.h"
#include "ProgressBar.h"
#include "ImageWidget.h"


CCharacterHUD::CCharacterHUD() {
}

CCharacterHUD::~CCharacterHUD() {
}


void CCharacterHUD::SetHP(float hp) {
	mHPBar->SetValue(hp);
}

bool CCharacterHUD::Init() {
	if (!CWidgetWindow::Init())
		return false;

	mScene->GetResource()->LoadSound(ESound_Group::UI, "ButtonHovered", false, "1Up.wav");
	mScene->GetResource()->LoadSound(ESound_Group::UI, "ButtonClick", false, "Stun.wav");

	SetSize(210.f, 110.f);
	SetPos(50.f, 50.f);

	mHPBarFrame = CreateWidget<CImageWidget>("HPBarFrame");
	mHPBarFrame->SetTexture("BarFrame", TEXT("BarBack.bmp"));
	mHPBarFrame->SetSize(220.f, 50.f);
	mHPBarFrame->SetColorKey(255, 0, 255);

	mHPBar = CreateWidget<CProgressBar>("HPBar");
	mHPBar->SetTexture(EProgressBar_Texture_Type::Bar, "HPBar", TEXT("BarDefault.bmp"));
	mHPBar->SetSize(200.f, 30.f);
	mHPBar->SetPos(10.f, 10.f);
	mHPBar->SetBarDir(EProgressBar_Dir::LeftToRight);

	return true;
}
