
#include "AlphaImage.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"

CAlphaImage::CAlphaImage() {
	SetTypeID<CAlphaImage>();
}

CAlphaImage::CAlphaImage(const CAlphaImage& widget) :
	CWidget(widget) {
}

CAlphaImage::~CAlphaImage() {
}


bool CAlphaImage::Init() {
	return true;
}

void CAlphaImage::Update(float deltaTime) {
}

void CAlphaImage::PostUpdate(float deltaTime) {
}

void CAlphaImage::Render(HDC hdc, float deltaTime) {
	Render(hdc, mPos + mOwner->GetPos(), deltaTime);
}
void CAlphaImage::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	if (mTwinkle) {
		mAlphaTime += deltaTime;
		float halfTime = mCycleTime * .5f;
		if (mAlphaTime > mCycleTime) {
			mAlphaValue = 255;
			mAlphaTime -= mCycleTime;
		}
		if (mAlphaTime <= halfTime)
			mAlphaValue = 255 - (UINT8)(mAlphaTime / mCycleTime * mRange);
		else
			mAlphaValue = 255 - (UINT8)((mCycleTime - mAlphaTime) / mCycleTime * mRange);
	}

	if (mTexture) {
		if (!mTexture->GetEnableAlpha())
			mTexture->InitAlphaBlend();
		RenderAlphaTexture(hdc, mTexture, mAlphaValue, pos, mSize);
	} else {
		Rectangle(hdc, (int)pos.x, (int)pos.y,
				  (int)(pos.x + mSize.x), (int)(pos.y + mSize.y));
	}
}