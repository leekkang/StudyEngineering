
#include "WidgetComponent.h"
#include "Widget.h"
#include "WidgetWindow.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"
#include "../Scene/Camera.h"
#include "../GameObject/GameObject.h"

CWidgetComponent::CWidgetComponent() {
}

CWidgetComponent::CWidgetComponent(const CWidgetComponent& obj) :
	CRef(obj) {
}

CWidgetComponent::~CWidgetComponent() {
}


Vector2 CWidgetComponent::GetPos() const {
	return mPos + mOwner->GetPos() - mScene->GetCamera()->GetPos();
}

float CWidgetComponent::GetBottom() const {
	Vector2 pos = GetPos();
	float bottom = pos.y;

	if (mWidget)
		bottom += mWidget->GetSize().y;

	return bottom;
}

void CWidgetComponent::SetWidget(CWidget* widget) {
	mWidget = widget;
}

bool CWidgetComponent::Init() {
	mScene->AddWidgetComponent(this);
	return true;
}

void CWidgetComponent::Update(float deltaTime) {
	if (mWidget)
		mWidget->Update(deltaTime);
}

void CWidgetComponent::PostUpdate(float deltaTime) {
	if (mWidget)
		mWidget->PostUpdate(deltaTime);
}

void CWidgetComponent::Render(HDC hdc, float deltaTime) {
	if (mWidget) {
		Vector2	pos = mPos + mOwner->GetPos() - mScene->GetCamera()->GetPos();
		mWidget->Render(hdc, pos, deltaTime);
	}
}