#pragma once

#include "WidgetWindow.h"

class CStartWindow : public CWidgetWindow {
    friend class CScene;

protected:
    CStartWindow();
    virtual ~CStartWindow();

private:
    CSharedPtr<class CNumber>   mHour;
    CSharedPtr<class CNumber>   mMinute;
    CSharedPtr<class CNumber>   mSecond;


public:
    virtual bool Init();
    virtual void Update(float deltaTime);

public:
    void StartButtonCallback();
    void EndButtonCallback();
};

