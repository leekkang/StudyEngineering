#pragma once

#include "Widget.h"

class CImageWidget : public CWidget {
    friend class CWidgetWindow;
    friend class CWidgetComponent;

protected:
    CImageWidget();
    CImageWidget(const CImageWidget& widget);
    virtual ~CImageWidget();

public:
    virtual bool Init();
    virtual void Update(float deltaTime);
    virtual void PostUpdate(float deltaTime);
    virtual void Render(HDC hdc, float deltaTime);
    virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);
};