#pragma once

#include "Widget.h"

class CImageWidget : public CWidget {
    friend class CWidgetWindow;
    friend class CWidgetComponent;

protected:
    CImageWidget();
    CImageWidget(const CImageWidget& widget);
    virtual ~CImageWidget();

protected:
    CSharedPtr<class CTexture>  mTexture;


public:
    virtual bool Init();
    virtual void Update(float deltaTime);
    virtual void PostUpdate(float deltaTime);
    virtual void Render(HDC hdc, float deltaTime);
    virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);


public:
    void SetTexture(const std::string& name, const TCHAR* fileName,
                    const std::string& pathName = TEXTURE_PATH);
    void SetTextureFullPath(const std::string& name, const TCHAR* fullPath);

#ifdef UNICODE

    void SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName,
                    const std::string& pathName = TEXTURE_PATH);
    void SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath);

#else

    void SetTexture(const std::string& name, const std::vector<std::string>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath);

#endif

	void SetColorKey(unsigned char r, unsigned char g, unsigned char b);
};