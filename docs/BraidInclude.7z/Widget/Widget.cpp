
#include "Widget.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"


CWidget::CWidget() {
}

CWidget::CWidget(const CWidget& obj) :
	CRef(obj),
	mZOrder(obj.mZOrder),
	mMouseHovered(obj.mMouseHovered) {
}

CWidget::~CWidget() {
}

bool CWidget::Init() {
	return true;
}

void CWidget::Update(float deltaTime) {
}

void CWidget::PostUpdate(float deltaTime) {
}

void CWidget::Render(HDC hdc, float deltaTime) {
}

void CWidget::Render(HDC hdc, const Vector2& pos, float deltaTime) {
}

void CWidget::Render(HDC hdc, const Vector2& pos, float deltaTime, int imageIndex) {
}

bool CWidget::CollisionMouse(const Vector2& pos) {
	if (pos.x < mPos.x)
		return false;
	else if (pos.x > mPos.x + mSize.x)
		return false;
	else if (pos.y < mPos.y)
		return false;
	else if (pos.y > mPos.y + mSize.y)
		return false;

	if (!mMouseHovered)
		CollisionMouseHoveredCallback(pos);

	return true;
}

void CWidget::CollisionMouseHoveredCallback(const Vector2& pos) {
	mMouseHovered = true;
}

void CWidget::CollisionMouseReleaseCallback() {
	mMouseHovered = false;
}



void CWidget::SetTexture(CTexture* texture) {
	mTexture = texture;
}
void CWidget::SetTexture(const std::string& name) {
	mTexture = mScene->GetResource()->FindTexture(name);
}

void CWidget::SetTexture(const std::string& name, const TCHAR* fileName, const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, fileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
	if (mTexture)
		SetSize(mTexture->GetSize());
}
void CWidget::SetTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, fullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
	if (mTexture)
		SetSize(mTexture->GetSize());
}

void CWidget::SetTexture(const std::string& name, const std::vector<const TCHAR*>& vecFileName,
						 const std::string& pathName) {
	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
	mTexture = mScene->GetResource()->FindTexture(name);
	if (mTexture)
		SetSize(mTexture->GetSize());
}
void CWidget::SetTextureFullPath(const std::string& name, const std::vector<const TCHAR*>& vecFullPath) {
	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
	mTexture = mScene->GetResource()->FindTexture(name);
	if (mTexture)
		SetSize(mTexture->GetSize());
}

//#ifdef UNICODE
//
//void CWidget::SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName, 
//						 const std::string& pathName) {
//	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
//	mTexture = mScene->GetResource()->FindTexture(name);
//	if (mTexture)
//		SetSize(mTexture->GetSize());
//}
//void CWidget::SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath) {
//	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
//	mTexture = mScene->GetResource()->FindTexture(name);
//	if (mTexture)
//		SetSize(mTexture->GetSize());
//}
//
//#else
//
//void CWidget::SetTexture(const std::string& name,  const std::vector<std::string>& vecFileName, 
//						 const std::string& pathName) {
//	mScene->GetResource()->LoadTexture(name, vecFileName, pathName);
//	mTexture = mScene->GetResource()->FindTexture(name);
//	if (mTexture)
//		SetSize(mTexture->GetSize());
//}
//void CWidget::SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath) {
//	mScene->GetResource()->LoadTextureFullPath(name, vecFullPath);
//	mTexture = mScene->GetResource()->FindTexture(name);
//	if (mTexture)
//		SetSize(mTexture->GetSize());
//}
//
//#endif // UNICODE

void CWidget::SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index) {
	if (mTexture)
		mTexture->SetColorKey(r, g, b, index);
}
void CWidget::SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b) {
	if (mTexture)
		mTexture->SetColorKeyAll(r, g, b);
}