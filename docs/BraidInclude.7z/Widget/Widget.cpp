
#include "Widget.h"

CWidget::CWidget() {
}

CWidget::CWidget(const CWidget& obj) :
	CRef(obj),
	mZOrder(obj.mZOrder),
	mMouseHovered(obj.mMouseHovered) {
}

CWidget::~CWidget() {
}

bool CWidget::Init() {
	return true;
}

void CWidget::Update(float deltaTime) {
}

void CWidget::PostUpdate(float deltaTime) {
}

void CWidget::Render(HDC hdc, float deltaTime) {
}

void CWidget::Render(HDC hdc, const Vector2& pos, float deltaTime) {
}

bool CWidget::CollisionMouse(const Vector2& pos) {
	if (pos.x < mPos.x)
		return false;
	else if (pos.x > mPos.x + mSize.x)
		return false;
	else if (pos.y < mPos.y)
		return false;
	else if (pos.y > mPos.y + mSize.y)
		return false;

	if (!mMouseHovered)
		CollisionMouseHoveredCallback(pos);

	return true;
}

void CWidget::CollisionMouseHoveredCallback(const Vector2& pos) {
	mMouseHovered = true;
}

void CWidget::CollisionMouseReleaseCallback() {
	mMouseHovered = false;
}

