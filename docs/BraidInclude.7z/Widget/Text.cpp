
#include "Text.h"
#include "../Resource/Font/Font.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"
#include "WidgetWindow.h"


CText::CText() {
	SetTypeID<CText>();
	mText = new TCHAR[mCapacity];
	memset(mText, 0, sizeof(TCHAR) * mCapacity);
}

CText::CText(const CText& widget) :
	CWidget(widget) {
}

CText::~CText() {
	SAFE_DELETE_ARRAY(mText);
}


void CText::SetFont(const std::string& name) {
	mFont = mScene->GetResource()->FindFont(name);
}

bool CText::Init() {
	mFont = mScene->GetResource()->FindFont("DefaultFont");
	return true;
}

void CText::Update(float deltaTime) {
}

void CText::PostUpdate(float deltaTime) {
}

void CText::Render(HDC hdc, float deltaTime) {
	Render(hdc, mPos + mOwner->GetPos(), deltaTime);
}
void CText::Render(HDC hdc, const Vector2& pos, float deltaTime) {
	mFont->SetFont(hdc);

	SetBkMode(hdc, TRANSPARENT);

	if (mShadow) {
		Vector2 shadowPos = pos + mShadowOffset;
		::SetTextColor(hdc, mShadowColor);
		TextOut(hdc, (int)shadowPos.x, (int)shadowPos.y, mText, mCount);
	}
	::SetTextColor(hdc, mTextColor);
	TextOut(hdc, (int)pos.x, (int)pos.y, mText, mCount);

	mFont->ResetFont(hdc);
}