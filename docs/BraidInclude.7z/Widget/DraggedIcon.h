#pragma once
#pragma once

#include "Widget.h"

class CDraggedIcon : public CWidget {
	friend class CWidgetWindow;
	friend class CWidgetComponent;

protected:
	CDraggedIcon();
	CDraggedIcon(const CDraggedIcon& obj);
	virtual ~CDraggedIcon();

protected:
	EButton_State	mIconState = EButton_State::Normal;

	CSharedPtr<class CTexture> mTexture;

	CSharedPtr<class CSound>   mStateSound[static_cast<int>(EButton_Sound_State::Max)];
	std::function<void()>      mCallback[static_cast<int>(EButton_Sound_State::Max)];

	bool mDragging = false;
	Vector2 mMouseOffset;

public:
	void StartDragCallback();
	void EndDragCallback();

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);
	virtual void Render(HDC hdc, const Vector2& pos, float deltaTime);



public:
	void SetTexture(const std::string& name, const TCHAR* fileName, 
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const TCHAR* fullPath);

#ifdef UNICODE

	void SetTexture(const std::string& name, const std::vector<std::wstring>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath);

#else

	void SetTexture(const std::string& name, const std::vector<std::string>& vecFileName,
					const std::string& pathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath);

#endif // UNICODE

	void SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index = 0);
	void SetSound(EButton_Sound_State state, const std::string& name);



public:
	virtual void CollisionMouseHoveredCallback(const Vector2& pos);
	virtual void CollisionMouseReleaseCallback();

public:
	template <typename T>
	void SetCallback(EButton_Sound_State state, T* obj, void(T::* func)()) {
		mCallback[(int)state] = std::bind(func, obj);
	}
};

