#pragma once

#include "../Ref.h"

class CWidgetComponent : public CRef {
	friend class CGameObject;

protected:
	CWidgetComponent();
	CWidgetComponent(const CWidgetComponent& obj);
	virtual ~CWidgetComponent();

private:
	class CScene*	   mScene = nullptr;
	class CGameObject* mOwner = nullptr;

	Vector2  mPos;
	CSharedPtr<class CWidget> mWidget;


public:
	Vector2 GetPos() const;
	CWidget* GetWidget() const {
		return mWidget;
	}
	float GetBottom() const;

	void SetPos(float x, float y) {
		mPos = Vector2(x, y);
	}
	void SetPos(const Vector2& pos) {
		mPos = pos;
	}

	void SetWidget(class CWidget* widget);

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);


	template <typename T>
	T* GetWidget() const {
		return (T*)mWidget.Get();
	}

	template <typename T>
	T* CreateWidget(const std::string& name) {
		T* widget = new T;
		widget->SetName(name);
		widget->mScene = mScene;

		if (!widget->Init()) {
			SAFE_DELETE(widget);
			return nullptr;
		}

		mWidget = widget;
		return (T*)widget;
	}
};

