#include "Ref.h"


CRef::CRef() {
}

CRef::~CRef() {
}

CRef::CRef(std::string name) :
	mName(name) {
}

CRef::CRef(const CRef& ref) :
	mRefCount(0),
	mTypeName(ref.mTypeName),
	mTypeID(ref.mTypeID),
	mEnable(ref.mEnable),
	mActive(ref.mActive) {
}


void CRef::AddRef() {
	++mRefCount;
}

int CRef::Release() {
	--mRefCount;

	if (mRefCount <= 0) {
		delete this;
		return 0;
	}

	return mRefCount;
}


void CRef::Save(FILE* file) {
	int	length = (int)mName.length();

	fwrite(&length, sizeof(int), 1, file);
	fwrite(mName.c_str(), sizeof(char), length, file);

	length = (int)mTypeName.length();

	fwrite(&length, sizeof(int), 1, file);
	fwrite(mTypeName.c_str(), sizeof(char), length, file);

	fwrite(&mTypeID, sizeof(size_t), 1, file);
}

void CRef::Load(FILE* file) {
	int	length = 0;
	char text[256] = {};

	fread(&length, sizeof(int), 1, file);
	fread(text, sizeof(char), length, file);
	mName = text;

	memset(text, 0, 256);

	fread(&length, sizeof(int), 1, file);
	fread(text, sizeof(char), length, file);
	mTypeName = text;

	fread(&mTypeID, sizeof(size_t), 1, file);
}
