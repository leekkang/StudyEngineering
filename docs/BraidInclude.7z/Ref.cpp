#include "Ref.h"


CRef::CRef() {
}

CRef::~CRef() {
}

CRef::CRef(std::string name) :
	mName(name) {
}

CRef::CRef(const CRef& ref) :
	mRefCount(0),
	mTypeName(ref.mTypeName),
	mTypeID(ref.mTypeID),
	mEnable(ref.mEnable),
	mActive(ref.mActive) {
}


void CRef::AddRef() {
	++mRefCount;
}

int CRef::Release() {
	--mRefCount;

	if (mRefCount <= 0) {
		delete this;
		return 0;
	}

	return mRefCount;
}
