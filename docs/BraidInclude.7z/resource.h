//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// GameFramework.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDI_ICON1                       101
#define IDD_DIALOG_EDIT                 102
#define IDC_EDIT_NAME                   1001
#define IDC_BUTTON_CREATE_MAP           1003
#define IDC_BUTTON_SAVE_MAP             1004
#define IDC_LIST_COLLIDER               1005
#define IDC_BUTTON_LOAD_MAP             1006
#define IDC_EDIT_LEFT                   1007
#define IDC_EDIT_TOP                    1008
#define IDC_EDIT_RIGHT                  1009
#define IDC_EDIT_BOTTOM                 1010
#define IDC_COMBO_COLLIDER_TYPE         1011
#define IDC_BUTTON_SAVE_COLLIDER        1012
#define IDC_BUTTON_CREATE_COLLIDER      1013
#define IDC_STATIC_MAP_SIZE             1014
#define IDC_STATIC_MAP_NAME             1015
#define IDC_COMBO_PROFILE_TYPE          1016
#define IDC_BUTTON_DELETE_COLLIDER      1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
