
#include "AnimationSequence.h"


CAnimationSequence::CAnimationSequence() {
}

CAnimationSequence::~CAnimationSequence() {
}


void CAnimationSequence::AddFrame(const Vector2& start, const Vector2& end) {
	AddFrame(start.x, start.y, end.x, end.y);
}

void CAnimationSequence::AddFrame(float posX, float posY, float sizeX, float sizeY) {
	AnimationFrameData	data = {};

	data.start = Vector2(posX, posY);
	data.end = Vector2(posX + sizeX, posY + sizeY);

	mVecFrame.push_back(data);
}
