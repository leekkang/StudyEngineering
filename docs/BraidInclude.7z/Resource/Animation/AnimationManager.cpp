
#include "AnimationManager.h"
#include "AnimationSequence.h"


CAnimationManager::CAnimationManager() {
}

CAnimationManager::~CAnimationManager() {
}

bool CAnimationManager::Init() {
	return true;
}

bool CAnimationManager::CreateAnimationSequence(const std::string& name, CTexture* texture) {
	CAnimationSequence* sequence = FindAnimationSeq(name);
	if (sequence)
		return true;

	sequence = new CAnimationSequence;
	sequence->SetName(name);
	sequence->mTexture = texture;

	mMapSequence.insert(std::make_pair(name, sequence));

	return true;
}

void CAnimationManager::AddAnimationFrame(const std::string& name, const Vector2& start, const Vector2& end) {
	AddAnimationFrame(name, start.x, start.y, end.x, end.y);
}

void CAnimationManager::AddAnimationFrame(const std::string& name, float posX, float posY, float sizeX, float sizeY) {
	CAnimationSequence* sequence = FindAnimationSeq(name);
	if (sequence)
		sequence->AddFrame(posX, posY, sizeX, sizeY);
}

void CAnimationManager::AddAnimationFullFrame(const std::string& name, const Vector2& size, int xNum, int yNum) {
	CAnimationSequence* sequence = FindAnimationSeq(name);
	if (!sequence)
		return;

	for (int j = 0; j < yNum; ++j) {
		for (int i = 0; i < xNum; ++i) {
			sequence->AddFrame(size.x * i, size.y * j, size.x, size.y);
		}
	}
}

CAnimationSequence* CAnimationManager::FindAnimationSeq(const std::string& name) {
	auto iter = mMapSequence.find(name);
	if (iter == mMapSequence.end())
		return nullptr;

	return iter->second;
}
void CAnimationManager::ReleaseAnimation(const std::string& name) {
	auto iter = mMapSequence.find(name);
	if (iter == mMapSequence.end())
		return;

	if (iter->second->GetRefCount() == 1)
		mMapSequence.erase(iter);
}
