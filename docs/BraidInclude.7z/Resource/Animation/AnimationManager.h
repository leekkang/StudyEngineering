#pragma once

#include "../../GameInfo.h"

class CAnimationManager {
	friend class CResourceManager;

private:
	CAnimationManager();
	~CAnimationManager();

private:
	std::unordered_map<std::string, CSharedPtr<class CAnimationSequence>> mMapSequence;

public:
	bool Init();


private:
	bool CreateAnimationSequence(const std::string& name, class CTexture* texture);

	void AddAnimationFrame(const std::string& name, const Vector2& start, const Vector2& end);
	void AddAnimationFrame(const std::string& name, float posX, float posY, float sizeX, float sizeY);
	// ��� ������ ����� ���� �� ���
	void AddAnimationFullFrame(const std::string& name, const Vector2& size, int xNum, int yNum);

	class CAnimationSequence* FindAnimationSeq(const std::string& name);
	void ReleaseAnimation(const std::string& name);
};

