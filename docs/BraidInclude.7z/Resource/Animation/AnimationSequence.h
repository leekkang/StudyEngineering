#pragma once

#include "../../Ref.h"
#include "../Texture/Texture.h"

class CAnimationSequence : public CRef {
    friend class CAnimationManager;

private:
    CAnimationSequence();
    ~CAnimationSequence();

private:
    CSharedPtr<CTexture>  mTexture;
    std::vector<AnimationFrameData> mVecFrame;

public:
    CTexture* GetTexture() const {
        return mTexture;
    }
    ETexture_Type GetTextureType() const {
        return mTexture->GetTextureType();
    }

    const AnimationFrameData& GetFrame(int index)   const {
        return mVecFrame[index];
    }

    int GetFrameCount() const {
        return (int)mVecFrame.size();
    }

public:
    void AddFrame(const Vector2& start, const Vector2& end);
    void AddFrame(float posX, float posY, float sizeX, float sizeY);
};

