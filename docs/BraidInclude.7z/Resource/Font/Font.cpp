
#include "Font.h"

CFont::CFont() {
}

CFont::~CFont() {
	if (mHFont)
		DeleteObject(mHFont);
}

bool CFont::LoadFont(const TCHAR* fontName, int width, int height) {
	/*
	#define FW_DONTCARE         0
	#define FW_THIN             100
	#define FW_EXTRALIGHT       200
	#define FW_LIGHT            300
	#define FW_NORMAL           400
	#define FW_MEDIUM           500
	#define FW_SEMIBOLD         600
	#define FW_BOLD             700
	#define FW_EXTRABOLD        800
	#define FW_HEAVY            900
	*/
	mFontInfo.lfWidth		   = (LONG)width;
	mFontInfo.lfHeight		   = (LONG)height;
	mFontInfo.lfCharSet		   = HANGEUL_CHARSET;
	mFontInfo.lfWeight		   = FW_NORMAL; // ����
	mFontInfo.lfItalic		   = 0;         // ����
	mFontInfo.lfEscapement	   = 1;         // ����
	mFontInfo.lfUnderline	   = 0;         // ����
	mFontInfo.lfStrikeOut	   = 0;         // ��Ҽ�
	mFontInfo.lfPitchAndFamily = 2;         // �ڰ�

	lstrcpy(mFontInfo.lfFaceName, fontName);

	mHFont = CreateFontIndirect(&mFontInfo);
	return mHFont == nullptr ? false : true;
}

void CFont::SetFont(HDC hdc) {
	mHPrevFont = (HFONT)SelectObject(hdc, mHFont);
}

void CFont::ResetFont(HDC hdc) {
	SelectObject(hdc, mHPrevFont);
}
