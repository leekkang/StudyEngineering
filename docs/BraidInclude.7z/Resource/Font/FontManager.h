#pragma once

#include "../../GameInfo.h"

class CFontManager {
	friend class CResourceManager;

private:
	CFontManager();
	~CFontManager();

private:
	std::unordered_map<std::string, CSharedPtr<class CFont>> mMapFont;

public:
	bool Init();

	bool LoadFont(const TCHAR* fontFileName, const std::string& pathName = FONT_PATH);

	bool LoadFont(const std::string& name, const TCHAR* fontName, int width, int height);
	void SetFont(const std::string& name, HDC hdc);
	void ResetFont(const std::string& name, HDC hdc);
	class CFont* FindFont(const std::string& name);
	void ReleaseFont(const std::string& name);
};

