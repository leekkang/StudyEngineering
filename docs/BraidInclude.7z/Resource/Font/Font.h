#pragma once

#include "../../Ref.h"

class CFont : public CRef {
	friend class CFontManager;

private:
	CFont();
	~CFont();

private:
	LOGFONT mFontInfo {};
	HFONT   mHFont	   = 0;
	HFONT   mHPrevFont = 0;

public:
	bool LoadFont(const TCHAR* fontName, int width, int height);
	void SetFont(HDC hdc);
	void ResetFont(HDC hdc);
};

