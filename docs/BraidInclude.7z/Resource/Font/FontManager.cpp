
#include "FontManager.h"

#include "Font.h"
#include "../../PathManager.h"

CFontManager::CFontManager() {
}

CFontManager::~CFontManager() {
}

bool CFontManager::Init() {
	LoadFont(TEXT("NotoSansKR-Black.otf"));
	LoadFont(TEXT("NotoSansKR-Bold.otf"));
	// ��Ʈ ũ�⸦ ũ�� �Ϸ��� height �� ������ �����ϸ� �ȴ�.
	LoadFont("DefaultFont", TEXT("Noto Sans KR Black"), 0, -32);
	
	LoadFont("RewindFont", TEXT("Noto Sans KR"), 0, -24);

	LoadFont("PuzzleFont", TEXT("Noto Sans KR Black"), 0, -20);

	return true;
}

bool CFontManager::LoadFont(const TCHAR* fontFileName, const std::string& pathName) {
	TCHAR fullPath[MAX_PATH] = {};

	const PathInfo* info = CPathManager::GetInst()->FindPath(FONT_PATH);
	if (info)
		lstrcpy(fullPath, info->path);

	lstrcat(fullPath, fontFileName);
	AddFontResource(fullPath);

	return true;
}

bool CFontManager::LoadFont(const std::string& name, const TCHAR* fontName, int width, int height) {
	CFont* font = FindFont(name);
	if (font)
		return true;

	font = new CFont;
	font->SetName(name);

	if (!font->LoadFont(fontName, width, height)) {
		SAFE_DELETE(font);
		return false;
	}
	mMapFont.insert(std::make_pair(name, font));

	return true;
}

void CFontManager::SetFont(const std::string& name, HDC hdc) {
	CFont* font = FindFont(name);
	if (!font)
		return;

	font->SetFont(hdc);
}

void CFontManager::ResetFont(const std::string& name, HDC hdc) {
	CFont* font = FindFont(name);
	if (!font)
		return;

	font->ResetFont(hdc);
}

CFont* CFontManager::FindFont(const std::string& name) {
	auto iter = mMapFont.find(name);
	if (iter == mMapFont.end())
		return nullptr;

	return iter->second;
}

void CFontManager::ReleaseFont(const std::string& name) {
	auto iter = mMapFont.find(name);
	if (iter == mMapFont.end())
		return;

	if (iter->second->GetRefCount() == 1)
		mMapFont.erase(iter);
}
