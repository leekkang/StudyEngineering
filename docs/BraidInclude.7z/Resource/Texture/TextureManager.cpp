#include "TextureManager.h"
#include "Texture.h"

CTextureManager::CTextureManager() {
}

CTextureManager::~CTextureManager() {
}

bool CTextureManager::Init() {
	return true;
}

bool CTextureManager::LoadTextureWithDIB(const std::string& name, const TCHAR* fileName) {
	CTexture* texture = FindTexture(name);
	if (texture)
		return true;

	texture = new CTexture;
	if (!texture->LoadTextureWithDIB(fileName)) {
		SAFE_RELEASE(texture);
		return false;
	}

	texture->SetName(name);
	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}
bool CTextureManager::LoadTextureWithDIB(const std::string& name, const std::vector<const TCHAR*>& vecFileName) {
	CTexture* texture = FindTexture(name);
	if (texture)
		return true;

	texture = new CTexture;
	if (!texture->LoadTextureWithDIB(vecFileName)) {
		SAFE_RELEASE(texture);
		return false;
	}

	texture->SetName(name);
	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}


bool CTextureManager::LoadTexture(const std::string& name,
								  const TCHAR* fileName, const std::string& pathName) {
	CTexture* texture = FindTexture(name);
	if (texture)
		return true;

	texture = new CTexture;
	if (!texture->LoadTexture(fileName, pathName)) {
		SAFE_RELEASE(texture);
		return false;
	}

	texture->SetName(name);
	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}
bool CTextureManager::LoadTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	CTexture* texture = FindTexture(name);
	if (texture)
		return true;

	texture = new CTexture;
	if (!texture->LoadTextureFullPath(fullPath)) {
		SAFE_RELEASE(texture);
		return false;
	}

	texture->SetName(name);
	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}

bool CTextureManager::LoadTexture(const std::string& name,
								  const std::vector<const TCHAR*>& vecFileName, const std::string& pathName) {
	CTexture* texture = FindTexture(name);
	if (texture)
		return true;

	texture = new CTexture;
	if (!texture->LoadTexture(vecFileName, pathName)) {
		SAFE_RELEASE(texture);
		return false;
	}

	texture->SetName(name);
	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}
bool CTextureManager::LoadTextureFullPath(const std::string& name,
										  const std::vector<const TCHAR*>& vecFullPath) {
	CTexture* texture = FindTexture(name);
	if (texture)
		return true;

	texture = new CTexture;
	if (!texture->LoadTextureFullPath(vecFullPath)) {
		SAFE_RELEASE(texture);
		return false;
	}

	texture->SetName(name);
	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}


CTexture* CTextureManager::LoadTexture(FILE* file) {
	// ���� �̸����� ����Ȱ� �ִٸ� �߸��Ȱ��̴�.
	CTexture* texture = new CTexture;
	texture->Load(file);

	CTexture* find = FindTexture(texture->GetName());
	if (find) {
		SAFE_DELETE(texture);
		return find;
	}

	mMapTexture.insert(std::make_pair(texture->GetName(), texture));

	return texture;
}

void CTextureManager::SetColorKey(const std::string& name, unsigned char r, unsigned char g, unsigned char b, int index) {
	CTexture* texture = FindTexture(name);
	if (texture)
		texture->SetColorKey(r, g, b, index);
}
void CTextureManager::SetColorKeyAll(const std::string& name, unsigned char r, unsigned char g, unsigned char b) {
	CTexture* texture = FindTexture(name);
	if (texture)
		texture->SetColorKeyAll(r, g, b);
}


CTexture* CTextureManager::FindTexture(const std::string& name) {
	auto iter = mMapTexture.find(name);
	if (iter == mMapTexture.end())
		return nullptr;

	return iter->second;
}

void CTextureManager::ReleaseTexture(const std::string& name) {
	auto	iter = mMapTexture.find(name);
	if (iter == mMapTexture.end())
		return;

	if (iter->second->GetRefCount() == 1)
		mMapTexture.erase(iter);
}

//#ifdef UNICODE
//
//bool CTextureManager::LoadTexture(const std::string& name,
//								  const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
//	CTexture* texture = FindTexture(name);
//	if (texture)
//		return true;
//
//	texture = new CTexture;
//	if (!texture->LoadTexture(vecFileName, pathName)) {
//		SAFE_RELEASE(texture);
//		return false;
//	}
//
//	texture->SetName(name);
//	mMapTexture.insert(std::make_pair(name, texture));
//	return true;
//}
//bool CTextureManager::LoadTextureFullPath(const std::string& name,
//										  const std::vector<std::wstring>& vecFullPath) {
//	CTexture* texture = FindTexture(name);
//	if (texture)
//		return true;
//
//	texture = new CTexture;
//	if (!texture->LoadTextureFullPath(vecFullPath)) {
//		SAFE_RELEASE(texture);
//		return false;
//	}
//
//	texture->SetName(name);
//	mMapTexture.insert(std::make_pair(name, texture));
//	return true;
//}
//
//#else
//
//bool CTextureManager::LoadTexture(const std::string& name,
//								  const std::vector<std::string>& vecFileName, const std::string& pathName) {
//	CTexture* texture = FindTexture(name);
//	if (texture)
//		return true;
//
//	texture = new CTexture;
//	if (!texture->LoadTexture(vecFileName, pathName)) {
//		SAFE_RELEASE(texture);
//		return false;
//	}
//
//	texture->SetName(name);
//	mMapTexture.insert(std::make_pair(name, texture));
//	return true;
//}
//bool CTextureManager::LoadTextureFullPath(const std::string& name,
//										  const std::vector<std::string>& vecFullPath) {
//	CTexture* texture = FindTexture(name);
//	if (texture)
//		return true;
//
//	texture = new CTexture;
//	if (!texture->LoadTextureFullPath(vecFullPath)) {
//		SAFE_RELEASE(texture);
//		return false;
//	}
//
//	texture->SetName(name);
//	mMapTexture.insert(std::make_pair(name, texture));
//	return true;
//}
//
//#endif