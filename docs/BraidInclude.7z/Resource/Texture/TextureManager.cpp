#include "TextureManager.h"
#include "Texture.h"

CTextureManager::CTextureManager() {
}

CTextureManager::~CTextureManager() {
}

bool CTextureManager::Init() {
	return true;
}

bool CTextureManager::LoadTexture(const std::string& name,
								  const TCHAR* fileName, const std::string& pathName) {
	// ���� �̸����� ����Ȱ� �ִٸ� �߸��Ȱ��̴�.
	CTexture* texture = FindTexture(name);
	if (texture)
		return false;

	texture = new CTexture;
	if (!texture->LoadTexture(fileName, pathName)) {
		SAFE_RELEASE(texture);
		return false;
	}

	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}
bool CTextureManager::LoadTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	// ���� �̸����� ����Ȱ� �ִٸ� �߸��Ȱ��̴�.
	CTexture* texture = FindTexture(name);
	if (texture)
		return false;

	texture = new CTexture;
	if (!texture->LoadTextureFullPath(fullPath)) {
		SAFE_RELEASE(texture);
		return false;
	}

	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}

#ifdef UNICODE

bool CTextureManager::LoadTexture(const std::string& name,
								  const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	// ���� �̸����� ����Ȱ� �ִٸ� �߸��Ȱ��̴�.
	CTexture* texture = FindTexture(name);
	if (texture)
		return false;

	texture = new CTexture;
	if (!texture->LoadTexture(vecFileName, pathName)) {
		SAFE_RELEASE(texture);
		return false;
	}

	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}
bool CTextureManager::LoadTextureFullPath(const std::string& name,
										  const std::vector<std::wstring>& vecFullPath) {
	// ���� �̸����� ����Ȱ� �ִٸ� �߸��Ȱ��̴�.
	CTexture* texture = FindTexture(name);
	if (texture)
		return false;

	texture = new CTexture;
	if (!texture->LoadTextureFullPath(vecFullPath)) {
		SAFE_RELEASE(texture);
		return false;
	}

	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}

#else

bool CTextureManager::LoadTexture(const std::string& name,
								  const std::vector<std::string>& vecFileName, const std::string& pathName) {
	// ���� �̸����� ����Ȱ� �ִٸ� �߸��Ȱ��̴�.
	CTexture* texture = FindTexture(name);
	if (texture)
		return false;

	texture = new CTexture;
	if (!texture->LoadTexture(vecFileName, pathName)) {
		SAFE_RELEASE(texture);
		return false;
	}

	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}
bool CTextureManager::LoadTextureFullPath(const std::string& name,
										  const std::vector<std::string>& vecFullPath) {
	// ���� �̸����� ����Ȱ� �ִٸ� �߸��Ȱ��̴�.
	CTexture* texture = FindTexture(name);
	if (texture)
		return false;

	texture = new CTexture;
	if (!texture->LoadTextureFullPath(vecFullPath)) {
		SAFE_RELEASE(texture);
		return false;
	}

	mMapTexture.insert(std::make_pair(name, texture));
	return true;
}

#endif

void CTextureManager::SetColorKey(const std::string& name, unsigned char r, unsigned char g, unsigned char b, int index) {
	CTexture* texture = FindTexture(name);
	if (texture)
		texture->SetColorKey(r, g, b, index);
}
void CTextureManager::SetColorKeyAll(const std::string& name, unsigned char r, unsigned char g, unsigned char b) {
	CTexture* texture = FindTexture(name);
	if (texture)
		texture->SetColorKeyAll(r, g, b);
}


CTexture* CTextureManager::FindTexture(const std::string& name) {
	auto iter = mMapTexture.find(name);
	if (iter == mMapTexture.end())
		return nullptr;

	return iter->second;
}

void CTextureManager::ReleaseTexture(const std::string& name) {
	auto	iter = mMapTexture.find(name);
	if (iter == mMapTexture.end())
		return;

	if (iter->second->GetRefCount() == 1)
		mMapTexture.erase(iter);
}