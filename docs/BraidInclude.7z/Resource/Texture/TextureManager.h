#pragma once

#include "../../GameInfo.h"

class CTextureManager {
	friend class CResourceManager;

private:
	CTextureManager();
	~CTextureManager();

private:
	std::unordered_map<std::string, CSharedPtr<class CTexture>>	mMapTexture;

public:
	bool Init();


public:
	bool LoadTextureWithDIB(const std::string& name, const TCHAR* fileName);
	bool LoadTextureWithDIB(const std::string& name, const std::vector<std::wstring>& vecFileName);


private:
	// ETexture_Type::Sprite
	bool LoadTexture(const std::string& name, const TCHAR* fileName,
					 const std::string& pathName = TEXTURE_PATH);
	bool LoadTextureFullPath(const std::string& name, const TCHAR* fullPath);

#ifdef UNICODE
	// ETexture_Type::Frame
	bool LoadTexture(const std::string& name, const std::vector<std::wstring>& vecFileName,
					 const std::string& pathName = TEXTURE_PATH);
	bool LoadTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath);

#else
	// ETexture_Type::Frame
	bool LoadTexture(const std::string& name, const std::vector<std::string>& vecFileName,
					 const std::string& pathName = TEXTURE_PATH);
	bool LoadTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath);

#endif // UNICODE

	// ETexture_Type::Sprite
	void SetColorKey(const std::string& name, unsigned char r, unsigned char g, unsigned char b, int Index = 0);
	// ETexture_Type::Frame
	void SetColorKeyAll(const std::string& name, unsigned char r, unsigned char g, unsigned char b);


	class CTexture* FindTexture(const std::string& name);
	void ReleaseTexture(const std::string& name);
};

