#pragma once

#include "../../Ref.h"

struct ImageInfo {
	HDC      hMemDC         = 0;
	HBITMAP  hBmp           = 0;
	HBITMAP  hPrevBmp       = 0;

    bool     EnableColorKey = false;
    COLORREF ColorKey       = RGB(255, 0, 255);

    BITMAP   BmpInfo {};

	ImageInfo() {
	}
	~ImageInfo() {
		// ������ ������� �����ش�.
		SelectObject(hMemDC, hPrevBmp);
		DeleteObject(hBmp);
		DeleteDC(hMemDC);
	}
};

class CTexture : public CRef {
    friend class CTextureManager;

private:
    CTexture();
    ~CTexture();

private:
    ETexture_Type   mType = ETexture_Type::Sprite;
    std::vector<ImageInfo*> mVecImageInfo;

public:
    ETexture_Type GetTextureType()  const {
        return mType;
    }

    HDC GetDC(int index = 0) const {
        return mVecImageInfo[index]->hMemDC;
    }

    bool GetEnableColorKey(int index = 0)    const {
        return mVecImageInfo[index]->EnableColorKey;
    }
    COLORREF GetColorKey(int index = 0)    const {
        return mVecImageInfo[index]->ColorKey;
    }
    ImageInfo* GetImageInfo(int index = 0) const {
        return mVecImageInfo[index];
    }


    void SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index = 0) {
        mVecImageInfo[index]->ColorKey = RGB(r, g, b);
        mVecImageInfo[index]->EnableColorKey = true;
    }
    void SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b) {
        size_t  size = mVecImageInfo.size();
        for (size_t i = 0; i < size; ++i) {
            mVecImageInfo[i]->ColorKey = RGB(r, g, b);
            mVecImageInfo[i]->EnableColorKey = true;
        }
    }


private:
    bool LoadTexture(const TCHAR* fileName,
                     const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureFullPath(const TCHAR* fullPath);

#ifdef UNICODE

    bool LoadTexture(const std::vector<std::wstring>& vecFileName,
                     const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureFullPath(const std::vector<std::wstring>& vecFullPath);

#else

    bool LoadTexture(const std::vector<std::string>& vecFileName,
                     const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureFullPath(const std::vector<std::string>& vecFullPath);

#endif // UNICODE

};
