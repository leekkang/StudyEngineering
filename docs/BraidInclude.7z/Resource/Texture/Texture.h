#pragma once

#include "../../Ref.h"

struct ImageInfo {
	HDC      hMemDC         = 0;
	HBITMAP  hBmp           = 0;
	HBITMAP  hPrevBmp       = 0;
    BITMAP   bmpInfo {};

    bool     enableColorKey = false;
    COLORREF colorKey       = RGB(255, 0, 255);
    TCHAR    fileName[MAX_PATH]{};
    TCHAR    fullPath[MAX_PATH]{};
    std::string pathName;

    // ���� �������� ���� ����
    bool enableAlpha = false;
    HDC hAlphaDC = 0;
    HBITMAP hBmpAlpha = 0;
    HBITMAP hBmpAlphaOld = 0;

    // ��Ʈ�� ���� ������ ���� ����
    bool bModulated = false; // ��Ʈ�� ��Ʈ�� ������ �Ͼ���� �˷��ش�.
    UINT8* bmpBits = nullptr;

	ImageInfo() {
	}
	~ImageInfo() {
        SAFE_DELETE_ARRAY(bmpBits);

		// ������ ������� �����ش�.
        if (enableAlpha) {
		    SelectObject(hAlphaDC, hBmpAlphaOld);
		    DeleteObject(hBmpAlpha);
            DeleteDC(hAlphaDC);
        }
		SelectObject(hMemDC, hPrevBmp);
		DeleteObject(hBmp);
		DeleteDC(hMemDC);
	}

    void InitAlphaBlend();

    void InitModulatedBits() {
        if (bmpBits || !bmpInfo.bmBits)
            return;

        //! ���� : bmWidth * 3 != bmWidthBytes �е� ����Ʈ�� �� �� �ִ�. (4����Ʈ �������� �ڸ��µ�?)
        size_t size = (size_t)(bmpInfo.bmWidthBytes) * bmpInfo.bmHeight;
        bmpBits = new UINT8[size];
        memcpy(bmpBits, bmpInfo.bmBits, size);
    }
    void ResetModulatedBmpBits() {
        if (bModulated) {
            bModulated = false;
            memcpy(bmpInfo.bmBits, bmpBits, bmpInfo.bmWidthBytes * bmpInfo.bmHeight);
        }
    }

    // ��Ʈ�� ������ r,g,b �÷��� ���´�. mixValue�� 0�̸� ���� ��Ʈ�� ������ ����Ѵ�.
    // 24��Ʈ ��Ʈ�ʸ� ó�� �����ϴ�. �ٸ��� �ȵ�.
    void MixColor(UINT8 mixValue, UINT8 r, UINT8 g, UINT8 b, int sizeX, int sizeY, int left, int top);
};

class CTexture : public CRef {
    friend class CTextureManager;

private:
    CTexture();
    ~CTexture();

private:
    ETexture_Type   mType = ETexture_Type::Sprite;
    std::vector<ImageInfo*> mVecImageInfo;

public:
    ETexture_Type GetTextureType()  const {
        return mType;
    }
    int GetWidth(int Index = 0) const {
        return (int)mVecImageInfo[Index]->bmpInfo.bmWidth;
    }
    int GetHeight(int Index = 0) const {
        return (int)mVecImageInfo[Index]->bmpInfo.bmHeight;
    }

    HDC GetDC(int index = 0) const {
        return mVecImageInfo[index]->hMemDC;
    }
    HDC GetAlphaDC(int index = 0) const {
        return mVecImageInfo[index]->hAlphaDC;
    }

    bool GetEnableAlpha(int index = 0) const {
        return mVecImageInfo[index]->enableAlpha;
    }

    bool GetEnableColorKey(int index = 0) const {
        return mVecImageInfo[index]->enableColorKey;
    }
    COLORREF GetColorKey(int index = 0) const {
        return mVecImageInfo[index]->colorKey;
    }


    void SetColorKey(unsigned char r, unsigned char g, unsigned char b, int index = 0) {
        mVecImageInfo[index]->colorKey = RGB(r, g, b);
        mVecImageInfo[index]->enableColorKey = true;
    }
    void SetColorKeyAll(unsigned char r, unsigned char g, unsigned char b) {
        size_t  size = mVecImageInfo.size();
        for (size_t i = 0; i < size; ++i) {
            mVecImageInfo[i]->colorKey = RGB(r, g, b);
            mVecImageInfo[i]->enableColorKey = true;
        }
    }

public:
    void InitAlphaBlend() {
        size_t  size = mVecImageInfo.size();
        for (size_t i = 0; i < size; ++i) {
            mVecImageInfo[i]->InitAlphaBlend();
        }
    }

    void InitModulatedBits() {
        size_t  size = mVecImageInfo.size();
        for (size_t i = 0; i < size; ++i) {
            mVecImageInfo[i]->InitModulatedBits();
        }
    }

    void ResetModulatedBmpBits(int index = 0) const {
        mVecImageInfo[index]->ResetModulatedBmpBits();
    }
    void MixColor(UINT8 mixRate, UINT8 r, UINT8 g, UINT8 b, int sizeX, int sizeY, int left, int top, int index = 0) const {
        mVecImageInfo[index]->MixColor(mixRate, r, g, b, sizeX, sizeY, left, top);
    }


private:
    bool LoadTextureWithDIB(const TCHAR* fileName, const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureWithDIB(const std::vector<std::wstring>& vecFileName, const std::string& pathName = TEXTURE_PATH);



private:
    bool LoadTexture(const TCHAR* fileName, const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureFullPath(const TCHAR* fullPath);

#ifdef UNICODE

    bool LoadTexture(const std::vector<std::wstring>& vecFileName,
                     const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureFullPath(const std::vector<std::wstring>& vecFullPath);

#else

    bool LoadTexture(const std::vector<std::string>& vecFileName,
                     const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureFullPath(const std::vector<std::string>& vecFullPath);

#endif // UNICODE


private:
    bool LoadTexture(ImageInfo* info, const TCHAR* fileName, const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureFullPath(ImageInfo* info, const TCHAR* fullPath);

#ifdef UNICODE

    bool LoadTexture(std::vector<ImageInfo*>* vecInfo, const std::vector<std::wstring>& vecFileName,
                     const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureFullPath(std::vector<ImageInfo*>* vecInfo, const std::vector<std::wstring>& vecFullPath);

#else

    bool LoadTexture(std::vector<ImageInfo*>* vecInfo, const std::vector<std::string>& vecFileName,
                     const std::string& pathName = TEXTURE_PATH);
    bool LoadTextureFullPath(std::vector<ImageInfo*>* vecInfo, const std::vector<std::string>& vecFullPath);

#endif // UNICODE

public:
    void Save(FILE* file);
    void Load(FILE* file);

};
