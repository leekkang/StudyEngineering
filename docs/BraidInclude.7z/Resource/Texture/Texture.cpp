#include "Texture.h"
#include "../../GameManager.h"
#include "../../PathManager.h"

CTexture::CTexture() {
	SetTypeID<CTexture>();
}

CTexture::~CTexture() {
	size_t	size = mVecImageInfo.size();
	for (size_t i = 0; i < size; ++i) {
		SAFE_DELETE(mVecImageInfo[i]);
	}
}

bool CTexture::LoadTexture(const TCHAR* fileName, const std::string& pathName) {
	TCHAR			fullPath[MAX_PATH] = {};

	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);
	if (path)
		lstrcpy(fullPath, path->path);

	lstrcat(fullPath, fileName);

	return LoadTextureFullPath(fullPath);
}
bool CTexture::LoadTextureFullPath(const TCHAR* fullPath) {
	// ȭ��DC�� �ְ� �޸� DC�� ��´�.
	HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());

	// ��Ʈ���� �ε��Ѵ�.
	HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
									  fullPath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (!hBmp)
		return false;

	// �о�� ��Ʈ���� �޸� DC�� �����Ѵ�.
	// ������ DC�� ������ �ִ� ������ ��ȯ�Ѵ�.
	HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

	BITMAP	bmpInfo;
	GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

	ImageInfo* info = new ImageInfo;
	info->hMemDC	= hdc;
	info->hBmp		= hBmp;
	info->hPrevBmp	= hPrevBmp;
	info->BmpInfo	= bmpInfo;

	mVecImageInfo.push_back(info);

	return true;
}

#ifdef UNICODE

bool CTexture::LoadTexture(const std::vector<std::wstring>& vecFileName, 
						   const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);

	size_t	size = vecFileName.size();
	// (����) �����ڴ� �ش� ������ŭ resize �س��´�. reserve�� �ƴ�!
	std::vector<std::wstring>	vecFullPath(size);

	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	return LoadTextureFullPath(vecFullPath);
}
bool CTexture::LoadTextureFullPath(const std::vector<std::wstring>& vecFullPath) {
	mType = ETexture_Type::Frame; // ���� ���� �̹����� ���ÿ� ������ Ÿ���̴�.

	size_t	size = vecFullPath.size();
	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, 
										  LR_LOADFROMFILE | LR_CREATEDIBSECTION);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = new ImageInfo;
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->BmpInfo = bmpInfo;

		mVecImageInfo.push_back(info);
	}

	return true;
}

#else

bool CTexture::LoadTexture(const std::vector<std::string>& vecFileName, const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);

	size_t size = vecFileName.size();
	std::vector<std::string> vecFullPath(size);

	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	return LoadTextureFullPath(vecFullPath);
}
bool CTexture::LoadTextureFullPath(const std::vector<std::string>& vecFullPath) {
	mType = ETexture_Type::Frame;

	size_t	size = vecFullPath.size();
	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = new ImageInfo;
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->BmpInfo = bmpInfo;

		mVecImageInfo.push_back(info);
	}

	return true;
}

#endif // UNICODE