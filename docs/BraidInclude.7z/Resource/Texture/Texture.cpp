
#include "Texture.h"

#include "../../GameManager.h"
#include "../../PathManager.h"



void ImageInfo::InitAlphaBlend() {
	enableAlpha = true;
	HDC hdc = CGameManager::GetInst()->GetWindowDC();
	hAlphaDC = CreateCompatibleDC(hdc);
	hBmpAlpha = CreateCompatibleBitmap(hdc, (int)bmpInfo.bmWidth, (int)bmpInfo.bmHeight);
	hBmpAlphaOld = (HBITMAP)SelectObject(hAlphaDC, hBmpAlpha);
}

void ImageInfo::MixColor(UINT8 mixValue, UINT8 r, UINT8 g, UINT8 b, int sizeX, int sizeY, int left, int top) {
	bModulated = true;
	UINT8* bits = (UINT8*)bmpInfo.bmBits;

	int pixelSize = (int)(bmpInfo.bmBitsPixel * 0.125f);
	int startY = bmpInfo.bmHeight - (top + sizeY);
	int endX = min(bmpInfo.bmWidth, left + sizeX);
	int endY = min(bmpInfo.bmHeight, startY + sizeY);
	float srcRate = (255 - mixValue) / 255.f;
	float destRate = mixValue / 255.f;
	r = (UINT8)(r * destRate);
	g = (UINT8)(g * destRate);
	b = (UINT8)(b * destRate);

	int index = 0;
	for (int i = startY; i < endY; ++i) {
		for (int j = left; j < endX; ++j) {
			index = i * bmpInfo.bmWidthBytes + j * pixelSize;
			if (RGB(bits[index], bits[index+1], bits[index+2]) == colorKey)
				continue;
			// ���� �ռ�
			bits[index] = (UINT8)(bits[index] * srcRate) + b;
			++index;
			bits[index] = (UINT8)(bits[index] * srcRate) + g;
			++index;
			bits[index] = (UINT8)(bits[index] * srcRate) + r;
		}
	}
}



CTexture::CTexture() {
	SetTypeID<CTexture>();
}

CTexture::~CTexture() {
	size_t	size = mVecImageInfo.size();
	for (size_t i = 0; i < size; ++i) {
		SAFE_DELETE(mVecImageInfo[i]);
	}
}


bool CTexture::LoadTextureWithDIB(const TCHAR* fileName, const std::string& pathName) {
	TCHAR fullPath[MAX_PATH] = {};
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);
	if (path)
		lstrcpy(fullPath, path->path);
	lstrcat(fullPath, fileName);

	HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());

	// ��Ʈ���� �ε��Ѵ�.
	HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
									  fullPath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	if (!hBmp)
		return false;

	HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);
	BITMAP	bmpInfo;
	GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

	ImageInfo* info = new ImageInfo;
	info->hMemDC = hdc;
	info->hBmp = hBmp;
	info->hPrevBmp = hPrevBmp;
	info->bmpInfo = bmpInfo;

	mVecImageInfo.push_back(info);

	return true;
}
bool CTexture::LoadTextureWithDIB(const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);
	size_t	size = vecFileName.size();

	std::vector<std::wstring>	vecFullPath(size);
	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	mType = ETexture_Type::Frame; // ���� ���� �̹����� ���ÿ� ������ Ÿ���̴�.

	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, 
										  LR_LOADFROMFILE | LR_CREATEDIBSECTION);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);
		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = new ImageInfo;
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->bmpInfo = bmpInfo;

		mVecImageInfo.push_back(info);
	}

	return true;
}


bool CTexture::LoadTexture(const TCHAR* fileName, const std::string& pathName) {
	TCHAR fullPath[MAX_PATH] = {};

	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);
	if (path)
		lstrcpy(fullPath, path->path);

	lstrcat(fullPath, fileName);

	return LoadTextureFullPath(fullPath);
}
bool CTexture::LoadTextureFullPath(const TCHAR* fullPath) {
	// ȭ��DC�� �ְ� �޸� DC�� ��´�.
	HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());

	// ��Ʈ���� �ε��Ѵ�.
	HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
									  fullPath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (!hBmp)
		return false;

	// �о�� ��Ʈ���� �޸� DC�� �����Ѵ�.
	// ������ DC�� ������ �ִ� ������ ��ȯ�Ѵ�.
	HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

	BITMAP	bmpInfo;
	GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

	ImageInfo* info = new ImageInfo;
	info->hMemDC	= hdc;
	info->hBmp		= hBmp;
	info->hPrevBmp	= hPrevBmp;
	info->bmpInfo	= bmpInfo;

	mVecImageInfo.push_back(info);

	return true;
}

#ifdef UNICODE

bool CTexture::LoadTexture(const std::vector<std::wstring>& vecFileName, 
						   const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);

	size_t	size = vecFileName.size();
	// (����) �����ڴ� �ش� ������ŭ resize �س��´�. reserve�� �ƴ�!
	std::vector<std::wstring>	vecFullPath(size);

	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	return LoadTextureFullPath(vecFullPath);
}
bool CTexture::LoadTextureFullPath(const std::vector<std::wstring>& vecFullPath) {
	mType = ETexture_Type::Frame; // ���� ���� �̹����� ���ÿ� ������ Ÿ���̴�.

	size_t	size = vecFullPath.size();
	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = new ImageInfo;
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->bmpInfo = bmpInfo;

		mVecImageInfo.push_back(info);
	}

	return true;
}

#else

bool CTexture::LoadTexture(const std::vector<std::string>& vecFileName, const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);

	size_t size = vecFileName.size();
	std::vector<std::string> vecFullPath(size);

	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	return LoadTextureFullPath(vecFullPath);
}
bool CTexture::LoadTextureFullPath(const std::vector<std::string>& vecFullPath) {
	mType = ETexture_Type::Frame;

	size_t	size = vecFullPath.size();
	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = new ImageInfo;
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->bmpInfo = bmpInfo;

		mVecImageInfo.push_back(info);
	}

	return true;
}

#endif // UNICODE
