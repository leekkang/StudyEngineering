
#include "Texture.h"

#include "../../GameManager.h"
#include "../../PathManager.h"



void ImageInfo::InitAlphaBlend() {
	enableAlpha = true;
	HDC hdc = CGameManager::GetInst()->GetWindowDC();
	hAlphaDC = CreateCompatibleDC(hdc);
	hBmpAlpha = CreateCompatibleBitmap(hdc, (int)bmpInfo.bmWidth, (int)bmpInfo.bmHeight);
	hBmpAlphaOld = (HBITMAP)SelectObject(hAlphaDC, hBmpAlpha);
}

void ImageInfo::MixColor(UINT8 mixValue, UINT8 r, UINT8 g, UINT8 b, int sizeX, int sizeY, int left, int top) {
	bModulated = true;
	UINT8* bits = (UINT8*)bmpInfo.bmBits;

	int pixelSize = (int)(bmpInfo.bmBitsPixel * 0.125f);
	int startY = bmpInfo.bmHeight - (top + sizeY);
	int endX = min(bmpInfo.bmWidth, left + sizeX);
	int endY = min(bmpInfo.bmHeight, startY + sizeY);
	float srcRate = (255 - mixValue) / 255.f;
	float destRate = mixValue / 255.f;
	r = (UINT8)(r * destRate);
	g = (UINT8)(g * destRate);
	b = (UINT8)(b * destRate);

	int index = 0;
	for (int i = startY; i < endY; ++i) {
		for (int j = left; j < endX; ++j) {
			index = i * bmpInfo.bmWidthBytes + j * pixelSize;
			if (RGB(bits[index], bits[index+1], bits[index+2]) == colorKey)
				continue;
			// ���� �ռ�
			bits[index] = (UINT8)(bits[index] * srcRate) + b;
			++index;
			bits[index] = (UINT8)(bits[index] * srcRate) + g;
			++index;
			bits[index] = (UINT8)(bits[index] * srcRate) + r;
		}
	}
}



CTexture::CTexture() {
	SetTypeID<CTexture>();
}

CTexture::~CTexture() {
	size_t	size = mVecImageInfo.size();
	for (size_t i = 0; i < size; ++i) {
		SAFE_DELETE(mVecImageInfo[i]);
	}
}


bool CTexture::LoadTextureWithDIB(const TCHAR* fileName, const std::string& pathName) {
	TCHAR fullPath[MAX_PATH] = {};
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);
	if (path)
		lstrcpy(fullPath, path->path);
	lstrcat(fullPath, fileName);

	HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());

	// ��Ʈ���� �ε��Ѵ�.
	HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
									  fullPath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	if (!hBmp)
		return false;

	HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);
	BITMAP	bmpInfo;
	GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

	ImageInfo* info = new ImageInfo;
	info->hMemDC = hdc;
	info->hBmp = hBmp;
	info->hPrevBmp = hPrevBmp;
	info->bmpInfo = bmpInfo;

	mVecImageInfo.push_back(info);

	return true;
}
bool CTexture::LoadTextureWithDIB(const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);
	size_t	size = vecFileName.size();

	std::vector<std::wstring>	vecFullPath(size);
	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	mType = ETexture_Type::Frame; // ���� ���� �̹����� ���ÿ� ������ Ÿ���̴�.

	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, 
										  LR_LOADFROMFILE | LR_CREATEDIBSECTION);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);
		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = new ImageInfo;
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->bmpInfo = bmpInfo;

		mVecImageInfo.push_back(info);
	}

	return true;
}


bool CTexture::LoadTexture(const TCHAR* fileName, const std::string& pathName) {
	TCHAR fullPath[MAX_PATH] = {};

	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);
	if (path)
		lstrcpy(fullPath, path->path);

	lstrcat(fullPath, fileName);

	bool result = LoadTextureFullPath(fullPath);
	if (result) {
		lstrcpy(mVecImageInfo.back()->fileName, fileName);
		mVecImageInfo.back()->pathName = pathName;
	}

	return result;
}
bool CTexture::LoadTextureFullPath(const TCHAR* fullPath) {
	// ȭ��DC�� �ְ� �޸� DC�� ��´�.
	HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());

	// ��Ʈ���� �ε��Ѵ�.
	HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
									  fullPath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (!hBmp)
		return false;

	// �о�� ��Ʈ���� �޸� DC�� �����Ѵ�.
	// ������ DC�� ������ �ִ� ������ ��ȯ�Ѵ�.
	HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

	BITMAP	bmpInfo;
	GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

	ImageInfo* info = new ImageInfo;
	info->hMemDC	= hdc;
	info->hBmp		= hBmp;
	info->hPrevBmp	= hPrevBmp;
	info->bmpInfo	= bmpInfo;
	lstrcpy(info->fullPath, fullPath);

	mVecImageInfo.push_back(info);

	return true;
}

#ifdef UNICODE

bool CTexture::LoadTexture(const std::vector<std::wstring>& vecFileName, 
						   const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);

	size_t	size = vecFileName.size();
	// (����) �����ڴ� �ش� ������ŭ resize �س��´�. reserve�� �ƴ�!
	std::vector<std::wstring>	vecFullPath(size);

	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	bool result = LoadTextureFullPath(vecFullPath);
	if (result) {
		for (size_t i = 0; i < size; ++i) {
			lstrcpy(mVecImageInfo[i]->fileName, vecFileName[i].c_str());
			mVecImageInfo[i]->pathName = pathName;
		}
	}

	return result;
}
bool CTexture::LoadTextureFullPath(const std::vector<std::wstring>& vecFullPath) {
	mType = ETexture_Type::Frame; // ���� ���� �̹����� ���ÿ� ������ Ÿ���̴�.

	size_t	size = vecFullPath.size();
	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = new ImageInfo;
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->bmpInfo = bmpInfo;
		lstrcpy(info->fullPath, vecFullPath[i].c_str());

		mVecImageInfo.push_back(info);
	}

	return true;
}

#else

bool CTexture::LoadTexture(const std::vector<std::string>& vecFileName, const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);

	size_t size = vecFileName.size();
	std::vector<std::string> vecFullPath(size);

	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	return LoadTextureFullPath(vecFullPath);
}
bool CTexture::LoadTextureFullPath(const std::vector<std::string>& vecFullPath) {
	mType = ETexture_Type::Frame;

	size_t	size = vecFullPath.size();
	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = new ImageInfo;
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->bmpInfo = bmpInfo;

		mVecImageInfo.push_back(info);
	}

	return true;
}

#endif // UNICODE

bool CTexture::LoadTexture(ImageInfo* info, const TCHAR* fileName, const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);
	TCHAR	fullPath[MAX_PATH] = {};

	if (path)
		lstrcpy(fullPath, path->path);

	lstrcat(fullPath, fileName);

	bool result = LoadTextureFullPath(info, fullPath);
	if (result) {
		lstrcpy(mVecImageInfo.back()->fileName, fileName);
		mVecImageInfo.back()->pathName = pathName;
	}

	return result;
}
bool CTexture::LoadTextureFullPath(ImageInfo* info, const TCHAR* fullPath) {
	// ȭ��DC�� �ְ� �޸� DC�� ��´�.
	HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());

	// ��Ʈ���� �ε��Ѵ�.
	HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
									  fullPath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (!hBmp)
		return false;

	// �о�� ��Ʈ���� �޸� DC�� �����Ѵ�.
	// ������ DC�� ������ �ִ� ������ ��ȯ�Ѵ�.
	HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

	BITMAP	bmpInfo;
	GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

	info->hMemDC = hdc;
	info->hBmp = hBmp;
	info->hPrevBmp = hPrevBmp;
	info->bmpInfo = bmpInfo;
	lstrcpy(info->fullPath, fullPath);

	return true;
}

#ifdef UNICODE

bool CTexture::LoadTexture(std::vector<ImageInfo*>* vecInfo, const std::vector<std::wstring>& vecFileName, 
						   const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);

	size_t	size = vecFileName.size();
	// (����) �����ڴ� �ش� ������ŭ resize �س��´�. reserve�� �ƴ�!
	std::vector<std::wstring>	vecFullPath(size);

	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	bool result = LoadTextureFullPath(vecInfo, vecFullPath);
	if (result) {
		for (size_t i = 0; i < size; ++i) {
			lstrcpy(mVecImageInfo[i]->fileName, vecFileName[i].c_str());
			mVecImageInfo[i]->pathName = pathName;
		}
	}

	return result;
}
bool CTexture::LoadTextureFullPath(std::vector<ImageInfo*>* vecInfo, const std::vector<std::wstring>& vecFullPath) {
	mType = ETexture_Type::Frame; // ���� ���� �̹����� ���ÿ� ������ Ÿ���̴�.

	size_t	size = vecFullPath.size();
	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = *(vecInfo->begin() + i);
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->bmpInfo = bmpInfo;
		lstrcpy(info->fullPath, vecFullPath[i].c_str());
	}

	return true;
}

#else

bool CTexture::LoadTexture(std::vector<ImageInfo*>* vecInfo, const std::vector<std::string>& vecFileName,
						   const std::string& pathName) {
	const PathInfo* path = CPathManager::GetInst()->FindPath(pathName);

	size_t size = vecFileName.size();
	std::vector<std::string> vecFullPath(size);

	for (size_t i = 0; i < size; ++i) {
		if (path)
			vecFullPath[i] = path->path;

		vecFullPath[i] += vecFileName[i];
	}

	return LoadTextureFullPath(vecInfo, vecFullPath);
}

bool CTexture::LoadTextureFullPath(std::vector<ImageInfo*>* vecInfo, const std::vector<std::string>& vecFullPath) {
	mType = ETexture_Type::Frame;

	size_t	size = vecFullPath.size();
	for (size_t i = 0; i < size; ++i) {
		HDC	hdc = CreateCompatibleDC(CGameManager::GetInst()->GetWindowDC());
		HBITMAP	hBmp = (HBITMAP)LoadImage(CGameManager::GetInst()->GetWindowInstance(),
										  vecFullPath[i].c_str(), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (!hBmp)
			return false;

		HBITMAP hPrevBmp = (HBITMAP)SelectObject(hdc, hBmp);

		BITMAP	bmpInfo;
		GetObject(hBmp, sizeof(BITMAP), &bmpInfo);

		ImageInfo* info = *(vecInfo->begin() + i);
		info->hMemDC = hdc;
		info->hBmp = hBmp;
		info->hPrevBmp = hPrevBmp;
		info->bmpInfo = bmpInfo;
	}

	return true;
}

#endif // UNICODE


void CTexture::Save(FILE* file) {
	CRef::Save(file);

	fwrite(&mType, sizeof(ETexture_Type), 1, file);

	int	count = (int)mVecImageInfo.size();
	fwrite(&count, sizeof(int), 1, file);
	TCHAR	folderName[8] = {};
	lstrcpy(folderName, TEXT("Texture"));
	for (int i = 0; i < count; ++i) {
		fwrite(&mVecImageInfo[i]->enableColorKey, sizeof(bool), 1, file);
		fwrite(&mVecImageInfo[i]->colorKey, sizeof(COLORREF), 1, file);

		if (lstrlen(mVecImageInfo[i]->fileName) == 0) {
			int	length = lstrlen(mVecImageInfo[i]->fullPath);
			for (int j = length - 1; j >= 0; --j) {
				if (mVecImageInfo[i]->fullPath[j] == '\\' || mVecImageInfo[i]->fullPath[j] == '/') {
					bool find = true;
					for (int k = 0; k < 7; ++k) {
						if (folderName[6 - k] != mVecImageInfo[i]->fullPath[j - k - 1]) {
							find = false;
							break;
						}
					}
					if (find) {
						lstrcpy(mVecImageInfo[i]->fileName, &mVecImageInfo[i]->fullPath[j + 1]);
					}

					break;
				}
			}
			mVecImageInfo[i]->pathName = TEXTURE_PATH;
		}
		fwrite(&mVecImageInfo[i]->fileName, sizeof(TCHAR), MAX_PATH, file);
		fwrite(&mVecImageInfo[i]->fullPath, sizeof(TCHAR), MAX_PATH, file);

		int length = (int)mVecImageInfo[i]->pathName.length();
		fwrite(&length, sizeof(int), 1, file);
		fwrite(mVecImageInfo[i]->pathName.c_str(), sizeof(char), length, file);
	}
}

void CTexture::Load(FILE* file) {
	CRef::Load(file);

	fread(&mType, sizeof(ETexture_Type), 1, file);

	int	count = 0;
	fread(&count, sizeof(int), 1, file);
	for (int i = 0; i < count; ++i) {
		ImageInfo* info = new ImageInfo;

		fread(&info->enableColorKey, sizeof(bool), 1, file);
		fread(&info->colorKey, sizeof(COLORREF), 1, file);

		fread(&info->fileName, sizeof(TCHAR), MAX_PATH, file);
		fread(&info->fullPath, sizeof(TCHAR), MAX_PATH, file);

		int length = 0;
		char pathName[256] = {};
		fread(&length, sizeof(int), 1, file);
		fread(pathName, sizeof(char), length, file);
		info->pathName = pathName;

		mVecImageInfo.push_back(info);
	}

	if (mVecImageInfo.size() == 1) {
		if (lstrlen(mVecImageInfo[0]->fileName) > 0)
			LoadTexture(mVecImageInfo[0], mVecImageInfo[0]->fileName, mVecImageInfo[0]->pathName);

		else
			LoadTextureFullPath(mVecImageInfo[0], mVecImageInfo[0]->fullPath);
	} else {
		if (lstrlen(mVecImageInfo[0]->fileName) > 0) {
			std::vector<std::wstring> vecFileName;

			size_t	size = mVecImageInfo.size();
			for (size_t i = 0; i < size; ++i) {
				vecFileName.push_back(mVecImageInfo[i]->fileName);
			}
			LoadTexture(&mVecImageInfo, vecFileName, mVecImageInfo[0]->pathName);
		} else {
			std::vector<std::wstring> vecFileName;

			size_t size = mVecImageInfo.size();

			for (size_t i = 0; i < size; ++i) {
				vecFileName.push_back(mVecImageInfo[i]->fullPath);
			}
			LoadTextureFullPath(&mVecImageInfo, vecFileName);
		}
	}
}