
#include "ResourceManager.h"
#include "Texture/TextureManager.h"
#include "Animation/AnimationManager.h"
#include "Sound/SoundManager.h"
#include "Font/FontManager.h"

DEFINITION_SINGLE(CResourceManager)

CResourceManager::CResourceManager() {
	mTextureManager = new CTextureManager;
	mTextureManager->Init();

	mAnimationManager = new CAnimationManager;
	mAnimationManager->Init();

	mSoundManager = new CSoundManager;
	mSoundManager->Init();

	mFontManager = new CFontManager;
	mFontManager->Init();
}

CResourceManager::~CResourceManager() {
	SAFE_DELETE(mFontManager);
	SAFE_DELETE(mSoundManager);
	SAFE_DELETE(mAnimationManager);
	SAFE_DELETE(mTextureManager);
}

bool CResourceManager::Init() {
	return true;
}

void CResourceManager::Update() {
	mSoundManager->Update();
}

bool CResourceManager::LoadTextureWithDIB(const std::string& name, const TCHAR* fileName) {
	return mTextureManager->LoadTextureWithDIB(name, fileName);
}

bool CResourceManager::LoadTextureWithDIB(const std::string& name, const std::vector<std::wstring>& vecFileName) {
	return mTextureManager->LoadTextureWithDIB(name, vecFileName);
}

bool CResourceManager::CreateAnimSeqWithDIB(const std::string& name, const std::string& textureName, const TCHAR* fileName) {
	CTexture* texture = FindTexture(textureName);
	if (texture)
		return mAnimationManager->CreateAnimationSequence(name, texture);
	if (!mTextureManager->LoadTextureWithDIB(textureName, fileName))
		return false;
	texture = FindTexture(textureName);
	return mAnimationManager->CreateAnimationSequence(name, texture);
}

bool CResourceManager::CreateAnimSeqWithDIB(const std::string& name, const std::string& textureName, const std::vector<std::wstring>& vecFileName) {
	CTexture* texture = FindTexture(textureName);
	if (texture)
		return mAnimationManager->CreateAnimationSequence(name, texture);
	if (!mTextureManager->LoadTextureWithDIB(textureName, vecFileName))
		return false;
	texture = FindTexture(textureName);
	return mAnimationManager->CreateAnimationSequence(name, texture);
}



bool CResourceManager::LoadTexture(const std::string& name, const TCHAR* fileName, const std::string& pathName) {
	return mTextureManager->LoadTexture(name, fileName, pathName);
}
bool CResourceManager::LoadTextureFullPath(const std::string& name, const TCHAR* fullPath) {
	return mTextureManager->LoadTextureFullPath(name, fullPath);
}

#ifdef UNICODE

bool CResourceManager::LoadTexture(const std::string& name,
								   const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	return mTextureManager->LoadTexture(name, vecFileName, pathName);
}
bool CResourceManager::LoadTextureFullPath(const std::string& name,
										   const std::vector<std::wstring>& vecFullPath) {
	return mTextureManager->LoadTextureFullPath(name, vecFullPath);
}

#else

bool CResourceManager::LoadTexture(const std::string& name,
								   const std::vector<std::string>& vecFileName, const std::string& pathName) {
	return mTextureManager->LoadTexture(name, vecFileName, pathName);
}
bool CResourceManager::LoadTextureFullPath(const std::string& name,
										   const std::vector<std::string>& vecFullPath) {
	return mTextureManager->LoadTextureFullPath(name, vecFullPath);
}

#endif

void CResourceManager::SetColorKey(const std::string& name, unsigned char r, unsigned char g, unsigned char b, int index) {
	mTextureManager->SetColorKey(name, r, g, b, index);
}
void CResourceManager::SetColorKeyAll(const std::string& name, unsigned char r, unsigned char g, unsigned char b) {
	mTextureManager->SetColorKeyAll(name, r, g, b);
}

CTexture* CResourceManager::FindTexture(const std::string& name) {
	return mTextureManager->FindTexture(name);
}
void CResourceManager::ReleaseTexture(const std::string& name) {
	mTextureManager->ReleaseTexture(name);
}



bool CResourceManager::CreateAnimationSequence(const std::string& name, CTexture* texture) {
	return mAnimationManager->CreateAnimationSequence(name, texture);
}
bool CResourceManager::CreateAnimationSequence(const std::string& name, const std::string& textureName) {
	CTexture* texture = FindTexture(textureName);
	return mAnimationManager->CreateAnimationSequence(name, texture);
}

bool CResourceManager::CreateAnimationSequence(const std::string& name, const std::string& textureName,
											   const TCHAR* fileName, const std::string& pathName) {
	CTexture* texture = FindTexture(textureName);
	// ���� �̸����� �߰��Ǿ� ���� ��� �ٷ� ó��
	if (texture)
		return mAnimationManager->CreateAnimationSequence(name, texture);

	// ���� �̸��� �ؽ��İ� ���� ��� �ε��ϰ� ó��
	if (!mTextureManager->LoadTexture(textureName, fileName, pathName))
		return false;

	texture = FindTexture(textureName);
	return mAnimationManager->CreateAnimationSequence(name, texture);
}
bool CResourceManager::CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName, 
													   const TCHAR* fullPath) {
	CTexture* texture = FindTexture(textureName);
	if (texture)
		return mAnimationManager->CreateAnimationSequence(name, texture);

	if (!mTextureManager->LoadTextureFullPath(textureName, fullPath))
		return false;

	texture = FindTexture(textureName);
	return mAnimationManager->CreateAnimationSequence(name, texture);
}

#ifdef UNICODE

bool CResourceManager::CreateAnimationSequence(const std::string& name, const std::string& textureName, 
											   const std::vector<std::wstring>& vecFileName, const std::string& pathName) {
	CTexture* texture = FindTexture(textureName);
	if (texture)
		return mAnimationManager->CreateAnimationSequence(name, texture);

	if (!mTextureManager->LoadTexture(textureName, vecFileName, pathName))
		return false;

	texture = FindTexture(textureName);
	return mAnimationManager->CreateAnimationSequence(name, texture);
}

bool CResourceManager::CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName, 
													   const std::vector<std::wstring>& vecFullPath) {
	CTexture* texture = FindTexture(textureName);
	if (texture)
		return mAnimationManager->CreateAnimationSequence(name, texture);

	if (!mTextureManager->LoadTextureFullPath(textureName, vecFullPath))
		return false;

	texture = FindTexture(textureName);
	return mAnimationManager->CreateAnimationSequence(name, texture);
}

#else

bool CResourceManager::CreateAnimationSequence(const std::string& name, const std::string& textureName, 
											   const std::vector<std::string>& vecFileName, const std::string& pathName) {
	CTexture* texture = FindTexture(textureName);
	if (texture)
		return mAnimationManager->CreateAnimationSequence(name, texture);

	if (!mTextureManager->LoadTexture(textureName, vecFileName, pathName))
		return false;

	texture = FindTexture(textureName);
	return mAnimationManager->CreateAnimationSequence(name, texture);
}

bool CResourceManager::CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName, 
													   const std::vector<std::string>& vecFullPath) {
	CTexture* texture = FindTexture(textureName);
	if (texture)
		return mAnimationManager->CreateAnimationSequence(name, texture);

	if (!mTextureManager->LoadTextureFullPath(textureName, vecFullPath))
		return false;

	texture = FindTexture(textureName);
	return mAnimationManager->CreateAnimationSequence(name, texture);
}

#endif

void CResourceManager::AddAnimationFrame(const std::string& name, const Vector2& start, const Vector2& end) {
	mAnimationManager->AddAnimationFrame(name, start, end);
}
void CResourceManager::AddAnimationFrame(const std::string& name, float posX, float posY, float sizeX, float sizeY) {
	mAnimationManager->AddAnimationFrame(name, posX, posY, sizeX, sizeY);
}
void CResourceManager::AddAnimationFullFrame(const std::string& name, const Vector2& size, int xNum, int yNum) {
	mAnimationManager->AddAnimationFullFrame(name, size, xNum, yNum);
}

CAnimationSequence* CResourceManager::FindAnimationSeq(const std::string& name) {
	return mAnimationManager->FindAnimationSeq(name);
}
void CResourceManager::ReleaseAnimation(const std::string& name) {
	mAnimationManager->ReleaseAnimation(name);
}



bool CResourceManager::CreateSoundChannel(ESound_Group type) {
	return mSoundManager->CreateSoundChannel(type);
}

bool CResourceManager::LoadSound(ESound_Group type, const std::string& name, bool loop, const char* fileName, const std::string& pathName) {
	return mSoundManager->LoadSound(type, name, loop, fileName, pathName);
}

void CResourceManager::SetMasterVolume(int volume) {
	mSoundManager->SetMasterVolume(volume);
}
void CResourceManager::SetVolume(ESound_Group type, int volume) {
	mSoundManager->SetVolume(type, volume);
}

bool CResourceManager::SoundPlay(const std::string& name) {
	return mSoundManager->SoundPlay(name);
}
bool CResourceManager::SoundStop(const std::string& name) {
	return mSoundManager->SoundStop(name);
}
bool CResourceManager::SoundPause(const std::string& name) {
	return mSoundManager->SoundPause(name);
}
bool CResourceManager::SoundResume(const std::string& name) {
	return mSoundManager->SoundResume(name);
}

FMOD::ChannelGroup* CResourceManager::FindChannelGroup(ESound_Group type) {
	return mSoundManager->FindChannelGroup(type);
}

CSound* CResourceManager::FindSound(const std::string& name) {
	return mSoundManager->FindSound(name);
}

void CResourceManager::ReleaseSound(const std::string& name) {
	mSoundManager->ReleaseSound(name);
}



bool CResourceManager::LoadFont(const std::string& name, const TCHAR* fontName, int width, int height) {
	return mFontManager->LoadFont(name, fontName, width, height);
}
bool CResourceManager::LoadFont(const TCHAR* fontFileName, const std::string& pathName) {
	return mFontManager->LoadFont(fontFileName, pathName);
}
void CResourceManager::SetFont(const std::string& name, HDC hdc) {
	mFontManager->SetFont(name, hdc);
}
void CResourceManager::ResetFont(const std::string& name, HDC hdc) {
	mFontManager->ResetFont(name, hdc);
}
CFont* CResourceManager::FindFont(const std::string& name) {
	return mFontManager->FindFont(name);
}
void CResourceManager::ReleaseFont(const std::string& name) {
	mFontManager->ReleaseFont(name);
}
