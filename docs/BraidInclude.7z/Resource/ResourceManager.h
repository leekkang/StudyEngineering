#pragma once

#include "../SingletonMacro.h"
#include "../GameInfo.h"

class CResourceManager {
	DECLARE_SINGLE(CResourceManager)

private:
	class CTextureManager*	 mTextureManager;
	class CAnimationManager* mAnimationManager;
	class CSoundManager*	 mSoundManager;
	class CFontManager*		 mFontManager;

public:
	bool Init();
	void Update();


public:
	bool LoadTextureWithDIB(const std::string& name, const TCHAR* fileName);
	bool LoadTextureWithDIB(const std::string& name, const std::vector<std::wstring>& vecFileName);
	bool CreateAnimSeqWithDIB(const std::string& name, const std::string& textureName, const TCHAR* fileName);
	bool CreateAnimSeqWithDIB(const std::string& name, const std::string& textureName,
								 const std::vector<std::wstring>& vecFileName);


public:	// ==================== texture ====================
	// ETexture_Type::Sprite
	bool LoadTexture(const std::string& name, const TCHAR* fileName,
					 const std::string& pathName = TEXTURE_PATH);
	bool LoadTextureFullPath(const std::string& name, const TCHAR* fullPath);

#ifdef UNICODE
	// ETexture_Type::Frame
	bool LoadTexture(const std::string& name, const std::vector<std::wstring>& vecFileName,
					 const std::string& pathName = TEXTURE_PATH);
	bool LoadTextureFullPath(const std::string& name, const std::vector<std::wstring>& vecFullPath);

#else
	// ETexture_Type::Frame
	bool LoadTexture(const std::string& name, const std::vector<std::string>& vecFileName,
					 const std::string& pathName = TEXTURE_PATH);
	bool LoadTextureFullPath(const std::string& name, const std::vector<std::string>& vecFullPath);

#endif // UNICODE

	class CTexture* LoadTexture(FILE* file);

	// ETexture_Type::Sprite
	void SetColorKey(const std::string& name, unsigned char r, unsigned char g, unsigned char b, int Index = 0);
	// ETexture_Type::Frame
	void SetColorKeyAll(const std::string& name, unsigned char r, unsigned char g, unsigned char b);

	class CTexture* FindTexture(const std::string& name);
	void ReleaseTexture(const std::string& name);



public:	// ==================== Animation Sequence ====================
	bool CreateAnimationSequence(const std::string& name, class CTexture* texture);
	bool CreateAnimationSequence(const std::string& name, const std::string& textureName);
	// ETexture_Type::Sprite
	bool CreateAnimationSequence(const std::string& name, const std::string& textureName,
									const TCHAR* fileName, const std::string& pathName = TEXTURE_PATH);
	bool CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName, const TCHAR* fullPath);

#ifdef UNICODE
	// ETexture_Type::Frame
	bool CreateAnimationSequence(const std::string& name, const std::string& textureName,
								 const std::vector<std::wstring>& vecFileName, const std::string& pathName = TEXTURE_PATH);
	bool CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName,
										 const std::vector<std::wstring>& vecFullPath);
#else
	// ETexture_Type::Frame
	bool CreateAnimationSequence(const std::string& name, const std::string& textureName,
								 const std::vector<std::string>& vecFileName, const std::string& pathName = TEXTURE_PATH);
	bool CreateAnimationSequenceFullPath(const std::string& name, const std::string& textureName,
										 const std::vector<std::string>& vecFullPath);

#endif // UNICODE

	void AddAnimationFrame(const std::string& name, const Vector2& start, const Vector2& end);
	void AddAnimationFrame(const std::string& name, float posX, float posY, float sizeX, float sizeY);
	// ��� ������ ����� ���� �� ���
	void AddAnimationFullFrame(const std::string& name, const Vector2& size, int xNum, int yNum);

	class CAnimationSequence* FindAnimationSeq(const std::string& name);
	void ReleaseAnimation(const std::string& name);



public:	// ==================== Animation Sequence ====================
	bool CreateSoundChannel(ESound_Group type);
	bool LoadSound(ESound_Group type, const std::string& name,
				   bool loop, const char* fileName, const std::string& pathName = SOUND_PATH);

	void SetMasterVolume(int volume);
	void SetVolume(ESound_Group type, int volume);

	bool SoundPlay(const std::string& name);
	bool SoundStop(const std::string& name);
	bool SoundPause(const std::string& name);
	bool SoundResume(const std::string& name);


	FMOD::ChannelGroup* FindChannelGroup(ESound_Group type);
	class CSound* FindSound(const std::string& name);
	void ReleaseSound(const std::string& name);



public: // ==================== Font ====================
	bool LoadFont(const std::string& name, const TCHAR* fontName, int width, int height);
	bool LoadFont(const TCHAR* fontFileName, const std::string& pathName = FONT_PATH);
	void SetFont(const std::string& name, HDC hdc);
	void ResetFont(const std::string& name, HDC hdc);
	class CFont* FindFont(const std::string& name);
	void ReleaseFont(const std::string& name);
};

