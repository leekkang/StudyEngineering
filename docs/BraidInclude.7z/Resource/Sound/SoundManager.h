#pragma once

#include "../../GameInfo.h"

class CSoundManager
{
	friend class CResourceManager;

private:
	CSoundManager();
	~CSoundManager();

private:
	FMOD::System* mSystem			 = nullptr;
	FMOD::ChannelGroup*	mMasterGroup = nullptr;

	std::unordered_map<std::string, CSharedPtr<class CSound>> mMapSound;
	std::unordered_map<ESound_Group, FMOD::ChannelGroup*>     mMapChannelGroup;

private:
	// ESound_Group �� �̸�
	const char* mGroupName[4]{"Master", "BGM", "Effect", "UI"};

public:
	bool Init();
	void Update();
	bool CreateSoundChannel(ESound_Group type);
	bool LoadSound(ESound_Group type, const std::string& name, bool loop, bool makeReverse,
				   const char* fileName, const char* extension, const std::string& pathName = SOUND_PATH);

	void SetMasterVolume(int volume);
	void SetVolume(ESound_Group type, int volume);

	bool SoundPlay(const std::string& name);
	bool SoundStop(const std::string& name);
	bool SoundPause(const std::string& name);
	bool SoundResume(const std::string& name);

	void SetAllSoundPause();
	void SetAllSoundResume();


	FMOD::ChannelGroup* FindChannelGroup(ESound_Group type);
	class CSound* FindSound(const std::string& name);
	void ReleaseSound(const std::string& name);
};

