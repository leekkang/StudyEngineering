
#include "SoundManager.h"
#include "sound.h"

CSoundManager::CSoundManager() {
}

CSoundManager::~CSoundManager() {
	mMapSound.clear();

	auto	iter = mMapChannelGroup.begin();
	auto	iterEnd = mMapChannelGroup.end();
	for (; iter != iterEnd; ++iter) {
		iter->second->release();
	}

	if (mSystem) {
		mSystem->release();
		mSystem->close();
	}
}

bool CSoundManager::Init() {
	// FMOD_RESULT : FMOD���� �����ϴ� Ÿ��. FMOD�� ����� ����Ҷ� �Լ��� ���� ���и� �˱� ���� Ÿ���̴�.
	FMOD_RESULT result = FMOD::System_Create(&mSystem);
	if (result != FMOD_OK)
		return false;

	result = mSystem->init(500, FMOD_INIT_NORMAL, nullptr);
	if (result != FMOD_OK)
		return false;

	result = mSystem->getMasterChannelGroup(&mMasterGroup);
	if (result != FMOD_OK)
		return false;

	mMapChannelGroup.insert(std::make_pair(ESound_Group::Master, mMasterGroup));

	CreateSoundChannel(ESound_Group::BGM);
	CreateSoundChannel(ESound_Group::Effect);
	CreateSoundChannel(ESound_Group::UI);

	return true;
}

void CSoundManager::Update() {
	mSystem->update();

	//// ���� ���� ���� ó��
	//auto iter = mMapSound.begin();
	//auto iterEnd = mMapSound.end();
	//for (; iter != iterEnd; ++iter) {
	//	iter->second->Reset();
	//}
}

bool CSoundManager::CreateSoundChannel(ESound_Group type) {
	if (FindChannelGroup(type))
		return false;

	FMOD::ChannelGroup* group = nullptr;
	FMOD_RESULT	result = mSystem->createChannelGroup(mGroupName[(int)type], &group);
	if (result != FMOD_OK)
		return false;

	// ������ �׷��� ������ �׷쿡 �߰����ش�.
	mMasterGroup->addGroup(group, false);

	mMapChannelGroup.insert(std::make_pair(type, group));
	return true;
}

bool CSoundManager::LoadSound(ESound_Group type, const std::string& name, bool loop, bool makeReverse,
							  const char* fileName, const char* extension, const std::string& pathName) {
	CSound* sound = FindSound(name);
	if (sound)
		return true;

	FMOD::ChannelGroup* group = FindChannelGroup(type);
	if (!group)
		return false;

	sound = new CSound;
	sound->SetName(name);

	if (!sound->LoadSound(mSystem, group, loop, makeReverse, fileName, extension, pathName)) {
		SAFE_DELETE(sound);
		return false;
	}

	mMapSound.insert(std::make_pair(name, sound));
	return true;
}


void CSoundManager::SetMasterVolume(int volume) {
	mMasterGroup->setVolume(volume / 100.f);
}

void CSoundManager::SetVolume(ESound_Group type, int volume) {
	FMOD::ChannelGroup* group = FindChannelGroup(type);
	if (group)
		group->setVolume(volume / 100.f);
}

bool CSoundManager::SoundPlay(const std::string& name) {
	CSound* sound = FindSound(name);
	if (!sound)
		return false;

	sound->Play();
	return true;
}

bool CSoundManager::SoundStop(const std::string& name) {
	CSound* sound = FindSound(name);
	if (!sound)
		return false;

	sound->Stop();
	return true;
}

bool CSoundManager::SoundPause(const std::string& name) {
	CSound* sound = FindSound(name);
	if (!sound)
		return false;

	sound->Pause();
	return true;
}

bool CSoundManager::SoundResume(const std::string& name) {
	CSound* sound = FindSound(name);
	if (!sound)
		return false;

	sound->Resume();
	return true;
}

bool CSoundManager::SoundChangeSpeed(const std::string& name, int speed) {
	CSound* sound = FindSound(name);
	if (!sound)
		return false;

	sound->ChangeSpeed(speed);
	return true;
}


FMOD::ChannelGroup* CSoundManager::FindChannelGroup(ESound_Group type) {
	auto iter = mMapChannelGroup.find(type);
	if (iter == mMapChannelGroup.end())
		return nullptr;

	return iter->second;
}

CSound* CSoundManager::FindSound(const std::string& name) {
	auto iter = mMapSound.find(name);
	if (iter == mMapSound.end())
		return nullptr;

	return iter->second;
}

void CSoundManager::ReleaseSound(const std::string& name) {
	auto iter = mMapSound.find(name);
	if (iter == mMapSound.end())
		return;

	if (iter->second->GetRefCount() == 1)
		mMapSound.erase(iter);
}
