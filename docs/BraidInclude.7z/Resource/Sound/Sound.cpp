
#include "Sound.h"
#include "../../PathManager.h"

CSound::CSound() {
	SetTypeID<CSound>();
}

CSound::~CSound() {
	if (mSound) {
		mSound->release();
	}
	if (mReverseSound) {
		mReverseSound->release();
	}
}

bool CSound::LoadSound(FMOD::System* system, FMOD::ChannelGroup* group, bool loop, bool makeReverse,
					   const char* fileName, const char* extension, const std::string& pathName) {
	mSystem = system;
	mGroup = group;

	mLoop = loop;
	mHaveReverse = makeReverse;

	char	fullPath[MAX_PATH] = {};
	const PathInfo* info = CPathManager::GetInst()->FindPath(pathName);

	if (info)
		strcpy_s(fullPath, info->pathMultibyte);
	strcat_s(fullPath, fileName);
	strcat_s(fullPath, extension);

	FMOD_MODE	mode = loop ? FMOD_LOOP_NORMAL : FMOD_DEFAULT;
	if (mSystem->createSound(fullPath, mode, nullptr, &mSound) != FMOD_OK)
		return false;

	if (makeReverse) {
		char	reversePath[MAX_PATH] = {};
		if (info)
			strcpy_s(reversePath, info->pathMultibyte);
		strcat_s(reversePath, fileName);
		strcat_s(reversePath, "_reverse");
		strcat_s(reversePath, extension);

		if (mSystem->createSound(reversePath, mode, nullptr, &mReverseSound) != FMOD_OK)
			return false;
	}

	mSound->getLength(&mLength, FMOD_TIMEUNIT_MS);

	return true;
}

void CSound::Play(bool reverse) {
	if (reverse) {
		if (mSpeed > 0 && !mChannel) {
			bool playing = false;
			mChannel->isPlaying(&playing);
			if (playing) {
				mChannel->stop();
				mChannel = nullptr;
			}
		}
		mSpeed = -1;
		mSystem->playSound(mReverseSound, mGroup, false, &mReverseChannel);
	} else {
		if (mSpeed < 0 && !mReverseChannel) {
			bool playing = false;
			mReverseChannel->isPlaying(&playing);
			if (playing) {
				mReverseChannel->stop();
				mReverseChannel = nullptr;
			}
		}
		mSpeed = 1;
		mSystem->playSound(mSound, mGroup, false, &mChannel);
	}
}

void CSound::Stop() {
	FMOD::Channel* channel = mSpeed == 0 ? (mReversePaused ? mReverseChannel : mChannel) :
											(mSpeed > 0 ? mChannel : mReverseChannel);
	if (!channel) {
		mSpeed = 0;
		return;
	}

	bool playing = false;
	channel->isPlaying(&playing);
	if (playing) {
		channel->stop();
		channel = nullptr;
	}
	mSpeed = 0;
}

void CSound::Pause() {
	if (mSpeed == 0)
		return;

	mReversePaused = mSpeed < 0;
	FMOD::Channel* channel = mReversePaused ? mReverseChannel : mChannel;
	if (channel) {
		bool playing = false;
		channel->isPlaying(&playing);
		if (playing)
			channel->setPaused(true);
	}
	mSpeed = 0;
}

void CSound::Resume() {
	if (mSpeed != 0)
		return;

	FMOD::Channel* channel = mReversePaused ? mReverseChannel : mChannel;
	if (!channel)
		return;

	mChannel->setPaused(false);
	mSpeed = mReversePaused ? -1 : 1;
}

void CSound::ChangeSpeed(int speed) {
	if (mSpeed == speed)
		return;

	if (mSpeed == 0) { // ������ ���� �ٽ� ���
		FMOD::Channel* channel = mReversePaused ? mReverseChannel : mChannel;
		if (channel) {
			if (mReversePaused == (speed < 0)) // ����鼭 ������ ����� ����� ���� ���
				Resume();
			else {								// ����鼭 ������ ����� ����� �ٸ� ���
				unsigned int pos;
				FMOD_RESULT result = channel->getPosition(&pos, FMOD_TIMEUNIT_MS);
				if (result != FMOD_OK)
					return;

				Play(speed < 0);
				channel = speed < 0 ? mReverseChannel : mChannel;
				channel->setPosition(mLength - pos, FMOD_TIMEUNIT_MS);
			}
		}

		if (mSpeed != speed) { // mSpeed �� �ٲ���� ������ �ѹ� �� �˻�
			channel->setPitch(fabs((float)speed));
			mSpeed = speed;
		}
		return;
	}
	
	if (speed == 0) {
		Pause();
		return;
	}

	// mSpeed�� speed�� ��ȣ�� �ٸ� ���ǹ����δ� ���� ���� �ʴ´�. �� �� ���� ���� �׽�Ʈ�� �ʿ���

	if (mSpeed > 0) { // ���� ��� ���� ��
		if (!mChannel) { // ������ ����ߴ�.
			Pause();
			return;
		}
		if (speed > 0) {
			mChannel->setPitch(fabs((float)speed));
			mSpeed = speed;
		} else {
			unsigned int pos = 0;
			FMOD_RESULT result = mChannel->getPosition(&pos, FMOD_TIMEUNIT_MS);
			if (result != FMOD_OK) {
				Pause();
				return;
			}

			Play(true); // ���� ������� ����ȴ�.
			mReverseChannel->setPosition(mLength - pos, FMOD_TIMEUNIT_MS);
			if (mSpeed != speed) { // mSpeed �� �ٲ���� ������ �ѹ� �� �˻�
				mReverseChannel->setPitch(fabs((float)speed));
				mSpeed = speed;
			}
		}
	} else {	// ���� ��� ���� ��
		if (!mReverseChannel) {
			Pause();
			return;
		}
		if (speed < 0) {
			mReverseChannel->setPitch(fabs((float)speed));
			mSpeed = speed;
		} else {
			unsigned int pos = 0;
			FMOD_RESULT result = mReverseChannel->getPosition(&pos, FMOD_TIMEUNIT_MS);
			if (result != FMOD_OK) {
				Pause();
				return;
			}

			Play(false); // ���� ������� ����ȴ�.
			mChannel->setPosition(mLength - pos, FMOD_TIMEUNIT_MS);
			if (mSpeed != speed) { // mSpeed �� �ٲ���� ������ �ѹ� �� �˻�
				mChannel->setPitch(fabs((float)speed));
				mSpeed = speed;
			}
		}
	}
}
