
#include "Sound.h"
#include "../../PathManager.h"

CSound::CSound() {
	SetTypeID<CSound>();
}

CSound::~CSound() {
	if (mSound) {
		mSound->release();
	}
	if (mReverseSound) {
		mReverseSound->release();
	}
}

bool CSound::LoadSound(FMOD::System* system, FMOD::ChannelGroup* group, bool loop, bool makeReverse,
					   const char* fileName, const char* extension, const std::string& pathName) {
	mSystem = system;
	mGroup = group;

	mLoop = loop;
	mHaveReverse = makeReverse;

	char	fullPath[MAX_PATH] = {};
	const PathInfo* info = CPathManager::GetInst()->FindPath(pathName);

	if (info)
		strcpy_s(fullPath, info->pathMultibyte);
	strcat_s(fullPath, fileName);
	strcat_s(fullPath, extension);

	FMOD_MODE	mode = loop ? FMOD_LOOP_NORMAL : FMOD_DEFAULT;
	if (mSystem->createSound(fullPath, mode, nullptr, &mSound) != FMOD_OK)
		return false;

	if (makeReverse) {
		char	reversePath[MAX_PATH] = {};
		if (info)
			strcpy_s(reversePath, info->pathMultibyte);
		strcat_s(reversePath, fileName);
		strcat_s(reversePath, "_reverse");
		strcat_s(reversePath, extension);

		if (mSystem->createSound(reversePath, mode, nullptr, &mReverseSound) != FMOD_OK)
			return false;
	}

	mSound->getLength(&mLength, FMOD_TIMEUNIT_MS);

	return true;
}

void CSound::Play(float volume, bool ignoreRewind) {
	if (ignoreRewind && !mLoop) {	// �������� �ʴ´�.
		FMOD::Channel* channel;
		if (FMOD_OK == mSystem->playSound(mSound, mGroup, false, &channel)) {
			channel->setVolume(volume);
			mSpeed = 1;
		}
	} else {
		PlayForward(volume);
		++mPlayCount;
	}
}

void CSound::PlayForward(float volume, int speed, unsigned int position) {
	if (mSpeed < 0) {	// ����� ���̸� �����.
		StopChannel(mReverseChannel);
	} else {
		//StopChannel(mChannel);
		if (IsPlaying(mChannel))
			if (FMOD_OK == mChannel->setPosition(position, FMOD_TIMEUNIT_MS)) {
				mSpeed = speed;
				mChannel->setVolume(volume);
				mChannel->setPitch((float)speed);
				mChannel->setPaused(false);
				return;
			}
	}

	mSpeed = speed;
	mSystem->playSound(mSound, mGroup, false, &mChannel);
	mChannel->setVolume(volume);
	if (mSpeed != 1)
		mChannel->setPitch((float)speed);
	if (position != 0)
		mChannel->setPosition(position, FMOD_TIMEUNIT_MS);
}
void CSound::PlayBackward(float volume, int speed, unsigned int position) {
	if (!mHaveReverse)
		return;
	if (mSpeed > 0) {	// ������ ��� ���̸� �����.
		StopChannel(mChannel);
	} else {
		//StopChannel(mReverseChannel);
		if (IsPlaying(mReverseChannel))
			if (FMOD_OK == mReverseChannel->setPosition(position, FMOD_TIMEUNIT_MS)) {
				mSpeed = speed;
				mReverseChannel->setVolume(volume);
				mReverseChannel->setPitch((float)-speed);
				mReverseChannel->setPaused(false);
				return;
			}
	}

	mSpeed = speed;
	mSystem->playSound(mReverseSound, mGroup, false, &mReverseChannel);
	mReverseChannel->setVolume(volume);
	if (mSpeed != -1)
		mReverseChannel->setPitch((float)-speed);
	if (position != 0)
		mReverseChannel->setPosition(position, FMOD_TIMEUNIT_MS);
}

void CSound::Stop() {
	StopChannel(mChannel);
	StopChannel(mReverseChannel);
	mSpeed = 0;
}

void CSound::Pause() {
	if (mSpeed == 0)
		return;

	mReversePaused = mSpeed < 0;
	mSpeed = 0;

	FMOD::Channel* channel = mReversePaused ? mReverseChannel : mChannel;
	if (IsPlaying(channel)) {
		channel->setPaused(true);
	} else {
		if (mReversePaused)
			mReverseChannel = nullptr;
		else
			mChannel = nullptr;
	}
}

void CSound::Resume() {
	if (mSpeed != 0)
		return;

	FMOD::Channel* channel = mReversePaused ? mReverseChannel : mChannel;
	if (IsPlaying(channel)) {
		mSpeed = mReversePaused ? -1 : 1;
		channel->setPaused(false);
		channel->setPitch(fabs((float)mSpeed));
	} else {
		if (mReversePaused)
			mReverseChannel = nullptr;
		else
			mChannel = nullptr;
	}

}

void CSound::ChangeSpeed(int speed, float volume) {
	if (mSpeed == speed)
		return;

	FMOD::Channel* channel = mReversePaused ? mReverseChannel : mChannel;
	if (mSpeed == 0) { // ������ ���� �ٽ� ���
		if (!channel)
			return;

		if (mReversePaused == (speed < 0))  // ������ ����� ����� ���� ���
			Resume();
		else {								// ������ ����� ����� �ٸ� ���
			unsigned int pos;
			FMOD_RESULT result = channel->getPosition(&pos, FMOD_TIMEUNIT_MS);
			StopChannel(channel);
			if (result != FMOD_OK)
				return;

			if (speed < 0) {
				PlayBackward(volume, -1, mLength - pos);
			} else {
				PlayForward(volume, 1, mLength - pos);
			}
		}
		return;
	}
	
	if (speed == 0) {			// �Ҹ��� �����
		Pause();
		return;
	} 
	channel = mSpeed < 0 ? mReverseChannel : mChannel;
	if (!IsPlaying(channel)) {	// ��������� ������ ä���� �����
		if (channel)
			channel->stop();
		channel = nullptr;
		mSpeed = 0;
		return;
	}

	// ���� ��� ������ ���� ��� ������ �ݴ�� ���� �÷��� �Ѵ�. ������ ��ġ�� �����Ѵ�.
	if (mSpeed > 0) {	// ���� ��� ���� ��
		if (speed < 0) {
			unsigned int pos = 0;
			FMOD_RESULT result = mChannel->getPosition(&pos, FMOD_TIMEUNIT_MS);
			float volume = 1.f;
			result = mChannel->getVolume(&volume);

			// ���� ������� ����ȴ�.
			PlayBackward(volume, speed, mLength - pos);
		} else if (mSpeed != speed) {
			mChannel->setPitch((float)speed);
			mSpeed = speed;
		}
	} else {			// ���� ��� ���� ��
		if (speed > 0) {
			unsigned int pos = 0;
			FMOD_RESULT result = mReverseChannel->getPosition(&pos, FMOD_TIMEUNIT_MS);
			float volume = 1.f;
			result = mReverseChannel->getVolume(&volume);

			// ���� ������� ����ȴ�.
			PlayForward(volume, speed, mLength - pos);
		} else if (mSpeed != speed) {
			mReverseChannel->setPitch((float)-speed);
			mSpeed = speed;
		}
	}
}