
#include "Sound.h"
#include "../../PathManager.h"

CSound::CSound() {
}

CSound::~CSound() {
	if (mSound) {
		mSound->release();
	}
}

bool CSound::LoadSound(FMOD::System* system, FMOD::ChannelGroup* group, bool loop,
					   const char* fileName, const std::string& pathName) {
	mSystem = system;
	mGroup = group;
	mLoop = loop;

	char	fullPath[MAX_PATH] = {};
	const PathInfo* info = CPathManager::GetInst()->FindPath(pathName);

	if (info)
		strcpy_s(fullPath, info->pathMultibyte);
	strcat_s(fullPath, fileName);

	FMOD_MODE	mode = FMOD_DEFAULT;
	if (loop)
		mode = FMOD_LOOP_NORMAL;

	if (mSystem->createSound(fullPath, mode, nullptr, &mSound) != FMOD_OK)
		return false;

	return true;
}

void CSound::Play() {
	mSystem->playSound(mSound, mGroup, false, &mChannel);
	mPlay = true;
	mPause = false;
}

void CSound::Stop() {
	if (!mChannel)
		return;

	bool playing = false;
	mChannel->isPlaying(&playing);

	if (playing) {
		mChannel->stop();
		mChannel = nullptr;

		mPlay = false;
		mPause = false;
	}
}

void CSound::Pause() {
	if (!mChannel)
		return;

	bool playing = false;
	mChannel->isPlaying(&playing);

	if (playing)
		mChannel->setPaused(true);

	mPlay = false;
	mPause = true;
}

void CSound::Resume() {
	if (!mChannel)
		return;
	if (!mPause)
		return;

	mChannel->setPaused(false);

	mPlay = true;
	mPause = false;
}
