#pragma once

#include "../../Ref.h"

class CSound : public CRef {
    friend class CSoundManager;

private:
    CSound();
    ~CSound();

private:
    FMOD::System*       mSystem  = nullptr;
    FMOD::Sound*        mSound   = nullptr;
    FMOD::ChannelGroup* mGroup   = nullptr;
    FMOD::Channel*      mChannel = nullptr;

    bool mPlay  = false;
    bool mLoop  = false;
    bool mPause = false;

public:
	bool GetPlay()   const {
		return mPlay;
	}
	bool GetLoop()  const {
		return mLoop;
	}

public:
    bool LoadSound(FMOD::System* system, FMOD::ChannelGroup* group, bool loop,
                    const char* fileName, const std::string& pathName = SOUND_PATH);
    void Play();
    void Stop();
    void Pause();
    void Resume();
};

