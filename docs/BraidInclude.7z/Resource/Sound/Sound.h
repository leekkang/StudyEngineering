#pragma once

#include "../../Ref.h"

class CSound : public CRef {
    friend class CSoundManager;
    friend class CSceneRewinder;

private:
    CSound();
    ~CSound();

private:
    FMOD::System*       mSystem  = nullptr;
    FMOD::ChannelGroup* mGroup   = nullptr;

    FMOD::Sound*        mSound   = nullptr;
    FMOD::Channel*      mChannel = nullptr;

    FMOD::Sound*        mReverseSound = nullptr;
    FMOD::Channel*      mReverseChannel = nullptr;

    bool mLoop = false;
    bool mHaveReverse = false;

    // ����� �� ���߸� true, �Ϲ� ��� �� ���߸� false �̴�.
    bool mReversePaused = false;
    
    int  mSpeed = 0;
    float mVolume = 1.f;
    unsigned int mLength = 0;
    unsigned int mPlayCount = 0;

public:
    bool CheckReversible() const {
        return mHaveReverse;
    }
	bool CheckLoop()  const {
		return mLoop;
	}

    float GetVolume() const {
        return mVolume;
    }
    unsigned int GetLength() const {
        return mLength;
    }
    unsigned int GetPlayCount() const {
        return mPlayCount;
    }
    void SetPlayCount(unsigned int count) {
        mPlayCount = count;
    }

    FMOD::Channel* GetChannel() const {
        return mSpeed < 0 ? mReverseChannel : mChannel;
    }

    bool CheckPlaying()   const {
        return mSpeed != 0 && IsPlaying(GetChannel());
    }

    unsigned int GetCurrentPosition() const {
        FMOD::Channel* channel = GetChannel();
        if (!channel)
            return 0;

        unsigned int ret = 0;
        FMOD_RESULT result = channel->getPosition(&ret, FMOD_TIMEUNIT_MS);
        return result == FMOD_OK ? (ret < mLength ? ret : mLength) : 0;
    }
    bool SetCurrentPosition(unsigned int pos) {
        FMOD::Channel* channel = GetChannel();
        if (!channel)
            return false;

        FMOD_RESULT result = channel->setPosition(pos, FMOD_TIMEUNIT_MS);
        return result == FMOD_OK;
    }

    // ����� ���� �� ���带 �����Ѵ�.
    void Reset() {
        if (mSpeed == 0 || mLoop)
            return;

        if (!IsPlaying(GetChannel())) {
            mSpeed = 0;
            mChannel = nullptr;
            mReverseChannel = nullptr;
        }
    }

public:
    bool LoadSound(FMOD::System* system, FMOD::ChannelGroup* group, bool loop, bool makeReverse,
                    const char* fileName, const char* extension, const std::string& pathName = SOUND_PATH);
    // �Һ� ������Ʈ�� ����� �Ҹ��� ������ ���Ѵ�.
    void Play(float volume = 1.f, bool ignoreRewind = false);
    void Stop();
    void Pause();
    void Resume();
    void ChangeSpeed(int speed, float volume = 1.f);
    void PlayForRewind(int speed, float volume = 1.f, unsigned int position = 0) {
        if (position == mLength) {
            Stop();
            return;
        }
        if (speed > 0) {
            PlayForward(volume, speed, position);
        } else if (speed < 0) {
            PlayBackward(volume, speed, position);
        }
    }

private:
    void PlayForward(float volume = 1.f, int speed = 1, unsigned int position = 0);
    void PlayBackward(float volume = 1.f, int speed = -1, unsigned int position = 0);
    bool IsPlaying(FMOD::Channel* channel) const {
        if (!channel)
            return false;
        bool playing = false;
        channel->isPlaying(&playing);
        return playing;
    }
    void StopChannel(FMOD::Channel* channel) {
        if (!channel)
            return;
        if (mLoop) {
            Pause();
            return;
        }

        bool playing = false;
        FMOD_RESULT result = channel->isPlaying(&playing);
        if (playing) {
            channel->stop();
            channel = nullptr;
        } else if (result != FMOD_OK) // channel �� INVALID �� ������ ��
            channel = nullptr;
    }
};

