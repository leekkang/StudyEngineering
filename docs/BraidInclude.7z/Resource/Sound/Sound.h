#pragma once

#include "../../Ref.h"

class CSound : public CRef {
    friend class CSoundManager;

private:
    CSound();
    ~CSound();

private:
    FMOD::System*       mSystem  = nullptr;
    FMOD::ChannelGroup* mGroup   = nullptr;

    FMOD::Sound*        mSound   = nullptr;
    FMOD::Channel*      mChannel = nullptr;

    FMOD::Sound*        mReverseSound = nullptr;
    FMOD::Channel*      mReverseChannel = nullptr;

    bool mLoop = false;
    bool mHaveReverse = false;

    // ����� �� ���߸� true, �Ϲ� ��� �� ���߸� false �̴�.
    bool mReversePaused = false;
    
    int  mSpeed = 0;
    float mVolume = 1.f;
    unsigned int mLength = 0;
    unsigned int mPlayCount = 0;

public:
    bool CheckReversible() const {
        return mHaveReverse;
    }
	bool CheckLoop()  const {
		return mLoop;
	}

    unsigned int GetPlayCount() const {
        return mPlayCount;
    }
    void SetPlayCount(unsigned int count) {
        mPlayCount = count;
    }

    int GetSpeed() const {
        return mSpeed;
    }
    FMOD::Channel* GetChannel() const {
        return mSpeed > 0 ? mChannel : mReverseChannel;
    }

    bool CheckPlaying()   const {
        if (mSpeed == 0)
            return false;
        FMOD::Channel* channel = GetChannel();
        if (!channel)
            return false;

        bool playing = false;
        channel->isPlaying(&playing);
        return playing;
    }

    unsigned int GetCurrentPosition() const {
        FMOD::Channel* channel = GetChannel();
        if (!channel)
            return 0;

        unsigned int ret = 0;
        FMOD_RESULT result = channel->getPosition(&ret, FMOD_TIMEUNIT_MS);
        return result == FMOD_OK ? ret : 0;
    }
    bool SetCurrentPosition(unsigned int pos) {
        FMOD::Channel* channel = GetChannel();
        if (channel)
            return false;

        FMOD_RESULT result = channel->setPosition(pos, FMOD_TIMEUNIT_MS);
        return result == FMOD_OK;
    }

    // ����� ���� �� ���带 �����Ѵ�.
    void Reset() {
        if (mSpeed == 0 || mLoop)
            return;

        FMOD::Channel* channel = GetChannel();
        if (channel) {
            bool playing = false;
            channel->isPlaying(&playing);
            if (!playing) { 
                mSpeed = 0;
                mChannel = nullptr;
                mReverseChannel = nullptr;
            }
        }
    }

public:
    bool LoadSound(FMOD::System* system, FMOD::ChannelGroup* group, bool loop, bool makeReverse,
                    const char* fileName, const char* extension, const std::string& pathName = SOUND_PATH);
    void Play(bool reverse = false);
    void Stop();
    void Pause();
    void Resume();
    void ChangeSpeed(int speed);
};

