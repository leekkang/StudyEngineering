#pragma once

#include "DefaultStageWindow.h"

class CStageHuntWindow : public CDefaultStageWindow {
    friend class CScene;

protected:
    CStageHuntWindow();
    virtual ~CStageHuntWindow();
    DISALLOW_COPY_AND_ASSIGN(CStageHuntWindow)

private:
    class CText* mText = nullptr;
    class CTexture* mCount = nullptr;

public:
    virtual bool Init();
    virtual void Update(float deltaTime);
    virtual void Render(HDC hdc, float deltaTime);
};