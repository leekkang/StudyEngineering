#pragma once

#include "DefaultStageWindow.h"

class CBossStageWindow : public CDefaultStageWindow {
    friend class CScene;

protected:
    CBossStageWindow();
    virtual ~CBossStageWindow();
    DISALLOW_COPY_AND_ASSIGN(CBossStageWindow)

private:
    bool mRenderHP = false;
    class CText* mText = nullptr;
    class CTexture* mHP = nullptr;

public:
    void SetRenderHP(bool render) {
        mRenderHP = render;
    }

public:
    virtual bool Init();
    virtual void Update(float deltaTime);
    virtual void Render(HDC hdc, float deltaTime);
};

