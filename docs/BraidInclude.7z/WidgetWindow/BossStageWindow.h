#pragma once

#include "WidgetWindow.h"

class CBossStageWindow : public CWidgetWindow {
    friend class CScene;

protected:
    CBossStageWindow();
    virtual ~CBossStageWindow();
    DISALLOW_COPY_AND_ASSIGN(CBossStageWindow)

private:
    class CText* mText = nullptr;
    class CTexture* mHP = nullptr;

public:
    virtual bool Init();
    virtual void Update(float deltaTime);
    virtual void Render(HDC hdc, float deltaTime);
};

