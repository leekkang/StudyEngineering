
#include "StageHuntWindow.h"

#include "../GameManager.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneManager.h"
#include "../Scene/SceneResource.h"

#include "../Scene/StageHunt.h"
#include "../GameObject/Monstar.h"

#include "../Widget/AlphaImage.h"
#include "../Widget/Text.h"


CStageHuntWindow::CStageHuntWindow() {
	SetTypeID<CStageHuntWindow>();
}

CStageHuntWindow::~CStageHuntWindow() {
}

bool CStageHuntWindow::Init() {
	if (!CDefaultStageWindow::Init())
		return false;

	Resolution rs = CGameManager::GetInst()->GetResolution();
	SetSize((float)rs.width, (float)rs.height);

	// 1600 / 2 - 30 = 770
	mScene->GetResource()->LoadTexture("HuntWidget", {TEXT("Widget/hunt.bmp"), TEXT("Widget/huntX.bmp")});
	mCount = mScene->GetResource()->FindTexture("HuntWidget");
	mCount->SetColorKeyAll(255, 0, 255);
	mCount->InitAlphaBlend();

	mText = CreateWidget<CText>("HuntText");
	mText->SetFont("StageWindowFont");
	mText->SetPos(480.f, 20.f);
	mText->SetText(TEXT("���!"));
	mText->SetTextColor(250, 250, 250);

	return true;
}

void CStageHuntWindow::Update(float deltaTime) {
	CDefaultStageWindow::Update(deltaTime);

}

void CStageHuntWindow::Render(HDC hdc, float deltaTime) {
	CDefaultStageWindow::Render(hdc, deltaTime);

	int count = ((CStageHunt*)mScene)->GetStageMonstarCount();
	for (int i = 0; i < 6; ++i) {
		mCount->Render(hdc, 620 + i * 65, 30, i < count ? 0 : 1, 200);
	}
}
