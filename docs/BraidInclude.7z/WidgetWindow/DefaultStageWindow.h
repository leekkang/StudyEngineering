#pragma once

#include "WidgetWindow.h"

class CDefaultStageWindow : public CWidgetWindow {
    friend class CScene;

protected:
    CDefaultStageWindow();
    virtual ~CDefaultStageWindow();
    DISALLOW_COPY_AND_ASSIGN(CDefaultStageWindow)

protected:
    UINT8 mStageImageAlphaValue = 0;
    float mStageImageAlphaTime = 1.2f;

    class CText* mStageText = nullptr;
    class CTexture* mStageTexture = nullptr;

public:
    void SetStageText(const TCHAR* stageName, float xPos);
    void SetStageTexture(const char* textureName);

public:
    virtual bool Init();
    virtual void Update(float deltaTime);
    virtual void Render(HDC hdc, float deltaTime);
};

