
#include "DefaultStageWindow.h"

#include "../GameManager.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneManager.h"
#include "../Scene/SceneResource.h"

#include "../Widget/AlphaImage.h"
#include "../Widget/Text.h"


CDefaultStageWindow::CDefaultStageWindow() {
	SetTypeID<CDefaultStageWindow>();
}
CDefaultStageWindow::~CDefaultStageWindow() {
}


void CDefaultStageWindow::SetStageText(const TCHAR* stageName, float xPos) {
	mStageText->SetText(stageName);
	mStageText->SetPos(xPos, 560.f);
}

void CDefaultStageWindow::SetStageTexture(const char* textureName) {
	mStageTexture = mScene->GetResource()->FindTexture(textureName);
	mStageTexture->SetColorKeyAll(255, 0, 255);
	mStageTexture->InitAlphaBlend();
}


bool CDefaultStageWindow::Init() {
	if (!CWidgetWindow::Init())
		return false;

	Resolution rs = CGameManager::GetInst()->GetResolution();
	SetSize((float)rs.width, (float)rs.height);

	mStageText = CreateWidget<CText>("StageText");
	mStageText->SetFont("StageTextFont");
	mStageText->SetTextColor(255, 255, 255);
	mStageText->EnableShadow(true);
	mStageText->SetShadowOffset(3.f, 3.f);

	return true;
}

void CDefaultStageWindow::Update(float deltaTime) {
	CWidgetWindow::Update(deltaTime);
	mStageImageAlphaTime -= deltaTime;
	if (mStageImageAlphaTime < .5f) {
		mStageText->SetEnable(false);
	}
}

void CDefaultStageWindow::Render(HDC hdc, float deltaTime) {
	CWidgetWindow::Render(hdc, deltaTime);

	if (mStageImageAlphaTime > .5f) {
		mStageTexture->Render(hdc, (int)((mSize.x - mStageTexture->GetWidth()) * .5f),
									(int)((mSize.y - mStageTexture->GetHeight()) * .5f - 50.f), 0, 255);
	} else if (mStageImageAlphaTime > 0.f) {
		mStageImageAlphaValue = (UINT8)(mStageImageAlphaTime * .5f * 255);
		mStageTexture->Render(hdc, (int)((mSize.x - mStageTexture->GetWidth()) * .5f), 
									(int)((mSize.y - mStageTexture->GetHeight()) * .5f - 50.f), 0, mStageImageAlphaValue);
	}
}
