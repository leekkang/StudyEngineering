#pragma once

#include "WidgetWindow.h"

class CCharacterHUD : public CWidgetWindow {
	friend class CScene;

protected:
	CCharacterHUD();
	virtual ~CCharacterHUD();
	DISALLOW_COPY_AND_ASSIGN(CCharacterHUD)

protected:
	CSharedPtr<class CProgressBar>  mHPBar;
	CSharedPtr<class CImageWidget>  mHPBarFrame;

public:
	void SetHP(float hp);

public:
	virtual bool Init();
};

