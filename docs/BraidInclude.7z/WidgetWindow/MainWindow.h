#pragma once

#include "WidgetWindow.h"

class CMainWindow : public CWidgetWindow {
    friend class CScene;

protected:
    CMainWindow();
    virtual ~CMainWindow();
    DISALLOW_COPY_AND_ASSIGN(CMainWindow)

private:
    CSharedPtr<class CNumber> mHour;
    CSharedPtr<class CNumber> mMinute;
    CSharedPtr<class CNumber> mSecond;
    class CImageWidget* mColon[2]{nullptr, };
    class CButton* mEditButton = nullptr;

public:
    virtual bool Init();
    virtual void Update(float deltaTime);

public:
    void StartButtonCallback();
    void EndButtonCallback();
};

