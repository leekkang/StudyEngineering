#pragma once

#include "WidgetWindow.h"

class CMainWindow : public CWidgetWindow {
    friend class CScene;

protected:
    CMainWindow();
    virtual ~CMainWindow();
    DISALLOW_COPY_AND_ASSIGN(CMainWindow)

private:
    bool mMainScene = false;
    bool mMenuOpen = false;
    int mIndex = 0;

    class CButton* mEditButton = nullptr;

private:
    void SetInput();

public:
    virtual bool Init();
    virtual void Update(float deltaTime);
    virtual void Render(HDC hdc, float deltaTime);

};

