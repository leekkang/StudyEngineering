#pragma once

#include "../Ref.h"
#include "../Widget/Widget.h"

class CWidgetWindow : public CRef {
	friend class CScene;

protected:
	CWidgetWindow();
	virtual ~CWidgetWindow();
	DISALLOW_COPY_AND_ASSIGN(CWidgetWindow)

protected:
	class CScene* mScene	= nullptr;
	int           mZOrder	= 0;

	Vector2		  mPos;
	Vector2		  mSize;

	std::vector<CSharedPtr<class CWidget>>  mVecWidget;

public:
	class CWidget* GetWidget(int Index) {
		return mVecWidget[Index];
	}

	int GetWidgetCount()    const {
		return (int)mVecWidget.size();
	}

	const Vector2& GetPos()	const {
		return mPos;
	}

	const Vector2& GetSize()	const {
		return mSize;
	}

	int GetZOrder()	const {
		return mZOrder;
	}

public:
	void SetPos(float x, float y) {
		mPos.x = x;
		mPos.y = y;
	}
	void SetPos(const Vector2& pos) {
		mPos = pos;
	}

	void SetSize(float x, float y) {
		mSize.x = x;
		mSize.y = y;
	}
	void SetSize(const Vector2& size) {
		mSize = size;
	}

	void SetZOrder(int order) {
		mZOrder = order;
	}

public:
	virtual bool Init();
	virtual void Update(float deltaTime);
	virtual void PostUpdate(float deltaTime);
	virtual void Render(HDC hdc, float deltaTime);

public:
	void SortCollision();
	bool CollisionMouse(class CWidget** widget, const Vector2& pos);

public:
	template <typename T>
	T* FindWidget(const std::string& name) {
		size_t  size = mVecWidget.size();
		for (size_t i = 0; i < size; ++i) {
			if (mVecWidget[i]->GetName() == name)
				return (T*)mVecWidget[i];
		}

		return nullptr;
	}

	template <typename T>
	T* CreateWidget(const std::string& name) {
		T* widget = new T;
		widget->SetName(name);
		widget->mScene = mScene;
		widget->mOwner = this;

		if (!widget->Init()) {
			SAFE_DELETE(widget);
			return nullptr;
		}

		mVecWidget.push_back(widget);
		return (T*)widget;
	}

private:
	static bool SortCollisionWidget(const CSharedPtr<class CWidget>& src, const CSharedPtr<class CWidget>& dest);
	static bool SortWidget(const CSharedPtr<CWidget>& src, const CSharedPtr<CWidget>& dest);
};

