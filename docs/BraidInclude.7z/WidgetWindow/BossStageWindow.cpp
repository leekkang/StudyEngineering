
#include "BossStageWindow.h"

#include "../GameManager.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneManager.h"
#include "../Scene/SceneResource.h"

#include "../Scene/StageBoss.h"
#include "../GameObject/Boss.h"

#include "../Widget/AlphaImage.h"
#include "../Widget/Text.h"


CBossStageWindow::CBossStageWindow() {
	SetTypeID<CBossStageWindow>();
}

CBossStageWindow::~CBossStageWindow() {
}

bool CBossStageWindow::Init() {
	if (!CDefaultStageWindow::Init())
		return false;

	Resolution rs = CGameManager::GetInst()->GetResolution();
	SetSize((float)rs.width, (float)rs.height);

	// 1600 / 2 - 30 = 770
	mScene->GetResource()->LoadTexture("BossHPWidget", {TEXT("Widget/bossHP.bmp"), TEXT("Widget/bossHPX.bmp")});
	mHP = mScene->GetResource()->FindTexture("BossHPWidget");
	mHP->SetColorKeyAll(255, 0, 255);
	mHP->InitAlphaBlend();

	mText = CreateWidget<CText>("BossStageText");
	mText->SetFont("BossStageFont");
	mText->SetPos(570.f, 20.f);
	mText->SetText(TEXT("���� :"));
	mText->SetTextColor(230, 230, 230);

	return true;
}

void CBossStageWindow::Update(float deltaTime) {
	CDefaultStageWindow::Update(deltaTime);
	mText->SetEnable(mRenderHP);

}

void CBossStageWindow::Render(HDC hdc, float deltaTime) {
	CDefaultStageWindow::Render(hdc, deltaTime);
	if (!mRenderHP)
		return;

	int hp = ((CStageBoss*)mScene)->GetBoss()->GetHP();
	for (int i = 0; i < 5; ++i) {
		mHP->Render(hdc, 700 + i * 60, 30, i < hp ? 0 : 1, 200);
	}
}
