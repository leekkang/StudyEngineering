
#include "BossStageWindow.h"

#include "../GameManager.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneManager.h"
#include "../Scene/SceneResource.h"

#include "../Scene/StageBoss.h"
#include "../GameObject/Boss.h"

#include "../Widget/AlphaImage.h"
#include "../Widget/Text.h"


CBossStageWindow::CBossStageWindow() {
	SetTypeID<CBossStageWindow>();
}

CBossStageWindow::~CBossStageWindow() {
}

bool CBossStageWindow::Init() {
	if (!CWidgetWindow::Init())
		return false;

	Resolution rs = CGameManager::GetInst()->GetResolution();
	SetSize((float)rs.width, (float)rs.height);

	// 1600 / 2 - 30 = 770
	for (int i = 0; i < 5; ++i) {
		mHP[i] = CreateWidget<CAlphaImage>("BossHPWidget");
		mHP[i]->SetTexture("BossHPWidget", {TEXT("Widget/bossHP.bmp"), TEXT("Widget/bossHPX.bmp")});
		mHP[i]->SetColorKey(255, 0, 255);
		mHP[i]->SetAlphaValue(200);
		mHP[i]->SetPos(20.f, 570.f + i *100.f);
		mHP[i]->GetTexture()->InitAlphaBlend();
	}

	mText = CreateWidget<CText>("BossStageText");
	mText->SetFont("BossStageFont");
	mText->SetText(TEXT("���� :"));
	mText->SetTextColor(255, 255, 255);

	return true;
}

void CBossStageWindow::Update(float deltaTime) {
	CWidgetWindow::Update(deltaTime);
}

void CBossStageWindow::Render(HDC hdc, float deltaTime) {
	mText->Render(hdc, deltaTime);
	int hp = ((CStageBoss*)mScene)->GetBoss()->GetHP();
	for (int i = 0; i < 5; ++i) {
		mHP[i]->Render(hdc, mHP[i]->GetPos(), deltaTime, i < hp ? 0 : 1);
	}
}
