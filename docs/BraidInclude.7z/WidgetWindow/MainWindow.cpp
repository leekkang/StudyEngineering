

#include "MainWindow.h"

#include "../GameManager.h"
#include "../Input.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneManager.h"
#include "../Scene/SceneResource.h"

#include "../Scene/MainScene.h"
#include "../Scene/EditScene.h"

#include "../Widget/Button.h"
#include "../Widget/ImageWidget.h"
#include "../Widget/DraggedIcon.h"
#include "../Widget/Text.h"
#include "../Widget/Number.h"


CMainWindow::CMainWindow() {
	SetTypeID<CMainWindow>();
}

CMainWindow::~CMainWindow() {
}

bool CMainWindow::Init() {
	if (!CWidgetWindow::Init())
		return false;

	//mScene->GetResource()->LoadSound(ESound_Group::UI, "ButtonHovered", false, "player_lands1.wav");
	mScene->GetResource()->LoadSound(ESound_Group::UI, "MenuEscape", false, "menu_escape.wav");

	SetSize(1600.f, 900.f);

	//CImageWidget* back = CreateWidget<CImageWidget>("Back");
	//back->SetTexture("StartBack", TEXT("GameBack.bmp"));
	//back->SetSize(1280.f, 720.f);


	CButton* startButton = CreateWidget<CButton>("Stage2-1");
	//std::vector<std::wstring> vec{L"2-1.bmp", L"2-1.bmp", L"2-2.bmp", L"2-2.bmp"};
	startButton->SetTexture("Stage2-1", {L"2-1.bmp", L"2-1.bmp", L"2-2.bmp", L"2-2.bmp"});
	startButton->SetColorKeyAll(255, 0, 255);
	startButton->SetPos(50.f, 50.f);
	startButton->SetButtonStateDataAll(Vector2(0.f, 0.f), Vector2(324.f, 316.f));

	//startButton->SetSound(EButton_Sound_State::MouseHovered, "ButtonHovered");
	startButton->SetSound(EButton_Sound_State::Click, "MenuEscape");

	startButton->SetCallback<CMainWindow>(
		EButton_Sound_State::Click, this, &CMainWindow::StartButtonCallback);
	startButton->SetZOrder(1);
	startButton->SetEnable(false);

	CDraggedIcon* icon = CreateWidget<CDraggedIcon>("Stage2-1");
	icon->SetTexture("Icon2-1", TEXT("2-1.bmp"));
	icon->SetColorKey(255, 0, 255);
	icon->SetPos(50.f, 50.f);
	icon->SetSound(EButton_Sound_State::Click, "MenuEscape");
	//icon->SetSound(EButton_Sound_State::MouseHovered, "ButtonHovered");
	icon->SetCallback<CDraggedIcon>(EButton_Sound_State::Click, icon, &CDraggedIcon::StartDragCallback);
	icon->SetCallback<CDraggedIcon>(EButton_Sound_State::MouseHovered, icon, &CDraggedIcon::EndDragCallback);
	icon->SetEnable(false);


	mEditButton = CreateWidget<CButton>("Stage2-2");
	mEditButton->SetPos(1280.f, 570.f);

	mEditButton->SetTexture("Stage2-2", TEXT("2-2.bmp"));
	mEditButton->SetColorKey(255, 0, 255);
	mEditButton->SetButtonStateDataAll(Vector2(0.f, 0.f), Vector2(324.f, 316.f));

	mEditButton->SetSound(EButton_Sound_State::Click, "MenuEscape");
	mEditButton->SetCallback(EButton_Sound_State::Click, [&]() {
		CSceneManager::GetInst()->CreateScene<CEditScene>();
							 });
	mEditButton->SetZOrder(1);


	mHour = CreateWidget<CNumber>("Hour");
	mMinute = CreateWidget<CNumber>("Minute");
	mSecond = CreateWidget<CNumber>("Second");

	mColon[0] = CreateWidget<CImageWidget>("Colon");
	mColon[0]->SetTexture("Colon", TEXT("Number/Colon.bmp"));
	mColon[0]->SetColorKey(255, 255, 255);
	mColon[0]->SetPos(1416.f, 10.f);

	mColon[1] = CreateWidget<CImageWidget>("Colon");
	mColon[1]->SetTexture("Colon", TEXT("Number/Colon.bmp"));
	mColon[1]->SetColorKey(255, 255, 255);
	mColon[1]->SetPos(1503.f, 10.f);

	std::vector<const TCHAR*>	vecFileName;
	for (int i = 0; i < 10; ++i) {
		TCHAR* fileName = new TCHAR[MAX_PATH]{};
		wsprintf(fileName, TEXT("Number/%d.bmp"), i);
		vecFileName.push_back(fileName);
	}

	mHour->SetTexture("Number", vecFileName);
	mHour->SetColorKeyAll(255, 255, 255);
	mMinute->SetTexture("Number", vecFileName);
	mMinute->SetColorKeyAll(255, 255, 255);
	mSecond->SetTexture("Number", vecFileName);
	mSecond->SetColorKeyAll(255, 255, 255);

	for (int i = 0; i < 10; ++i)
		delete[] vecFileName[i];
	
	mHour->SetPos(1358.f, 10.f);
	mMinute->SetPos(1445.f, 10.f);
	mSecond->SetPos(1532.f, 10.f);


	return true;
}

void CMainWindow::Update(float deltaTime) {
	CWidgetWindow::Update(deltaTime);

	SYSTEMTIME	Time;

	GetLocalTime(&Time);

	mHour->SetNumber(Time.wHour);
	mMinute->SetNumber(Time.wMinute);
	mSecond->SetNumber(Time.wSecond);

#ifdef _DEBUG
	mEditButton->SetEnable(gDebugMode);

	mHour->SetEnable(gDebugMode);
	mMinute->SetEnable(gDebugMode);
	mSecond->SetEnable(gDebugMode);
	mColon[0]->SetEnable(gDebugMode);
	mColon[1]->SetEnable(gDebugMode);
#endif
}

void CMainWindow::StartButtonCallback() {
	//CInput::GetInst()->ClearCallback();
	//CSceneManager::GetInst()->CreateScene<CMainScene>();
}

void CMainWindow::EndButtonCallback() {
	CSceneManager::GetInst()->CreateScene<CEditScene>();
	//CGameManager::GetInst()->Exit();
}
