

#include "MainWindow.h"

#include "../GameManager.h"
#include "../Input.h"

#include "../Scene/Scene.h"
#include "../Scene/SceneManager.h"
#include "../Scene/SceneResource.h"

#include "../Scene/MainScene.h"
#include "../Scene/EditScene.h"

#include "../Widget/Button.h"
#include "../Widget/ImageWidget.h"
#include "../Widget/DraggedIcon.h"
#include "../Widget/Text.h"
#include "../Widget/Number.h"


CMainWindow::CMainWindow() {
	SetTypeID<CMainWindow>();
}

CMainWindow::~CMainWindow() {
}

void CMainWindow::SetInput() {
	CInput::GetInst()->AddBindFunction("Space", Input_Type::Down, mScene, [&]() {
		if (!mMenuOpen)
			return;

		mMenuOpen = false;
		if (!mMainScene) {
			if (mIndex == 0) {
				CSceneManager::GetInst()->StartChangeScene([&]() {
					CSceneManager::GetInst()->CreateScene<CMainScene>();
														   }, true);
			} else {
				CGameManager::GetInst()->Exit();
			}
		} else {
#ifdef _DEBUG
			if (mIndex == 0) {
				CSceneManager::GetInst()->CreateScene<CEditScene>();
			} else {
				CGameManager::GetInst()->Exit();
			}
#else
			CGameManager::GetInst()->Exit();
#endif
		}

		mScene->GetResource()->SoundPlay("MenuEnter", 100, true);
									   });
	CInput::GetInst()->AddBindFunction("Escape", Input_Type::Down, mScene, [&]() {
		mMenuOpen = !mMenuOpen;
		mScene->SetMenuOpen(mMenuOpen);
		if (mMenuOpen) {
			mIndex = 0;
			mScene->StopAllObject();
		} else {
			mScene->RestartScene();
		}

		mVecWidget[0]->SetEnable(mMenuOpen);
		mVecWidget[1]->SetEnable(mMenuOpen && !mMainScene);
#ifdef _DEBUG
		mVecWidget[2]->SetEnable(mMenuOpen && mMainScene);
#endif
		if (!mMainScene) {
			((CText*)*mVecWidget[0])->EnableShadow(false);
			((CText*)*mVecWidget[1])->EnableShadow(true);
		} else {
#ifdef _DEBUG
			((CText*)*mVecWidget[0])->EnableShadow(false);
			((CText*)*mVecWidget[2])->EnableShadow(true);
#else
			((CText*)*mVecWidget[0])->EnableShadow(true);
#endif
		}
		mScene->GetResource()->SoundPlay("MenuEscape", 100, true);
									   });
	CInput::GetInst()->AddBindFunction("ArrowUp", Input_Type::Down, mScene, [&]() {
		if (mIndex == 0)
			return;

		mIndex = 0;
		if (!mMainScene) {
			((CText*)*mVecWidget[0])->EnableShadow(false);
			((CText*)*mVecWidget[1])->EnableShadow(true);
		} else {
#ifdef _DEBUG
			((CText*)*mVecWidget[0])->EnableShadow(false);
			((CText*)*mVecWidget[2])->EnableShadow(true);
#else
			((CText*)*mVecWidget[0])->EnableShadow(true);
#endif
		}
		mScene->GetResource()->SoundPlay("MenuUp", 100, true);
									   });
	CInput::GetInst()->AddBindFunction("ArrowDown", Input_Type::Down, mScene, [&]() {
		if (!mMainScene) {
			mIndex = 1;
			((CText*)*mVecWidget[0])->EnableShadow(true);
			((CText*)*mVecWidget[1])->EnableShadow(false);
		} else {
#ifdef _DEBUG
			mIndex = 1;
			((CText*)*mVecWidget[0])->EnableShadow(true);
			((CText*)*mVecWidget[2])->EnableShadow(false);
#else
			((CText*)*mVecWidget[0])->EnableShadow(true);
#endif
		}
		mScene->GetResource()->SoundPlay("MenuDown", 100, true);
									   });
}

bool CMainWindow::Init() {
	if (!CWidgetWindow::Init())
		return false;

	Resolution rs = CGameManager::GetInst()->GetResolution();
	SetSize((float)rs.width, (float)rs.height);

	mScene->GetResource()->LoadSound(ESound_Group::UI, "MenuEnter", false, false, "UI/menu_enter", ".wav");
	mScene->GetResource()->LoadSound(ESound_Group::UI, "MenuEscape", false, false, "UI/menu_escape", ".wav");
	mScene->GetResource()->LoadSound(ESound_Group::UI, "MenuUp", false, false, "UI/menu_up", ".wav");
	mScene->GetResource()->LoadSound(ESound_Group::UI, "MenuDown", false, false, "UI/menu_down", ".wav");

	mMainScene = dynamic_cast<CMainScene*>(mScene);

	CText* text = CreateWidget<CText>("MenuText");
	text->SetFont("MenuFont");
	text->SetPos(620.f, 400.f);
	text->SetText(TEXT("���� �����ϱ�"));
	text->SetTextColor(250, 250, 250);
	text->EnableShadow(false);
	text->SetShadowOffset(4.f, 4.f);
	text->SetTextShadowColor(0, 0, 0);
	text->SetEnable(false);

	text = CreateWidget<CText>("MenuText");
	text->SetFont("MenuFont");
	text->SetPos(585.f, 200.f);
	text->SetText(TEXT("�������� ������"));
	text->SetTextColor(250, 250, 250);
	text->EnableShadow(true);
	text->SetShadowOffset(4.f, 4.f);
	text->SetTextShadowColor(0, 0, 0);
	text->SetEnable(false);

#ifdef _DEBUG
	text = CreateWidget<CText>("MenuText");
	text->SetFont("MenuFont");
	text->SetPos(605.f, 200.f);
	text->SetText(TEXT("�� ������ ����"));
	text->SetTextColor(250, 250, 250);
	text->EnableShadow(false);
	text->SetShadowOffset(4.f, 4.f);
	text->SetTextShadowColor(0, 0, 0);
	text->SetEnable(false);
#endif

	SetInput();

	return true;
}

void CMainWindow::Update(float deltaTime) {
	CWidgetWindow::Update(deltaTime);

}

void CMainWindow::Render(HDC hdc, float deltaTime) {
	CWidgetWindow::Render(hdc, deltaTime);
}
