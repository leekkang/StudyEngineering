#pragma once

#include <math.h>

const float	PI = 3.14159f;

struct Vector2 {
	float	x, y;

	Vector2() :
		x(0.f),
		y(0.f) {
	}
	Vector2(float _x, float _y) :
		x(_x),
		y(_y) {
	}
	Vector2(const Vector2& v) :
		x(v.x),
		y(v.y) {
	}

	void operator = (const Vector2& v) {
		x = v.x;
		y = v.y;
	}
	void operator = (float f) {
		x = f;
		y = f;
	}

	bool operator == (const Vector2& v)	const {
		return x == v.x && y == v.y;
	}
	bool operator != (const Vector2& v)	const {
		return x != v.x || y != v.y;
	}

	// +
	Vector2 operator + (const Vector2& v)	const {
		Vector2	result;

		result.x = x + v.x;
		result.y = y + v.y;

		return result;
	}
	Vector2 operator + (float f)	const {
		Vector2	result;

		result.x = x + f;
		result.y = y + f;

		return result;
	}
	Vector2 operator + (int i)	const {
		Vector2	result;

		result.x = x + (float)i;
		result.y = y + (float)i;

		return result;
	}

	// +=
	void operator += (const Vector2& v) {
		x += v.x;
		y += v.y;
	}
	void operator += (float f) {
		x += f;
		y += f;
	}
	void operator += (int i) {
		x += (float)i;
		y += (float)i;
	}

	// -
	Vector2 operator - () const {
		return {-x, -y};
	}
	Vector2 operator - (const Vector2& v)	const {
		Vector2	result;

		result.x = x - v.x;
		result.y = y - v.y;

		return result;
	}
	Vector2 operator - (float f)	const {
		Vector2	result;

		result.x = x - f;
		result.y = y - f;

		return result;
	}
	Vector2 operator - (int i)	const {
		Vector2	result;

		result.x = x - (float)i;
		result.y = y - (float)i;

		return result;
	}

	// -=
	void operator -= (const Vector2& v) {
		x -= v.x;
		y -= v.y;
	}
	void operator -= (float f) {
		x -= f;
		y -= f;
	}
	void operator -= (int i) {
		x -= (float)i;
		y -= (float)i;
	}

	// *
	Vector2 operator * (const Vector2& v)	const {
		Vector2	result;

		result.x = x * v.x;
		result.y = y * v.y;

		return result;
	}
	Vector2 operator * (float f)	const {
		Vector2	result;

		result.x = x * f;
		result.y = y * f;

		return result;
	}
	Vector2 operator * (int i)	const {
		Vector2	result;

		result.x = x * (float)i;
		result.y = y * (float)i;

		return result;
	}

	// *=
	void operator *= (const Vector2& v) {
		x *= v.x;
		y *= v.y;
	}
	void operator *= (float f) {
		x *= f;
		y *= f;
	}
	void operator *= (int i) {
		x *= (float)i;
		y *= (float)i;
	}

	//
	Vector2 operator / (const Vector2& v)	const {
		Vector2	result;

		result.x = x / v.x;
		result.y = y / v.y;

		return result;
	}
	Vector2 operator / (float f)	const {
		Vector2	result;

		result.x = x / f;
		result.y = y / f;

		return result;
	}
	Vector2 operator / (int i)	const {
		Vector2	result;

		result.x = x / (float)i;
		result.y = y / (float)i;

		return result;
	}

	// /=
	void operator /= (const Vector2& v) {
		x /= v.x;
		y /= v.y;
	}
	void operator /= (float f) {
		x /= f;
		y /= f;
	}
	void operator /= (int i) {
		x /= (float)i;
		y /= (float)i;
	}

	float Angle(const Vector2& v)	const {
		float width = v.x - x;
		float height = v.y - y;

		// sqrtf : ��Ʈ
		float c = sqrtf(width * width + height * height);

		float Angle = width / c;

		Angle = acosf(Angle) / PI * 180.f;

		if (v.y < y)
			Angle = 360.f - Angle;

		return Angle;
	}

	float Length() const {
		return sqrtf(x * x + y * y);
	}

	float Distance(const Vector2& v) const {
		float width = x - v.x;
		float height = y - v.y;
		return sqrtf(width * width + height * height);
	}
	float DistanceSquare(const Vector2& v) const {
		float width = x - v.x;
		float height = y - v.y;
		return width * width + height * height;
	}

	// ����
	float Dot(const Vector2& v) const {
		return x * v.x - y * v.y;
	}

	// 2���� ����
	float Cross(const Vector2& v) const {
		return x * v.y - y * v.x;
	}
};
