#pragma once

#include "GameInfo.h"

class CRef {
public:
	CRef();
	virtual ~CRef();
	CRef(const CRef& ref);

	CRef(std::string name);

protected:
	size_t		mTypeID		 = 0;
	int			mRefCount	 = 0;
	bool		mActive		 = true;	// ��� �ִ��� �׾�����
	bool		mEnable		 = true;	// Ȱ��, ��Ȱ��

	std::string	mName;
	std::string	mTypeName;

public:
	void AddRef();
	int Release();


public:
	size_t GetTypeID()	const {
		return mTypeID;
	}
	int GetRefCount()	const {
		return mRefCount;
	}
	bool GetActive()	const {
		return mActive;
	}
	bool GetEnable()	const {
		return mEnable;
	}


	const std::string& GetName()	 const {
		return mName;
	}
	const std::string& GetTypeName() const {
		return mTypeName;
	}

	void SetName(const std::string& name) {
		mName = name;
	}
	void SetActive(bool active) {
		mActive = active;
	}
	void SetEnable(bool enable) {
		mEnable = enable;
	}

	template <typename T>
	bool CheckTypeID()	const {
		return mTypeID == typeid(T).hash_code();
	}

public:
	template <typename T>
	void SetTypeID() {
		// Ÿ�� �̸��� ���ڿ��� ���´�.
		mTypeName = typeid(T).name();

		// Ÿ���� ������ ��ȣ�� ���´�.
		mTypeID = typeid(T).hash_code();
	}

public:
	virtual void Save(FILE* file);
	virtual void Load(FILE* file);
};

